﻿
using System;
using System.Collections;
using System.IO;
using CIConfigGlobalParameters;
using NBiis;
using NBiis.Generic;

namespace CIFicheiro
{


    public abstract class Ficheiro 
    {
        public CIConfigGP.CIGlobalParameters m_oParameters;
        public CIComumInterface m_iInterface;
        public string m_sLinha;
        public int m_iCounter ;
        
        public string m_sFichID;
        public string m_sLoteID;
        public string m_sDocID;


        public abstract bool validaHeaderFich();
        public abstract void insertHeaderFich();
        public abstract bool validaHeaderLote();
        public abstract void insertHeaderLote();
        public abstract bool validaDetalhe();
        public abstract void insertDetalhe();
        public abstract bool validaTrailerLote();
        public abstract void insertTrailerLote();
        public abstract bool validaTrailerFich();
        public abstract void insertTrailerFich();
        //public abstract void LastOperations();


        public bool m_bIsRunning;
        public string m_sFileName;
        public string m_sPrefixo;
        public string m_sHDT;
        ////LinhaFicheiro m_oLinhaFicheiro;
        //public string m_sFICH;
        //public string m_sBANCO;
        //public string m_sNSEQFICH;
        //public string m_sDTFICH;
        //public DateTime m_dtDTFICH;
        //public string m_sFICH_ID;
        public int m_iCountDetalhesLote; //Inicializado no HL incrementado em cada detalhe e comparado com TOTREG do TL
        public decimal m_dAcumDetalhesLote; //Inicializado no HL acumulado em cada detalhe comparado com MONTTOTAL do TL

        public int m_iCountTotRegLotes; //Inicializado no HF acumulado com TOTREG de cada TL e comparado com TOTREGFIS do TF
        public decimal m_dAcumMontTotalLotes; //Inicializado no HF acumulado com MONTOTAL de cada TL e comparado com MONTTOTFIS do TF

        public Ficheiro(CIComumInterface iInterface, CIConfigGP.CIGlobalParameters oParameters)
        {
            m_oParameters = oParameters;
            m_iInterface = iInterface;

            m_sLinha = "";
            
           
            
        }

        public bool processaFile(string sFileName, string sPrefixo)
        {

            m_sPrefixo = sPrefixo;
            StreamReader sr = null;
            m_sFileName = sFileName;

            if (!initImportFile())
            {
                return false;
            }

            try
            {
                sr = new StreamReader(m_sFileName, System.Text.Encoding.ASCII);

                while ((m_sLinha = sr.ReadLine()) != null && m_bIsRunning)
                {

                    if ((m_iCounter++ % 10) == 0)
                    {
                        m_iInterface.InfoMessageCount(m_iCounter.ToString());
                    }

                    //m_iInterface.InfoMessage(m_iCounter.ToString());  //para sair
                    //Thread.Sleep(1000); //para sair
                    //m_iInterface.InfoMessage(m_iCounter.ToString()); //para sair

                    processaLinha();

                    if (!m_bIsRunning)
                        m_iInterface.WarningMessage("Importação cancelada");

                }
                sr.Close();
                CloseImport();
                m_iInterface.WarningMessage("Fim de importação do ficheiro: " + m_sFileName + " com " + m_iCounter.ToString() + " Registos ");
                return true;
            }
            catch (Exception ex)
            {
                if (sr != null)
                {
                    sr.Close(); 
                }
                m_iInterface.ErrorMessage("Linha: " + m_iCounter.ToString() + " Erro: " + ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "Ficheiro()", 500);
                try
                {
                    CloseImport("Erro");
                }
                catch(Exception ex2)
                {
                    m_iInterface.ErrorMessage(" CloseImport(Erro): " + ex2.Message);
                    GenericLog.GenLogRegistarErro(ref ex, "Ficheiro()", 500);
                }
                m_iInterface.WarningMessage("Erro importação do ficheiro: " + m_sFileName);
                return false;

            }
            
        }

        private bool initImportFile()
        {
            string sNewFileName = Path.GetDirectoryName(m_sFileName) + "\\" + m_sPrefixo + "." + Path.GetFileName(m_sFileName);
            try
            {
                File.Move(m_sFileName, sNewFileName);
            }
            catch (Exception ex)
            {
                m_iInterface.WarningMessage(m_sFileName + " " + ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "Ficheiro()", 500);
                return false;
            }

            m_sFileName = sNewFileName;

            m_iInterface.WarningMessage("Inicio de importação do ficheiro: " + m_sFileName);
            m_bIsRunning = true;
            m_iCounter = 0;
        
            return true;
        }

        private void CloseImport()
        {
            if (m_iCounter==0)
            {
                throw new Exception("Ficheiro vazio: " + m_sFileName);
            }

            LastOperations();
            CloseImport("");
        }
        private void CloseImport(string sExtensao)
        {

            if (sExtensao.Length > 0)
                sExtensao += ".";

            m_bIsRunning = false;
            string sDestPath = m_oParameters.m_sFileBackupPath;
            string sNewFileName = sDestPath + sExtensao + Path.GetFileName(m_sFileName) + "." + DateTime.Now.ToString("yyyyMMddHHmmss");
            File.Move(m_sFileName, sNewFileName);

            CIFicheiro.DeleteOldFiles oDel = new CIFicheiro.DeleteOldFiles(m_iInterface);
            oDel.DeleteFiles(m_oParameters.m_sFileBackupPath, m_oParameters.GetProfileInt("Ficheiros","Delete","Backup",60), "*", false);
            
        }

        public void LastOperations()
        {
            ArrayList oParam;
            try
            {

                oParam = new ArrayList();
                oParam.Add(new GeneralDBParameters("@Fich_Id", m_sFichID));

                m_oParameters.DirectStoredProcedureNonQuery("dbo.Update_ActualizarAutoAssociarFicheiro", ref oParam);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);

            }
        }

        public virtual void processaLinha()
        {
            //processa
            m_sHDT = m_sLinha.Substring(0, 1);
            try
            {
                switch (m_sHDT)
                {
                    case "0":
                        validaHeaderFich();
                        insertHeaderFich();
                        break;
                    case "1":
                        validaHeaderLote();
                        insertHeaderLote();
                        break;
                    case "2":
                        validaDetalhe();
                        insertDetalhe();
                        break;
                    case "8":
                        validaTrailerLote();
                        insertTrailerLote();
                        break;
                    case "9":
                        validaTrailerFich();
                        insertTrailerFich();
                        break;
                }
            }
            catch 
            {
                throw;
                //m_iInterface.ErrorMessage(ex.Message);
                //MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }

}
