﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Collections;
using System.Text;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;



namespace CIFicheiro
{
    public class FicheiroEnvm : FichEnvmAcom
    {

        

       // public string m_sHDT;

        //public string m_sHFREFCMP;
        //public string m_sHFFICH;
        //public string m_sHFBANCO;
        //public string m_sHFNSEQFICH;
        //public string m_sHFDTFICH;
        //public DateTime m_dtHFDTFICH;
        //public string m_sHFFICH_ID;

        //public string m_sHLNLOTE;
        public string m_sHLCODBAL;
        public string m_sHLNREM;
        public string m_sHLDTREM;
        public string m_sHLTCAP;
        public string m_sHLTREM;
        public decimal m_dHLMONTANTE;
        public string m_sHLNRDOCUM;
        public string m_sHLANOMAL;
        
        public string m_sHLCHAHOST;
        public string m_sHLCHAHOSTEXT;
        public string m_sHLVALREQ;
        public string m_sHLSERVADIC;
        public string m_sHLLote_ID;

        public string m_sDZIB;
        public string m_sDNCONTA;
        public string m_sDNCHQ;
        public string m_sDTIPCHQ;
        //public string m_sDIMPORT;
        //public string m_sDREFARQ;
        public string m_sDANOMAL;
        public string m_sDIMGQUAL;
        public string m_sDDTCMP;
        //public string m_sDCODANA;
        //public string m_sDCHAHOST;
        //public string m_sDCHAHOSTEXT;
        public string m_sDREQDOC;
        public string m_sDDUPLICADO;
        public string m_sDSERVADIC;
        //public string m_sDREFARQCAP;
        //public string m_sDCODBAL;

        public decimal m_dTLMONTAPU;
        //public string m_sTLTOTREG;
        //public string m_sTLMONTTOTAL;

        //public string m_sTFTOTREGFIS;
        //public string m_sTFMONTTOTFIC;
        //public string m_sTFULTFICH;



        public FicheiroEnvm(CIComumInterface iInterface, CIConfigGP.CIGlobalParameters oParameters)
            : base(iInterface, oParameters)
        {
            m_sExpectedName = "ENVM";
            m_iTipoFicheiro = 1;
            m_oParam = new ArrayList();

            m_sHDT = "";
            m_sLinha = "";

            m_sHFREFCMP = "";
            m_sHFFICH = "";
            m_sHFBANCO = "";
            m_sHFNSEQFICH = "";
            m_sHFDTFICH = "";
            m_dtHFDTFICH = DateTime.MinValue;
            m_sHFFICH_ID = "";

            m_sHLNLOTE = "";
            m_sHLCODBAL = "";
            m_sHLNREM = "";
            m_sHLDTREM = "";
            m_sHLTCAP = "";
            m_sHLTREM = "";
            m_dHLMONTANTE = 0;
            m_sHLNRDOCUM = "";
            m_sHLANOMAL = "";
            m_sHLCHAHOST = "";
            m_sHLCHAHOSTEXT = "";
            m_sHLVALREQ = "";
            m_sHLSERVADIC = "";


            m_sDZIB = "";
            m_sDNCONTA = "";
            m_sDNCHQ = "";
            m_sDTIPCHQ = "";
            m_dDIMPORT = 0;
            m_sDREFARQ = "";
            m_sDANOMAL = "";
            m_sDIMGQUAL = "";
            m_sDDTCMP = "";
            m_sDCODANA = "";
            m_sDCHAHOST = "";
            m_sDCHAHOSTEXT = "";
            m_sDREQDOC = "";
            m_sDDUPLICADO = "";
            m_sDSERVADIC = "";
            //m_sDREFARQCAP = "";
            m_sDCODBAL = "";

            m_dTLMONTAPU = 0;
            m_iTLTOTREG = 0;
            m_dTLMONTTOTAL = 0;

            m_iTFTOTREGFIS = 0;
            m_dTFMONTTOTFIC = 0;
            m_sTFULTFICH = "";
        }

        public override void parseHeaderLote()
        {
          
            string sLinha = m_sLinha;
            int iPos = 0, iLen = 1;

            m_sHDT = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 6;
            m_sHLNLOTE = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 4;
            m_sHLCODBAL = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 11;
            m_sHLNREM = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 8;
            m_sHLDTREM = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 1;
            m_sHLTCAP = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 3;
            m_sHLTREM = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 15;
            string m_sHLMONTANTE = sLinha.Substring(iPos, iLen);
            m_dHLMONTANTE = (decimal.Parse(m_sHLMONTANTE)/ (decimal)100.0);

            iPos = iPos + iLen; iLen = 6;
            m_sHLNRDOCUM = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 3;
            m_sHLANOMAL = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 51;
            m_sHLCHAHOST = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 77;
            m_sHLCHAHOSTEXT = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 3;
            m_sHLVALREQ = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 120;
            m_sHLSERVADIC = sLinha.Substring(iPos, iLen);

        }

        public override bool validaHeaderLote()
        {
            m_iCountDetalhesLote = 0;
            m_dAcumDetalhesLote = 0;

            if (m_sLinha.Length < 309)
                return false;

            parseHeaderLote();

            m_iInterface.InfoMessage("Importação ENVM Lote:" + m_sHLNLOTE, "");

            return true;
        }

        public override void parseDetalhe()
        {
            string sLinha = m_sLinha;
            int iPos = 0, iLen = 1;
                      
            m_iCountDetalhesLote++;
            

            m_sHDT = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 8;
            m_sDZIB = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 11;
            m_sDNCONTA = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 10;
            m_sDNCHQ = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 12;
            string m_sDIMPORT = sLinha.Substring(iPos, iLen);
            m_dDIMPORT = (decimal.Parse(m_sDIMPORT)/ (decimal)100.0);

            iPos = iPos + iLen; iLen = 2;
            m_sDTIPCHQ = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 14;
            m_sDREFARQ = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 2;
            m_sDANOMAL = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 2;
            m_sDIMGQUAL = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 8;
            m_sDDTCMP = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 2;
            m_sDCODANA = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 51;
            m_sDCHAHOST = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 77;
            m_sDCHAHOSTEXT = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 50;
            m_sDREQDOC = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 1;
            m_sDDUPLICADO = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 120;
            m_sDSERVADIC = sLinha.Substring(iPos, iLen);

            m_dAcumDetalhesLote = m_dAcumDetalhesLote + m_dDIMPORT;
        }

        public override bool validaDetalhe()
        {
            if (m_sLinha.Length < 371)
                return false;

            parseDetalhe();
            
            return true;
        }

        public override void parseTrailerLote()
        {
            string sLinha = m_sLinha;
            int iPos = 0, iLen = 1;

            m_sHDT = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 15;
            string m_sTLMONTAPU = sLinha.Substring(iPos, iLen);
            m_dTLMONTAPU = (decimal.Parse(m_sTLMONTAPU)/ (decimal)100.0);

            iPos = iPos + iLen; iLen = 6;
            string m_sTLTOTREG = sLinha.Substring(iPos, iLen);
            m_iTLTOTREG = int.Parse(m_sTLTOTREG);

            iPos = iPos + iLen; iLen = 15;
            string sTLMONTTOTAL = sLinha.Substring(iPos, iLen);
            m_dTLMONTTOTAL = (decimal.Parse(sTLMONTTOTAL) / (decimal)100.0);

            m_iCountTotRegLotes = m_iTLTOTREG + m_iCountTotRegLotes;
            m_dAcumMontTotalLotes = m_dTLMONTTOTAL + m_dAcumMontTotalLotes;
        }
        


        public override bool validaTrailerLote()
        {
            if (m_sLinha.Length < 37)
                return false;

            parseTrailerLote();
            
            
            ValidaTotaisLote();
          
            return true;

        }





        //public override bool validaTrailerFich()
        //{
        //    string sLinha = m_sLinha;
        //    int iPos = 0, iLen = 1;

        //    if (sLinha.Length < 24)
        //        return false;

        //    m_sHDT = sLinha.Substring(iPos, iLen);

        //    iPos = iPos + iLen; iLen = 6;
        //    m_sTFTOTREGFIS = sLinha.Substring(iPos, iLen);

        //    iPos = iPos + iLen; iLen = 15;
        //    m_sTFMONTTOTFIC = sLinha.Substring(iPos, iLen);

        //    iPos = iPos + iLen; iLen = 2;
        //    m_sTFULTFICH = sLinha.Substring(iPos, iLen);


        //    if (int.Parse(m_sTFTOTREGFIS) != m_iCountTotRegLotes)
        //    {
        //        alertaErroFich("Total de registos " + m_sTLTOTREG + " do trailer do lote " + m_sHLNLOTE + " na linha " + m_iCounter.ToString() + " != da quantidade de detalhes " + m_iCountTotRegLotes.ToString());
        //    }
        //    if (decimal.Parse(m_sTLMONTTOTAL) != m_dAcumDetalhesLote)
        //    {
        //        alertaErroFich("Montante total " + m_sTLMONTTOTAL + " do trailer do lote " + m_sHLNLOTE + " na linha " + m_iCounter.ToString() + " != do montante dos detalhes " + m_dAcumDetalhesLote.ToString());
        //    }
        //    //validar Qt, e mont dar msg mas continuar

        //    return true;
        //}

        //public override void insertHeaderFich()
        //{
        //    try
        //    {
        //        m_oParam.Clear();
        //        m_oParam.Add(new GeneralDBParameters("@Fich", m_sHFFICH));
        //        m_oParam.Add(new GeneralDBParameters("@Banco", m_sHFBANCO));
        //        m_oParam.Add(new GeneralDBParameters("@NSeqFich", m_sHFNSEQFICH));
        //        m_oParam.Add(new GeneralDBParameters("@DtFich", m_dtHFDTFICH));
        //        m_oParam.Add(new GeneralDBParameters("@RefCmp", m_sHFREFCMP));
        //        m_oParam.Add(new GeneralDBParameters("@FullPathName", m_sFileName));

        //        m_sFichID = m_oParameters.DirectStoredProcedureScalar("dbo.Insert_Ficheiro", ref m_oParam).ToString();
        //    }
        //    catch (Exception ex)
        //    {
        //        if (ex.Message.IndexOf("UK_FICHEIRO") > 0)
        //        {
        //            throw new Exception("Ficheiro já importado anteriormente");
        //        }
        //        throw;
        //    }
        //}

        public override void insertHeaderLote()
        {
            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@FichID", m_sFichID));
            m_oParam.Add(new GeneralDBParameters("@NLote", m_sHLNLOTE));
            m_oParam.Add(new GeneralDBParameters("@CodBal", m_sHLCODBAL));
            m_oParam.Add(new GeneralDBParameters("@NRem", m_sHLNREM));
            m_oParam.Add(new GeneralDBParameters("@DTrem", m_sHLDTREM));
            m_oParam.Add(new GeneralDBParameters("@TCap", m_sHLTCAP));
            m_oParam.Add(new GeneralDBParameters("@TREM", m_sHLTREM));
            m_oParam.Add(new GeneralDBParameters("@Montante", m_dHLMONTANTE));
            m_oParam.Add(new GeneralDBParameters("@NrDocum", m_sHLNRDOCUM));
            m_oParam.Add(new GeneralDBParameters("@Anomal", m_sHLANOMAL));
            m_oParam.Add(new GeneralDBParameters("@ChaveH", m_sHLCHAHOST));
            m_oParam.Add(new GeneralDBParameters("@ChaveHext", m_sHLCHAHOSTEXT));
            m_oParam.Add(new GeneralDBParameters("@ValReq", m_sHLVALREQ));
            m_oParam.Add(new GeneralDBParameters("@ServVadic", m_sHLSERVADIC));

            m_sLoteID = m_oParameters.DirectStoredProcedureScalar("dbo.Insert_LoteENVM", ref m_oParam).ToString();
        }

        public override void insertDetalhe()
        {
            
            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@LoteEnvm_Id", m_sLoteID));
            m_oParam.Add(new GeneralDBParameters("@Zib", m_sDZIB));
            m_oParam.Add(new GeneralDBParameters("@NConta", m_sDNCONTA));
            m_oParam.Add(new GeneralDBParameters("@NChq", m_sDNCHQ));
            m_oParam.Add(new GeneralDBParameters("@Import", m_dDIMPORT));
            m_oParam.Add(new GeneralDBParameters("@TipChq", m_sDTIPCHQ));
            m_oParam.Add(new GeneralDBParameters("@Refarq", m_sDREFARQ));
            m_oParam.Add(new GeneralDBParameters("@Anomal", m_sDANOMAL));
            m_oParam.Add(new GeneralDBParameters("@ImgQual", m_sDIMGQUAL));
            m_oParam.Add(new GeneralDBParameters("@CodAna", m_sDCODANA));
            m_oParam.Add(new GeneralDBParameters("@ChaveH", m_sDCHAHOST));
            m_oParam.Add(new GeneralDBParameters("@ChaveHext", m_sDCHAHOSTEXT));
            m_oParam.Add(new GeneralDBParameters("@ReqDoc", m_sDREQDOC));
            m_oParam.Add(new GeneralDBParameters("@duplicado", m_sDDUPLICADO));
            m_oParam.Add(new GeneralDBParameters("@servadic", m_sDSERVADIC));

            m_sDocID = m_oParameters.DirectStoredProcedureScalar("dbo.Insert_DocumentoEnvm", ref m_oParam).ToString();
  
       }

        public override void insertTrailerLote()
        {
            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@LoteEnvmID", m_sLoteID));
            m_oParam.Add(new GeneralDBParameters("@FichID", m_sFichID));
            m_oParam.Add(new GeneralDBParameters("@MontApu", m_dTLMONTAPU));
            m_oParam.Add(new GeneralDBParameters("@TotReg", m_iTLTOTREG));
            m_oParam.Add(new GeneralDBParameters("@MontTotal", m_dTLMONTTOTAL));
            
            m_oParameters.DirectStoredProcedureNonQuery("dbo.Update_Loteenvm", ref m_oParam);
            
        }
        //public override void insertTrailerFich()
        //{
        //    m_oParam.Clear();
        //    m_oParam.Add(new GeneralDBParameters("@FichID", m_sFichID));
        //    m_oParam.Add(new GeneralDBParameters("@TotReg", m_sTFTOTREGFIS));
        //    m_oParam.Add(new GeneralDBParameters("@MontTotal", m_sTFMONTTOTFIC));
        //    m_oParam.Add(new GeneralDBParameters("@UltFich", m_sTFULTFICH));

        //    m_oParameters.DirectStoredProcedureNonQuery("dbo.Update_Ficheiro", ref m_oParam);

        //}

        




    }
}
