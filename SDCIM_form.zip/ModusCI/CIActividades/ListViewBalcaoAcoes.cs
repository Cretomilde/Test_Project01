﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CIActividades
{
    public class ListViewBalcaoAcoes
    {
        public DateTime dtREM_BALCAO_DATA;
        public DateTime dtREM_BALCAO_PROC;
        public Int16 iREM_BALCAO;
        public Int32 iREM_NUMERO;
        public Int32 iNUM_DEPOSITO; // REM_SEQUENCIA
        public String sREMBALCAO_STAT_DESC; //Estado da Remessa
        public String sDOC_ID;
        public String sZIB; // [DOC_ZONA5]
        public String sNUM_CONTA; // [DOC_ZONA4]
        public String sNUM_CHEQUE; //[DOC_ZONA3]
        public Double fCHEQUE_MONTANTE; //[DOC_ZONA2]
        public String sTIPO_CHEQUE; // [DOC_ZONA1]
        public String sREM_NIB;
        public String sREFARQ;
        public String sREFARQ_ORI;
        public String sDOC_CODANA;
        public String sDOC_CANCELADO_ID;
        public String sCANCELA_EFECTUADO; // Coluna Cancelamento 1º campo
        public String sCANCELA_ESTADO; // Coluna Cancelamento 2º campo
        public String sCANCELA_DESCRICAO; // Coluna Cancelamento 3º campo
        public String sCANCELA_ERRO; // Coluna Cancelamento 4º campo
        public String sDOCACOM_NOTIFICADO_ID; // Coluna Notificacao 1º campo
        public String sNOTIFICA_EFECTUADO; // Coluna Notificacao 1º campo
        public String sNOTIFICA_ESTADO; // Coluna Notificacao 2º campo
        public String sNOTIFICA_DESCRICAO; // Coluna Notificacao 3º campo
        public String sNOTIFICA_ERRO; // Coluna Notificacao 4º campo
        public String sDOC_CHAVEH;
        public Int16 iREMBALCAO_TIPO_ID;
        public DateTime dtFICH_DATA;
        public String sDOCACOM_ID;

        private void initVars()
        {
            dtREM_BALCAO_DATA = DateTime.MinValue;
            dtREM_BALCAO_PROC = DateTime.MinValue;
            sREMBALCAO_STAT_DESC = "";
            sDOC_ID = "";
            sZIB = "";
            sNUM_CONTA = "";
            sNUM_CHEQUE = "";
            sTIPO_CHEQUE = "";
            sREM_NIB = "";
            sREFARQ = "";
            sREFARQ_ORI = "";
            sDOC_CODANA = "";
            sDOC_CANCELADO_ID = "";
            sCANCELA_EFECTUADO = "";
            sCANCELA_ESTADO = "";
            sCANCELA_DESCRICAO = "";
            sCANCELA_ERRO = "";
            sDOCACOM_NOTIFICADO_ID = "";
            sNOTIFICA_EFECTUADO = "";
            sNOTIFICA_ESTADO = "";
            sNOTIFICA_DESCRICAO = "";
            sNOTIFICA_ERRO = "";
            sDOC_CHAVEH = "";
        }

        public ListViewBalcaoAcoes(SqlDataReader dr)
        {
            initVars();

            dtREM_BALCAO_DATA = Convert.ToDateTime(dr["REMBALCAO_DATA"]);
            dtREM_BALCAO_PROC = Convert.ToDateTime(dr["REMBALCAO_TIMER"]);
            iREM_BALCAO = Convert.ToInt16(dr["BALCAO"]);
            iREM_NUMERO = Convert.ToInt32(dr["REMBALCAO_NUMERO"]);
            iNUM_DEPOSITO = Convert.ToInt32(dr["REMBALCAO_SEQUENCIA"]);
            sREMBALCAO_STAT_DESC = Convert.ToString(dr["REMINSTAT_DESC"]);
            sDOC_ID = Convert.ToString(dr["DOC_ID"]);
            sZIB = Convert.ToString(dr["DOCACOM_ZONA5"]);
            sNUM_CONTA = Convert.ToString(dr["DOCACOM_ZONA4"]);
            sNUM_CHEQUE = Convert.ToString(dr["DOCACOM_ZONA3"]);
            fCHEQUE_MONTANTE = Convert.ToDouble(dr["DOCACOM_ZONA2"]);
            sTIPO_CHEQUE = Convert.ToString(dr["DOCACOM_ZONA1"]);
            sREM_NIB = Convert.ToString(dr["REMBALCAO_NIB"]);
            sREFARQ = Convert.ToString(dr["REFARQ"]);
            sREFARQ_ORI = Convert.ToString(dr["REFARQ_ORI"]);
            sDOC_CODANA = Convert.ToString(dr["DOCACOM_CODANA"]);
            sDOC_CANCELADO_ID = Convert.ToString(dr["DOCACOM_CANCELADO"]);
            sCANCELA_EFECTUADO = Convert.ToString(dr["CANCELA_EFECTUADO"]);
            sCANCELA_ESTADO = Convert.ToString(dr["CANCEL_ESTADO"]);
            sCANCELA_DESCRICAO = Convert.ToString(dr["CANCELA_DESCRICAO"]);
            sCANCELA_ERRO = Convert.ToString(dr["CANCELA_ERRO"]);
            sDOCACOM_NOTIFICADO_ID = Convert.ToString(dr["DOCACOM_NOTIFICADO"]);
            sNOTIFICA_EFECTUADO = Convert.ToString(dr["NOTIFICA_EFECTUADO"]);
            sNOTIFICA_ESTADO = Convert.ToString(dr["NOTIFICA_ESTADO"]);
            sNOTIFICA_DESCRICAO = Convert.ToString(dr["NOTIFICA_DESCRICAO"]);
            sNOTIFICA_ERRO = Convert.ToString(dr["NOTIFICA_ERRO"]);
            sDOC_CHAVEH = Convert.ToString(dr["DOCACOM_CHAVEH"]);
            iREMBALCAO_TIPO_ID = Convert.ToInt16(dr["REMBALCAO_TIPO_ID"]);
            sDOCACOM_ID = Convert.ToString(dr["DOCACOM_ID"]);
        }

        public ListViewBalcaoAcoes(DataRow dtr)
        {
            initVars();

            dtREM_BALCAO_DATA = Convert.ToDateTime(dtr["REMBALCAO_DATA"]);
            dtREM_BALCAO_PROC = Convert.ToDateTime(dtr["REMBALCAO_TIMER"]);
            iREM_BALCAO = Convert.ToInt16(dtr["BALCAO"]);
            iREM_NUMERO = Convert.ToInt32(dtr["REMBALCAO_NUMERO"]);
            iNUM_DEPOSITO = Convert.ToInt32(dtr["REMBALCAO_SEQUENCIA"]);
            sREMBALCAO_STAT_DESC = Convert.ToString(dtr["REMINSTAT_DESC"]);
            sDOC_ID = Convert.ToString(dtr["DOC_ID"]);
            sZIB = Convert.ToString(dtr["DOCACOM_ZONA5"]);
            sNUM_CONTA = Convert.ToString(dtr["DOCACOM_ZONA4"]);
            sNUM_CHEQUE = Convert.ToString(dtr["DOCACOM_ZONA3"]);
            fCHEQUE_MONTANTE = Convert.ToDouble(dtr["DOCACOM_ZONA2"]);
            sTIPO_CHEQUE = Convert.ToString(dtr["DOCACOM_ZONA1"]);
            sREM_NIB = Convert.ToString(dtr["REMBALCAO_NIB"]);
            sREFARQ = Convert.ToString(dtr["REFARQ"]);
            sREFARQ_ORI = Convert.ToString(dtr["REFARQ_ORI"]);
            sDOC_CODANA = Convert.ToString(dtr["DOCACOM_CODANA"]);
            sDOC_CANCELADO_ID = Convert.ToString(dtr["DOCACOM_CANCELADO"]);
            sCANCELA_EFECTUADO = Convert.ToString(dtr["CANCELA_EFECTUADO"]);
            sCANCELA_ESTADO = Convert.ToString(dtr["CANCEL_ESTADO"]);
            sCANCELA_DESCRICAO = Convert.ToString(dtr["CANCELA_DESCRICAO"]);
            sCANCELA_ERRO = Convert.ToString(dtr["CANCELA_ERRO"]);
            sDOCACOM_NOTIFICADO_ID = Convert.ToString(dtr["DOCACOM_NOTIFICADO"]);
            sNOTIFICA_EFECTUADO = Convert.ToString(dtr["NOTIFICA_EFECTUADO"]);
            sNOTIFICA_ESTADO = Convert.ToString(dtr["NOTIFICA_ESTADO"]);
            sNOTIFICA_DESCRICAO = Convert.ToString(dtr["NOTIFICA_DESCRICAO"]);
            sNOTIFICA_ERRO = Convert.ToString(dtr["NOTIFICA_ERRO"]);
            sDOC_CHAVEH = Convert.ToString(dtr["DOCACOM_CHAVEH"]);
            iREMBALCAO_TIPO_ID = Convert.ToInt16(dtr["REMBALCAO_TIPO_ID"]);
            sDOCACOM_ID = Convert.ToString(dtr["DOCACOM_ID"]);
        }

        public ListViewItem MakeListViewItemsAcoes(string sDateFormat)
        {
            ListViewItem olvItem = new ListViewItem();
            olvItem.Text = dtREM_BALCAO_DATA.ToString(sDateFormat);
            olvItem.SubItems.Add(dtREM_BALCAO_PROC.ToString(sDateFormat));
            olvItem.SubItems.Add(iREM_BALCAO.ToString("0000"));
            olvItem.SubItems.Add(iREM_NUMERO.ToString("0000000"));
            olvItem.SubItems.Add(iNUM_DEPOSITO.ToString("000000"));
            olvItem.SubItems.Add(sREMBALCAO_STAT_DESC);
            olvItem.SubItems.Add(sDOC_ID);
            olvItem.SubItems.Add(sZIB);
            olvItem.SubItems.Add(sNUM_CONTA);
            olvItem.SubItems.Add(sNUM_CHEQUE);
            string montanteToInsert = this.fCHEQUE_MONTANTE.ToString().Equals("0") ? this.fCHEQUE_MONTANTE.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.fCHEQUE_MONTANTE).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(fCHEQUE_MONTANTE).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(sTIPO_CHEQUE);
            olvItem.SubItems.Add(sREM_NIB);
            olvItem.SubItems.Add(sREFARQ);
            olvItem.SubItems.Add(sREFARQ_ORI);
            olvItem.SubItems.Add(sDOC_CODANA);
            olvItem.SubItems.Add(sCANCELA_EFECTUADO + "  " + sCANCELA_ESTADO + " " + sCANCELA_DESCRICAO + " " + sCANCELA_ERRO);
            olvItem.SubItems.Add(sDOC_CANCELADO_ID);
            olvItem.SubItems.Add(sNOTIFICA_EFECTUADO + " " + sNOTIFICA_ESTADO + " " + sNOTIFICA_DESCRICAO + " " + sNOTIFICA_ERRO);
            olvItem.SubItems.Add(sDOCACOM_NOTIFICADO_ID);
            olvItem.SubItems.Add(sDOC_CHAVEH);
            return olvItem;
        }
    }
}