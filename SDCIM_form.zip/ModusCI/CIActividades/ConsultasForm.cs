﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using System.Collections;
using NBiis.Generic;

namespace CIActividades
{
    public partial class ConsultasForm : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        protected Form m_oMainForm;
        protected CIConfigGlobalParameters.CIMenuInterface m_oMenuInterface;

        public ConsultasForm(CIConfigGP.CIGlobalParameters oParameters, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_oMenuInterface = oMenuInterface;
        }

        private void Consultas_Load(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;

            dataInicio.Value = DateTime.Now.AddDays(-7);

            refreshConsultaRemessas();
            refreshConsultaDocs();

            m_oMenuInterface.consultasEnable(false);
        }

        public void refreshConsultaRemessas()
        {
            DataSet ds = null;
            string sQuery = "select * from VW_CONSULTA_REMESSA ";
            sQuery += whereClauseData();
            sQuery += " order by TIMER_CRIACAO DESC, mais_resultados";

            try
            {
                ds = m_oParameters.DirectSqlDataSet(sQuery, "Consulta Remessas");
                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    AddConsultaRemessa2ListView(oRow);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Consultas.cs", 8);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            
        }

        private void AddConsultaRemessa2ListView(DataRow oRow)
        {
            ConsultaRemessaDetalhe oCr = new ConsultaRemessaDetalhe(oRow, m_oParameters);

            ListViewItem olvItem = oCr.MakeListViewItem(m_oParameters.DateFormat, m_oParameters.DateTimeSysFmt);

            olvItem.Tag = oCr;

            listViewConsultaRemessas.Items.Add(olvItem);

        }

        private string whereClauseData()
        {
            string sWhereClause;
            sWhereClause = " where TIMER_CRIACAO between '" + dataInicio.Value.ToString(m_oParameters.DateSysFmt) + "' and ";
            sWhereClause += "'" + dataFim.Value.AddDays(+1).ToString(m_oParameters.DateSysFmt) + "' ";

            return sWhereClause;
        }

        public void refreshConsultaDocs()
        {
            DataSet ds = null;

            string sQuery = "select * from VW_CONSULTA_DOCS ";
            sQuery += whereClauseData();
            sQuery += " order by TIMER_CRIACAO DESC, MAIS_RESULTADOS";

            try
            {
                ds = m_oParameters.DirectSqlDataSet(sQuery, "Consulta Documentos");
                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    AddConsultaDocs2ListView(oRow);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Consultas.cs", 9);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }
        private void AddConsultaDocs2ListView(DataRow oRow)
        {
            ConsultaDocumentosDetalhe oCd = new ConsultaDocumentosDetalhe(oRow, m_oParameters);

            ListViewItem olvItem = oCd.MakeListViewItem(m_oParameters.DateFormat, m_oParameters.DateTimeSysFmt);

            olvItem.Tag = oCd;

            listViewConsultaDocs.Items.Add(olvItem);

        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            listViewConsultaRemessas.Items.Clear();
            listViewConsultaDocs.Items.Clear();
            listViewImagens.Items.Clear();

            refreshConsultaRemessas();
            refreshConsultaDocs();
        }

        private void consultarImagensToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewConsultaDocs.SelectedItems.Count != 1)
            {
                return;
            }

            ConsultaDocumentosDetalhe oCd = null;
            ArrayList oParams = new ArrayList();
           
            try
            { 
                oCd = (ConsultaDocumentosDetalhe)listViewConsultaDocs.SelectedItems[0].Tag;

                //if (!verificaDisponibilidade(oCd))
                //{
                //    MessageBox.Show("Imagem não disponivel", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    return;
                //}   
               
                oParams.Add(new GeneralDBParameters("@ConsultaId", oCd.m_lConsultaId));
                oParams.Add(new GeneralDBParameters("@Operativa", oCd.m_iOperativa));
                oParams.Add(new GeneralDBParameters("@NomeImagem", oCd.m_sNomeImagem));
                oParams.Add(new GeneralDBParameters("@NumPagina", 1));

                m_oParameters.DirectStoredProcedureNonQuery("dbo.Insert_TibcoObtemImagem", ref oParams);

                oParams.Clear();
                oParams.Add(new GeneralDBParameters("@ConsultaId", oCd.m_lConsultaId));
                oParams.Add(new GeneralDBParameters("@Operativa", oCd.m_iOperativa));
                oParams.Add(new GeneralDBParameters("@NomeImagem", oCd.m_sNomeImagem));
                oParams.Add(new GeneralDBParameters("@NumPagina", 2));

                m_oParameters.DirectStoredProcedureNonQuery("dbo.Insert_TibcoObtemImagem", ref oParams);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                GenericLog.GenLogRegistarErro(ref ex, "consultarImagensToolStripMenuItem_Click", 10); 
            }
        }

        //private bool verificaDisponibilidade(ConsultaDocumentosDetalhe oCd)
        //{
        //    if (oCd.m_sNomeImagem == null || oCd.m_sNomeImagem== "")
        //        return false;
        //    else
        //        return true;

        //}

        private void listViewConsultaDocs_DoubleClick(object sender, EventArgs e)
        {
            SqlDataReader oReader = null;

            try
            {
                listViewImagens.MyClear();

                ConsultaDocumentosDetalhe oCurrDoc = null;

                if (listViewConsultaDocs.SelectedItems.Count == 0)
                {
                    return;
                }

                oCurrDoc = (ConsultaDocumentosDetalhe)listViewConsultaDocs.SelectedItems[0].Tag;


                oReader = oCurrDoc.GetConsultaImagens();

                if (oReader == null)
                {
                    return;
                }

                if ( !oReader.HasRows )
                {
                    return;
                }

                while (oReader.Read())
                {
                    ListViewDetalhesImagem oTag = new ListViewDetalhesImagem(oReader, m_oParameters);
                    ListViewItem oItem = oTag.BuildListViewItem();

                    listViewImagens.Items.Add(oItem);
                }
            }
            catch (Exception ex)
            {
                NBiis.GenericLog.GenLogRegistarErro(ref ex, this.Name, 0);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (oReader != null)
                {
                    if (!oReader.IsClosed)
                    {
                        oReader.Close();
                    }

                    oReader.Dispose();
                    oReader = null;
                }
            }

            //ConsultaDocumentosDetalhe oCurrDoc = null;
            //oCurrDoc = (ConsultaDocumentosDetalhe)listViewConsultaDocs.SelectedItems[0].Tag;
            //if (oCurrDoc.m_iEstadoImagemB == 2 && oCurrDoc.m_iEstadoImagemF == 2)
            //{
            //    MostraImagem fMostraImg = new MostraImagem(m_oParameters, oCurrDoc);
            //    fMostraImg.ShowDialog();
            //}
            //else 
            //{
            //    MessageBox.Show("A imagem não está disponivel!", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
        }

        private void contextMenuStripConsultaDocs_Opening(object sender, CancelEventArgs e)
        {
            if (listViewConsultaDocs.SelectedItems.Count == 0)
            {
                contextMenuStripConsultaDocs.Enabled = false;
            }
            else
            {
                contextMenuStripConsultaDocs.Enabled = true;
            }
        }

        private void listViewImagens_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                string sFileName;
                ListViewDetalhesImagem oItem = null; 

                if (m_pictureBox.Image != null)
                {
                    m_pictureBox.Image.Dispose();
                    m_pictureBox.Image = null;
                }

                if (listViewImagens.SelectedItems.Count == 0)
                {
                    return;
                }

                oItem = (ListViewDetalhesImagem)listViewImagens.SelectedItems[0].Tag;

                sFileName = oItem.GetImage();

                m_pictureBox.Image = System.Drawing.Image.FromFile(sFileName);
                m_pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            catch (Exception ex)
            {
                NBiis.GenericLog.GenLogRegistarErro(ref ex, this.Name, 0);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ConsultasForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (m_pictureBox.Image != null)
            {
                m_pictureBox.Image.Dispose();
                m_pictureBox.Image = null;
            }
        }
    }
}