﻿namespace CIActividades
{
    partial class PesqFicheiroACOM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listViewPesquisaDocumentoACOM = new NBIISNET.ListViewBase();
            this.columnHeader28 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader29 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader30 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader32 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader33 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader34 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader36 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader37 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader40 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnOrigem = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader41 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader42 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader43 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader44 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader45 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader46 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader47 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader48 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader49 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnACOMCancel = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CancelID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderACOMNotif = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.NotifyID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader50 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader51 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStripACOM = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CancelaACOMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.confirmarCancelamentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.anulaCancelaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.NotificaACOMStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ConfirmaNotificaACOMStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AnulaNotificaACOMStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelACOM = new System.Windows.Forms.Label();
            this.lblDeposito = new System.Windows.Forms.Label();
            this.txtDeposito = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxNumCheque = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxREFARQ = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxBalcao = new System.Windows.Forms.TextBox();
            this.m_ctrldtFim = new System.Windows.Forms.DateTimePicker();
            this.m_ctrldtInicio = new System.Windows.Forms.DateTimePicker();
            this.buttonACOM = new System.Windows.Forms.Button();
            this.contextMenuStripACOM.SuspendLayout();
            this.SuspendLayout();
            // 
            // listViewPesquisaDocumentoACOM
            // 
            this.listViewPesquisaDocumentoACOM.AllowColumnReorder = true;
            this.listViewPesquisaDocumentoACOM.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewPesquisaDocumentoACOM.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader28,
            this.columnHeader29,
            this.columnHeader30,
            this.columnHeader32,
            this.columnHeader33,
            this.columnHeader34,
            this.columnHeader36,
            this.columnHeader37,
            this.columnHeader40,
            this.columnOrigem,
            this.columnHeader41,
            this.columnHeader42,
            this.columnHeader43,
            this.columnHeader44,
            this.columnHeader45,
            this.columnHeader46,
            this.columnHeader47,
            this.columnHeader48,
            this.columnHeader49,
            this.columnACOMCancel,
            this.CancelID,
            this.columnHeaderACOMNotif,
            this.NotifyID,
            this.columnHeader50,
            this.columnHeader51});
            this.listViewPesquisaDocumentoACOM.ContextMenuStrip = this.contextMenuStripACOM;
            this.listViewPesquisaDocumentoACOM.EnableExportar = true;
            this.listViewPesquisaDocumentoACOM.FullRowSelect = true;
            this.listViewPesquisaDocumentoACOM.GridLines = true;
            this.listViewPesquisaDocumentoACOM.HideSelection = false;
            this.listViewPesquisaDocumentoACOM.Location = new System.Drawing.Point(6, 82);
            this.listViewPesquisaDocumentoACOM.Name = "listViewPesquisaDocumentoACOM";
            this.listViewPesquisaDocumentoACOM.Size = new System.Drawing.Size(1344, 234);
            this.listViewPesquisaDocumentoACOM.TabIndex = 45;
            this.listViewPesquisaDocumentoACOM.UseCompatibleStateImageBehavior = false;
            this.listViewPesquisaDocumentoACOM.View = System.Windows.Forms.View.Details;
            this.listViewPesquisaDocumentoACOM.DoubleClick += new System.EventHandler(this.listViewPesquisaDocumentoACOM_DoubleClick);
            // 
            // columnHeader28
            // 
            this.columnHeader28.Text = "FichID";
            this.columnHeader28.Width = 0;
            // 
            // columnHeader29
            // 
            this.columnHeader29.Text = "FichNSeq";
            this.columnHeader29.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader29.Width = 50;
            // 
            // columnHeader30
            // 
            this.columnHeader30.Text = "FichData";
            this.columnHeader30.Width = 70;
            // 
            // columnHeader32
            // 
            this.columnHeader32.Text = "LotAcomID";
            this.columnHeader32.Width = 0;
            // 
            // columnHeader33
            // 
            this.columnHeader33.Text = "LotNum";
            this.columnHeader33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader33.Width = 0;
            // 
            // columnHeader34
            // 
            this.columnHeader34.Text = "Produto";
            this.columnHeader34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader34.Width = 30;
            // 
            // columnHeader36
            // 
            this.columnHeader36.Text = "DataProc";
            this.columnHeader36.Width = 80;
            // 
            // columnHeader37
            // 
            this.columnHeader37.Text = "LoteStatus";
            // 
            // columnHeader40
            // 
            this.columnHeader40.Text = "DocAcomID";
            this.columnHeader40.Width = 0;
            // 
            // columnOrigem
            // 
            this.columnOrigem.Text = "Origem";
            // 
            // columnHeader41
            // 
            this.columnHeader41.Text = "ZIB";
            this.columnHeader41.Width = 70;
            // 
            // columnHeader42
            // 
            this.columnHeader42.Text = "NConta";
            this.columnHeader42.Width = 80;
            // 
            // columnHeader43
            // 
            this.columnHeader43.Text = "NCheque";
            this.columnHeader43.Width = 75;
            // 
            // columnHeader44
            // 
            this.columnHeader44.Text = "Import";
            this.columnHeader44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader44.Width = 100;
            // 
            // columnHeader45
            // 
            this.columnHeader45.Text = "Tipo";
            this.columnHeader45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader45.Width = 30;
            // 
            // columnHeader46
            // 
            this.columnHeader46.Text = "REFARQ";
            this.columnHeader46.Width = 100;
            // 
            // columnHeader47
            // 
            this.columnHeader47.Text = "REFARQ2";
            this.columnHeader47.Width = 100;
            // 
            // columnHeader48
            // 
            this.columnHeader48.Text = "Balcão";
            this.columnHeader48.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader48.Width = 50;
            // 
            // columnHeader49
            // 
            this.columnHeader49.Text = "CodAna";
            // 
            // columnACOMCancel
            // 
            this.columnACOMCancel.Text = "Cancelamento";
            // 
            // CancelID
            // 
            this.CancelID.Text = "CancelID";
            // 
            // columnHeaderACOMNotif
            // 
            this.columnHeaderACOMNotif.Text = "Notificação";
            // 
            // NotifyID
            // 
            this.NotifyID.Text = "NotifyID";
            // 
            // columnHeader50
            // 
            this.columnHeader50.Text = "ChaveH";
            this.columnHeader50.Width = 100;
            // 
            // columnHeader51
            // 
            this.columnHeader51.Text = "Linha Óptica";
            this.columnHeader51.Width = 100;
            // 
            // contextMenuStripACOM
            // 
            this.contextMenuStripACOM.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CancelaACOMToolStripMenuItem,
            this.confirmarCancelamentoToolStripMenuItem,
            this.anulaCancelaToolStripMenuItem,
            this.NotificaACOMStripMenuItem,
            this.ConfirmaNotificaACOMStripMenuItem,
            this.AnulaNotificaACOMStripMenuItem});
            this.contextMenuStripACOM.Name = "contextMenuStripRemTrans";
            this.contextMenuStripACOM.Size = new System.Drawing.Size(365, 136);
            this.contextMenuStripACOM.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripACOM_Opening);
            // 
            // CancelaACOMToolStripMenuItem
            // 
            this.CancelaACOMToolStripMenuItem.Name = "CancelaACOMToolStripMenuItem";
            this.CancelaACOMToolStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.CancelaACOMToolStripMenuItem.Text = "Cancela Acolhimento";
            this.CancelaACOMToolStripMenuItem.Click += new System.EventHandler(this.CancelaACOMToolStripMenuItem_Click);
            // 
            // confirmarCancelamentoToolStripMenuItem
            // 
            this.confirmarCancelamentoToolStripMenuItem.Name = "confirmarCancelamentoToolStripMenuItem";
            this.confirmarCancelamentoToolStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.confirmarCancelamentoToolStripMenuItem.Text = "Confirmar Cancelamento";
            this.confirmarCancelamentoToolStripMenuItem.Click += new System.EventHandler(this.confirmarCancelamentoToolStripMenuItem_Click);
            // 
            // anulaCancelaToolStripMenuItem
            // 
            this.anulaCancelaToolStripMenuItem.Name = "anulaCancelaToolStripMenuItem";
            this.anulaCancelaToolStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.anulaCancelaToolStripMenuItem.Text = "Anula Cancelamento";
            this.anulaCancelaToolStripMenuItem.Click += new System.EventHandler(this.anulaCancelaToolStripMenuItem_Click);
            // 
            // NotificaACOMStripMenuItem
            // 
            this.NotificaACOMStripMenuItem.Name = "NotificaACOMStripMenuItem";
            this.NotificaACOMStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.NotificaACOMStripMenuItem.Text = "Notifica Acolhimento de Envio Documento Fora Prazo";
            this.NotificaACOMStripMenuItem.Click += new System.EventHandler(this.NotificaACOMStripMenuItem_Click);
            // 
            // ConfirmaNotificaACOMStripMenuItem
            // 
            this.ConfirmaNotificaACOMStripMenuItem.Name = "ConfirmaNotificaACOMStripMenuItem";
            this.ConfirmaNotificaACOMStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.ConfirmaNotificaACOMStripMenuItem.Text = "Confirmar Notificação de Envio Documento Fora Prazo";
            this.ConfirmaNotificaACOMStripMenuItem.Click += new System.EventHandler(this.ConfirmaNotificaACOMStripMenuItem_Click);
            // 
            // AnulaNotificaACOMStripMenuItem
            // 
            this.AnulaNotificaACOMStripMenuItem.Name = "AnulaNotificaACOMStripMenuItem";
            this.AnulaNotificaACOMStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.AnulaNotificaACOMStripMenuItem.Text = "Anula Notificação de Envio Documento Fora Prazo";
            this.AnulaNotificaACOMStripMenuItem.Click += new System.EventHandler(this.AnulaNotificaACOMStripMenuItem_Click);
            // 
            // labelACOM
            // 
            this.labelACOM.AutoSize = true;
            this.labelACOM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelACOM.Location = new System.Drawing.Point(88, 66);
            this.labelACOM.Name = "labelACOM";
            this.labelACOM.Size = new System.Drawing.Size(115, 13);
            this.labelACOM.TabIndex = 46;
            this.labelACOM.Text = "Registos em ACOM";
            // 
            // lblDeposito
            // 
            this.lblDeposito.AutoSize = true;
            this.lblDeposito.Location = new System.Drawing.Point(413, 9);
            this.lblDeposito.Name = "lblDeposito";
            this.lblDeposito.Size = new System.Drawing.Size(49, 13);
            this.lblDeposito.TabIndex = 82;
            this.lblDeposito.Text = "Depósito";
            // 
            // txtDeposito
            // 
            this.txtDeposito.Location = new System.Drawing.Point(416, 23);
            this.txtDeposito.MaxLength = 7;
            this.txtDeposito.Name = "txtDeposito";
            this.txtDeposito.Size = new System.Drawing.Size(76, 20);
            this.txtDeposito.TabIndex = 81;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(97, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 80;
            this.label4.Text = "Data Final";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 79;
            this.label3.Text = "Data Inicial";
            // 
            // textBoxNumCheque
            // 
            this.textBoxNumCheque.Location = new System.Drawing.Point(341, 23);
            this.textBoxNumCheque.MaxLength = 10;
            this.textBoxNumCheque.Name = "textBoxNumCheque";
            this.textBoxNumCheque.Size = new System.Drawing.Size(69, 20);
            this.textBoxNumCheque.TabIndex = 71;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(338, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 77;
            this.label1.Text = "NumCheque";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label2.Location = new System.Drawing.Point(232, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 78;
            this.label2.Text = "REFARQ";
            // 
            // textBoxREFARQ
            // 
            this.textBoxREFARQ.Location = new System.Drawing.Point(235, 23);
            this.textBoxREFARQ.MaxLength = 14;
            this.textBoxREFARQ.Name = "textBoxREFARQ";
            this.textBoxREFARQ.Size = new System.Drawing.Size(100, 20);
            this.textBoxREFARQ.TabIndex = 70;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(188, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 13);
            this.label7.TabIndex = 75;
            this.label7.Text = "Balcão";
            // 
            // textBoxBalcao
            // 
            this.textBoxBalcao.Location = new System.Drawing.Point(191, 23);
            this.textBoxBalcao.MaxLength = 4;
            this.textBoxBalcao.Name = "textBoxBalcao";
            this.textBoxBalcao.Size = new System.Drawing.Size(38, 20);
            this.textBoxBalcao.TabIndex = 69;
            // 
            // m_ctrldtFim
            // 
            this.m_ctrldtFim.CustomFormat = "yyyy-MM-dd";
            this.m_ctrldtFim.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrldtFim.Location = new System.Drawing.Point(100, 23);
            this.m_ctrldtFim.Name = "m_ctrldtFim";
            this.m_ctrldtFim.Size = new System.Drawing.Size(85, 20);
            this.m_ctrldtFim.TabIndex = 68;
            // 
            // m_ctrldtInicio
            // 
            this.m_ctrldtInicio.CustomFormat = "yyyy-MM-dd";
            this.m_ctrldtInicio.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrldtInicio.Location = new System.Drawing.Point(6, 23);
            this.m_ctrldtInicio.Name = "m_ctrldtInicio";
            this.m_ctrldtInicio.Size = new System.Drawing.Size(85, 20);
            this.m_ctrldtInicio.TabIndex = 67;
            // 
            // buttonACOM
            // 
            this.buttonACOM.Location = new System.Drawing.Point(7, 56);
            this.buttonACOM.Name = "buttonACOM";
            this.buttonACOM.Size = new System.Drawing.Size(75, 23);
            this.buttonACOM.TabIndex = 83;
            this.buttonACOM.Text = "Refresh";
            this.buttonACOM.UseVisualStyleBackColor = true;
            this.buttonACOM.Click += new System.EventHandler(this.buttonACOM_Click);
            // 
            // PesqFicheiroACOM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1362, 317);
            this.Controls.Add(this.buttonACOM);
            this.Controls.Add(this.lblDeposito);
            this.Controls.Add(this.txtDeposito);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxNumCheque);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxREFARQ);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxBalcao);
            this.Controls.Add(this.m_ctrldtFim);
            this.Controls.Add(this.m_ctrldtInicio);
            this.Controls.Add(this.labelACOM);
            this.Controls.Add(this.listViewPesquisaDocumentoACOM);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "PesqFicheiroACOM";
            this.Text = "Pesquisas e Reenvios ACOM";
            this.Load += new System.EventHandler(this.PesqFicheiroACOM_Load);
            this.Leave += new System.EventHandler(this.PesqFicheiroACOM_Leave);
            this.contextMenuStripACOM.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public NBIISNET.ListViewBase listViewPesquisaDocumentoACOM;
        private System.Windows.Forms.ColumnHeader columnHeader28;
        private System.Windows.Forms.ColumnHeader columnHeader29;
        private System.Windows.Forms.ColumnHeader columnHeader30;
        private System.Windows.Forms.ColumnHeader columnHeader32;
        private System.Windows.Forms.ColumnHeader columnHeader33;
        private System.Windows.Forms.ColumnHeader columnHeader34;
        private System.Windows.Forms.ColumnHeader columnHeader36;
        private System.Windows.Forms.ColumnHeader columnHeader37;
        private System.Windows.Forms.ColumnHeader columnHeader40;
        private System.Windows.Forms.ColumnHeader columnOrigem;
        private System.Windows.Forms.ColumnHeader columnHeader41;
        private System.Windows.Forms.ColumnHeader columnHeader42;
        private System.Windows.Forms.ColumnHeader columnHeader43;
        private System.Windows.Forms.ColumnHeader columnHeader44;
        private System.Windows.Forms.ColumnHeader columnHeader45;
        private System.Windows.Forms.ColumnHeader columnHeader46;
        private System.Windows.Forms.ColumnHeader columnHeader47;
        private System.Windows.Forms.ColumnHeader columnHeader48;
        private System.Windows.Forms.ColumnHeader columnHeader49;
        private System.Windows.Forms.ColumnHeader columnACOMCancel;
        private System.Windows.Forms.ColumnHeader columnHeaderACOMNotif;
        private System.Windows.Forms.ColumnHeader columnHeader50;
        private System.Windows.Forms.ColumnHeader columnHeader51;
        public System.Windows.Forms.Label labelACOM;
        private System.Windows.Forms.Label lblDeposito;
        private System.Windows.Forms.TextBox txtDeposito;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxNumCheque;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxREFARQ;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxBalcao;
        private System.Windows.Forms.DateTimePicker m_ctrldtFim;
        private System.Windows.Forms.DateTimePicker m_ctrldtInicio;
        private System.Windows.Forms.Button buttonACOM;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripACOM;
        private System.Windows.Forms.ToolStripMenuItem CancelaACOMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem confirmarCancelamentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem anulaCancelaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem NotificaACOMStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ConfirmaNotificaACOMStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AnulaNotificaACOMStripMenuItem;
        private System.Windows.Forms.ColumnHeader NotifyID;
        private System.Windows.Forms.ColumnHeader CancelID;

    }
}