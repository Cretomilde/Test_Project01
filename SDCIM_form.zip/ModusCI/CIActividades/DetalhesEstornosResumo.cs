﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CIActividades
{
    class DetalhesEstornosResumo
    {
        public DateTime ZEstorno { get; set; }
        public string EstadoEstornoDesc { get; set; }
        public Int32 EstadoEstornoID { get; set; }
        public Int32 NumEstorno { get; set; }
        public int NumDocs { get; set; }
        public double Montante { get; set; }
        public string ENVM { get; set; }
        public DateTime ZProcessamento { get; set; }
        public Int32 RemessaTipoID { get; set; }
        private String _remesssaTipoDest = String.Empty;
        public String RemessaTipoDesc
        {
            get
            {
                return this._remesssaTipoDest;
            }
            set
            {
                this._remesssaTipoDest = value;
            }
        }

        public void iniciarVar()
        {
            this.ZEstorno = DateTime.MinValue;
            this.EstadoEstornoDesc = "";
            this.EstadoEstornoID = 0;
            this.NumEstorno = 0;
            this.NumDocs = 0;
            this.Montante = 0.0f;
            this.ENVM = "";
            this.RemessaTipoDesc = String.Empty;
            this.RemessaTipoID = 0;
        }

        public DetalhesEstornosResumo(SqlDataReader dr)
        {
            iniciarVar();
            try
            {
                this.ZProcessamento = Convert.ToDateTime(dr["Z_PROCESS"]);
                ZEstorno = Convert.ToDateTime(dr["Z_ESTRN"]);
                EstadoEstornoDesc = Convert.ToString(dr["D_ESTRN_STATUS"]);
                EstadoEstornoID = Convert.ToInt32(dr["ESTRN_STATUS_ID"]);
                NumEstorno = Convert.ToInt32(dr["QT_ESTRN"]);
                NumDocs = Convert.ToInt32(dr["ESTRN_QT_DOCS"]);
                Montante = Convert.ToDouble(dr["ESTRN_MT_DOCS"]);
                ENVM = Convert.ToString(dr["LOTEENV_CGDERROR"]);
                this.RemessaTipoDesc = Convert.ToString(dr["REMTIPOBALCAO_DESC"]);
                this.RemessaTipoID = Convert.ToInt32(dr["REMBALCAO_TIPO_BALCAO_ID"]);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ListViewItem MakeListViewItemEstornoResumos(string sDateFormat)
        {
            ListViewItem olvItem = new ListViewItem();
            olvItem.Text = this.ZProcessamento.ToString(sDateFormat);
            olvItem.SubItems.Add(this.ZEstorno.ToString(sDateFormat));
            olvItem.SubItems.Add(this.EstadoEstornoID.ToString() + " " + this.EstadoEstornoDesc.ToString());
            olvItem.SubItems.Add(this.RemessaTipoID + " - " + this.RemessaTipoDesc.ToString());
            olvItem.SubItems.Add(this.NumEstorno.ToString());
            olvItem.SubItems.Add(this.NumDocs.ToString());
            string montanteToInsert = this.Montante.ToString().Equals("0") ? this.Montante.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.Montante).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(this.Montante).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(this.ENVM.ToString() == "0" ? "" : "Erro");
            return olvItem;
        }
    }
}