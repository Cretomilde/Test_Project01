﻿
namespace CIActividades
{
    public class Actividades
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        //protected Form m_oMainForm;

        CIConfigGlobalParameters.CIMenuInterface m_oMenuInterface;

        public Actividades(CIConfigGP.CIGlobalParameters oParameters, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
        {
            m_oParameters = oParameters;
            //m_oMainForm = oMainForm;
            m_oMenuInterface = oMenuInterface;

        }

        public void ControloActividades()
        {
            ActividadesForm oRes = new ActividadesForm(m_oParameters, m_oMenuInterface);
            oRes.MdiParent = m_oMenuInterface.GetMainForm();

            if (oRes.MdiParent == null)
            {
                oRes.ShowDialog();
            }
            else
            {
                oRes.Show();
            }
        }

      
        public void ControloPesquisas()
        {
            PesquisasForm oRes = new PesquisasForm(m_oParameters, m_oMenuInterface);
            oRes.MdiParent = m_oMenuInterface.GetMainForm();

            if (oRes.MdiParent == null)
            {
                oRes.ShowDialog();
            }
            else
            {
                oRes.Show();
            }
        }

        public void Alertas()
        {
            AlertasForm oAl = new AlertasForm(m_oParameters, m_oMenuInterface);
            oAl.MdiParent = m_oMenuInterface.GetMainForm();
            if (oAl.MdiParent == null)
            {
                oAl.ShowDialog();
            }
            else
            {
                oAl.Show();
            }
        }

        //SDCIM 7
        public void ControloSaco()
        {
            SacoForm oRes = new SacoForm(m_oParameters, m_oMenuInterface);
            oRes.MdiParent = m_oMenuInterface.GetMainForm();

            if (oRes.MdiParent == null)
            {
                oRes.ShowDialog();
            }
            else
            {
                oRes.Show();
            }
        }
        //SDCIM 7
        public void ControloBalcao()
        {
            ActividadeBalcaoForm oRes = new ActividadeBalcaoForm(m_oParameters, m_oMenuInterface);
            oRes.MdiParent = m_oMenuInterface.GetMainForm();

            if (oRes.MdiParent == null)
            {
                oRes.ShowDialog();
            }
            else
            {
                oRes.Show();
            }
        }
        //SDCIM 7
        public void ControloBalcaoAcoes()
        {
            ControloBalcaoAcoes oRes = new ControloBalcaoAcoes(m_oParameters, m_oMenuInterface);
            oRes.MdiParent = m_oMenuInterface.GetMainForm();

            if (oRes.MdiParent == null)
            {
                oRes.ShowDialog();
            }
            else
            {
                oRes.Show();
            }
        }
     
    }
}
