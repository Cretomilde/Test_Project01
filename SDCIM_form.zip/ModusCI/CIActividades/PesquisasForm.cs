﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using CIConfigGlobalParameters;
using NBiis;
using NBiis.Generic;
using NBIISNET;

namespace CIActividades
{

    public partial class PesquisasForm : Form
    {
        private List<Int32> _idsNotificacao = null;
        private List<Int32> _idsCancelamento = null;        
        public CIMenuInterface m_oMenuInterface;
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        private Tibco Tibco = new Tibco();
        public PesquisasForm(CIConfigGP.CIGlobalParameters oParameters, CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_oMenuInterface = oMenuInterface;
            this.LoadCbOrigem();
        }

        private void LoadCbOrigem()
        {
            try
            {
                string strQuery = "SELECT  [REMORI_ID],[REMORI_ABR] FROM [dbo].[REMESSA_ORIGEM] WHERE I_VISIVEL = 'TRUE' ORDER BY [REMORI_ABR] ASC";
                DataSet ds = m_oParameters.DirectSqlDataSet(strQuery, "REMESSA_ORIGEM");
                List<ComboBoxItem> items = new List<ComboBoxItem>();
                items.Add(new ComboBoxItem
                {
                    ISelected = true,
                    Text = "Todos",
                    Value = "0"
                });
                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    ComboBoxItem item = new ComboBoxItem
                    {
                        ISelected = false,
                        Text = oRow["REMORI_ABR"].ToString(),
                        Value = oRow["REMORI_ID"].ToString()
                    };
                    items.Add(item);
                }
                ds.Dispose();
                this.cbOrigem.DataSource = items;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
        }

        public decimal GetDecimal(string str)
        {
            if (str.Trim().Length == 0) return 0;
            string s = Convert.ToString(1.2);
            if (s.IndexOf('.') > 0) { str = str.Replace(',', '.'); } else { str = str.Replace('.', ','); }
            decimal dValor = -1;
            if (!Decimal.TryParse(str, out dValor))
            {
                dValor = -1;
            }
            return dValor;
        }

        private void definirNivelUtilizacao()
        {
            checkBoxPorAnalisar.Visible = (m_oParameters.UserLogged.m_iUserGroup < 1);
            if (m_oParameters.UserLogged.m_iUserGroup > 1)
            {
                CancelaACOMToolStripMenuItem.Enabled = false;
                confirmarCancelamentoToolStripMenuItem.Enabled = false;
                anulaCancelaToolStripMenuItem.Enabled = false;

                toolStripMenuItemENVMNotificaAcolhimento.Enabled = false;
                confirmarNotificacaoToolStripMenuItem.Enabled = false;
                toolStripMenuItemENVMAnulaNotificacao.Enabled = false;

                reapresentarCompensacaoToolStripMenuItem.Enabled = false;
                ConfirmarReapresentacaoToolStripMenuItem.Enabled = false;
                anularReapresentacaoToolStripMenuItem.Enabled = false;

                toolStripMenuItemReapresentarDOC.Enabled = false;
                toolStripMenuItemConfirmarDOC.Enabled = false;
                toolStripMenuItemAnularDOC.Enabled = false;

                cancelaDocumentoToolStripMenuItem.Enabled = false;
                confirmarCancelamentoToolStripMenuItem1.Enabled = false;
                anularCancelamentoToolStripMenuItem.Enabled = false;
                //cancelamentoOKToolStripMenuItem.Enabled = false;

                cancelaDocumentoToolStripMenuItem1.Enabled = false;
                confirmarCancelamentoToolStripMenuItem2.Enabled = false;
                anularCancelamentoToolStripMenuItem1.Enabled = false;

                NotificaACOMStripMenuItem.Enabled = false;
                ConfirmaNotificaACOMStripMenuItem.Enabled = false;
                AnulaNotificaACOMStripMenuItem.Enabled = false;

            }
        }

        private void PesquisasForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
                ////SUPFBKOFF 20 intervalo de dados por defeito passou a ser 1 dia.
                m_ctrldtFim.Value = DateTime.Now.Date;
                m_ctrldtInicio.Value = DateTime.Now.Date;
                definirNivelUtilizacao();
                m_oMenuInterface.PesquisasEnable(false);
                BotoesJanelasEnabled();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Dispose();
            }
        }

        private string FiltroNumRemessa()
        {
            if (GetDecimal(textBoxNumRemessa.Text) <= 0)
            {
                return "";
            }
            return " and REMESSA_NUMERO=" + textBoxNumRemessa.Text;
        }

        private string FiltroREFARQ_ACOM()
        {
            string sWhereClause = "";
            if (GetDecimal(textBoxREFARQ.Text) > 0)
            {
                sWhereClause += " Where (REFARQ='" + textBoxREFARQ.Text + "' or DOCACOM_REFARQ2='" + textBoxREFARQ.Text + "') ";
            }
            return sWhereClause;
        }

        private string FiltroREFARQ()
        {
            string sWhereClause = "";
            if (GetDecimal(textBoxREFARQ.Text) > 0)
            {
                sWhereClause += " Where (REFARQ='" + textBoxREFARQ.Text + "' or REFARQ_ORI='" + textBoxREFARQ.Text + "') ";
            }
            return sWhereClause;
        }

        private string FiltrosComuns()
        {
            string sWhereClause = "";
            sWhereClause = " Where (DATA between '" + m_ctrldtInicio.Value.ToString(m_oParameters.DateFormat) + "' and ";
            sWhereClause += "'" + m_ctrldtFim.Value.ToString(m_oParameters.DateFormat) + "' ";
            sWhereClause += "  or DATA2 between '" + m_ctrldtInicio.Value.ToString(m_oParameters.DateFormat) + "' and ";
            sWhereClause += "'" + m_ctrldtFim.Value.ToString(m_oParameters.DateFormat) + "') ";
            if (GetDecimal(textBoxMontante.Text) > 0)
            {
                string aux = GetDecimal(textBoxMontante.Text).ToString();
                aux = aux.Replace(",", "").Replace(",", "");
                sWhereClause += " and DOC_MONTANTE*100=" + aux;
            }
            if (GetDecimal(textBoxBalcao.Text) > 0)
            {
                sWhereClause += " and BALCAO=" + textBoxBalcao.Text;
            }
            if (GetDecimal(textBoxNumCheque.Text) > 0)
            {
                sWhereClause += " and DOC_NCHEQUE='" + textBoxNumCheque.Text + "'";
            }
            //if (GetDecimal(textBoxREFARQ.Text) > 0)
            //{
            //    sWhereClause += " and REFARQ='" + textBoxREFARQ.Text + "'";
            //}
            if (this.cbOrigem.SelectedIndex > 0)
            {
                sWhereClause += " and DOC_ORIGEM_ID=" + this.cbOrigem.SelectedValue;
            }
            return sWhereClause;
        }

        private void RefreshListaDocumento()
        {
            string padleft = "";
            if (this.textBoxBalcao.Text.Length > 0 && this.textBoxBalcao.Text.Length < 4)
            {
                padleft = textBoxBalcao.Text.PadLeft(4, '0');
                this.textBoxBalcao.Text = padleft;
            }

            listViewPesquisaDocumento.MyClear();

            string sWhereClause = FiltrosComuns();

            if (FiltroREFARQ().Length > 0)
            {
                RefreshDocumento(FiltroREFARQ());
            }
            else
            {
                if (this.cbOrigem.SelectedValue.Equals("2") && this.GetDecimal(this.txtDeposito.Text.Trim()) > 0)
                {
                    sWhereClause += " AND SEQ_DEPOSITO = " + this.txtDeposito.Text;
                }

                RefreshDocumento(sWhereClause + FiltroNumRemessa() + FiltrosBotoes());
            }
        }

        private void buttonDocumento_Click(object sender, EventArgs e)
        {
            RefreshListaDocumento();
        }

        private void RefreshDocumento(string sWhereClause)
        {
            string sQuery = "select * from VW_PESQ_DOCUMENTO " + sWhereClause + " order by REMIN_DATA, REMIN_BALCAO, REFARQ";

            SqlDataReader dr = null;
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    AddDocumento2ListView(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "RefreshDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                listViewPesquisaDocumento.EndUpdate();
                labelDOC.Text = listViewPesquisaDocumento.Items.Count.ToString() + " Registos em Remessas enviadas à Compensação";
            }
        }

        private void AddDocumento2ListView(SqlDataReader dr)
        {
            PesquisaDocumento oPd = new PesquisaDocumento(dr);
            ListViewItem olvItem = oPd.MakeListViewItem(m_oParameters.DateFormat, m_oParameters.DateTimeSysFmt);
            olvItem.Tag = oPd;
            listViewPesquisaDocumento.Items.Add(olvItem);
        }

        private string FiltrosBotoes()
        {
            string sWhereClause = "";
            if (toolStripButtonEmAnalise.Checked)
            {
                sWhereClause += " and (DOC_REAPRESENTADO is not null or DOC_CANCELADO is not null or REFARQ_ORI is not null)";
            }
            if (checkBoxPorAnalisar.Checked)
            {
                //sWhereClause += " and not (DOC_REAPRESENTADO is not null or DOC_CANCELADO is not null or REFARQ_ORI is not null)";
                sWhereClause += " and DOC_REAPRESENTADO is null and DOC_CANCELADO is null and REFARQ_ORI is null ";
            }

            /*
             * Adicionado botão para mostrar todos os registos pendentens de intervenção
             */
            if (this.cbPendenteIntervencao.Checked)
            {
                sWhereClause += " AND (CANCELA_EFECTUADO = 100 OR REAPRESENTADO_EFECTUADO = 100) ";
            }
            string sWhereStatus = "";
            if (toolStripButtonErro.Checked)
            {
                sWhereStatus += " or (REAPRESENTADO_EFECTUADO<0 or CANCELA_EFECTUADO<0)";
            }
            if (toolStripButtonMaisMenos.Checked)
            {
                sWhereStatus += " or (REAPRESENTADO_EFECTUADO<>2 and REAPRESENTADO_EFECTUADO>=0)";
                sWhereStatus += " or (CANCELA_EFECTUADO<>2 and CANCELA_EFECTUADO>=0)";
            }
            if (toolStripButtonOK.Checked)
            {
                sWhereStatus += " or (REAPRESENTADO_EFECTUADO=2 or CANCELA_EFECTUADO=2)";
            }

            if (sWhereStatus.Length > 0)
            {
                sWhereStatus = " and (" + sWhereStatus.Substring(3) + ")";
            }

            return sWhereClause + sWhereStatus;
        }

        private string FiltrosBotoesENVM()
        {
            string sWhereClause = "";
            if (toolStripButtonEmAnalise.Checked)
            {
                sWhereClause += " and (DOCENV_CANCELADO is not null or DOCENV_REAPRESENTADO is not null or DOCENV_NOTIFICADO is not null or DOCENV_DUPLICADO<>0)";
            }
            if (checkBoxPorAnalisar.Checked)
            {
                sWhereClause += " and not (DOCENV_CANCELADO is not null or DOCENV_REAPRESENTADO is not null or DOCENV_NOTIFICADO is not null or DOCENV_DUPLICADO<>0)";
            }
            /*
             * Adicionado botão para mostrar todos os registos pendentens de intervenção
             */
            if (this.cbPendenteIntervencao.Checked)
            {
                sWhereClause += " AND (NOTIFICA_EFECTUADO = 100 OR REAPRESENTADO_EFECTUADO = 100) ";
            }
            string sWhereStatus = "";
            if (toolStripButtonErro.Checked)
            {
                sWhereStatus += " or (REAPRESENTADO_EFECTUADO<0 or NOTIFICA_EFECTUADO<0)";
            }
            if (toolStripButtonMaisMenos.Checked)
            {
                sWhereStatus += " or (REAPRESENTADO_EFECTUADO<>2 and REAPRESENTADO_EFECTUADO>=0)";
                sWhereStatus += " or (NOTIFICA_EFECTUADO<>2 and NOTIFICA_EFECTUADO>=0)";
                //                sWhereStatus += " or (DOCENV_DUPLICADO<>0)";
            }
            if (toolStripButtonOK.Checked)
            {
                sWhereStatus += " or (REAPRESENTADO_EFECTUADO=2 or NOTIFICA_EFECTUADO=2)";
            }

            if (sWhereStatus.Length > 0)
            {
                sWhereStatus = " and (" + sWhereStatus.Substring(3) + ")";
            }

            return sWhereClause + sWhereStatus;
        }

        private string FiltrosBotoesACOM()
        {
            string sWhereClause = "";
            if (toolStripButtonEmAnalise.Checked)
            {
                sWhereClause += " and (DOCACOM_CANCELADO is not null or DOCACOM_NOTIFICADO is not null or ESTADO_ALERTA=1)";
            }
            if (checkBoxPorAnalisar.Checked)
            {
                sWhereClause += " and not (DOCACOM_CANCELADO is not null or DOCACOM_NOTIFICADO is not null or ESTADO_ALERTA=1)";
            }
            /*
             * Adicionado botão para mostrar todos os registos pendentens de intervenção
             */
            if (this.cbPendenteIntervencao.Checked)
            {
                sWhereClause += " AND (CANCELA_EFECTUADO = 100 OR NOTIFICA_EFECTUADO = 100) ";
            }
            string sWhereStatus = "";
            if (toolStripButtonErro.Checked)
            {
                sWhereStatus += " or (CANCELA_EFECTUADO<0 or NOTIFICA_EFECTUADO<0)";
            }
            if (toolStripButtonMaisMenos.Checked)
            {
                sWhereStatus += " or (CANCELA_EFECTUADO<>2 and CANCELA_EFECTUADO>=0)";
                sWhereStatus += " or (NOTIFICA_EFECTUADO<>2 and NOTIFICA_EFECTUADO>=0)";
            }
            if (toolStripButtonOK.Checked)
            {
                sWhereStatus += " or (CANCELA_EFECTUADO=2 or NOTIFICA_EFECTUADO=2)";
            }

            if (sWhereStatus.Length > 0)
            {
                sWhereStatus = " and (" + sWhereStatus.Substring(3) + ")";
            }

            return sWhereClause + sWhereStatus;
        }

        private void RefreshListaENVM()
        {
            listViewPesquisaDocumentoENVM.MyClear();
            if (FiltroREFARQ().Length > 0)
            {
                RefreshDocumentoENVM(FiltroREFARQ());
            }
            else
            {
                string sWhereClause = FiltrosComuns();
                String innerJoin = String.Empty;
                if (this.cbOrigem.SelectedValue.Equals("2") && this.GetDecimal(this.txtDeposito.Text.Trim()) > 0)
                {
                    innerJoin = @" INNER JOIN dbo.DOCUMENTO_BALCAO as docBalcao ON docBalcao.ID = DOC_ID 
                                         INNER JOIN dbo.REMESSA_BALCAO as rem ON rem.ID = docBalcao.REMBALCAO_ID ";
                    sWhereClause += " AND rem.REMBALCAO_SEQUENCIA = " + this.txtDeposito.Text;
                }
                this.RefreshDocumentoENVM(String.Format(" {0} {1} {2} ", innerJoin, sWhereClause, FiltrosBotoesENVM()));
            }
        }

        private void buttonENVM_Click(object sender, EventArgs e)
        {
            RefreshListaENVM();
        }
        private void RefreshDocumentoENVM(string sWhereClause)
        {
            string sQuery = "select * from VW_PESQ_DOCUMENTO_ENVM " + sWhereClause + " order by FICH_DATA";

            SqlDataReader dr = null;
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    AddDocumento2ListViewENVM(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "RefreshDocumentoENVM()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                listViewPesquisaDocumentoENVM.EndUpdate();
                labelENVM.Text = listViewPesquisaDocumentoENVM.Items.Count.ToString() + " Registos em ENVM";
            }
        }

        private void AddDocumento2ListViewENVM(SqlDataReader dr)
        {
            PesquisaDocumentoENVM oPd = new PesquisaDocumentoENVM(dr);

            ListViewItem olvItem = oPd.MakeListViewItem(m_oParameters.DateFormat);

            olvItem.Tag = oPd;

            listViewPesquisaDocumentoENVM.Items.Add(olvItem);
        }

        private void RefreshListaACOM()
        {
            listViewPesquisaDocumentoACOM.MyClear();
            if (FiltroREFARQ().Length > 0)
            {
                RefreshDocumentoACOM(FiltroREFARQ_ACOM());
            }
            else
            {
                string sWhereClause = FiltrosComuns();
                String innerJoin = String.Empty;
                if (this.cbOrigem.SelectedValue.Equals("2") && this.GetDecimal(this.txtDeposito.Text.Trim()) > 0)
                {
                    innerJoin = @" INNER JOIN dbo.DOCUMENTO_BALCAO as docBalcao ON docBalcao.ID = DOC_ID 
                                         INNER JOIN dbo.REMESSA_BALCAO as rem ON rem.ID = docBalcao.REMBALCAO_ID ";
                    sWhereClause += " AND rem.REMBALCAO_SEQUENCIA = " + this.txtDeposito.Text;
                }
                this.RefreshDocumentoACOM(String.Format(" {0} {1} {2} ", innerJoin, sWhereClause, FiltrosBotoesACOM()));
            }
        }
        private void buttonACOM_Click(object sender, EventArgs e)
        {
            RefreshListaACOM();
        }
        private void RefreshDocumentoACOM(string sWhereClause)
        {
            string sQuery = "select * from VW_PESQ_DOCUMENTO_ACOM " + sWhereClause + " order by FICH_DATA";

            SqlDataReader dr = null;
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    AddDocumento2ListViewACOM(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "RefreshDocumentoACOM()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                listViewPesquisaDocumentoACOM.EndUpdate();
                labelACOM.Text = listViewPesquisaDocumentoACOM.Items.Count.ToString() + " Registos em ACOM";
            }
        }
        private void AddDocumento2ListViewACOM(SqlDataReader dr)
        {
            PesquisaDocumentoACOM oPd = new PesquisaDocumentoACOM(dr);

            ListViewItem olvItem = oPd.MakeListViewItem(m_oParameters.DateFormat);

            olvItem.Tag = oPd;

            listViewPesquisaDocumentoACOM.Items.Add(olvItem);
        }

        private void toolStripButtonExitJanela_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

  

        private void CancelaACOMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_ID;
                    Tibco.Insert_TibcoCancelaEnvioDocumento((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag,m_oParameters);
                    GenericLog.GenLogRegistarInfo("DocACOM Cancelado", "Insert_TibcoCancelaEnvioDocumento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Acolhimento dos documentos cancelado", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Insert_TibcoCancelaEnvioDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaACOM();
            }
        }

        private void anulaCancelaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_ID;
                    Tibco.Delete_TibcoCancelaEnvioDocumento(((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_CANCELADO,m_oParameters);
                    GenericLog.GenLogRegistarInfo("Anulado o Cancelamento DocACOM", "Delete_TibcoCancelaEnvioDocumento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Anulado o Cancelamento do Acolhimento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Delete_TibcoCancelaChaveDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaACOM();
            }
        }

        private void toolStripMenuItemENVMNotificaAcolhimento_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoENVM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoENVM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_ID;
                    Tibco.Insert_TibcoCancelaChaveDocumento((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag, m_oParameters);
                    GenericLog.GenLogRegistarInfo("DocENVM Notificado", "Insert_TibcoNotificaEnvioDocumentoForaPrazo()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Notificação de envio de documentos fora de prazo para acolhimento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Insert_TibcoNotificaEnvioDocumentoForaPrazo()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaENVM();
            }
        }

        private void confirmarCancelamentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_ID;
                    Tibco.Confirma_TibcoCancelaEnvioDocumento(((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_CANCELADO, 0,m_oParameters);
                    GenericLog.GenLogRegistarInfo("Confirmado o Cancelamento DocACOM", "Update_ConfirmaTibcoCancelaEnvioDocumento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Confirmado o Cancelamento do Acolhimento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Confirma_TibcoCancelaEnvioDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaACOM();
            }
        }

        private void confirmarNotificacaoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoENVM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoENVM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_ID;
                    Tibco.Confirma_TibcoNotificaEnvioDocumentoForaPrazo(((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_NOTIFICADO,m_oParameters);
                    GenericLog.GenLogRegistarInfo("DocENVM Notifica Confirma", "Confirma_TibcoNotificaEnvioDocumentoForaPrazo()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Confirma Notificação de envio de documentos fora de prazo para acolhimento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Confirma_TibcoNotificaEnvioDocumentoForaPrazo()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaENVM();
            }
        }

        private void toolStripMenuItemENVMAnulaNotificacao_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoENVM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoENVM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_ID;
                    Tibco.Anula_TibcoNotificaEnvioDocumentoForaPrazo(((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_NOTIFICADO,m_oParameters);
                    GenericLog.GenLogRegistarInfo("DocENVM Notifica Anula", "Anula_TibcoNotificaEnvioDocumentoForaPrazo()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Anula Notificação de envio de documentos fora de prazo para acolhimento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Anula_TibcoNotificaEnvioDocumentoForaPrazo()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaENVM();
            }
        }

        private void reapresentarCompensacaoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoENVM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoENVM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_ID;
                    Reapresentar_Documento((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag);
                    GenericLog.GenLogRegistarInfo("DocENVM Reapresentar_Documento", "Reapresentar_Documento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Reapresentar Documentos", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Reapresentar_Documento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaENVM();
            }
        }

        private void ConfirmarReapresentacaoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoENVM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoENVM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_ID;
                    Confirmar_Reapresentar_Documento(((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_REAPRESENTADO);
                    GenericLog.GenLogRegistarInfo("DocENVM Confirmar_Reapresentar_Documento", "Confirmar_Reapresentar_Documento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Confirmar Reapresentar Documentos", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Confirmar_Reapresentar_Documento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaENVM();
            }
        }

        private void anularReapresentacaoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoENVM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoENVM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_ID;
                    Anular_Reapresentar_Documento(((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_REAPRESENTADO);
                    GenericLog.GenLogRegistarInfo("DocENVM Anular_Reapresentar_Documento", "Anular_Reapresentar_Documento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Anular Reapresentar Documentos", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Anular_Reapresentar_Documento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaENVM();
            }
        }

       
        public void Reapresentar_Documento(PesquisaDocumento oDoc)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@Doc_id", oDoc.m_sDOC_ID));
            oParams.Add(new GeneralDBParameters("@REFARQ", oDoc.m_sREFARQ));
            oParams.Add(new GeneralDBParameters("@DOC_ISREAPRESENTADO", oDoc.m_sDOC_ISREAPRESENTADO));
            //SDCIM 7 - Adicionar origem ao documento
            oParams.Add(new GeneralDBParameters("@DOC_OrigemID", oDoc.m_sDocOrigemID));
            //SDCIM 7 - Adicionar origem ao documento
            m_oParameters.DirectStoredProcedureNonQuery("[dbo].[Insert_ReapresentarDocumentoCompensacao]", ref oParams);
        }
        public void Reapresentar_Documento(PesquisaDocumentoENVM oDoc)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@Docenv_id", oDoc.m_sDOCENV_ID));

            m_oParameters.DirectStoredProcedureNonQuery("[dbo].[Insert_ReapresentarDocumentoCompensacao]", ref oParams);
        }
        public void Confirmar_Reapresentar_Documento(string sREAPRESENTADO)
        {
            try
            {
                m_oParameters.BeginTrans(IsolationLevel.ReadCommitted);

                ArrayList oParams = new ArrayList();
                oParams.Add(new GeneralDBParameters("@Reapresentado", sREAPRESENTADO));

                m_oParameters.DirectStoredProcedureNonQuery("[dbo].[Update_ConfirmarReapresentarDocumentoCompensacao]", ref oParams);

                m_oParameters.Commit();
            }
            catch
            {
                m_oParameters.RollBack();
                throw;
            }
        }

        public void Anular_Reapresentar_Documento(string sREAPRESENTADO)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@Reapresentado", sREAPRESENTADO));

            m_oParameters.DirectStoredProcedureNonQuery("[dbo].[Delete_ReapresentarDocumentoCompensacao]", ref oParams);
        }

        private void listViewPesquisaDocumento_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            PesquisaDocumento oDoc = (PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[0].Tag;
            MostraImagem fMostraImg = new MostraImagem(m_oParameters, oDoc, Convert.ToInt32(oDoc.m_sDocOrigemID));
            fMostraImg.ShowDialog();
        }

        private void toolStripMenuItemReapresentarDOC_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumento.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumento.SelectedItems.Count; i++)
                {
                    int sID = ((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag).m_sDOC_ID;
                    Reapresentar_Documento((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag);
                    GenericLog.GenLogRegistarInfo("Doc Reapresentar_Documento", "Reapresentar_Documento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Reapresentar Documentos", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Reapresentar_Documento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaDocumento();
            }
        }

        private void toolStripMenuItemConfirmarDOC_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumento.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumento.SelectedItems.Count; i++)
                {
                    int sID = ((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag).m_sDOC_ID;
                    Confirmar_Reapresentar_Documento(((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag).m_sDOC_REAPRESENTADO);
                    GenericLog.GenLogRegistarInfo("Doc Confirmar_Reapresentar_Documento", "Confirmar_Reapresentar_Documento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Confirmar Reapresentar Documentos", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Confirmar_Reapresentar_Documento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaDocumento();
            }
        }

        private void toolStripMenuItemAnularDOC_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumento.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumento.SelectedItems.Count; i++)
                {
                    int sID = ((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag).m_sDOC_ID;
                    Anular_Reapresentar_Documento(((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag).m_sDOC_REAPRESENTADO);
                    GenericLog.GenLogRegistarInfo("Doc Anular_Reapresentar_Documento", "Anular_Reapresentar_Documento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Anular Reapresentar Documentos", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Anular_Reapresentar_Documento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaDocumento();
            }
        }

        private void BotoesJanelasEnabled()
        {
            //if (toolStripButtonRem.Checked)
            //{
            //}
            //if (toolStripButtonENVM.Checked)
            //{
            //}
            //if (toolStripButtonACOM.Checked)
            //{
            //}
            splitContainer1.Panel1Collapsed = !toolStripButtonRem.Checked;
            splitContainer1.Panel2Collapsed = !toolStripButtonENVM.Checked && !toolStripButtonACOM.Checked;
            splitContainer2.Panel1Collapsed = !toolStripButtonENVM.Checked;
            splitContainer2.Panel2Collapsed = !toolStripButtonACOM.Checked;
        }

        private void toolStripButtonRem_Click(object sender, EventArgs e)
        {
            BotoesJanelasEnabled();
        }

        private void toolStripButtonENVM_Click(object sender, EventArgs e)
        {
            BotoesJanelasEnabled();
        }

        private void toolStripButtonACOM_Click(object sender, EventArgs e)
        {
            BotoesJanelasEnabled();
        }

        private void Historico_Documento(string sREFARQ, int iOrigem)
        //private void Historico_Documento(string sNUMERO_CHEQUE, int iOrigem)
        {
            string sWhereClause = " WHERE REFARQ='" + sREFARQ + "'";
            //string sWhereClause = " WHERE NUMERO_CHEQUE='" + sNUMERO_CHEQUE + "'";
            switch (iOrigem)
            {
                case 1:
                    listViewPesquisaDocumento.MyClear();
                    listViewPesquisaDocumentoENVM.MyClear();
                    listViewPesquisaDocumentoACOM.MyClear();
                    RefreshDocumento(sWhereClause);
                    RefreshDocumentoENVM(sWhereClause);
                    RefreshDocumentoACOM(sWhereClause);
                    break;
                case 2:
                    listViewPesquisaDocumento.MyClear();
                    listViewPesquisaDocumentoENVM.MyClear();
                    listViewPesquisaDocumentoACOM.MyClear();
                    RefreshDocumento(sWhereClause);
                    RefreshDocumentoENVM(sWhereClause);
                    RefreshDocumentoACOM(sWhereClause);
                    break;
                case 3:
                    listViewPesquisaDocumento.MyClear();
                    listViewPesquisaDocumentoENVM.MyClear();
                    listViewPesquisaDocumentoACOM.MyClear();
                    RefreshDocumento(sWhereClause);
                    RefreshDocumentoENVM(sWhereClause);
                    RefreshDocumentoACOM(sWhereClause);
                    break;
            }
        }

        private void historicoDoDocumentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumento.SelectedItems.Count != 1)
                return;

            try
            {
                //string sNUMERO_CHEQUE = ((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[0].Tag).m_sDOC_ZONA3;
                string sRefArq = ((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[0].Tag).m_sREFARQ;
                Historico_Documento(sRefArq, 1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripMenuItemHistoricoENVM_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoENVM.SelectedItems.Count != 1)
                return;

            try
            {
                //string sNUMERO_CHEQUE = ((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[0].Tag).m_sDOCENV_ZONA3;
                string sRefArq = ((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[0].Tag).m_sDOCENV_REFARQ;
                Historico_Documento(sRefArq, 2);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ToolStripMenuItemHistoricoACOM_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoACOM.SelectedItems.Count != 1)
                return;

            try
            {
                //string sNUMERO_CHEQUE = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[0].Tag).m_sDOCACOM_ZONA3;
                string sRefArq = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[0].Tag).m_sREFARQ;
                Historico_Documento(sRefArq, 3);
                //Historico_Documento(sNUMERO_CHEQUE, 3);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cancelaDocumentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumento.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumento.SelectedItems.Count; i++)
                {
                    int sID = ((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag).m_sDOC_ID;
                    Tibco.Insert_TibcoCancelaChaveDocumento((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag,m_oParameters);
                    GenericLog.GenLogRegistarInfo("Doc Cancelado", "Insert_TibcoCancelaChaveDocumento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Documentos cancelado", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Insert_TibcoCancelaChaveDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaDocumento();
            }
        }

        private void confirmarCancelamentoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumento.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumento.SelectedItems.Count; i++)
                {
                    int sID = ((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag).m_sDOC_ID;
                    Tibco.Confirma_TibcoCancelaChaveDocumento(((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag).m_sDOC_CANCELADO, 0,m_oParameters);
                    GenericLog.GenLogRegistarInfo("Confirmado o Cancelamento Doc", "Delete_TibcoCancelaChaveDocumento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Confirmado o Cancelamento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Confirma_TibcoCancelaChaveDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaDocumento();
            }
        }

        private void anularCancelamentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumento.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumento.SelectedItems.Count; i++)
                {
                    int sID = ((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag).m_sDOC_ID;
                    Tibco.Delete_TibcoCancelaEnvioDocumento(((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag).m_sDOC_CANCELADO,m_oParameters);
                    GenericLog.GenLogRegistarInfo("Anulado o Cancelamento Doc", "Delete_TibcoCancelaChaveDocumento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Anulado o Cancelamento do DOC", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Delete_TibcoCancelaChaveDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaDocumento();
            }
        }

        private void cancelaDocumentoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoENVM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoENVM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_ID;
                    Tibco.Insert_TibcoCancelaChaveDocumento((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag,m_oParameters);
                    GenericLog.GenLogRegistarInfo("DocENV Cancelado", "Insert_TibcoCancelaChaveDocumento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Documentos ENVM cancelados", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Insert_TibcoCancelaChaveDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaENVM();
            }
        }

        private void confirmarCancelamentoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoENVM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoENVM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_ID;
                    Tibco.Confirma_TibcoCancelaChaveDocumento(((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_CANCELADO, 0,m_oParameters);
                    GenericLog.GenLogRegistarInfo("Confirmado o Cancelamento DocENV", "Delete_TibcoCancelaChaveDocumento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Confirmado o Cancelamento do DOCENV", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Confirma_TibcoCancelaChaveDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaENVM();
            }
        }

        private void anularCancelamentoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoENVM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoENVM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_ID;
                    Tibco.Delete_TibcoCancelaEnvioDocumento(((PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag).m_sDOCENV_CANCELADO,m_oParameters);
                    GenericLog.GenLogRegistarInfo("Anulado o Cancelamento DocENV", "Delete_TibcoCancelaChaveDocumento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Anulado o Cancelamento do DOCENV", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Delete_TibcoCancelaChaveDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaENVM();
            }
        }

        private void NotificaACOMStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_ID;
                    Tibco.Insert_TibcoNotificaEnvioDocumentoForaPrazo((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag,m_oParameters);
                    GenericLog.GenLogRegistarInfo("DocACOM Notificado", "Insert_TibcoNotificaEnvioDocumentoForaPrazo()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Notificação de envio de documentos fora de prazo para acolhimento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Insert_TibcoNotificaEnvioDocumentoForaPrazo()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaACOM();
            }
        }

        private void ConfirmaNotificaACOMStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_ID;
                    Tibco.Confirma_TibcoNotificaEnvioDocumentoForaPrazo(((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_NOTIFICADO,m_oParameters);
                    GenericLog.GenLogRegistarInfo("DocACOM Notifica Confirma", "Confirma_TibcoNotificaEnvioDocumentoForaPrazo()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Confirma Notificação de envio de documentos fora de prazo para acolhimento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Confirma_TibcoNotificaEnvioDocumentoForaPrazo()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaACOM();
            }
        }

        private void AnulaNotificaACOMStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_ID;
                    Tibco.Anula_TibcoNotificaEnvioDocumentoForaPrazo(((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_NOTIFICADO,m_oParameters);
                    GenericLog.GenLogRegistarInfo("DocACOM Notifica Anula", "Anula_TibcoNotificaEnvioDocumentoForaPrazo()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Anula Notificação de envio de documentos fora de prazo para acolhimento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Anula_TibcoNotificaEnvioDocumentoForaPrazo()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaACOM();
            }
        }

        private void marcarCancelamentoComEfectuadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumento.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewPesquisaDocumento.SelectedItems.Count; i++)
                {
                    int sID = ((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag).m_sDOC_ID;
                    Tibco.Confirma_TibcoCancelaChaveDocumento(((PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag).m_sDOC_CANCELADO, 2,m_oParameters);
                    GenericLog.GenLogRegistarInfo("Cancelamento marcado como efectuado", "Confirma_TibcoCancelaChaveDocumento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Cancelamento marcado como efectuado", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Confirma_TibcoCancelaChaveDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaDocumento();
            }
        }

        private void textBoxBalcao_TextChanged(object sender, EventArgs e)
        {
            this.ValidarNumerico(this.textBoxBalcao);
        }

        private void txtDeposito_TextChanged(object sender, EventArgs e)
        {
            this.ValidarNumerico(this.txtDeposito);
        }

        private void textBoxNumRemessa_TextChanged(object sender, EventArgs e)
        {
            this.ValidarNumerico(this.textBoxNumRemessa);
        }

        private void textBoxMontante_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(this.textBoxMontante.Text, "[^0-9]"))
            {
                MessageBox.Show("Montante não deve conter separador decimal");
                this.textBoxMontante.Text= this.textBoxMontante.Text.Remove(this.textBoxMontante.Text.Length - 1);
            }
        }

        private void textBoxREFARQ_TextChanged(object sender, EventArgs e)
        {
            this.ValidarNumerico(this.textBoxREFARQ);
        }

        private void textBoxNumCheque_TextChanged(object sender, EventArgs e)
        {
            this.ValidarNumerico(this.textBoxNumCheque);
        }

        private void ValidarNumerico(TextBox txtValidar)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txtValidar.Text, "[^0-9]"))
            {
                MessageBox.Show("Campo numérico");
                txtValidar.Text = txtValidar.Text.Remove(txtValidar.Text.Length - 1);
            }
        }

        private void cbOrigem_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.txtDeposito.Enabled = false;
            this.txtDeposito.Text = String.Empty;
            if (this.cbOrigem.SelectedValue.Equals("2"))
            {
                this.txtDeposito.Enabled = true;
            }
        }

        #region SDCIM 7 - Eventos menuStrip

        private void contextMenuStripENVM_Opening(object sender, CancelEventArgs e)
        {
            /*
             * SDCIM 7 - Mostrar opções de acordo com Origem
             */
            if (this.listViewPesquisaDocumentoENVM.SelectedItems.Count < 1)
            {
                e.Cancel = true;
                return;
            }

            for (int i = 0; i < this.listViewPesquisaDocumentoENVM.SelectedItems.Count; i++)
            {
                PesquisaDocumentoENVM docEnvm = (PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[i].Tag;
                Int32 id = 0;
                Int32.TryParse(docEnvm.m_sDocOrigemID, out id);
                switch ((RemessaOrigem)id)
                {
                    case RemessaOrigem.GCCA:
                        this.EnabledMenuStripEnvm(true);

                        if (!docEnvm.m_sCANCELA_EFECTUADO.Equals("100"))
                        {
                            //SDCIM 7 - Caso seja erro tem de ser possível anular. Estado < 0
                            if (!String.IsNullOrEmpty(docEnvm.m_sCANCELA_EFECTUADO) && Convert.ToInt32(docEnvm.m_sCANCELA_EFECTUADO) < 0)
                            {
                                this.anularCancelamentoToolStripMenuItem1.Enabled = true;
                            }
                            else
                            {
                                this.anularCancelamentoToolStripMenuItem1.Enabled = false;
                            }
                            this.confirmarCancelamentoToolStripMenuItem2.Enabled = false;
                        }
                        else
                        {
                            this.cancelaDocumentoToolStripMenuItem1.Enabled = false;
                        }

                        if (!docEnvm.m_sREAPRESENTADO_EFECTUADO.Equals("100"))
                        {
                            //SDCIM 7 - Caso seja erro tem de ser possível anular. Estado < 0
                            if (!String.IsNullOrEmpty(docEnvm.m_sREAPRESENTADO_EFECTUADO) && Convert.ToInt32(docEnvm.m_sREAPRESENTADO_EFECTUADO) < 0)
                            {
                                this.anularReapresentacaoToolStripMenuItem.Enabled = true;
                            }
                            else
                            {
                                this.anularReapresentacaoToolStripMenuItem.Enabled = false;
                            }
                            this.ConfirmarReapresentacaoToolStripMenuItem.Enabled = false;
                        }
                        else
                        {
                            this.reapresentarCompensacaoToolStripMenuItem.Enabled = false;
                        }
                        break;
                    case RemessaOrigem.Balcao:
                        this.EnabledMenuStripEnvm(false);
                        //SDCIM 7 - Caso seja erro tem de ser possível anular. Estado < 0
                        if (!String.IsNullOrEmpty(docEnvm.m_sCANCELA_EFECTUADO) && Convert.ToInt32(docEnvm.m_sCANCELA_EFECTUADO) < 0)
                        {
                            this.anularCancelamentoToolStripMenuItem1.Enabled = true;
                        }
                        //SDCIM 7 - Caso seja erro tem de ser possível anular. Estado < 0
                        if (!String.IsNullOrEmpty(docEnvm.m_sREAPRESENTADO_EFECTUADO) && Convert.ToInt32(docEnvm.m_sREAPRESENTADO_EFECTUADO) < 0)
                        {
                            this.anularReapresentacaoToolStripMenuItem.Enabled = true;
                        }
                        this.toolStripMenuItemHistoricoENVM.Enabled = true;
                        break;
                    default:
                        this.EnabledMenuStripEnvm(false);
                        break;
                }
                this.toolStripMenuItemENVMNotificaAcolhimento.Visible = false;
                this.confirmarNotificacaoToolStripMenuItem.Visible = false;
                this.toolStripMenuItemENVMAnulaNotificacao.Visible = false;
                this.toolStripMenuItem1.Visible = false;
            }
            /*
             * SDCIM 7 - Mostrar opções de acordo com Origem
             */
        }

        private void EnabledMenuStripEnvm(Boolean enabled)
        {
            this.toolStripMenuItemENVMNotificaAcolhimento.Enabled = enabled;
            this.confirmarNotificacaoToolStripMenuItem.Enabled = enabled;
            this.toolStripMenuItemENVMAnulaNotificacao.Enabled = enabled;
            this.reapresentarCompensacaoToolStripMenuItem.Enabled = enabled;
            this.ConfirmarReapresentacaoToolStripMenuItem.Enabled = enabled;
            this.anularReapresentacaoToolStripMenuItem.Enabled = enabled;
            this.toolStripMenuItemHistoricoENVM.Enabled = enabled;
            this.cancelaDocumentoToolStripMenuItem1.Enabled = enabled;
            this.confirmarCancelamentoToolStripMenuItem2.Enabled = enabled;
            this.anularCancelamentoToolStripMenuItem1.Enabled = enabled;
            this.toolStripMenuItem1.Enabled = enabled;
            this.toolStripMenuItem3.Enabled = enabled;
            this.toolStripMenuItem6.Enabled = enabled;
        }

        private void contextMenuStripACOM_Opening(object sender, CancelEventArgs e)
        {
            /*
             * SDCIM 7 - Mostrar opções de acordo com Origem
             */
            if (this.listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
            {
                e.Cancel = true;
                return;
            }

            for (int i = 0; i < this.listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
            {
                PesquisaDocumentoACOM docAcom = (PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag;
                Int32 id = 0;
                Int32.TryParse(docAcom.m_sDocOrigemID, out id);
                switch ((RemessaOrigem)id)
                {
                    case RemessaOrigem.GCCA:
                    case RemessaOrigem.Balcao:
                        this.EnabledMenuStripAcom(true);
                        if (!this.TryCancelamento(docAcom))
                        {
                            this.CancelaACOMToolStripMenuItem.Enabled = false;
                        }
                        if (!this.TryNotificacao(docAcom))
                        {
                            this.NotificaACOMStripMenuItem.Enabled = false;
                        }
                        if (!docAcom.m_sCANCELA_EFECTUADO.Equals("100"))
                        {
                            //SDCIM 7 - Caso seja erro tem de ser possível anular. Estado < 0
                            if (!String.IsNullOrEmpty(docAcom.m_sCANCELA_EFECTUADO) && Convert.ToInt32(docAcom.m_sCANCELA_EFECTUADO) < 0)
                            {
                                this.anulaCancelaToolStripMenuItem.Enabled = true;
                            }
                            else
                            {
                                this.anulaCancelaToolStripMenuItem.Enabled = false;
                            }
                            this.confirmarCancelamentoToolStripMenuItem.Enabled = false;
                        }
                        else
                        {
                            this.CancelaACOMToolStripMenuItem.Enabled = false;
                        }
                        if (!docAcom.m_sNOTIFICA_EFECTUADO.Equals("100"))
                        {
                            //SDCIM 7 - Caso seja erro tem de ser possível anular. Estado < 0
                            if (!String.IsNullOrEmpty(docAcom.m_sNOTIFICA_EFECTUADO) && Convert.ToInt32(docAcom.m_sNOTIFICA_EFECTUADO) < 0)
                            {
                                this.AnulaNotificaACOMStripMenuItem.Enabled = true;
                            }
                            else
                            {
                                this.AnulaNotificaACOMStripMenuItem.Enabled = false;
                            }
                            this.ConfirmaNotificaACOMStripMenuItem.Enabled = false;
                        }
                        else
                        {
                            this.NotificaACOMStripMenuItem.Enabled = false;
                        }
                        break;
                    default:
                        this.EnabledMenuStripAcom(false);
                        break;
                }
            }
        }

        private void EnabledMenuStripAcom(Boolean enabled)
        {
            this.CancelaACOMToolStripMenuItem.Enabled = enabled;
            this.confirmarCancelamentoToolStripMenuItem.Enabled = enabled;
            this.anulaCancelaToolStripMenuItem.Enabled = enabled;
            this.ToolStripMenuItemHistoricoACOM.Enabled = enabled;
            this.NotificaACOMStripMenuItem.Enabled = enabled;
            this.ConfirmaNotificaACOMStripMenuItem.Enabled = enabled;
            this.AnulaNotificaACOMStripMenuItem.Enabled = enabled;
            this.toolStripMenuItem4.Enabled = enabled;
            this.toolStripMenuItem7.Enabled = enabled;
        }

        private void contextMenuStripDOC_Opening(object sender, CancelEventArgs e)
        {
            /*
             * SDCIM 7 - Mostrar opções de acordo com Origem
             */
            if (this.listViewPesquisaDocumento.SelectedItems.Count < 1)
            {
                e.Cancel = true;
                return;
            }

            for (int i = 0; i < this.listViewPesquisaDocumento.SelectedItems.Count; i++)
            {
                PesquisaDocumento doc = (PesquisaDocumento)listViewPesquisaDocumento.SelectedItems[i].Tag;
                Int32 id = 0;
                Int32.TryParse(doc.m_sDocOrigemID, out id);
                switch ((RemessaOrigem)id)
                {
                    case RemessaOrigem.GCCA:
                        this.EnabledMenuStripCompensacao(true);
                        if (!doc.m_sCANCELA_EFECTUADO.Equals("100"))
                        {
                            if (!String.IsNullOrEmpty(doc.m_sCANCELA_EFECTUADO) && Convert.ToInt32(doc.m_sCANCELA_EFECTUADO) < 0)
                            {
                                this.anularCancelamentoToolStripMenuItem.Enabled = true;
                            }
                            else
                            {
                                this.anularCancelamentoToolStripMenuItem.Enabled = false;
                            }
                            this.confirmarCancelamentoToolStripMenuItem1.Enabled = false;
                            this.marcarCancelamentoComEfectuadoToolStripMenuItem.Enabled = false;
                        }
                        else
                        {
                            this.cancelaDocumentoToolStripMenuItem.Enabled = false;
                        }
                        if (!doc.m_sREAPRESENTADO_EFECTUADO.Equals("100"))
                        {

                            if (!String.IsNullOrEmpty(doc.m_sREAPRESENTADO_EFECTUADO) && Convert.ToInt32(doc.m_sREAPRESENTADO_EFECTUADO) < 0)
                            {
                                this.toolStripMenuItemAnularDOC.Enabled = true;
                            }
                            else
                            {
                                this.toolStripMenuItemAnularDOC.Enabled = false;
                            }
                            this.toolStripMenuItemConfirmarDOC.Enabled = false;

                        }
                        else
                        {
                            this.toolStripMenuItemReapresentarDOC.Enabled = false;
                        }
                        break;
                    case RemessaOrigem.Balcao:
                        this.EnabledMenuStripCompensacao(false);
                        if (!String.IsNullOrEmpty(doc.m_sCANCELA_EFECTUADO) && Convert.ToInt32(doc.m_sCANCELA_EFECTUADO) < 0)
                        {
                            this.anularCancelamentoToolStripMenuItem.Enabled = true;
                        }
                        if (!String.IsNullOrEmpty(doc.m_sREAPRESENTADO_EFECTUADO) && Convert.ToInt32(doc.m_sREAPRESENTADO_EFECTUADO) < 0)
                        {
                            this.toolStripMenuItemAnularDOC.Enabled = true;
                        }
                        this.historicoDoDocumentoToolStripMenuItem.Enabled = true;
                        break;
                    default:
                        this.EnabledMenuStripCompensacao(false);
                        break;
                }
            }
        }

        private void EnabledMenuStripCompensacao(Boolean enabled)
        {
            this.toolStripMenuItemReapresentarDOC.Enabled = enabled;
            this.toolStripMenuItemConfirmarDOC.Enabled = enabled;
            this.toolStripMenuItemAnularDOC.Enabled = enabled;
            this.historicoDoDocumentoToolStripMenuItem.Enabled = enabled;
            this.cancelaDocumentoToolStripMenuItem.Enabled = enabled;
            this.confirmarCancelamentoToolStripMenuItem1.Enabled = enabled;
            this.anularCancelamentoToolStripMenuItem.Enabled = enabled;
            this.marcarCancelamentoComEfectuadoToolStripMenuItem.Enabled = enabled;
            this.toolStripMenuItem2.Enabled = enabled;
            this.toolStripMenuItem5.Enabled = enabled;
        }

        /// <summary>
        /// Método que verifica a possibilidade de se enviar para "notificação fora de prazo" o documento ACOM
        /// </summary>
        /// <param name="docENVM">Documento ENVM</param>
        /// <returns>TRUE se pode notificar, FALSE caso contrário</returns>
        private Boolean TryNotificacao(PesquisaDocumentoACOM docACOM)
        {
            if (this._idsNotificacao == null)
                this.LoadIDSNotificaoOrCancelamento();

            if (this._idsNotificacao.Count > 0 && this._idsNotificacao.Contains(Convert.ToInt32(docACOM.m_sDOCACOM_CODANA))
                && DateTime.Now.Date >= docACOM.m_dtFICH_DATA.AddDays(1).Date)
                return true;
            return false;
        }

        /// <summary>
        /// Método que verifica a possibilidade de se enviar para "notificação fora de prazo" o documento ACOM
        /// </summary>
        /// <param name="docENVM">Documento ENVM</param>
        /// <returns>TRUE se pode notificar, FALSE caso contrário</returns>
        private Boolean TryCancelamento(PesquisaDocumentoACOM docACOM)
        {
            if (this._idsCancelamento == null)
                this.LoadIDSNotificaoOrCancelamento();

            if (this._idsCancelamento.Count > 0 && this._idsCancelamento.Contains(Convert.ToInt32(docACOM.m_sDOCACOM_CODANA)))
                return true;
            return false;
        }

        /// <summary>
        /// Carrega os ids de estados de cancelamento e notificação para documentos ACOM
        /// </summary>
        private void LoadIDSNotificaoOrCancelamento()
        {
            this._idsNotificacao = new List<int>();
            this._idsCancelamento = new List<int>();
            String sQuery = "SELECT [ESTADO], I_NOTIFICA, I_CANCELA FROM [dbo].[SIBSP_ESTADO_DOCUMENTO_ACOM] WHERE I_NOTIFICA = 'TRUE' OR I_CANCELA = 'TRUE';";
            SqlDataReader dr = null;
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    if (Convert.ToBoolean(dr["I_NOTIFICA"]))
                    {
                        this._idsNotificacao.Add(Convert.ToInt32(dr["ESTADO"]));
                    }
                    if (Convert.ToBoolean(dr["I_CANCELA"]))
                    {
                        this._idsCancelamento.Add(Convert.ToInt32(dr["ESTADO"]));
                    }
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "LoadIDS()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
            }
        }

        #endregion

        private void listViewPesquisaDocumentoENVM_DoubleClick(object sender, EventArgs e)
        {
            //PesquisaDocumentoENVM oDoc = (PesquisaDocumentoENVM)listViewPesquisaDocumentoENVM.SelectedItems[0].Tag;
            //MostraImagem fMostraImg = new MostraImagem(m_oParameters, oDoc, Convert.ToInt32(oDoc.m_sDocOrigemID));
            //fMostraImg.ShowDialog();
        }

        private void listViewPesquisaDocumentoACOM_DoubleClick(object sender, EventArgs e)
        {
            //PesquisaDocumentoACOM oDoc = (PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[0].Tag;
            //MostraImagem fMostraImg = new MostraImagem(m_oParameters, oDoc, Convert.ToInt32(oDoc.m_sDocOrigemID));
            //fMostraImg.ShowDialog();
        }

        
    }
}