﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CIActividades
{
    class DetalheDocumento
    {
        public int docID { get; set; }
        public String ZIB { get; set; }
        public string numConta { get; set; }
        public string numCheque { get; set; }
        public Double montante { get; set; }
        public string tipoCheque { get; set; }
        public int estadoDocId { get; set; }
        public string estadoDoc { get; set; }
        public string contaNIB { get; set; }
        public string refArquivo { get; set; }
        public int numSeq { get; set; }
        public string chaveH { get; set; }
        public int index { get; set; }
        public int maquina { get; set; }
        public string chaveHext { get; set; }
        public string tipoDoc { get; set; }
        public string tipoDocDescricao { get; set; }
        public DateTime timer { get; set; }
        public DateTime dataRemessa { get; set; }
        public int remId { get; set; }
        public int transId { get; set; }
        public int balcaoTomador { get; set; }
        public int balcaoDesbobramento { get; set; }
        public int remNum { get; set; }
        public int depositoSeq { get; set; }
        public string estadoTranche { get; set; }
        public int numeroTranche { get; set; }
        public string error { get; set; }
        public string balcaoTomadorDescricao { get; set; }
        public string balcaoDesbobramentoDescricao { get; set; }

        private void iniVArs()
        {

            this.docID = 0;
            this.ZIB = "";
            this.numConta = "";
            this.numCheque = "";
            this.montante = 0;
            this.tipoCheque = "";
            this.estadoDoc = "";
            this.contaNIB = "";
            this.refArquivo = "";
            this.numSeq = 0;
            this.chaveH = "";
            this.index = 0;
            this.maquina = 0;
            this.chaveHext = "";
            this.tipoDoc = "";
            this.timer = DateTime.MinValue;
            this.dataRemessa = DateTime.MinValue;
            this.remId = 0;
            this.transId = 0;
            this.balcaoTomador = 0;
            this.balcaoDesbobramento = 0;
            this.remNum = 0;
            this.depositoSeq = 0;
            this.estadoTranche = "";
            this.numeroTranche = 0;
            this.error = "";
            this.estadoDocId = 0;
            this.tipoDocDescricao = "";
            this.balcaoTomadorDescricao = "";
            this.balcaoDesbobramentoDescricao = "";
        }

        public DetalheDocumento(SqlDataReader dr)
        {

            iniVArs();

            this.docID = Convert.ToInt32(dr["DOC_ID"]);
            this.ZIB = Convert.ToString(dr["DOC_ZONA5"]);
            this.numConta = Convert.ToString(dr["DOC_ZONA4"]);
            this.numCheque = Convert.ToString(dr["DOC_ZONA3"]);
            this.montante = Convert.ToDouble(dr["DOC_ZONA2"]);
            this.tipoCheque = Convert.ToString(dr["DOC_ZONA1"]);
            this.estadoDocId = Convert.ToInt32(dr["DOCSTAT_ID"]);
            this.estadoDoc = Convert.ToString(dr["DOCSTAT_ABR"]);
            this.contaNIB = String.IsNullOrEmpty(dr["DOC_NIB"].ToString()) ? String.Empty : Convert.ToString(dr["DOC_NIB"]);
            this.refArquivo = Convert.ToString(dr["DOC_REFARQ"]);
            this.numSeq = String.IsNullOrEmpty(dr["DOC_NSEQ"].ToString()) ? (Int32)0 : Convert.ToInt32(dr["DOC_NSEQ"]);
            this.chaveH = String.IsNullOrEmpty(dr["DOC_CHAVEH"].ToString()) ? String.Empty : Convert.ToString(dr["DOC_CHAVEH"]);
            this.index = String.IsNullOrEmpty(dr["DOC_INDEX"].ToString()) ? (Int32)0 : Convert.ToInt32(dr["DOC_INDEX"]);
            this.maquina = Convert.ToInt32(dr["DOC_MAQUINA"]);
            this.chaveHext = String.IsNullOrEmpty(dr["DOC_CHAVEHEXT"].ToString()) ? String.Empty : Convert.ToString(dr["DOC_CHAVEHEXT"]);
            this.tipoDoc = Convert.ToString(dr["DOC_TIPO"]);
            this.tipoDocDescricao = Convert.ToString(dr["DOC_TIPO_DESC"]);
            this.timer = Convert.ToDateTime(dr["DOC_TIMER"]);
            this.dataRemessa = Convert.ToDateTime(dr["REMIN_DATA"]);
            this.remId = Convert.ToInt32(dr["REMIN_ID"]);
            this.transId = String.IsNullOrEmpty(dr["TRANOUT_ID"].ToString()) ? (Int32)0 : Convert.ToInt32(dr["TRANOUT_ID"]);           
            this.balcaoTomador = Convert.ToInt32(dr["REMIN_BALCAO"]);
            this.remNum = Convert.ToInt32(dr["REMIN_NUMERO"]);
            this.depositoSeq = Convert.ToInt32(dr["REMIN_SEQ"]);
            this.estadoTranche = String.IsNullOrEmpty(dr["TRANOUTSTAT_ID"].ToString()) ? String.Empty : Convert.ToString(dr["TRANOUTSTAT_ID"]);
            this.numeroTranche = String.IsNullOrEmpty(dr["TRANOUT_NUMERO"].ToString()) ? (Int32)0 : Convert.ToInt32(dr["TRANOUT_NUMERO"]);
            this.error = String.IsNullOrEmpty(dr["DOC_ERRO"].ToString()) ? String.Empty : Convert.ToString(dr["DOC_ERRO"]);
            this.balcaoDesbobramento = Convert.ToInt32(dr["DOCBALCAO_BALDESD"]);
            this.balcaoDesbobramentoDescricao = Convert.ToString(dr["DOCBALCAO_BALDESDDESCRICAO"]);
            this.balcaoTomadorDescricao = Convert.ToString(dr["REMIN_BALCAO_DESCRICAO"]);
        }
        public ListViewItem MakeListViewItemDocumento(string sDateFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = docID.ToString();
            olvItem.SubItems.Add(ZIB.ToString());
            olvItem.SubItems.Add(numConta.ToString());
            olvItem.SubItems.Add(numCheque.ToString());
            string montanteToInsert = montante.ToString().Equals("0") ? montante.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(montante).PadLeft(16, ' ');
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(tipoCheque.ToString());
            olvItem.SubItems.Add(estadoDocId + " " + estadoDoc.ToString());
            olvItem.SubItems.Add(contaNIB.ToString());
            olvItem.SubItems.Add(refArquivo.ToString());
            olvItem.SubItems.Add(numSeq.ToString());
            olvItem.SubItems.Add(chaveH.ToString());
            olvItem.SubItems.Add(index.ToString());
            olvItem.SubItems.Add(maquina.ToString());
            olvItem.SubItems.Add(balcaoTomador.ToString().PadLeft(4, '0') + " - " + balcaoTomadorDescricao);
            olvItem.SubItems.Add(chaveHext.ToString());
            olvItem.SubItems.Add(tipoDoc.ToString() + " - " + tipoDocDescricao);
            olvItem.SubItems.Add(timer.ToString("yyyy-MM-dd HH:mm:ss"));
            olvItem.SubItems.Add(dataRemessa.ToString(sDateFormat));
            olvItem.SubItems.Add(remId.ToString());
            olvItem.SubItems.Add(transId.ToString());
            olvItem.SubItems.Add(this.balcaoDesbobramento.ToString().PadLeft(4, '0') + " - " + balcaoDesbobramentoDescricao);
            olvItem.SubItems.Add(remNum.ToString());
            olvItem.SubItems.Add(estadoTranche.ToString());
            olvItem.SubItems.Add(numeroTranche.ToString());
            olvItem.SubItems.Add(error.ToString());
            olvItem.SubItems.Add(depositoSeq.ToString());
            return olvItem;
        }

    }
}
