﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;
using System.IO;


namespace CIActividades
{
    public partial class ActividadesForm : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
       // TranchesDetalhe m_oCurrTran;
        DetalhesDocumento m_oCurrDoc;
        public int m_iNewEstado;
        public string m_sSPProcessa;
        public string m_sSPValida;
        //public bool m_bIsRemessas;

        public CIMenuInterface m_oMenuInterface;

        public ActividadesForm(CIConfigGP.CIGlobalParameters oParameters, CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;

            m_oMenuInterface = oMenuInterface;
        }

        private void ResumoForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = System.Windows.Forms.FormWindowState.Maximized;

                definirNivelUtilizacao(); 

                DefinirDatas();

                m_splitContainerRemessaTranche.Panel1Collapsed = false;
                m_splitContainerRemessaTranche.Panel2Collapsed = true;

                RefreshRemessasAndTranches();

                m_oMenuInterface.actividadesEnable(false);

                ShowListViews();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Dispose();
            }
        }

        protected void definirNivelUtilizacao()
        {
            contextMenuStripRemessa.Items["consultaRemessasToolStripMenuItem"].Enabled = (m_oParameters.UserLogged.m_iUserGroup == 0);
            contextMenuStripDetalheDoc.Items[1].Enabled = (m_oParameters.UserLogged.m_iUserGroup == 0);
        }

        protected void DefinirDatas()
        {
            //SUPFBKOFF 20 intervalo de dados por defeito passou a ser 1 dia.
            m_ctrldtFim.Value = DateTime.Now.Date;
            m_ctrldtInicio.Value = DateTime.Now.Date;
        }

        private void AddRemessaResumo2ListView(SqlDataReader dr)
        {
            RemessasResumo oRr = new RemessasResumo(dr);

            ListViewItem olvItem = oRr.MakeListViewItemResumoRemessas(m_oParameters.DateFormat);

            olvItem.Tag = oRr;

            listViewResumoRemessas.Items.Add(olvItem);
        }

        private void RefreshResumoRemessas(string sWhereClause)
        {
            listViewResumoRemessas.BeginUpdate();
            listViewResumoRemessas.MyClear();
            listViewDetalhesDocumentos.MyClear();

            SqlDataReader dr = null;
            //string sQuery = "select * from VW_REMESSAS_ESTADO_RESUMO ";
            string sQuery = "select * from dbo.GetResumoRemessasEstado  ";
            sQuery += sWhereClause;
            sQuery += " order by REMPROC_DATA desc, REMIN_DATA desc, REMINSTAT_ID desc";

            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    AddRemessaResumo2ListView(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ResumoForm.cs", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                listViewResumoRemessas.EndUpdate();
            }
        }

        private void AddTrancheResumo2ListView(SqlDataReader dr)
        {
            TranchesResumo oTr = new TranchesResumo(dr);

            ListViewItem olvItem = oTr.MakeListViewItemResumoTranches(m_oParameters.DateFormat);

            olvItem.Tag = oTr;

            listViewResumoTranches.Items.Add(olvItem);
        }

        private void RefreshResumoTranches(string sWhereClause, bool bInicializa)
        {
            listViewResumoTranches.BeginUpdate();
            if (bInicializa)
            {
                listViewResumoTranches.MyClear();
                listViewDetalhesDocumentos.MyClear();
            }

            SqlDataReader dr = null;
            string sQuery = "select * from dbo.GetResumoTranchesEstado ";
            sQuery += sWhereClause;
            sQuery += " order by TRANOUT_DATA desc, REMIN_DATA desc, TRANOUTSTAT_ID desc";

            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    AddTrancheResumo2ListView(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ResumoForm.cs", 2);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                listViewResumoTranches.EndUpdate();
            }

        }

        private void DisplayTranche()
        {
            string sWhereClause="";
            RemessasResumo oRr = null;

            for (int i = 0; i < listViewResumoRemessas.SelectedItems.Count; i++)
            {
                oRr = (RemessasResumo)listViewResumoRemessas.SelectedItems[i].Tag;
                sWhereClause = " ('" + oRr.m_dtREMIN_DATA.ToString(m_oParameters.DateFormat) + "' , ";
                sWhereClause += " '" + oRr.m_dtREMIN_DATA.ToString(m_oParameters.DateFormat) + "' , ";
                sWhereClause += " '" + oRr.m_dtREMPROC_DATA.ToString(m_oParameters.DateFormat) + "' , ";
                sWhereClause += " '" + oRr.m_dtREMPROC_DATA.ToString(m_oParameters.DateFormat) + "') ";
                sWhereClause += " Where REMINSTAT_ID=" + oRr.m_iREMINSTAT_ID;
                sWhereClause += " and LOTEENV_CGDERROR =" + oRr.m_iLOTEENV_CGDERROR;
                RefreshResumoTranches(sWhereClause, i == 0);
            }
        }

        private void DisplaySelectedRemessas_ResumoAndDetalhe()
        { 
            string sWhereClause="";
            RemessasResumo oRr = null;

            for (int i = 0; i < listViewResumoRemessas.SelectedItems.Count; i++)
            {
                oRr = (RemessasResumo)listViewResumoRemessas.SelectedItems[i].Tag;

                sWhereClause = " where  REMIN_DATA= '" + oRr.m_dtREMIN_DATA.ToString(m_oParameters.DateFormat) + "' and ";
                sWhereClause += " REMINSTAT_ID=" + oRr.m_iREMINSTAT_ID;
                sWhereClause += " and REMPROC_TIMER between '" + oRr.m_dtREMPROC_DATA.ToString(m_oParameters.DateFormat) + "'";
                sWhereClause += " and '" + oRr.m_dtREMPROC_DATA.AddDays(+1).ToString(m_oParameters.DateFormat) + "'";
                sWhereClause += " and LOTEENV_CGDERROR =" + oRr.m_iLOTEENV_CGDERROR;
                RefreshDetalheRemessas(sWhereClause, i == 0);
            }
        }

        private void listViewRemessaResumo1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listViewResumoRemessas.SelectedItems.Count != 1)
                return;
            DisplayTranche();
        }

        private void RefreshDetalheTranches(string sWhereClause, bool bInicializa)
        {
            listViewDetalhesTranche.BeginUpdate();
            listViewDetalhesTranche.Items.Clear();
            CriaListTranche();

            SqlDataReader dr = null;
            string sQuery = "select * from dbo.VW_TRANCHE_DETALHE ";
            sQuery += sWhereClause;
            sQuery += " and TRANOUT_ID is not null order by REMIN_DATA, REMIN_BALCAO, REMIN_ID, TRANOUT_NUMERO";

            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    ListViewTrancheDetalhe oTd = new ListViewTrancheDetalhe(dr, m_oParameters);
                    ListViewItem olvItem = oTd.MakeListViewItem(m_oParameters.DateFormat, m_oParameters.DateTimeSysFmt);

                    olvItem.Tag = oTd;

                    listViewDetalhesTranche.Items.Add(olvItem);
                    //AddTrancheDetalhe2ListView(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ResumoForm.cs", 3);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                labelCountTran.Text = listViewDetalhesTranche.Items.Count.ToString() + " Tranches.";
                listViewDetalhesTranche.EndUpdate();
            }
        }

        private void CriaListRemessa()
        {
            m_splitContainerRemessaTranche.Panel1Collapsed = false;
            m_splitContainerRemessaTranche.Panel2Collapsed = true;

        }

        private void CriaListTranche()
        {
            m_splitContainerRemessaTranche.Panel1Collapsed = true;
            m_splitContainerRemessaTranche.Panel2Collapsed = false;
        }


        private void RefreshDetalheRemessas(string sWhereClause, bool bInicializa)
        {
            SqlDataReader dr = null;
            string sQuery = "select * from VW_REMESSA_DETALHE ";

            sQuery += sWhereClause;
            
            sQuery += " order by LOTEENV_CGDERROR, REMIN_DATA, REMIN_BALCAO, REMIN_ID";

            try
            {
                listViewDetalhesRemessa.BeginUpdate();
                listViewDetalhesRemessa.MyClear();
                listViewDetalhesDocumentos.MyClear();
                CriaListRemessa();

                dr = m_oParameters.DirectSqlDataReader(sQuery);

                if (!dr.HasRows)
                {
                    MessageBox.Show("A Pesquisa não retornou resultados", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                while (dr.Read())
                {
                    ListViewRemessaDetalhe oTd = new ListViewRemessaDetalhe(dr, m_oParameters);
                    ListViewItem olvItem = oTd.MakeListViewItem(m_oParameters.DateFormat, m_oParameters.DateTimeSysFmt);

                    olvItem.Tag = oTd;

                    listViewDetalhesRemessa.Items.Add(olvItem);
                    
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ResumoForm.cs", 4);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    if (!dr.IsClosed)
                    {
                        dr.Close();
                    }
                    dr = null;
                }
                labelCountRem.Text = listViewDetalhesRemessa.Items.Count.ToString() + " Remessas.";
                listViewDetalhesRemessa.EndUpdate();
            }
        }

        private void listViewResumoTranches_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listViewResumoTranches.SelectedItems.Count == 0)
                return;
            string sWhereClause = "";
            TranchesResumo oTr = null;

            for (int i = 0; i < listViewResumoTranches.SelectedItems.Count; i++)
            {
                oTr = (TranchesResumo)listViewResumoTranches.SelectedItems[i].Tag;
                sWhereClause = " where REMIN_DATA='" + oTr.m_dtREMIN_DATA.ToString(m_oParameters.DateFormat) + "'";
                sWhereClause += " and TRANOUTSTAT_ID=" + oTr.m_iTRANOUTSTAT_ID.ToString();
                sWhereClause += " and REMINSTAT_ID=" + oTr.m_iREMINSTAT_ID.ToString();
                sWhereClause += " and TRANOUT_TIMER between '" + oTr.m_dtTRANOUT_DATA.ToString(m_oParameters.DateFormat) + "'";
                sWhereClause += " and '" + oTr.m_dtTRANOUT_DATA.AddDays(+1).ToString(m_oParameters.DateFormat) + "'";
                RefreshDetalheTranches(sWhereClause, i == 0);
            }
        }

        private void RefreshRemessasAndTranches()
        {
            RefreshRemessas();
            RefreshTranches();
        }

       
        private void btTranches_Click(object sender, EventArgs e)
        {
            RefreshTranches();
        }
        private void RefreshTranches()
        {
            listViewDetalhesTranche.MyClear();
            listViewDetalhesRemessa.MyClear();
            listViewDetalhesDocumentos.MyClear();

            string sWhereClause;
            sWhereClause = "( '" + m_ctrldtInicio.Value.ToString(m_oParameters.DateTimeSysFmt) + "' , ";
            sWhereClause += "'" + m_ctrldtFim.Value.ToString(m_oParameters.DateTimeSysFmt) + "' , ";
            sWhereClause += "'" + m_ctrldtInicio.Value.ToString(m_oParameters.DateTimeSysFmt) + "' , ";
            sWhereClause += "'" + m_ctrldtFim.Value.ToString(m_oParameters.DateTimeSysFmt) + "') ";
            sWhereClause += filtrosTranches();
            RefreshResumoTranches(sWhereClause, true);
        }

        private string filtrosTranches()
        {
            string sFiltroStart = "where TRANOUTSTAT_ID in (";
            string sFiltros = "";

            if (toolStripButtonProcessamento.Checked)
                sFiltros += " 10,";
            if (toolStripButtonProcessado.Checked)
                sFiltros += " 20,";
            if (toolStripButtonEnviada.Checked)
                sFiltros += " 30,";
            if (toolStripButtonErro.Checked)
                sFiltros += " -30, 99,";

            if (sFiltros.Length == 0)
            {
                return "";
            }
            sFiltros = sFiltroStart + sFiltros.Substring(0, sFiltros.Length - 1) + ")";

            return sFiltros;
        }


        private void RefreshRemessas()
        {
            listViewDetalhesTranche.MyClear();
            listViewDetalhesRemessa.MyClear();
            listViewDetalhesDocumentos.MyClear();

            string sWhereClause;
            sWhereClause = " ('" + m_ctrldtInicio.Value.ToString(m_oParameters.DateTimeSysFmt) + "' ,";
            sWhereClause += "'" + m_ctrldtFim.Value.ToString(m_oParameters.DateTimeSysFmt) + "' ) ";
            sWhereClause += filtrosRemessas();
            RefreshResumoRemessas(sWhereClause);
        }

        private string filtrosRemessas()
        {
            string sFiltroStart = "where REMINSTAT_ID in (";
            string sFiltros = "";
            if (toolStripButtonAbertas.Checked)
                sFiltros += "10,";
            if (toolStripButtonFechados.Checked)
                sFiltros += " 20,";
            if (toolStripButtonEspMaquinas.Checked)
                sFiltros += " 25,";
            if (toolStripButtonProcessamento.Checked)
                sFiltros += " 30,";
            if (toolStripButtonProcessado.Checked)
                sFiltros += " 40,";
            if (toolStripButtonEnviada.Checked)
                sFiltros += " 50,";
            if (toolStripButtonENVM.Checked)
                sFiltros += " 60, 70, 80,";
            if (toolStripButtonErro.Checked)
                sFiltros += " -20, -40, -50, -60,";

            if (sFiltros.Length == 0)
            {
                return "";
            }
            sFiltros = sFiltroStart + sFiltros.Substring(0, sFiltros.Length - 1) + ")";

            return sFiltros;
        }

        private void m_btRefreshRemessas_Click(object sender, EventArgs e)
        {
            RefreshRemessas();
        }

        private void AddDetalhesDocumento2ListView(SqlDataReader dr)
        {
            DetalhesDocumento oDd = new DetalhesDocumento(dr);
           
            ListViewItem olvItem = oDd.MakeListViewItemDetalhesDocumento(m_oParameters.DateFormat, m_oParameters.DateTimeSysFmt );

            olvItem.Tag = oDd;

            listViewDetalhesDocumentos.Items.Add(olvItem);
        }
 
        private void RefreshDetalheDocumentos(string sWhereClause)
        {
            

            listViewDetalhesDocumentos.BeginUpdate();
            listViewDetalhesDocumentos.MyClear();

            SqlDataReader dr = null;
            string sQuery = "select * from VW_DETALHE_DOCUMENTOS ";
            sQuery += sWhereClause;
            sQuery += " order by REMIN_ID, TRANOUT_ID, DOC_REFARQ";

            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    AddDetalhesDocumento2ListView(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ResumoForm.cs", 5);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                labelCountDocs.Text = listViewDetalhesDocumentos.Items.Count.ToString()+ " Documentos.";
                listViewDetalhesDocumentos.EndUpdate();
            }
        }

        //private void mostraContainerDocumentos()
        //{
        //    m_splitContainerRemDocs.Panel2Collapsed = false;
        //    m_splitContainerMain.Panel1Collapsed = true;
  
        //}

        private void ConfirmaPrivilegios()
        {
            if (m_oParameters.UserLogged.m_iUserGroup > 1)
            {
                throw new Exception("Utilizador sem privilegios para alterar estados");
            }
        }

        private void VerificaEstadosIguaisRemessa()
        {
            ListViewRemessaDetalhe oDetalhe;

            int iCurrStat = -99999;

            for (int i = 0; i < listViewDetalhesRemessa.SelectedItems.Count; i++)
            {
                oDetalhe = (ListViewRemessaDetalhe)listViewDetalhesRemessa.SelectedItems[i].Tag;

                if (iCurrStat != -99999 && iCurrStat != oDetalhe.m_iStatus)
                {
                    throw new Exception("Remessas em Estados Diferentes");
                }
                iCurrStat = oDetalhe.m_iStatus;
            }

        }
        private void VerificaEstadosIguaisTranche()
        {
            ListViewTrancheDetalhe oDetalhe;
            int iCurrStat = -99999;

            for (int i = 0; i < listViewDetalhesTranche.SelectedItems.Count; i++)
            {
                oDetalhe = (ListViewTrancheDetalhe)listViewDetalhesTranche.SelectedItems[i].Tag;

                if (iCurrStat != -99999 && iCurrStat != oDetalhe.m_iStatus)
                {
                    throw new Exception("Tranches em Estados Diferentes");
                }
                iCurrStat = oDetalhe.m_iStatus;
            }

        }

        private void toolStripMenuMudarEstado_Click(object sender, EventArgs e)
        {

            int iDebug = -1;


            if (listViewDetalhesRemessa.SelectedItems.Count == 0)
                return;

            
            try
            {
                ConfirmaPrivilegios();

                ListViewRemessaDetalhe oDetalhe = (ListViewRemessaDetalhe)listViewDetalhesRemessa.SelectedItems[0].Tag;

                VerificaEstadosIguaisRemessa();

                MudarEstadoForm mudarEstado;
                mudarEstado = new MudarEstadoForm(m_oParameters, oDetalhe.m_iStatus, oDetalhe.GetTableName(), oDetalhe.m_sStatusAbr);
            

                if (mudarEstado.ShowDialog() == DialogResult.Cancel)
                {
                    throw new Exception("Operação cancelada pelo utilizador");
                }

                try
                {
                    m_oParameters.BeginTrans(IsolationLevel.ReadCommitted);
                    while (listViewDetalhesRemessa.SelectedItems.Count > 0)
                    {
                        m_iNewEstado = mudarEstado.m_iNewEstado;
                        m_sSPProcessa = mudarEstado.m_sSPProcessa;
                        m_sSPValida = mudarEstado.m_sSPValida;
                        oDetalhe = (ListViewRemessaDetalhe)listViewDetalhesRemessa.SelectedItems[0].Tag;

                        oDetalhe.ChangeEstado(m_iNewEstado, m_sSPProcessa, m_sSPValida);

                        listViewDetalhesRemessa.SelectedItems[0].Remove();
                    }
                    
                    m_oParameters.Commit();
                }
                catch
                {
                    iDebug = Convert.ToInt32(oDetalhe.m_sRemessaID);
                    m_oParameters.RollBack();
                    throw;
                }

                RefreshRemessas();
                //RefreshTranches();
            }
            catch(Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "toolStripMenuMudarEstado_Click", iDebug);
                MessageBox.Show(this, ex.Message,Application.ProductName,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }

        }

        private void toolStripMenuItemMudar_Click(object sender, EventArgs e)
        {
            if (listViewDetalhesDocumentos.SelectedItems.Count == 0)
                return;

            try
            {
                if (m_oParameters.UserLogged.m_iUserGroup > 1)
                {
                    MessageBox.Show("Utilizador sem privilegios para alterar estados", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int iCurrStatDoc = -1;
                
                for (int i = 0; i < listViewDetalhesDocumentos.SelectedItems.Count; i++)
                {
                    m_oCurrDoc = (DetalhesDocumento)listViewDetalhesDocumentos.SelectedItems[i].Tag;
                    if (i == 0)
                    {
                        iCurrStatDoc = m_oCurrDoc.m_iDOCSTAT_ID;
                        
                    }
                    if (m_oCurrDoc.m_iDOCSTAT_ID != iCurrStatDoc)
                    {
                        MessageBox.Show("Documentos em Estados Diferentes", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }


                MudarEstadoForm mudarEstado;

                mudarEstado = new MudarEstadoForm(m_oParameters, m_oCurrDoc.m_iDOCSTAT_ID, "DOCUMENTO", m_oCurrDoc.m_sDOCSTAT_ABR);
                mudarEstado.ShowDialog();

                if (mudarEstado.m_bCancelPressed || mudarEstado.m_iNewEstado == -999)
                {
                    return;
                }
                m_iNewEstado = mudarEstado.m_iNewEstado;
                m_sSPProcessa = mudarEstado.m_sSPProcessa;
                m_sSPValida = mudarEstado.m_sSPValida;
                
                SqlTransaction oTrans = (SqlTransaction)m_oParameters.BeginTrans(IsolationLevel.ReadCommitted);

                for (int i = 0; i < listViewDetalhesDocumentos.SelectedItems.Count; i++)
                {

                    m_oCurrDoc = (DetalhesDocumento)listViewDetalhesDocumentos.SelectedItems[i].Tag;

                    ChangeEstadoDocumento(m_iNewEstado, m_sSPProcessa, m_sSPValida);
                }
               
                for (int i = 0; i < listViewDetalhesDocumentos.SelectedItems.Count; i++)
                {
                    listViewDetalhesDocumentos.SelectedItems[i].SubItems[6].Text = mudarEstado.m_sNewEstado;
                    ((DetalhesDocumento)listViewDetalhesDocumentos.SelectedItems[i].Tag).m_iDOCSTAT_ID = mudarEstado.m_iNewEstado;
                 }
               
                m_oParameters.Commit();  

            }
            catch(Exception ex)
            {
                m_oParameters.RollBack();
                GenericLog.GenLogRegistarErro(ref ex, "ChangeEstadoDocumento", int.Parse(m_oCurrDoc.m_sDOC_ID));
                MessageBox.Show(ex.Message,Application.ProductName,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }

        }

        private void ChangeEstadoDocumento(int iNewEstado, string m_sSPProcessa, string m_sSPValida)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@NewEstado", iNewEstado));
            oParams.Add(new GeneralDBParameters("@DocID", m_oCurrDoc.m_sDOC_ID));
            if (m_sSPValida.Length > 0)
            {
                m_oParameters.DirectStoredProcedureNonQuery(m_sSPValida, ref oParams);
            }
            m_oParameters.DirectStoredProcedureNonQuery(m_sSPProcessa, ref oParams);


            string sSmg = "Mudou estado do DOCUMENTO: " + m_oCurrDoc.m_sDOC_ID + " para " + iNewEstado.ToString();
            GenericLog.GenLogRegistarAlerta(sSmg, "ChangeEstadoDocumento()", 110);
            m_oParameters.EnviarAlertaSituacao(110, sSmg);

        }

        private void verDocumentosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listViewDetalhesRemessas_DoubleClick (sender, e);
        }

        private void toolStripButtonRefresh_Click(object sender, EventArgs e)
        {
            if (!m_toolStripButtonShowResumo.Checked)
            {
                m_toolStripButtonShowResumo.Checked = true;
                m_toolStripButtonShowDocs.Checked = false;
            }
            ShowListViews();

            RefreshRemessasAndTranches();
        }

        private void contextMenuStripRemTrans_Opening(object sender, CancelEventArgs e)
        {
            if (listViewDetalhesRemessa.SelectedItems.Count == 0)
            {
                contextMenuStripRemessa.Enabled = false;
            }
            else
            {
                contextMenuStripRemessa.Enabled = true;
            }
            //contextMenuStripRemessa.Enabled = true;
            
            //enbaleSeRemessa();
            //enabledSeAberta(); 
        }

        private void enabledSeAberta()
        {
            if (listViewResumoRemessas.SelectedItems.Count != 1)
            {
                return;
            }

            RemessasResumo oRr = null;
            oRr = (RemessasResumo)listViewResumoRemessas.SelectedItems[0].Tag;
            
            if (oRr.m_iREMINSTAT_ID == 10)
            {
                verTranchesToolStripMenuItem.Enabled = false;
            }
            else
            {
                verTranchesToolStripMenuItem.Enabled = true;
            }
        }

        //private void enbaleSeRemessa()
        //{
        //    if (!m_splitContainerRemessaTranche.Panel1Collapsed)
        //    {
        //        verRemessasToolStripMenuItem.Visible = false;
        //        verTranchesToolStripMenuItem.Visible = true;
        //        consultaRemessasToolStripMenuItem.Visible = true;
        //    }
        //    else
        //    {
        //        verRemessasToolStripMenuItem.Visible = true;
        //        verTranchesToolStripMenuItem.Visible = false;
        //        consultaRemessasToolStripMenuItem.Visible = false;
        //    }

        //}

        private void verTranchesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewDetalhesRemessa.SelectedItems.Count != 1)
                return;
            
            try
            {
                string sWhereClause = "";
                ListViewDetalhes oTd = null;

                oTd = (ListViewDetalhes)listViewDetalhesRemessa.SelectedItems[0].Tag;
                sWhereClause = "where REMIN_ID = " + oTd.m_sRemessaID;

                RefreshDetalheTranches(sWhereClause, true);
                
            }
            catch { }

        }

        private void verRemessasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewDetalhesTranche.SelectedItems.Count != 1)
                return;
            try
            {
                string sWhereClause = "";
                ListViewDetalhes oTd = null;

                oTd = (ListViewDetalhes)listViewDetalhesTranche.SelectedItems[0].Tag;
                sWhereClause = "where REMIN_ID = " + oTd.m_sRemessaID;

                RefreshDetalheRemessas(sWhereClause, true);

            }
            catch { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
                string sFiltro = filtros();
                RefreshDetalheRemessas(sFiltro, true);
           
        }

        private string filtros()
        {
            string sWhereClause;
            sWhereClause = "";

            

            if (textBoxFiltroReminID.Text.Length > 0)
            {
                sWhereClause = " where REMIN_ID = " + textBoxFiltroReminID.Text;
                return sWhereClause;
            }

            if (textBoxFiltroBalcao.Text.Length > 0)
            {
                sWhereClause += " REMIN_BALCAO = " + textBoxFiltroBalcao.Text;
            }

            if (textBoxFiltroNRemessa.Text.Length > 0)
            {
                if (sWhereClause.Length > 0) sWhereClause += " and ";
                sWhereClause += " REMIN_NUMERO = " + textBoxFiltroNRemessa.Text;
            }

            if (sWhereClause.Length > 0)
            {
                sWhereClause = " and " + sWhereClause;
                //filtroData();
            }

            

            string sFiltroRem = filtrosRemessas();

            if (sFiltroRem.Length > 0)
            {
                return filtrosRemessas() + " and " + filtroData() +sWhereClause;
            }
            else if (sWhereClause == "")
            {
                return " where " + filtroData();
            }
            else
            {
                return " where " + filtroData() +sWhereClause;
            }
        }

        private string filtroData()
        {

            string sWhereDate = "";
            sWhereDate = " REMPROC_TIMER between '" + m_ctrldtInicio.Value.ToString(m_oParameters.DateTimeSysFmt) + "' and ";
            sWhereDate += "'" + m_ctrldtFim.Value.AddDays(+1).ToString(m_oParameters.DateTimeSysFmt) + "' ";
            return sWhereDate;
        }

        private void listViewDetalhesDocumentos_DoubleClick(object sender, EventArgs e)
        {

            m_oCurrDoc = (DetalhesDocumento)listViewDetalhesDocumentos.SelectedItems[0].Tag;
            MostraImagem fMostraImg = new MostraImagem(m_oParameters, m_oCurrDoc, Convert.ToInt32(m_oCurrDoc.m_iDOC_TIPO));
            fMostraImg.ShowDialog();    
        }

 
        private void consultaRemessasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewDetalhesRemessa.SelectedItems.Count != 1)
                return;

            ListViewRemessaDetalhe oTd = null;
            oTd = (ListViewRemessaDetalhe)listViewDetalhesRemessa.SelectedItems[0].Tag;
            DialogResult oResult = DialogResult.No;
            if (pesquisaReminConsulta(oTd))
            {

                oResult = MessageBox.Show("A Consulta já foi efectuada deseja repetir?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (oResult == DialogResult.Yes)
                {
                    insereConsultaRemessaTibco(oTd);
                }
            }
            else 
            {
                insereConsultaRemessaTibco(oTd);
            }

            MessageBox.Show("Consulta efectuada!", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);   
        }
        
        private void insereConsultaRemessaTibco(ListViewRemessaDetalhe oTd)
        {
            try
            {
                ArrayList oParams = new ArrayList();
                oParams.Add(new GeneralDBParameters("@Operativa", oTd.m_iOperativa));
                oParams.Add(new GeneralDBParameters("@Filtro", xmlFiltroRemessas(oTd)));
                oParams.Add(new GeneralDBParameters("@Remin_id", oTd.m_sRemessaID));

                m_oParameters.DirectStoredProcedureNonQuery("dbo.Insert_TibcoConsultaRemessas", ref oParams);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "consultaRemessasToolStripMenuItem_Click", int.Parse(oTd.m_sRemessaID.ToString()));
            }
        }

        private string xmlFiltroRemessas(ListViewRemessaDetalhe oTd)
        {
            ArrayList oNome = new ArrayList();
            ArrayList oValor = new ArrayList();

            oNome.Add("BALCAO");
            oValor.Add(oTd.m_iREMIN_BALCAO.ToString("0000"));
            

            oNome.Add("DATAREM");
            //oValor.Add(oTd.m_dtTimer.ToString("yyyy/MM/dd"));
            oValor.Add(oTd.m_dtREMIN_DATA.ToString("yyyy/MM/dd"));

            //oNome.Add("NUM_PROPOSTA_LOGICA");
            oNome.Add("NUM_REMESSA");
            oValor.Add(oTd.m_sNumero.PadLeft(11, '0'));

            string sFiltro = CriaXML.Filtro(oNome, oValor);

            return sFiltro;

        }

        private void consultaDocumentosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewDetalhesDocumentos.SelectedItems.Count != 1)
                return;

            DetalhesDocumento oTd = null;
            oTd = (DetalhesDocumento)listViewDetalhesDocumentos.SelectedItems[0].Tag;

            
            DialogResult oResult;
            if (pesquisaDocConsulta(oTd))
            {
                oResult = MessageBox.Show("A Consulta já foi efectuada deseja repetir?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (oResult == DialogResult.Yes)
                {
                    insereConsultaDocTibco(oTd);
                    //MessageBox.Show("Consulta efectuada!", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }    
            }
            else
            { 
                 insereConsultaDocTibco(oTd);
                 //MessageBox.Show("Consulta efectuada!", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);   
            }
            MessageBox.Show("Consulta efectuada!", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);   
            
        }

        private void insereConsultaDocTibco(DetalhesDocumento oTd)
        {
            string sFiltro = xmlFiltroDocumentos(oTd);
            ArrayList oParams = new ArrayList();
            try
            {
                oParams.Add(new GeneralDBParameters("@Operativa", oTd.m_iOperativa));
                oParams.Add(new GeneralDBParameters("@Filtro", sFiltro));
                oParams.Add(new GeneralDBParameters("@Doc_id", oTd.m_sDOC_ID));

                m_oParameters.DirectStoredProcedureNonQuery("dbo.Insert_TibcoConsultaDocumentos", ref oParams);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "consultaDocumentosToolStripMenuItem_Click", int.Parse(oTd.m_sREMIN_ID.ToString()));
            }
        }


        private bool pesquisaDocConsulta(DetalhesDocumento oTd)
        {
            long lConsulta = 0;
            lConsulta = long.Parse(m_oParameters.DirectSqlScalar("select count(*) from vw_consulta_docs where Doc_ID =" + oTd.m_sDOC_ID).ToString());

            if (lConsulta > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool pesquisaReminConsulta(ListViewRemessaDetalhe oTd)
        {
            long lConsulta = 0;
            lConsulta = long.Parse(m_oParameters.DirectSqlScalar("select count(*) from vw_consulta_Remessa where Remin_id =" + oTd.m_sRemessaID).ToString());

            if (lConsulta > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        private string xmlFiltroDocumentos(DetalhesDocumento oTd)
        {
            ArrayList oNome = new ArrayList();
            ArrayList oValor = new ArrayList();

            oNome.Add("BALCAO");
            oValor.Add(oTd.m_iREMIN_BALCAO.ToString("0000"));

            oNome.Add("ZIB");
            oValor.Add(oTd.m_sDOC_ZONA5.PadLeft(8, '0'));

            oNome.Add("NUM_CONTA");
            oValor.Add(oTd.m_sDOC_ZONA4.PadLeft(11, '0'));

            oNome.Add("NUM_CHEQUE");
            oValor.Add(oTd.m_sDOC_ZONA3.PadLeft(10, '0'));

            oNome.Add("MONTANTE");
            oValor.Add(oTd.m_dDOC_ZONA2.ToString("0000000000.00"));

            oNome.Add("TIPOCHEQUE");
            oValor.Add(oTd.m_sDOC_ZONA1);

            string sFiltro = CriaXML.Filtro(oNome, oValor);

            return sFiltro;

            
        }

        private void contextMenuStripRemessas_Opening(object sender, CancelEventArgs e)
        {
            if (listViewResumoRemessas.SelectedItems.Count == 0)
            {
                contextMenuStripRemessasResumo.Enabled = false;
            }
            else
            {
                contextMenuStripRemessasResumo.Enabled = true;
            }
        }

        private void contextMenuStripDetalheDoc_Opening(object sender, CancelEventArgs e)
        {
            if (listViewDetalhesDocumentos.SelectedItems.Count == 0)
            {
                contextMenuStripDetalheDoc.Enabled = false;
            }
            else
            {
                contextMenuStripDetalheDoc.Enabled = true;
            }
        }

        private void verRemessasDetalheToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (listViewResumoRemessas.SelectedItems.Count == 0)
                return;

            DisplayRemessas();
            
        }

        private void listViewResumoRemessas_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            DisplayRemessas();
        }

        private void DisplayRemessas()
        {
            //### aqui
            m_splitContainerRemessaTranche.Panel1Collapsed = false;
            m_splitContainerRemessaTranche.Panel2Collapsed = true;

            if (listViewResumoRemessas.SelectedItems.Count != 1)
                return;
            DisplaySelectedRemessas_ResumoAndDetalhe();
        }

        private void verImagemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewDetalhesDocumentos.SelectedItems.Count == 0)
                return;
            listViewDetalhesDocumentos_DoubleClick(sender, e);
        }

        private void m_toolStripButtonShowDocs_Click(object sender, EventArgs e)
        {
            ShowListViews();
        }

        private void m_toolStripButtonShowResumo_Click(object sender, EventArgs e)
        {
            ShowListViews();
        }

        protected void ShowListViews()
        {
            m_splitContainerRemDocs.Panel2Collapsed = !m_toolStripButtonShowDocs.Checked;
            m_splitContainerMain.Panel1Collapsed = !m_toolStripButtonShowResumo.Checked;

            btTranches.Visible = m_toolStripButtonShowResumo.Checked;
            m_btRefreshRemessas.Visible = m_toolStripButtonShowResumo.Checked;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void listViewDetalhesRemessas_DoubleClick(object sender, EventArgs e)
        {
            if (listViewDetalhesRemessa.SelectedItems.Count != 1)
            {
                return;
            }

            if (!m_toolStripButtonShowDocs.Checked)
            {
                m_toolStripButtonShowDocs.Checked = true;
                m_toolStripButtonShowResumo.Checked = false;
            }
            ShowListViews();

            listViewDetalhesRemessa.EnsureVisible(listViewDetalhesRemessa.SelectedItems[0].Index);

            try
            {
                Cursor = Cursors.WaitCursor;
                frmEspereUmMomento.ShowWaitForm();

                string sWhereClause = "";
                ListViewDetalhes oTd = null;

                oTd = (ListViewDetalhes)listViewDetalhesRemessa.SelectedItems[0].Tag;
                sWhereClause = oTd.GetWhereClause2ViewDetails();
                RefreshDetalheDocumentos(sWhereClause);

            }
            catch { }
            finally
            {
                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
        }

        private void listViewDetalhesTranche_DoubleClick(object sender, EventArgs e)
        {
            if (listViewDetalhesTranche.SelectedItems.Count != 1)
            {
                return;
            }

            if (!m_toolStripButtonShowDocs.Checked)
            {
                m_toolStripButtonShowDocs.Checked = true;
                m_toolStripButtonShowResumo.Checked = false;
            }
            ShowListViews();

            listViewDetalhesTranche.EnsureVisible(listViewDetalhesTranche.SelectedItems[0].Index);

            try
            {
                Cursor = Cursors.WaitCursor;
                frmEspereUmMomento.ShowWaitForm();

                string sWhereClause = "";
                ListViewDetalhes oTd = null;

                oTd = (ListViewDetalhes)listViewDetalhesTranche.SelectedItems[0].Tag;
                sWhereClause = oTd.GetWhereClause2ViewDetails();
                RefreshDetalheDocumentos(sWhereClause);

            }
            catch { }
            finally
            {
                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
        }

        private void contextMenuStripTrancheMudaEstado_Click(object sender, EventArgs e)
        {
            int iDebug = -1;


            if (listViewDetalhesTranche.SelectedItems.Count == 0)
                return;


            try
            {
                ConfirmaPrivilegios();

                ListViewTrancheDetalhe oDetalhe = (ListViewTrancheDetalhe)listViewDetalhesTranche.SelectedItems[0].Tag;

                //VerificaEstadosIguaisTranche(listViewDetalhesTranche, ref oDetalhe);
                VerificaEstadosIguaisTranche();

                MudarEstadoForm mudarEstado;
                mudarEstado = new MudarEstadoForm(m_oParameters, oDetalhe.m_iStatus, oDetalhe.GetTableName(), oDetalhe.m_sStatusAbr);


                if (mudarEstado.ShowDialog() == DialogResult.Cancel)
                {
                    throw new Exception("Operação cancelada pelo utilizador");
                }

                try
                {
                    m_oParameters.BeginTrans(IsolationLevel.ReadCommitted);
                    while (listViewDetalhesTranche.SelectedItems.Count > 0)
                    {
                        m_iNewEstado = mudarEstado.m_iNewEstado;
                        m_sSPProcessa = mudarEstado.m_sSPProcessa;
                        m_sSPValida = mudarEstado.m_sSPValida;
                        oDetalhe = (ListViewTrancheDetalhe)listViewDetalhesTranche.SelectedItems[0].Tag;

                        oDetalhe.ChangeEstado(m_iNewEstado, m_sSPProcessa, m_sSPValida);

                        listViewDetalhesTranche.SelectedItems[0].Remove();
                    }

                    m_oParameters.Commit();
                }
                catch
                {
                    iDebug = Convert.ToInt32(oDetalhe.m_sTrancheID);
                    m_oParameters.RollBack();
                    throw;
                }

                //RefreshRemessas();
                RefreshTranches();
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "toolStripMenuMudarEstado_Click", iDebug);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void contextMenuStripTrancheVerDocs_Click(object sender, EventArgs e)
        {
            listViewDetalhesTranche_DoubleClick(sender, e);
        }

        private void contextMenuStripTrancheVerRemessas_Click(object sender, EventArgs e)
        {
            if (listViewDetalhesTranche.SelectedItems.Count != 1)
                return;
            try
            {
                string sWhereClause = "";
                ListViewDetalhes oTd = null;

                oTd = (ListViewDetalhes)listViewDetalhesTranche.SelectedItems[0].Tag;
                sWhereClause = "where REMIN_ID = " + oTd.m_sRemessaID;

                RefreshDetalheRemessas(sWhereClause, true);

            }
            catch { }
        }
        private void buttonReenviarRemessas_Click(object sender, EventArgs e)
        {
            try
            {
                //ConfirmaPrivilegios();

                if (MessageBox.Show("Confirma o reenvio de todas as remessas em erro?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                string sSmg = "Reenvio manual de todas as remessas em erro";
                GenericLog.GenLogRegistarAlerta(sSmg, "buttonReenviarRemessas_Click()", 110);
                m_oParameters.EnviarAlertaSituacao(110, sSmg);

                string sQuery = "exec dbo.Update_ReenviarTodasRemessasEmErro";
                m_oParameters.DirectSqlNonQuery(sQuery);

                RefreshRemessasAndTranches();

                MessageBox.Show(this, "Efectuado", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "buttonReenviarRemessas_Click", -2);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

       
    }
}