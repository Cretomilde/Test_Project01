﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;
using CIConfigGlobalParameters;
using System.IO;



namespace CIActividades
{


    public class DetalhesDocumento : InterfaceDocs
    {  
        
        public DateTime m_dtREMIN_DATA;
        public string m_sREMIN_ID;
        public string m_sTRANOUT_ID;
        public string m_sREMIN_PAIS;
        public int m_iREMIN_BANCO;
        public int m_iREMIN_BALCAO;
        public string m_sREMIN_NUMERO;
        public int m_iTRANOUTSTAT_ID;
        public string m_sTRANOUT_NUMERO;

        public string m_sDOC_ID;
        public string m_sDOCORI_ID;
        public int m_iDOC_BALTOM;
        public int m_iDOC_TIPO;
        public string m_sDOC_ZONA5;
        public string m_sDOC_ZONA4;
        public string m_sDOC_ZONA3;
        public decimal m_dDOC_ZONA2;
        public string m_sDOC_ZONA1;
        public int m_iDOC_NSEQ;
        public string m_sDOC_INDEX;
        public DateTime m_dtDOC_DATADIGIT;
        public string m_sDOC_REFARQ;
        public string m_sDOC_MAQUINA;
        public string m_sDOC_CHAVEH;
        public string m_sDOC_CHAVEHEXT;
        public string m_sDOC_DOCNIB;
        public int m_iDOCSTAT_ID;
        public string m_sDOCSTAT_ABR;
        public DateTime m_dtDOC_TIMER;
        public string m_sDOC_ERRO;
        public int m_iOperativa;

        private void InitVars()
        {
            //m_oParameters = new CIConfigGP.CIGlobalParameters();

            m_dtREMIN_DATA=DateTime.MinValue;
            m_sREMIN_ID="-1";
            m_sTRANOUT_ID="-1";
            m_sREMIN_PAIS="PT  ";
            m_iREMIN_BANCO=35;
            m_iREMIN_BALCAO=0;
            m_sREMIN_NUMERO="";
            m_iTRANOUTSTAT_ID=0;
            m_sTRANOUT_NUMERO="";

            m_sDOC_ID="-1";
            m_sDOCORI_ID = "-1";
            m_iDOC_BALTOM = 0;
            m_iDOC_TIPO = 0;
            m_sDOC_ZONA5 = "";
            m_sDOC_ZONA4="";
            m_sDOC_ZONA3="";
            m_dDOC_ZONA2=0;
            m_sDOC_ZONA1="";
            m_iDOC_NSEQ=0;
            m_sDOC_INDEX="";
            m_dtDOC_DATADIGIT = DateTime.MinValue;
            m_sDOC_REFARQ="";
            m_sDOC_MAQUINA="ND";
            m_sDOC_CHAVEH="";
            m_sDOC_CHAVEHEXT="";
            m_sDOC_DOCNIB="";
            m_iDOCSTAT_ID=0;
            m_sDOCSTAT_ABR = "ND";
            m_dtDOC_TIMER = DateTime.MinValue;
            m_sDOC_ERRO = "";

            m_iOperativa = 0;
        }

        public DetalhesDocumento()
        {
            InitVars();
        }

        public DetalhesDocumento(SqlDataReader dr)
        {
            InitVars();

            //try
            //{
                m_dtREMIN_DATA = Convert.ToDateTime(dr["REMIN_DATA"]);
                m_sREMIN_ID = Convert.ToString(dr["REMIN_ID"]);
                m_sREMIN_PAIS = Convert.ToString(dr["REMIN_PAIS"]);
                m_iREMIN_BANCO = Convert.ToInt16(dr["REMIN_BANCO"]);
                m_iREMIN_BALCAO = Convert.ToInt16(dr["REMIN_BALCAO"]);
                m_sREMIN_NUMERO = Convert.ToString(dr["REMIN_NUMERO"]);
                if (dr["TRANOUT_ID"] == DBNull.Value)
                {
                    this.m_sTRANOUT_ID = String.Empty;
                }
                else
                {
                    this.m_sTRANOUT_ID = Convert.ToString(dr["TRANOUT_ID"]);
                }
                if (dr["TRANOUTSTAT_ID"] == DBNull.Value)
                {
                    this.m_iTRANOUTSTAT_ID = 0;
                }
                else
                {
                    this.m_iTRANOUTSTAT_ID = Convert.ToInt16(dr["TRANOUTSTAT_ID"]);
                }
                if (dr["TRANOUT_NUMERO"] == DBNull.Value)
                {
                    this.m_sTRANOUT_NUMERO = String.Empty;
                }
                else
                {
                    this.m_sTRANOUT_NUMERO = Convert.ToString(dr["TRANOUT_NUMERO"]);
                }
                //try
                //{
                //    m_sTRANOUT_ID = Convert.ToString(dr["TRANOUT_ID"]);
                //    m_iTRANOUTSTAT_ID = Convert.ToInt16(dr["TRANOUTSTAT_ID"]);
                //    m_sTRANOUT_NUMERO = Convert.ToString(dr["TRANOUT_NUMERO"]);
                //}
                //catch
                //{
                //}
                m_sDOC_ID = Convert.ToString(dr["DOC_ID"]);
                m_sDOCORI_ID = Convert.ToString(dr["DOCORI_ID"]);
                m_iDOC_BALTOM = Convert.ToInt16(dr["DOC_BALTOM"]);
                m_iDOC_TIPO = Convert.ToInt16(dr["DOC_TIPO"]);
                m_sDOC_ZONA5 = Convert.ToString(dr["DOC_ZONA5"]);
                m_sDOC_ZONA4 = Convert.ToString(dr["DOC_ZONA4"]);
                m_sDOC_ZONA3 = Convert.ToString(dr["DOC_ZONA3"]);
                m_dDOC_ZONA2 = Convert.ToDecimal(dr["DOC_ZONA2"]);
                m_sDOC_ZONA1 = Convert.ToString(dr["DOC_ZONA1"]);
                if (dr["DOC_NSEQ"] == DBNull.Value)
                {
                    m_iDOC_NSEQ = 0;
                }
                else {
                    m_iDOC_NSEQ = Convert.ToInt32(dr["DOC_NSEQ"]);
                }
                //try { m_iDOC_NSEQ = Convert.ToInt32(dr["DOC_NSEQ"]); }
                //catch { }
                if (dr["DOC_INDEX"] == DBNull.Value)
                {
                    m_sDOC_INDEX = String.Empty;
                }
                else
                {
                    m_sDOC_INDEX = Convert.ToString(dr["DOC_INDEX"]);
                }
                //try { m_sDOC_INDEX = Convert.ToString(dr["DOC_INDEX"]); }
                //catch { }
                if (dr["DOC_DATADIGIT"] == DBNull.Value)
                {
                    m_dtDOC_DATADIGIT = DateTime.Now;
                }
                else
                {
                   m_dtDOC_DATADIGIT = Convert.ToDateTime(dr["DOC_DATADIGIT"]); 
                }
                //try { m_dtDOC_DATADIGIT = Convert.ToDateTime(dr["DOC_DATADIGIT"]); }
                //catch { }
                if (dr["DOC_REFARQ"] == DBNull.Value)
                {
                    m_sDOC_REFARQ = String.Empty;
                }
                else
                {
                    m_sDOC_REFARQ = Convert.ToString(dr["DOC_REFARQ"]);
                }
                //try { m_sDOC_REFARQ = Convert.ToString(dr["DOC_REFARQ"]); }
                //catch { }
                //m_sDOC_MAQUINA = Convert.ToString(dr["DOC_MAQUINA"],"00");
                m_sDOC_MAQUINA = Convert.ToInt16(dr["DOC_MAQUINA"]).ToString("00");
                if (dr["DOC_CHAVEH"] == DBNull.Value)
                {
                    m_sDOC_CHAVEH = String.Empty;
                }
                else
                {
                    m_sDOC_CHAVEH = Convert.ToString(dr["DOC_CHAVEH"]);
                }
                //try { m_sDOC_CHAVEH = Convert.ToString(dr["DOC_CHAVEH"]); }
                //catch { }
                if (dr["DOC_CHAVEHEXT"] == DBNull.Value)
                {
                    m_sDOC_CHAVEHEXT = String.Empty;
                }
                else
                {
                    m_sDOC_CHAVEHEXT = Convert.ToString(dr["DOC_CHAVEHEXT"]);
                }
                //try { m_sDOC_CHAVEHEXT = Convert.ToString(dr["DOC_CHAVEHEXT"]); }
                //catch { }
                if (dr["DOC_NIB"] == DBNull.Value)
                {
                    m_sDOC_DOCNIB = String.Empty;
                }
                else
                {
                    m_sDOC_DOCNIB = Convert.ToString(dr["DOC_NIB"]);
                }
                //try { m_sDOC_DOCNIB = Convert.ToString(dr["DOC_NIB"]); }
                //catch { }
                m_iDOCSTAT_ID = Convert.ToInt16(dr["DOCSTAT_ID"]);
                m_sDOCSTAT_ABR = Convert.ToString(dr["DOCSTAT_ABR"]);
                m_dtDOC_TIMER = Convert.ToDateTime(dr["DOC_TIMER"]);
                m_sDOC_ERRO = Convert.ToString(dr["DOC_ERRO"]);
                m_iOperativa = int.Parse(dr["REMPROC_OPERATIVA"].ToString());

            //}
            //catch
            //{
            //}
        }
        public DetalhesDocumento(DataRow oRow)
        {
            InitVars();

            //try
            //{
                m_dtREMIN_DATA = Convert.ToDateTime(oRow["REMIN_DATA"]);
                m_sREMIN_ID = Convert.ToString(oRow["REMIN_ID"]);
                m_sREMIN_PAIS = Convert.ToString(oRow["REMIN_PAIS"]);
                m_iREMIN_BANCO = Convert.ToInt16(oRow["REMIN_BANCO"]);
                m_iREMIN_BALCAO = Convert.ToInt16(oRow["REMIN_BALCAO"]);
                m_sREMIN_NUMERO = Convert.ToString(oRow["REMIN_NUMERO"]);
                if (oRow["TRANOUT_ID"] == DBNull.Value)
                {
                    this.m_sTRANOUT_ID = String.Empty;
                }
                else
                {
                    m_sTRANOUT_ID = Convert.ToString(oRow["TRANOUT_ID"]);
                }
                if (oRow["TRANOUTSTAT_ID"] == DBNull.Value)
                {
                    this.m_iTRANOUTSTAT_ID = 0;
                }
                else
                {
                    m_iTRANOUTSTAT_ID = Convert.ToInt16(oRow["TRANOUTSTAT_ID"]);
                }
                if (oRow["TRANOUT_NUMERO"] == DBNull.Value)
                {
                    this.m_sTRANOUT_NUMERO = String.Empty;
                }
                else
                {
                    m_sTRANOUT_NUMERO = Convert.ToString(oRow["TRANOUT_NUMERO"]);
                }
                //try
                //{
                //    m_sTRANOUT_ID = Convert.ToString(oRow["TRANOUT_ID"]);
                //    m_iTRANOUTSTAT_ID = Convert.ToInt16(oRow["TRANOUTSTAT_ID"]);
                //    m_sTRANOUT_NUMERO = Convert.ToString(oRow["TRANOUT_NUMERO"]);
                //}
                //catch
                //{
                //}
                m_sDOC_ID = Convert.ToString(oRow["DOC_ID"]);
                m_sDOCORI_ID = Convert.ToString(oRow["DOCORI_ID"]);
                m_iDOC_BALTOM = Convert.ToInt16(oRow["DOC_BALTOM"]);
                m_iDOC_TIPO = Convert.ToInt16(oRow["DOC_TIPO"]);
                m_sDOC_ZONA5 = Convert.ToString(oRow["DOC_ZONA5"]);
                m_sDOC_ZONA4 = Convert.ToString(oRow["DOC_ZONA4"]);
                m_sDOC_ZONA3 = Convert.ToString(oRow["DOC_ZONA3"]);
                m_dDOC_ZONA2 = Convert.ToDecimal(oRow["DOC_ZONA2"]);
                m_sDOC_ZONA1 = Convert.ToString(oRow["DOC_ZONA1"]);
                if (oRow["DOC_NSEQ"] == DBNull.Value)
                {
                    m_iDOC_NSEQ = 0;
                }
                else {
                    m_iDOC_NSEQ = Convert.ToInt32(oRow["DOC_NSEQ"]);
                }
                //try { m_iDOC_NSEQ = Convert.ToInt32(oRow["DOC_NSEQ"]); }
                //catch { }
                if (oRow["DOC_INDEX"] == DBNull.Value)
                {
                    m_sDOC_INDEX = String.Empty;
                }
                else
                {
                    m_sDOC_INDEX = Convert.ToString(oRow["DOC_INDEX"]);
                }
                //try { m_sDOC_INDEX = Convert.ToString(oRow["DOC_INDEX"]); }
                //catch { }
                if (oRow["DOC_DATADIGIT"] == DBNull.Value)
                {
                    m_dtDOC_DATADIGIT = DateTime.Now;
                }
                else
                {
                    m_dtDOC_DATADIGIT = Convert.ToDateTime(oRow["DOC_DATADIGIT"]);
                }
                //try { m_dtDOC_DATADIGIT = Convert.ToDateTime(oRow["DOC_DATADIGIT"]); }
                //catch { }
                if (oRow["DOC_REFARQ"] == DBNull.Value)
                {
                    m_sDOC_REFARQ = String.Empty;
                }
                else
                {
                    m_sDOC_REFARQ = Convert.ToString(oRow["DOC_REFARQ"]);
                }
                //try { m_sDOC_REFARQ = Convert.ToString(oRow["DOC_REFARQ"]); }
                //catch { }
                //m_sDOC_MAQUINA = Convert.ToString(oRow["DOC_MAQUINA"], "00");
                m_sDOC_MAQUINA = Convert.ToInt16(oRow["DOC_MAQUINA"]).ToString("00");
                if (oRow["DOC_CHAVEH"] == DBNull.Value)
                {
                    m_sDOC_CHAVEH = String.Empty;
                }
                else
                {
                    m_sDOC_CHAVEH = Convert.ToString(oRow["DOC_CHAVEH"]);
                }
                //try { m_sDOC_CHAVEH = Convert.ToString(oRow["DOC_CHAVEH"]); }
                //catch { }              
                //try { m_sDOC_CHAVEHEXT = Convert.ToString(oRow["DOC_CHAVEHEXT"]); }
                //catch { }
                if (oRow["DOC_NIB"] == DBNull.Value)
                {
                }
                else
                {
                    m_sDOC_DOCNIB = Convert.ToString(oRow["DOC_NIB"]);
                }
                //try { m_sDOC_DOCNIB = Convert.ToString(oRow["DOC_NIB"]); }
                //catch { }                
                m_iDOCSTAT_ID = Convert.ToInt16(oRow["DOCSTAT_ID"]);
                m_sDOCSTAT_ABR = Convert.ToString(oRow["DOCSTAT_ABR"]);
                m_dtDOC_TIMER = Convert.ToDateTime(oRow["DOC_TIMER"]);
                m_sDOC_ERRO = Convert.ToString(oRow["DOC_ERRO"]);
                m_iOperativa = int.Parse(oRow["REMPROC_OPERATIVA"].ToString());

            //}
            //catch
            //{
            //}
        }

        public ListViewItem MakeListViewItemDetalhesDocumento(string sDateFormat, string sDateTimeFormat)
        {
            ListViewItem olvItem = new ListViewItem();
                    
            olvItem.Text = m_sDOC_ID;
            olvItem.SubItems.Add(m_sDOC_ZONA5);
            olvItem.SubItems.Add(m_sDOC_ZONA4);
            olvItem.SubItems.Add(m_sDOC_ZONA3);
            string montanteToInsert = this.m_dDOC_ZONA2.ToString().Equals("0") ? this.m_dDOC_ZONA2.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.m_dDOC_ZONA2).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dDOC_ZONA2).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(m_sDOC_ZONA1);
            olvItem.SubItems.Add(m_iDOCSTAT_ID.ToString() + " " + m_sDOCSTAT_ABR);
            olvItem.SubItems.Add(m_sDOC_DOCNIB);
            olvItem.SubItems.Add(m_sDOC_REFARQ);
            olvItem.SubItems.Add(m_iDOC_NSEQ.ToString());
            olvItem.SubItems.Add(m_sDOC_CHAVEH);
            olvItem.SubItems.Add(m_sDOC_INDEX);
            olvItem.SubItems.Add(m_sDOC_MAQUINA);
            olvItem.SubItems.Add(m_iDOC_BALTOM.ToString());
            olvItem.SubItems.Add(m_sDOC_CHAVEHEXT);
            olvItem.SubItems.Add(m_iDOC_TIPO.ToString());
            olvItem.SubItems.Add(m_dtDOC_TIMER.ToString(sDateTimeFormat));

            olvItem.SubItems.Add(m_dtREMIN_DATA.ToString(sDateFormat));
            olvItem.SubItems.Add(m_sREMIN_ID);
            olvItem.SubItems.Add(m_sTRANOUT_ID);
            olvItem.SubItems.Add(m_sREMIN_PAIS);
            olvItem.SubItems.Add(m_iREMIN_BANCO.ToString());
            olvItem.SubItems.Add(m_iREMIN_BALCAO.ToString());
            olvItem.SubItems.Add(m_sREMIN_NUMERO);
            olvItem.SubItems.Add(m_iTRANOUTSTAT_ID.ToString());
            olvItem.SubItems.Add(m_sTRANOUT_NUMERO);
            olvItem.SubItems.Add(m_sDOC_ERRO);
            olvItem.SubItems.Add(m_sDOCORI_ID);
            olvItem.SubItems.Add(m_dtDOC_DATADIGIT.ToString(sDateFormat));

            return olvItem;
        }

        public string getImgFrente(CIConfigGP.CIGlobalParameters oParameters, Int32? origem = null)
        {
            string sFileNameFrente, sWhereClauseFront;
            sWhereClauseFront = " where DOC_ID= " + m_sDOC_ID + " and IMG_SIDE = 0 and IMG_TYPE= 'JPG'";
            byte[] aImgF = (byte[])oParameters.DirectSqlScalar("select IMG_IMAGE from dbo.Imagem" + sWhereClauseFront);

            if (aImgF == null)
                return null;

            sFileNameFrente = oParameters.GetTempFileName("IMGFront") + ".jpg";

            WriteImage(aImgF, sFileNameFrente);

            return sFileNameFrente;

        }

        public string getImgBack(CIConfigGP.CIGlobalParameters oParameters, Int32? origem = null)
        {
            string sFileNameBack, sWhereClauseBack;
            sWhereClauseBack = " where DOC_ID= " + m_sDOC_ID + " and IMG_SIDE = 1 and IMG_TYPE= 'JPG'";
            byte[] aImgB = (byte[])oParameters.DirectSqlScalar("select IMG_IMAGE from dbo.Imagem" + sWhereClauseBack);

            if (aImgB == null)
                return null;

            sFileNameBack = oParameters.GetTempFileName("IMGBack") + ".jpg";
            WriteImage(aImgB, sFileNameBack);

            return sFileNameBack;
        }

        protected void WriteImage(byte[] aBytes, string sFileName)
        {
            StreamWriter sw = new StreamWriter(sFileName, false);
            BinaryWriter bw = new BinaryWriter(sw.BaseStream);
            bw.Write(aBytes);
            sw.Close();
            bw.Close();
        }

    }
}
