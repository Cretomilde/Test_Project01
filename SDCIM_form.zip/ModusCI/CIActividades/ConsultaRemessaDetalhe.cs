﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Windows.Forms;
using NBiis;

namespace CIActividades
{
    class ConsultaRemessaDetalhe
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public long m_lConsultaId;
        public string m_sReminId;
        public int m_iAguardaRedig;
        public string m_sBalcao;
        public string m_sChaveHost;
        public decimal m_dMontante;
        public string m_sNumContaDep;
        public string m_sNIB;
        public DateTime m_dDataRem;
        public int m_iEstadoLote;
        public string m_sEstadoLote;
        public DateTime m_dHoraChegada;
        public string m_sIdRemessa;
        public string m_sNomeImagemCabLote;
        public string m_sNumCabecaLote;
        public int m_iNumDocs;
        public int m_iNumPaginaCabLote;
        public string m_sNumPropostaLogica;
        public string m_sOrigem;
        public string m_sSubProduto;
        public string m_sTipoRemessa;
        public string m_sFiltro;
        public int m_iEstado;
        public int m_iMaisResultados;
        public DateTime m_dTimerCriacao;
        public DateTime m_dTimerActualizacao;
        public string m_sErro;

        public ConsultaRemessaDetalhe()
        {
            m_lConsultaId = 0;
            m_sReminId = "";
            m_iAguardaRedig = 0;
            m_sBalcao = "";
            m_sChaveHost = "";
            m_dMontante = 0;
            m_sNumContaDep = "";
            m_sNIB = "";
            m_dDataRem = DateTime.MinValue;
            m_iEstadoLote = 0;
            m_sEstadoLote = "";
            m_dHoraChegada = DateTime.MinValue;
            m_sIdRemessa = "";
            m_sNomeImagemCabLote = "";
            m_sNumCabecaLote = "";
            m_iNumDocs = 0;
            m_iNumPaginaCabLote = 0;
            m_sNumPropostaLogica = "";
            m_sOrigem = "";
            m_sSubProduto = "";
            m_sTipoRemessa = "";
            m_sFiltro="";
            m_iEstado=0;
            m_iMaisResultados=0;
            m_dTimerCriacao= DateTime.MinValue;
            m_dTimerActualizacao= DateTime.MinValue;
            m_sErro="";
            m_oParameters = null;
        }

        public ConsultaRemessaDetalhe(DataRow oRow, CIConfigGP.CIGlobalParameters oParameters)
        {
            try
            {
                m_lConsultaId = long.Parse(oRow["CONSULTA_ID"].ToString());
                m_sReminId = oRow["REMIN_ID"].ToString();
                m_sFiltro = oRow["filtro"].ToString();
                m_iEstado = int.Parse(oRow["ESTADO"].ToString());
                 m_dTimerCriacao = DateTime.Parse(oRow["TIMER_CRIACAO"].ToString());
                m_dTimerActualizacao = DateTime.Parse(oRow["TIMER_ACTUALIZACAO"].ToString());
                 m_oParameters = oParameters;

                //try
                //{
                 if (oRow["LAST_ERRO_DESC"] == DBNull.Value)
                 {
                     this.m_sErro = string.Empty;
                }
                else{

                    m_sErro = oRow["LAST_ERRO_DESC"].ToString();
                }
                    //try
                    //{
                    //    m_sErro = oRow["LAST_ERRO_DESC"].ToString();
                    //}
                    //catch { }                    
                    m_iAguardaRedig = int.Parse(oRow["aguarda_redig"].ToString());                
                    m_sBalcao = oRow["BALCAO"].ToString();
                    m_sChaveHost = oRow["CHAVEHOST"].ToString();
                    m_dMontante = decimal.Parse(oRow["MONTANTE"].ToString());
                    m_sNumContaDep = oRow["NUM_CONTA_DEP"].ToString();
                    m_sNIB = oRow["NIB"].ToString();
                    m_dDataRem = DateTime.Parse(oRow["DATAREM"].ToString());
                    m_iEstadoLote = int.Parse(oRow["ESTADO_LOTE"].ToString());
                    m_sEstadoLote = oRow["ESTADO_LOTE"].ToString() + " - " + oRow["ESTADO_DESC"].ToString();
                    m_dHoraChegada = DateTime.Parse(oRow["hora_chegada"].ToString());
                    m_sIdRemessa = oRow["id_remessa"].ToString();
                    m_sNomeImagemCabLote = oRow["nome_imagem_cablote"].ToString();
                    m_sNumCabecaLote = oRow["num_cabeca_lote"].ToString();
                    m_iNumDocs = int.Parse(oRow["num_docs"].ToString());
                    m_iNumPaginaCabLote = int.Parse(oRow["num_paginas_cab_lote"].ToString());
                    m_sNumPropostaLogica = oRow["num_proposta_logica"].ToString();
                    m_sOrigem = oRow["origem"].ToString();
                    m_sSubProduto = oRow["subproduto"].ToString();
                    m_sTipoRemessa = oRow["tipo_remessa"].ToString();
                    m_iMaisResultados = int.Parse(oRow["mais_resultados"].ToString());
                              
                //}
                //catch{}
            }
            catch(Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ConsultaRemessaDetalhe", int.Parse(m_lConsultaId.ToString()));
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public ListViewItem MakeListViewItem(string sDateFormat, string sDateTimeFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_lConsultaId.ToString();
            olvItem.SubItems.Add(m_sReminId);
            olvItem.SubItems.Add(m_dTimerCriacao.ToString(sDateTimeFormat));
            olvItem.SubItems.Add(m_dTimerActualizacao.ToString(sDateTimeFormat));
            olvItem.SubItems.Add(m_iEstado.ToString());
            olvItem.SubItems.Add(m_sFiltro);
            olvItem.SubItems.Add(m_iAguardaRedig.ToString());
            olvItem.SubItems.Add(m_sBalcao);
            olvItem.SubItems.Add(m_sChaveHost);
            olvItem.SubItems.Add(m_dMontante.ToString("0.00"));
            olvItem.SubItems.Add(m_sNumContaDep);
            olvItem.SubItems.Add(m_sNIB);
            if (m_dDataRem.ToString().Equals(DateTime.MinValue.ToString()))
            {
                olvItem.SubItems.Add("");
            }
            else
            {
                olvItem.SubItems.Add(m_dDataRem.ToString(sDateTimeFormat));
            }
            //olvItem.SubItems.Add(m_iEstadoLote.ToString());
            olvItem.SubItems.Add(m_sEstadoLote);
            if (m_dHoraChegada.ToString().Equals(DateTime.MinValue.ToString()))
            {
                olvItem.SubItems.Add("");
            }
            else
            {
                olvItem.SubItems.Add(m_dHoraChegada.ToString(sDateTimeFormat));
            }
            olvItem.SubItems.Add(m_sIdRemessa);
            olvItem.SubItems.Add(m_sNomeImagemCabLote);
            olvItem.SubItems.Add(m_sNumCabecaLote);
            olvItem.SubItems.Add(m_iNumDocs.ToString());
            olvItem.SubItems.Add(m_iNumPaginaCabLote.ToString());
            olvItem.SubItems.Add(m_sNumPropostaLogica);
            olvItem.SubItems.Add(m_sOrigem);
            olvItem.SubItems.Add(m_sSubProduto);
            olvItem.SubItems.Add(m_sTipoRemessa);
            olvItem.SubItems.Add(m_iMaisResultados.ToString());
            olvItem.SubItems.Add(m_sErro);

            return olvItem;
        }
    }
}
