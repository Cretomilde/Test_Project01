﻿namespace CIActividades
{
    partial class MostraImagem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MostraImagem));
            this.picImgFront = new System.Windows.Forms.PictureBox();
            this.pictImgBack = new System.Windows.Forms.PictureBox();
            this.labelErro = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picImgFront)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictImgBack)).BeginInit();
            this.SuspendLayout();
            // 
            // picImgFront
            // 
            this.picImgFront.ErrorImage = global::CIActividades.Properties.Resources.Erro;
            this.picImgFront.Location = new System.Drawing.Point(17, 15);
            this.picImgFront.Name = "picImgFront";
            this.picImgFront.Size = new System.Drawing.Size(489, 249);
            this.picImgFront.TabIndex = 1;
            this.picImgFront.TabStop = false;
            // 
            // pictImgBack
            // 
            this.pictImgBack.ErrorImage = global::CIActividades.Properties.Resources.Erro;
            this.pictImgBack.Location = new System.Drawing.Point(17, 270);
            this.pictImgBack.Name = "pictImgBack";
            this.pictImgBack.Size = new System.Drawing.Size(489, 249);
            this.pictImgBack.TabIndex = 2;
            this.pictImgBack.TabStop = false;
            // 
            // labelErro
            // 
            this.labelErro.AutoSize = true;
            this.labelErro.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelErro.ForeColor = System.Drawing.Color.Red;
            this.labelErro.Location = new System.Drawing.Point(37, 240);
            this.labelErro.Name = "labelErro";
            this.labelErro.Size = new System.Drawing.Size(452, 56);
            this.labelErro.TabIndex = 3;
            this.labelErro.Text = "ERRO NA IMAGEM";
            this.labelErro.Visible = false;
            // 
            // MostraImagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 534);
            this.Controls.Add(this.labelErro);
            this.Controls.Add(this.pictImgBack);
            this.Controls.Add(this.picImgFront);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MostraImagem";
            this.ShowInTaskbar = false;
            this.Text = "Imagem";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MostraImagem_FormClosed);
            this.Load += new System.EventHandler(this.MostraImagem_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picImgFront)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictImgBack)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picImgFront;
        private System.Windows.Forms.PictureBox pictImgBack;
        private System.Windows.Forms.Label labelErro;

    }
}