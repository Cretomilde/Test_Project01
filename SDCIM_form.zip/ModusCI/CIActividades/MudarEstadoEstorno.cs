﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CIActividades
{
    public partial class MudarEstadoEstorno : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        public int id;
        public string estado;
        public int idEstado;
        public MudarEstadoEstorno(CIConfigGP.CIGlobalParameters oParameters, int id, string estado, int idEstado)
        {
            this.idEstado = idEstado;
            this.id = id;
            this.estado = estado;
            m_oParameters = oParameters;
            InitializeComponent();
            preenheComboBox();
            preenchertexbox();
        }
        private void preenchertexbox() {

            this.tbCurrentEstado.Text = estado;
        
        }

        private void preenheComboBox()
        {
            DataSet ds = null;


            if (cbEstadoNovo.Items.Count > 0)
            {
                return;
            }

            try
            {

                string sComm = "select * from dbo.ESTORNO_STATUS";
                ds = m_oParameters.DirectSqlDataSet(sComm, "Estorno_Estatus");
                cbEstadoNovo.DataSource = ds.Tables[0];
                cbEstadoNovo.DisplayMember = "NM_ESTRN_STATUS";
                cbEstadoNovo.ValueMember = "ID";

            }
            finally
            {
                if (ds != null)
                {
                    ds.Dispose();
                    ds = null;
                }
            }
        }
       
        private void cbEstadoNovo_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            this.tbCurrentEstado.Text = cbEstadoNovo.Text;
        }

        private void btOK_Click(object sender, EventArgs e)
        {
            estado = cbEstadoNovo.Text;
            idEstado = Convert.ToInt32(cbEstadoNovo.SelectedValue);
            SqlDataReader dr = null;
            string sQuery = "update  REMESSA_BALCAO Set REMBALCAO_STAT_ID ="+idEstado+"where ID =" + id;
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
            }
            catch
            {
                MessageBox.Show("Não foi possivel mudar o estado");
            }

            DialogResult = DialogResult.OK;
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
