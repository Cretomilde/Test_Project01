﻿namespace CIActividades
{
    partial class AlertasForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);

            m_oMenuInterface.alertasToolStripMenuItemEnable(true);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AlertasForm));
            this.listViewAlertas = new NBIISNET.ListViewBase();
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.m_btRefresh = new System.Windows.Forms.Button();
            this.m_ctrldtFim = new System.Windows.Forms.DateTimePicker();
            this.m_ctrldtInicio = new System.Windows.Forms.DateTimePicker();
            this.cbAlertasFiltro = new System.Windows.Forms.ComboBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonSairJanela = new System.Windows.Forms.Button();
            this.labelCount = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listViewAlertas
            // 
            this.listViewAlertas.AllowColumnReorder = true;
            this.listViewAlertas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
                        | System.Windows.Forms.AnchorStyles.Left) 
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewAlertas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader15,
            this.columnHeader21,
            this.columnHeader18,
            this.columnHeader6,
            this.columnHeader20,
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader7,
            this.columnHeader8});
            this.listViewAlertas.EnableExportar = true;
            this.listViewAlertas.FullRowSelect = true;
            this.listViewAlertas.GridLines = true;
            this.listViewAlertas.HideSelection = false;
            this.listViewAlertas.Location = new System.Drawing.Point(23, 94);
            this.listViewAlertas.MultiSelect = false;
            this.listViewAlertas.Name = "listViewAlertas";
            this.listViewAlertas.Size = new System.Drawing.Size(984, 172);
            this.listViewAlertas.TabIndex = 12;
            this.listViewAlertas.TabStop = false;
            this.listViewAlertas.UseCompatibleStateImageBehavior = false;
            this.listViewAlertas.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Alerta ID";
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "Alerta Timer";
            this.columnHeader21.Width = 95;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Alerta Text";
            this.columnHeader18.Width = 390;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "Situação ID";
            this.columnHeader20.Width = 77;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Situação Desc";
            this.columnHeader1.Width = 133;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Tipo Acção ID";
            this.columnHeader2.Width = 88;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Tipo Acção Desc";
            this.columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Acção ID";
            this.columnHeader4.Width = 61;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Acção Desc";
            this.columnHeader5.Width = 111;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Alerta Desc";
            this.columnHeader6.Width = 113;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Acção Status";
            this.columnHeader7.Width = 98;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Acção Timer";
            this.columnHeader8.Width = 91;
            // 
            // m_btRefresh
            // 
            this.m_btRefresh.Image = global::CIActividades.Properties.Resources.Refresh;
            this.m_btRefresh.Location = new System.Drawing.Point(580, 18);
            this.m_btRefresh.Name = "m_btRefresh";
            this.m_btRefresh.Size = new System.Drawing.Size(53, 42);
            this.m_btRefresh.TabIndex = 4;
            this.toolTip1.SetToolTip(this.m_btRefresh, "Refresh");
            this.m_btRefresh.UseVisualStyleBackColor = true;
            this.m_btRefresh.Click += new System.EventHandler(this.m_btRefresh_Click);
            // 
            // m_ctrldtFim
            // 
            this.m_ctrldtFim.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrldtFim.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrldtFim.Location = new System.Drawing.Point(335, 12);
            this.m_ctrldtFim.Name = "m_ctrldtFim";
            this.m_ctrldtFim.Size = new System.Drawing.Size(202, 20);
            this.m_ctrldtFim.TabIndex = 2;
            // 
            // m_ctrldtInicio
            // 
            this.m_ctrldtInicio.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrldtInicio.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrldtInicio.Location = new System.Drawing.Point(85, 12);
            this.m_ctrldtInicio.Name = "m_ctrldtInicio";
            this.m_ctrldtInicio.Size = new System.Drawing.Size(202, 20);
            this.m_ctrldtInicio.TabIndex = 1;
            // 
            // cbAlertasFiltro
            // 
            this.cbAlertasFiltro.DropDownHeight = 300;
            this.cbAlertasFiltro.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAlertasFiltro.DropDownWidth = 476;
            this.cbAlertasFiltro.FormattingEnabled = true;
            this.cbAlertasFiltro.IntegralHeight = false;
            this.cbAlertasFiltro.ItemHeight = 13;
            this.cbAlertasFiltro.Location = new System.Drawing.Point(61, 50);
            this.cbAlertasFiltro.Name = "cbAlertasFiltro";
            this.cbAlertasFiltro.Size = new System.Drawing.Size(476, 21);
            this.cbAlertasFiltro.TabIndex = 3;
            this.cbAlertasFiltro.SelectedIndexChanged += new System.EventHandler(this.cbAlertasFiltro_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "De";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(304, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "a ";
            // 
            // buttonSairJanela
            // 
            this.buttonSairJanela.Image = ((System.Drawing.Image)(resources.GetObject("buttonSairJanela.Image")));
            this.buttonSairJanela.Location = new System.Drawing.Point(660, 18);
            this.buttonSairJanela.Name = "buttonSairJanela";
            this.buttonSairJanela.Size = new System.Drawing.Size(46, 42);
            this.buttonSairJanela.TabIndex = 5;
            this.buttonSairJanela.UseVisualStyleBackColor = true;
            this.buttonSairJanela.Click += new System.EventHandler(this.buttonSairJanela_Click);
            // 
            // labelCount
            // 
            this.labelCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(921, 68);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(57, 13);
            this.labelCount.TabIndex = 18;
            this.labelCount.Text = "0 Registos";
            // 
            // AlertasForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 278);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.buttonSairJanela);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbAlertasFiltro);
            this.Controls.Add(this.listViewAlertas);
            this.Controls.Add(this.m_btRefresh);
            this.Controls.Add(this.m_ctrldtFim);
            this.Controls.Add(this.m_ctrldtInicio);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AlertasForm";
            this.ShowInTaskbar = false;
            this.Text = "Alertas";
            this.Load += new System.EventHandler(this.AlertasForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private NBIISNET.ListViewBase listViewAlertas;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.Button m_btRefresh;
        private System.Windows.Forms.DateTimePicker m_ctrldtFim;
        private System.Windows.Forms.DateTimePicker m_ctrldtInicio;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ComboBox cbAlertasFiltro;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonSairJanela;
        private System.Windows.Forms.Label labelCount;
    }
}