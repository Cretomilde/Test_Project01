﻿using System;
using System.Collections;
using System.Data.SqlClient;
using System.Windows.Forms;
using NBiis;
using NBiis.Generic;

namespace CIActividades
{
    class DetalheTranche
    {
        private CIConfigGP.CIGlobalParameters m_oParameters;

        public int remId;
        public int estadoId;
        public int transId;
        public DateTime? remData;
        public int numero;
        public string estado;
        public int quantidade;
        public double montante;
        public string erro;
        public string chaveWS;
        public int estadoTIBCO;


        private void initVars()
        {
            this.remId = 0;
            this.estadoId = 0;
            this.transId = 0;
            this.remData = DateTime.MinValue;
            this.numero = 0;
            this.estado = "";
            this.quantidade = 0;
            this.erro = "";
            this.chaveWS = "";
            this.estadoTIBCO = 0;
            this.montante = 0.0;
        }

        public string GetTableName()
        {
            return "TRANCHE_OUT";
        }

        public DetalheTranche(SqlDataReader dr, CIConfigGP.CIGlobalParameters oParameters)
        {
            initVars();

            this.remId = Convert.ToInt32(dr["ID"]);
            this.estadoId = String.IsNullOrEmpty(dr["TRANOUTSTAT_ID"].ToString()) ? (Int32)0 : Convert.ToInt32(dr["TRANOUTSTAT_ID"]);
            this.transId = String.IsNullOrEmpty(dr["TRANOUT_ID"].ToString()) ? (Int32)0 : Convert.ToInt32(dr["TRANOUT_ID"]);
            this.remData = String.IsNullOrEmpty(dr["TRANOUT_TIMER"].ToString()) ? (DateTime?)null : Convert.ToDateTime(dr["TRANOUT_TIMER"]);
            this.numero = String.IsNullOrEmpty(dr["TRANOUT_NUMERO"].ToString()) ? (Int32)0 : Convert.ToInt32(dr["TRANOUT_NUMERO"]); ;
            this.estado = String.IsNullOrEmpty(dr["TRANOUTSTAT_ABR"].ToString()) ? string.Empty : Convert.ToString(dr["TRANOUTSTAT_ABR"]);
            this.quantidade = Convert.ToInt32(dr["TRANOUT_QT_DOCS"]);
            this.erro = String.IsNullOrEmpty(dr["TRANOUT_ERRO"].ToString()) ? string.Empty : Convert.ToString(dr["TRANOUT_ERRO"]);
            this.chaveWS = Convert.ToString(dr["CHAVE_WEBSERVICE"]);
            this.estadoTIBCO = String.IsNullOrEmpty(dr["ESTADO"].ToString()) ? (Int32)0 : Convert.ToInt32(dr["ESTADO"]);
            this.montante = Convert.ToDouble(dr["TRANOUT_MT_DOCS"]);

            this.m_oParameters = oParameters;
        }

        public ListViewItem MakeListViewItemTranche(string sDateFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = remId.ToString();
            olvItem.SubItems.Add(transId.ToString());
            olvItem.SubItems.Add(remData.ToString());
            olvItem.SubItems.Add(numero.ToString());
            olvItem.SubItems.Add(estadoId.ToString() + " " + estado.ToString());
            olvItem.SubItems.Add(quantidade.ToString());
            string montanteToInsert = montante.ToString().Equals("0") ? montante.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(montante).PadLeft(16, ' ');
            //olvItem.SubItems.Add(montante.ToString());
            olvItem.SubItems.Add(montanteToInsert);
            //olvItem.SubItems.Add(erro.ToString() == "0" ? "" : "Erro");
            olvItem.SubItems.Add(erro.ToString());
            olvItem.SubItems.Add(chaveWS.ToString());
            olvItem.SubItems.Add(estadoTIBCO.ToString());


            return olvItem;
        }

        public void ChangeEstado(int iNewStatus, string m_sSPProcessa, string m_sSPValida)
        {
            // ValidaChangeEstadoTranche(iNewStatus);
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@OldEstado", estadoId));
            oParams.Add(new GeneralDBParameters("@NewEstado", iNewStatus));
            oParams.Add(new GeneralDBParameters("@TranoutID", transId));

            if (m_sSPValida.Length > 0)
            {
                m_oParameters.DirectStoredProcedureNonQuery(m_sSPValida, ref oParams);
            }
            m_oParameters.DirectStoredProcedureNonQuery(m_sSPProcessa, ref oParams);

            string sSmg = "Mudou estado da TRANCHE: " + transId + " de " + estado.ToString() + " para " + iNewStatus.ToString();
            GenericLog.GenLogRegistarAlerta(sSmg, "ChangeEstadoTranche()", 110);
            m_oParameters.EnviarAlertaSituacao(110, sSmg);

        }

    }
}
