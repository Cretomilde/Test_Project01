﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Windows.Forms;
using System.IO;

using System.Data.SqlClient;

namespace CIActividades
{
    class ConsultaDocumentosDetalhe : InterfaceDocs
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public long m_lConsultaId;
        public int m_iOperativa;
        public string m_sDoc_id;
        public int m_iAguardaRedig;
        public int m_iAnomaliaDadosIleg;
        public string m_sBalcao;
        public string m_sChaveHost;
        public string m_sZIB;
        public string m_sNumConta;
        public string m_sNumCheque;
        public decimal m_dMontante;
        public string m_sTipoCheque;
        public int m_iValidaRequisitosDoc;
        public int m_iEstado;
        public string m_sEstado;
        public int m_iFsl;
        public string m_sIdDocumento;
        public string m_sIdRemessa;
        public long m_lLote;
        public int m_iMaquina;
        public string m_sNomeImagem;
        public int m_iNumPaginas;
        public string m_sOrigem;
        public string m_sRefarqCaptura;
        public int m_iSequencia;
        public string m_sSubProduto;
        public string m_sFiltro;
        public int m_iEstadoTibco;
        public int m_iMaisResultados;
        public string m_sErro;
        public DateTime m_dTimerCriacao;
        public DateTime m_dTimerActualizacao;

        //imagem
        //public int m_iEstadoImagemF;
        //public int m_iEstadoImagemB;
        //public string m_sEstadoImagemF;
        //public string m_sEstadoImagemB;

       

        public ConsultaDocumentosDetalhe()
        {
            InicializaVariaveis();
            m_oParameters = null;
        }

        protected void InicializaVariaveis()
        {

            m_lConsultaId = 0;
            m_iOperativa = 0;
            m_sDoc_id = "";
            m_sChaveHost = "";

            //m_iEstadoImagemF = 0;
            //m_iEstadoImagemB = 0;
            //m_sEstadoImagemF = "";
            //m_sEstadoImagemB = "";

            m_sFiltro = "";
            m_iEstadoTibco = 0;
            m_sErro = "";
            m_dTimerCriacao = DateTime.MinValue;
            m_dTimerActualizacao = DateTime.MinValue;

            m_sErro = "";
            m_iAguardaRedig = 0;
            m_iAnomaliaDadosIleg = 0;
            m_sBalcao = "";
            m_sChaveHost = "";
            m_sZIB = "";
            m_sNumConta = "";
            m_sNumCheque = "";
            m_dMontante = 0;
            m_sTipoCheque = "";
            m_iValidaRequisitosDoc = 0;
            m_iEstado = 0;
            m_sEstado = "";
            m_iFsl = 0;
            m_sIdDocumento = "";
            m_sIdRemessa = "";
            m_lLote = 0;
            m_iMaquina = 0;
            m_sNomeImagem = "";
            m_iNumPaginas = 0;
            m_sOrigem = "";
            m_sRefarqCaptura = "";
            m_iSequencia = 0;
            m_sSubProduto = "";
            m_iMaisResultados=0;
        }

        public ConsultaDocumentosDetalhe(DataRow oRow, CIConfigGP.CIGlobalParameters oParameters)
        {
            //try
            //{
                m_oParameters = oParameters;
                InicializaVariaveis();

                m_lConsultaId = Convert.ToInt64(oRow["CONSULTA_ID"].ToString());
                m_iOperativa = Convert.ToInt32(oRow["OPERATIVA"].ToString());
                m_sDoc_id = oRow["DOC_ID"].ToString();
                m_sFiltro = oRow["FILTRO"].ToString();
                m_dTimerCriacao = Convert.ToDateTime(oRow["TIMER_CRIACAO"].ToString());
                m_dTimerActualizacao = Convert.ToDateTime(oRow["TIMER_ACTUALIZACAO"].ToString());
                m_iEstadoTibco = Convert.ToInt32(oRow["ESTADO_TIBCO"].ToString());

                //try
                //{
                if (oRow["LAST_ERRO_DESC"] == DBNull.Value) {

                    m_sErro = String.Empty;
                    m_sErro = string.Empty;
                } else {
                    m_sErro = oRow["LAST_ERRO_DESC"].ToString();
                }
                    //try
                    //{
                    //    m_sErro = oRow["LAST_ERRO_DESC"].ToString();
                    //}
                    //catch { }
                    m_iAguardaRedig = Convert.ToInt32(oRow["aguarda_redig"].ToString());

                    m_iAnomaliaDadosIleg = Convert.ToInt32(oRow["anomalia_dados_ileg"].ToString());
                    m_sBalcao = oRow["balcao"].ToString();
                    m_sChaveHost = oRow["chavehost"].ToString();
                    m_sZIB = oRow["ZIB"].ToString();
                    m_sNumConta = oRow["NUM_CONTA"].ToString();
                    m_sNumCheque = oRow["NUM_CHEQUE"].ToString();
                    m_dMontante = Convert.ToDecimal(oRow["MONTANTE"].ToString());
                    m_sTipoCheque = oRow["TIPOCHEQUE"].ToString();
                    m_iValidaRequisitosDoc = Convert.ToInt32(oRow["VALIDA_REQUiSITOS_DOC"].ToString());
                    m_iEstado = Convert.ToInt32(oRow["estado"]);
                    m_sEstado = oRow["estado"].ToString() + " - " + oRow["estado_desc"].ToString();
                    m_iFsl = Convert.ToInt32(oRow["fsl"].ToString());
                    m_sIdDocumento = oRow["id_documento"].ToString();
                    m_sIdRemessa = oRow["id_remessa"].ToString();
                    m_lLote = Convert.ToInt64(oRow["lote"].ToString());
                    m_iMaquina = Convert.ToInt32(oRow["maquina"].ToString());
                    m_sNomeImagem = oRow["nome_imagem"].ToString();
                    m_iNumPaginas = Convert.ToInt32(oRow["num_paginas"].ToString());
                    m_sOrigem = oRow["origem"].ToString();
                    m_sRefarqCaptura = oRow["refarq_captura"].ToString();
                    m_iSequencia = Convert.ToInt32(oRow["sequencia"].ToString());
                    m_sSubProduto = oRow["subproduto"].ToString();


                    //m_iEstadoImagemF = Convert.ToInt32(oRow["ESTADO_IMAGEMF"].ToString());
                    //m_iEstadoImagemB = Convert.ToInt32(oRow["ESTADO_IMAGEMB"].ToString());
                    //m_sEstadoImagemF = converte2stringF();
                    //m_sEstadoImagemB = converte2stringB();



                    m_iMaisResultados = Convert.ToInt32(oRow["MAIS_RESULTADOS"].ToString());
                //}
                //catch { }
            //}
            //catch {}

            
        }

        //private string converte2stringF()
        //{
        //    if (m_iEstadoImagemF == 2)
        //        return "Imagem Disponivel";
        //    else
        //        return "Sem Imagem Disponivel";
        //}

        //private string converte2stringB()
        //{
        //    if (m_iEstadoImagemB == 2)
        //        return "Imagem Disponivel";
        //    else
        //        return "Sem Imagem Disponivel";

        //}

        public ListViewItem MakeListViewItem(string sDateFormat, string sDateTimeFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_lConsultaId.ToString();
            olvItem.SubItems.Add(m_iOperativa.ToString());
            olvItem.SubItems.Add(m_sDoc_id);
            olvItem.SubItems.Add(m_dTimerCriacao.ToString(sDateTimeFormat));
            olvItem.SubItems.Add(m_dTimerActualizacao.ToString(sDateTimeFormat));
            olvItem.SubItems.Add(m_iEstadoTibco.ToString());
            olvItem.SubItems.Add(m_sFiltro);
            olvItem.SubItems.Add(m_iAguardaRedig.ToString());
            olvItem.SubItems.Add(m_iAnomaliaDadosIleg.ToString());
            olvItem.SubItems.Add(m_sBalcao);
            olvItem.SubItems.Add(m_sChaveHost);
            olvItem.SubItems.Add(m_sZIB);
            olvItem.SubItems.Add(m_sNumConta);
            olvItem.SubItems.Add(m_sNumCheque);
            olvItem.SubItems.Add(m_dMontante.ToString("0.00"));
            olvItem.SubItems.Add(m_sTipoCheque);
            olvItem.SubItems.Add(m_iValidaRequisitosDoc.ToString());
            //olvItem.SubItems.Add(m_iEstado.ToString());
            olvItem.SubItems.Add(m_sEstado.ToString());
            olvItem.SubItems.Add(m_iFsl.ToString());
            olvItem.SubItems.Add(m_sIdDocumento);
            olvItem.SubItems.Add(m_sIdRemessa);
            olvItem.SubItems.Add(m_lLote.ToString());
            olvItem.SubItems.Add(m_iMaquina.ToString());
            olvItem.SubItems.Add(m_sNomeImagem);
            olvItem.SubItems.Add(m_iNumPaginas.ToString());
            olvItem.SubItems.Add(m_sOrigem);
            olvItem.SubItems.Add(m_sRefarqCaptura);
            olvItem.SubItems.Add(m_iSequencia.ToString());
            olvItem.SubItems.Add(m_sSubProduto);
            //olvItem.SubItems.Add(m_sEstadoImagemF);
            //olvItem.SubItems.Add(m_sEstadoImagemB);
            olvItem.SubItems.Add(m_iMaisResultados.ToString());
            olvItem.SubItems.Add(m_sErro);

            return olvItem;
        }

        public string getImgFrente(CIConfigGP.CIGlobalParameters oParameters, Int32? origem = null)
        {
            string sFileNameFrente, sWhereClauseFront;
            sWhereClauseFront = " where NOME_IMAGEM= " + m_sNomeImagem + " and NUM_PAGINA = 1 and TIPO= 'JPG'";
            byte[] aImgF = (byte[])oParameters.DirectSqlScalar("select IMAGEM from dbo.VW_CONSULTA_DOCS" + sWhereClauseFront);

            sFileNameFrente = m_oParameters.GetTempFileName("IMGFront") + ".jpg";
            WriteImage(aImgF, sFileNameFrente);

            return sFileNameFrente;

        }

        public string getImgBack(CIConfigGP.CIGlobalParameters oParameters, Int32? origem = null)
        {
            string sFileNameBack, sWhereClauseBack;
            sWhereClauseBack = " where NOME_IMAGEM= " + m_sNomeImagem + " and NUM_PAGINA = 2 and TIPO= 'JPG'";
            byte[] aImgB = (byte[])oParameters.DirectSqlScalar("select IMAGEM from dbo.VW_CONSULTA_DOCS" + sWhereClauseBack);

            sFileNameBack = m_oParameters.GetTempFileName("IMGBack") + ".jpg";

            WriteImage(aImgB, sFileNameBack);

            return sFileNameBack;
        }

        protected void WriteImage(byte[] aBytes, string sFileName)
        {
            StreamWriter sw = new StreamWriter(sFileName, false);
            BinaryWriter bw = new BinaryWriter(sw.BaseStream);
            bw.Write(aBytes);
            sw.Close();
            bw.Close();
        }

        public virtual SqlDataReader GetConsultaImagens()
        {
            string sQuery = "";

            sQuery += "select * from VW_TIBCO_OBTEM_IMAGEM ";
            sQuery += " where  ID_DADOS_DOCUMENTO_CONSULTA = " + m_lConsultaId.ToString();

            return m_oParameters.DirectSqlDataReader(sQuery);
        }
    }
}
