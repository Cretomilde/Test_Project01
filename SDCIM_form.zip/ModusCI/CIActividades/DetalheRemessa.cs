﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Collections;
using NBiis.Generic;
using NBiis;

namespace CIActividades
{
    public class DetalheRemessa
    {
        private static int ORIGEM = 2;

        public int remId;
        public DateTime remData;
        public DateTime timer;
        public DateTime? timerEnviada;
        public string balcaoGestor;
        public int bancoRemessa;
        public int numRemessa;
        public string descricaoTipoRemessa;
        public int tipoRemessaId;
        public int numDeposito;
        public int estadoId;
        public string estadoRemessa;
        public int numTranches;
        public string chaveH;
        public string cgdError;
        public int quantidadeDoc;
        public int maquina;
        public string error;
        public double montante;
        public string balcaoDescricao;

        private CIConfigGP.CIGlobalParameters m_oParameters;

        private void initVars()
        {
            this.remId = 0;
            this.remData = DateTime.MinValue;
            this.timer = DateTime.MinValue; ;
            this.timerEnviada = DateTime.MinValue;
            this.balcaoGestor = "";
            this.numRemessa = 0;
            this.descricaoTipoRemessa = "";
            this.numDeposito = 0;
            this.estadoId = 0;
            this.estadoRemessa = "";
            this.numTranches = 0;
            this.chaveH = "";
            this.cgdError = "";
            this.quantidadeDoc = 0;
            this.maquina = 0;
            this.error = "";
            this.montante = 0.0;
            this.tipoRemessaId = 0;
            this.bancoRemessa = 0;
            this.balcaoDescricao = "";
        }

        /// <summary>
        /// Método para ser utilizado na contrução do form MudarEstado.
        /// Método vai à tabela [ACTIVITY_CHANGE] e como o mapeamento de estados das Remessas é igual para as Remessas Balcão, é utilizado o nome REMESSA_IN
        /// </summary>
        /// <returns></returns>
        public string GetTableName()
        {
            //E001212 - Neste caso manteve-se o nome porque na tabela activity-change, os estados da remessa in = remessa balcão
            return "REMESSA_IN";
        }

        public DetalheRemessa(SqlDataReader dr, CIConfigGP.CIGlobalParameters oParameters)
        {
            initVars();

            this.remId = Convert.ToInt32(dr["ID"]);
            this.remData = Convert.ToDateTime(dr["REMBALCAO_DATA"]);
            this.timer = Convert.ToDateTime(dr["REMBALCAOPROC_TIMER"]);
            this.timerEnviada = String.IsNullOrEmpty(dr["REMBALCAO_TM_ENVIADA"].ToString()) ? (DateTime?)null : Convert.ToDateTime(dr["REMBALCAO_TM_ENVIADA"]);
            this.balcaoGestor = Convert.ToString(dr["REMBALCAO_BALCAO"]);
            this.numRemessa = Convert.ToInt32(dr["REMBALCAO_NUMERO"]);
            this.bancoRemessa = Convert.ToInt32(dr["REMBALCAO_BANCO"]);
            this.descricaoTipoRemessa = Convert.ToString(dr["REMTIPO"]);
            this.tipoRemessaId = Convert.ToInt32(dr["REMBALCAO_TIPO_BALCAO_ID"]);
            this.numDeposito = Convert.ToInt32(dr["REMSEQ"]);
            this.estadoId = Convert.ToInt32(dr["REMINSTAT_ID"]);
            this.estadoRemessa = Convert.ToString(dr["REMINSTAT_DESC"]);
            this.numTranches = Convert.ToInt32(dr["REMQTTRANCHES"]);
            this.chaveH = Convert.ToString(dr["REMBALCAOPROC_CHAVEH"]);
            this.cgdError = Convert.ToString(dr["LOTEENV_CGDERROR"]);
            this.quantidadeDoc = Convert.ToInt32(dr["REMBALCAO_QT_DOCS"]);
            this.maquina = Convert.ToInt32(dr["REMBALCAOPROC_MAQUINA"]);
            this.error = Convert.ToString(dr["REMBALCAOPROC_ERRO"]);
            this.montante = Convert.ToDouble(dr["REMBALCAO_MT_DOCS"]);
            this.m_oParameters = oParameters;
            this.balcaoDescricao = Convert.ToString(dr["BALCAO_DESC"]);
        }

        public ListViewItem MakeListViewItemRemessas(string sDateFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = remId.ToString();
            olvItem.SubItems.Add(remData.ToString(sDateFormat));
            olvItem.SubItems.Add(timer.ToString());
            olvItem.SubItems.Add(timerEnviada.HasValue ? timerEnviada.Value.ToString("yyyy-MM-dd HH:mm:ss") : "");
            olvItem.SubItems.Add(bancoRemessa.ToString());
            olvItem.SubItems.Add(balcaoGestor.ToString().PadLeft(4, '0') + " - " + balcaoDescricao);
            olvItem.SubItems.Add(tipoRemessaId + " - " + descricaoTipoRemessa.ToString());
            olvItem.SubItems.Add(numDeposito.ToString());
            olvItem.SubItems.Add(estadoId.ToString() + " " + estadoRemessa.ToString());
            olvItem.SubItems.Add(numTranches.ToString());
            olvItem.SubItems.Add(chaveH.ToString());
            olvItem.SubItems.Add(cgdError.ToString());
            olvItem.SubItems.Add(quantidadeDoc.ToString());
            string montanteToInsert = montante.ToString().Equals("0") ? montante.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(montante).PadLeft(16, ' ');
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(error.ToString());
            olvItem.SubItems.Add(maquina.ToString());

            return olvItem;
        }

        public void ChangeEstado(int iNewEstado, string m_sSPProcessa, string m_sSPValida)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@OldEstado", estadoId));
            oParams.Add(new GeneralDBParameters("@NewEstado", iNewEstado));
            oParams.Add(new GeneralDBParameters("@ReminID", remId));
            oParams.Add(new GeneralDBParameters("@Origem_ID", ORIGEM)); //E001212 - SUPBKOFF 11 2017/08/07
            try
            {
                if (m_sSPValida.Length > 0)
                {
                    m_oParameters.DirectStoredProcedureNonQuery(m_sSPValida, ref oParams);
                }

                m_oParameters.DirectStoredProcedureNonQuery(m_sSPProcessa, ref oParams);

                string sSmg = "Mudou estado da REMESSA: " + remId + " de " + estadoId.ToString() + " para " + iNewEstado.ToString();
                GenericLog.GenLogRegistarAlerta(sSmg, "ChangeEstadoRemessa()", 110);
                m_oParameters.EnviarAlertaSituacao(110, sSmg);

            }
            catch (Exception ex)
            {
                if (!(ex.Message.Substring(0, 5).Equals("#004#")))
                {
                    throw;
                }
            }
        }



    }
}
