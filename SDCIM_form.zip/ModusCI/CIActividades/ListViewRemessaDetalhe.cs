﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;
namespace CIActividades
{

    public class ListViewRemessaDetalhe: ListViewDetalhes
    {
        public DateTime m_dtREMIN_TIMER;
        public DateTime m_dtREMIN_TM_ENVIADA;
        public string m_sREMIN_PAIS;
        public int m_iREMIN_BANCO;
        public int m_iREMIN_BALCAO;
        public string m_sBALCAO_ABR;
        public DateTime m_dtREMIN_DATA;
        public string m_sREMPROC_CHAVEH;
        public string m_sREMPROC_CHAVEHEXT;
        public int m_iLOTEENV_CGDERROR;
        public int m_iOperativa;

        public int m_iMaquina;

        public override string GetTableName()
        {
            return "REMESSA_IN";
        }

        public ListViewRemessaDetalhe(SqlDataReader oReader, CIConfigGP.CIGlobalParameters oParameters)
            : base(oReader, oParameters)
        {
            m_sRemessaID = oReader["REMIN_ID"].ToString();
            m_dtREMIN_DATA = Convert.ToDateTime(oReader["REMIN_DATA"]);
            m_dtTimer = Convert.ToDateTime(oReader["REMPROC_TIMER"]);
            m_dtREMIN_TIMER = Convert.ToDateTime(oReader["REMIN_TIMER"]);
            m_dtREMIN_TM_ENVIADA = Convert.ToDateTime(oReader["REMIN_TM_ENVIADA"]);
            if (m_dtREMIN_TIMER == m_dtREMIN_TM_ENVIADA)
            {
                m_dtREMIN_TM_ENVIADA = DateTime.MinValue;
            }
            m_sREMIN_PAIS = oReader["REMIN_PAIS"].ToString();
            m_iREMIN_BANCO = Convert.ToInt16(oReader["REMIN_BANCO"]);
            m_iREMIN_BALCAO = Convert.ToInt16(oReader["REMIN_BALCAO"]);
            m_sBALCAO_ABR = oReader["BALCAO_ABR"].ToString();
            m_sNumero = oReader["REMIN_NUMERO"].ToString();
            m_iStatus = Convert.ToInt16(oReader["REMINSTAT_ID"]);
            m_sStatusAbr = oReader["REMINSTAT_ABR"].ToString();
            m_sREMPROC_CHAVEH = oReader["REMPROC_CHAVEH"].ToString();
            m_sREMPROC_CHAVEHEXT = oReader["REMPROC_CHAVEHEXT"].ToString();
            m_iQt = Convert.ToInt16(oReader["REMIN_QT_DOCS"]);
            m_dMt = Convert.ToDecimal(oReader["REMIN_MT_DOCS"]);
            m_sErro = oReader["REMPROC_ERRO"].ToString();
            m_iLOTEENV_CGDERROR = Convert.ToInt16(oReader["LOTEENV_CGDERROR"]);
            m_iOperativa = Convert.ToInt16(oReader["REMPROC_OPERATIVA"]);
            if (oReader["REMPROC_MAQUINA"] == DBNull.Value)
            {

                m_iMaquina = 0;
            }
            else
            {
                m_iMaquina = Convert.ToInt16(oReader["REMPROC_MAQUINA"]);
            } 
        }

        public ListViewRemessaDetalhe(DataRow oRow, CIConfigGP.CIGlobalParameters oParameters)
            : base(oRow, oParameters)
        {
            m_sRemessaID = oRow["REMIN_ID"].ToString();
            m_dtREMIN_DATA = Convert.ToDateTime(oRow["REMIN_DATA"]);
            m_dtTimer = Convert.ToDateTime(oRow["REMPROC_TIMER"]);
            m_dtREMIN_TIMER = Convert.ToDateTime(oRow["REMIN_TIMER"]);
            m_dtREMIN_TM_ENVIADA = Convert.ToDateTime(oRow["REMIN_TM_ENVIADA"]);
            if (m_dtREMIN_TIMER == m_dtREMIN_TM_ENVIADA)
            {
                m_dtREMIN_TM_ENVIADA = DateTime.MinValue;
            }
            m_sREMIN_PAIS = oRow["REMIN_PAIS"].ToString();
            m_iREMIN_BANCO = Convert.ToInt16(oRow["REMIN_BANCO"]);
            m_iREMIN_BALCAO = Convert.ToInt16(oRow["REMIN_BALCAO"]);
            m_sBALCAO_ABR = oRow["BALCAO_ABR"].ToString();
            m_sNumero = oRow["REMIN_NUMERO"].ToString();
            m_iStatus = Convert.ToInt16(oRow["REMINSTAT_ID"]);
            m_sStatusAbr = oRow["REMINSTAT_ABR"].ToString();
            m_sREMPROC_CHAVEH = oRow["REMPROC_CHAVEH"].ToString();
            m_sREMPROC_CHAVEHEXT = oRow["REMPROC_CHAVEHEXT"].ToString();
            m_iQt = Convert.ToInt16(oRow["REMIN_QT_DOCS"]);
            m_dMt = Convert.ToDecimal(oRow["REMIN_MT_DOCS"]);
            m_sErro = oRow["REMPROC_ERRO"].ToString();
            m_iLOTEENV_CGDERROR = Convert.ToInt16(oRow["LOTEENV_CGDERROR"]);
            m_iOperativa = Convert.ToInt16(oRow["REMPROC_OPERATIVA"]);
            if (oRow["REMPROC_MAQUINA"] == DBNull.Value)
            {

                m_iMaquina = 0;
            }
            else
            {
                m_iMaquina = Convert.ToInt16(oRow["REMPROC_MAQUINA"]);
            }
            //try
            //{
            //    m_iMaquina = Convert.ToInt16(oRow["REMPROC_MAQUINA"]);
            //}
            //catch
            //{
            //    m_iMaquina = 0;
            //}
        }

        public override ListViewItem MakeListViewItem(string sDateFormat, string sDateTimeFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_sRemessaID;
            olvItem.SubItems.Add(m_dtREMIN_DATA.ToString(sDateFormat));
            olvItem.SubItems.Add(m_dtTimer.ToString(sDateTimeFormat));
            if (m_dtREMIN_TM_ENVIADA == DateTime.MinValue)
            {
                olvItem.SubItems.Add("");
            }
            else
            {
                olvItem.SubItems.Add(m_dtREMIN_TM_ENVIADA.ToString(sDateTimeFormat));
            }
            olvItem.SubItems.Add(m_sREMIN_PAIS);//esconder
            olvItem.SubItems.Add(m_iREMIN_BANCO.ToString());//esconder
            olvItem.SubItems.Add(m_iREMIN_BALCAO.ToString() + " " + m_sBALCAO_ABR);
            olvItem.SubItems.Add(m_sNumero.ToString());
            olvItem.SubItems.Add(m_iStatus.ToString() + " " + m_sStatusAbr);
            olvItem.SubItems.Add(m_sREMPROC_CHAVEH);
            olvItem.SubItems.Add(m_sREMPROC_CHAVEHEXT);
            olvItem.SubItems.Add(m_iLOTEENV_CGDERROR.ToString());
            olvItem.SubItems.Add(m_iQt.ToString().PadLeft(6, ' '));
            string montanteToInsert = this.m_dMt.ToString().Equals("0") ? this.m_dMt.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.m_dMt).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dMt).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(m_sErro);
            olvItem.SubItems.Add(m_iMaquina.ToString("00"));
            
            return olvItem;
        }



        public override void ChangeEstado(int iNewEstado, string m_sSPProcessa, string m_sSPValida)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@OldEstado", m_iStatus));
            oParams.Add(new GeneralDBParameters("@NewEstado", iNewEstado));
            oParams.Add(new GeneralDBParameters("@ReminID", m_sRemessaID));
            
            try
            {
                if (m_sSPValida.Length > 0)
                {
                    
                    m_oParameters.DirectStoredProcedureNonQuery(m_sSPValida , ref oParams);
                }

                m_oParameters.DirectStoredProcedureNonQuery(m_sSPProcessa, ref oParams);

                string sSmg = "Mudou estado da REMESSA: " + m_sRemessaID + " de " + m_iStatus.ToString() + " para " + iNewEstado.ToString();
                GenericLog.GenLogRegistarAlerta(sSmg, "ChangeEstadoRemessa()", 110);
                m_oParameters.EnviarAlertaSituacao(110, sSmg);

            }
            catch (Exception ex)
            {
                if (!(ex.Message.Substring(0, 5).Equals("#004#")))
                {
                    throw;
                }

                DialogResult oRes = MessageBox.Show(ex.Message + "\nConfirma?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (oRes.Equals(DialogResult.Yes))
                {
                    try
                    {
                        FecharRemessa(1);

                    }
                    catch
                    {
                        throw;
                    }
                }
            }



        }

        

        public void FecharRemessa(int iForcarFecho)
        {
            string sSPName = "dbo.Update_FecharRemessa";
            ArrayList oParam = new ArrayList();

            oParam.Add(new GeneralDBParameters("@RemID", m_sRemessaID));
            //oParam.Add(new GeneralDBParameters("@Pais", m_sREMIN_PAIS));
            //oParam.Add(new GeneralDBParameters("@Banco", m_iREMIN_BANCO));
            //oParam.Add(new GeneralDBParameters("@Balcao",m_iREMIN_BALCAO));
            //oParam.Add(new GeneralDBParameters("@Numero", m_sNumero));
            //oParam.Add(new GeneralDBParameters("@Banco", m_iREMIN_BANCO));
            //oParam.Add(new GeneralDBParameters("@Data", m_dtREMIN_DATA));
            oParam.Add(new GeneralDBParameters("@ForcarFecho", iForcarFecho));

            m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref oParam);
        }

        public override string GetWhereClause2ViewDetails()
        {
            string sWhereClause;
            sWhereClause = " where REMIN_ID=" + m_sRemessaID;

            return sWhereClause;
        }

    }
}
