﻿using System;
using System.Collections;
using System.Data.SqlClient;
using System.Windows.Forms;
using NBiis;
using NBiis.Generic;

namespace CIActividades
{
    class DetalheRemessasEstorno
    {
        private CIConfigGP.CIGlobalParameters m_oParameters;

        public int remId;
        public DateTime remData;
        public DateTime timer;
        public DateTime? timerEnviada;
        public DateTime timerEstorno;
        public string estornoRem; //Remessa não tem
        public string estornoDoc; //Remessa não tem
        public String balcaoGestorDescricao;
        public String balcaoGestor;
        public int numRemessa;
        public string descricaoTipoRemessa;
        public int tipoRemessaId;
        public int numDepositoSeq;
        public string estadoEstorno;
        public int estadoId;
        public string chaveH;
        public string cgdError;
        public int quantidadeDoc;
        public int maquina;
        public string error;
        public double montante;
        public Int64? Doc_ID {get; set;}
        //SDCIM 17
        public Int32 EstrnID { get; set; }


        private void initVars()
        {
            this.remId = 0;
            this.remData = DateTime.MinValue;
            this.timer = DateTime.MinValue; ;
            this.timerEnviada = DateTime.MinValue;
            this.estornoRem = "";//confirmar campos
            this.estornoDoc = "";//confirmar campos
            this.balcaoGestorDescricao = String.Empty;
            this.numRemessa = 0;
            this.descricaoTipoRemessa = "";
            this.numDepositoSeq = 0;
            this.estadoEstorno = "";
            this.estadoId = 0;
            this.chaveH = "";
            this.cgdError = "";
            this.quantidadeDoc = 0;
            this.maquina = 0;
            this.error = "";
            this.montante = 0.0;
            this.Doc_ID = null;
            this.tipoRemessaId = 0;
            this.balcaoGestor = "";
            this.timerEstorno = DateTime.MinValue;
            this.EstrnID = 0;
        }

        public string GetTableName()
        {
            return "ESTORNO_BALCAO";
        }

        public DetalheRemessasEstorno(SqlDataReader dr, CIConfigGP.CIGlobalParameters oParameters)
        {
            initVars();
            this.remId = Convert.ToInt32(dr["ID"]);
            this.remData = Convert.ToDateTime(dr["REMBALCAO_DATA"]);
            this.timer = Convert.ToDateTime(dr["REMBALCAOPROC_TIMER"]);
            this.timerEnviada = String.IsNullOrEmpty(dr["ESTRN_ENVIADO"].ToString()) ? (DateTime?)null : Convert.ToDateTime(dr["ESTRN_ENVIADO"]);
            this.estornoRem = Convert.ToString(dr["I_ESTRN_REMESSA"]);
            this.estornoDoc = Convert.ToString(dr["I_ESTRN_DOC"]);
            this.balcaoGestorDescricao = Convert.ToString(dr["BALCAO_DESC"]);
            this.numRemessa = Convert.ToInt32(dr["REMBALCAO_NUMERO"]);
            this.descricaoTipoRemessa = Convert.ToString(dr["REMTIPO"]);
            this.tipoRemessaId = Convert.ToInt32(dr["REMTIPOID"]);
            this.numDepositoSeq = Convert.ToInt32(dr["REMSEQ"]);
            this.estadoEstorno = Convert.ToString(dr["ESTRN_STATUS_ID"]) + " " + Convert.ToString(dr["D_ESTRN_STATUS"]);
            this.estadoId = Convert.ToInt32(dr["ESTRN_STATUS_ID"]);
            this.chaveH = Convert.ToString(dr["REMBALCAOPROC_CHAVEH"]);
            this.cgdError = Convert.ToString(dr["LOTEENV_CGDERROR"]);
            this.quantidadeDoc = Convert.ToInt32(dr["ESTRN_QT_DOCS"]);
            this.maquina = Convert.ToInt32(dr["REMBALCAOPROC_MAQUINA"]);
            this.error = String.IsNullOrEmpty(dr["ESTRN_ERRO"].ToString()) ? String.Empty : Convert.ToString(dr["ESTRN_ERRO"]);
            this.montante = Convert.ToDouble(dr["ESTRN_MT_DOCS"]);
            this.Doc_ID = String.IsNullOrEmpty(dr["Doc_ID"].ToString()) ? (Int64?)null : Convert.ToInt64(dr["Doc_ID"]);
            this.balcaoGestor = Convert.ToString(dr["REMBALCAO_BALCAO"]);
            this.timerEstorno = Convert.ToDateTime(dr["ESTRN_TIMER"]);
            this.EstrnID = Convert.ToInt32(dr["ESTRN_ID"]);
            this.m_oParameters = oParameters;
        }

        public ListViewItem MakeListViewItemRemessasEstorno(string sDateFormat)
        {
            ListViewItem olvItem = new ListViewItem();
            olvItem.Text = remId.ToString();
            olvItem.SubItems.Add(remData.ToString(sDateFormat));
            olvItem.SubItems.Add(timer.ToString());
            olvItem.SubItems.Add(timerEstorno.ToString());
            olvItem.SubItems.Add(timerEnviada.HasValue ? timerEnviada.Value.ToString("yyyy-MM-dd HH:mm:ss") : "");
            olvItem.SubItems.Add(estornoRem.ToString());
            olvItem.SubItems.Add(estornoDoc.ToString());
            olvItem.SubItems.Add(balcaoGestor.PadLeft(4, '0') + " - " + balcaoGestorDescricao.ToString());
            olvItem.SubItems.Add(numRemessa.ToString());
            olvItem.SubItems.Add(tipoRemessaId + " - " + descricaoTipoRemessa.ToString());
            olvItem.SubItems.Add(numDepositoSeq.ToString());
            olvItem.SubItems.Add(estadoEstorno.ToString());
            olvItem.SubItems.Add(chaveH.ToString());
            olvItem.SubItems.Add(cgdError.ToString());
            olvItem.SubItems.Add(quantidadeDoc.ToString());
            string montanteToInsert = montante.ToString().Equals("0") ? montante.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(montante).PadLeft(16, ' ');          
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(error.ToString());            
            olvItem.SubItems.Add(maquina.ToString());
            return olvItem;
        }

        public void ChangeEstado(int iNewStatus, string m_sSPProcessa, string m_sSPValida)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@OldEstado", estadoId));
            oParams.Add(new GeneralDBParameters("@NewEstado", iNewStatus));
            oParams.Add(new GeneralDBParameters("@EstornoID", this.EstrnID)); //SDCIM 17 remId para EstrnID
            if (m_sSPValida.Length > 0)
            {
                m_oParameters.DirectStoredProcedureNonQuery(m_sSPValida, ref oParams);
            }
            m_oParameters.DirectStoredProcedureNonQuery(m_sSPProcessa, ref oParams);
            string sSmg = "Mudou estado do Estorno da Remessa: " + remId + " de " + estadoEstorno.ToString() + " para " + iNewStatus.ToString();
            GenericLog.GenLogRegistarAlerta(sSmg, "ChangeEstadoRemessaEstorno()", 110);
            m_oParameters.EnviarAlertaSituacao(110, sSmg);

        }
    }
}