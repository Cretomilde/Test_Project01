﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CIActividades
{
    public class PesquisaDocumentoENVM
    {

        public string m_sFICH_ID;
        public string m_sFICH_NSEQ;
        public DateTime m_dtFICH_DATA;
        public string m_sFICH_REFCMP;

        public string m_sLOTEENV_ID;
        public string m_sLOTEENV_NUMERO;
        public string m_sLOTEENV_CODBAL;
        public string m_sLOTEENV_NREM;
        public DateTime m_dtLOTEENV_DTREM;
        public string m_sLOTEENV_TCAP;
        public string m_sLOTEENV_TREM;
        public string m_sLOTESTATUS_ID;
        public string m_sLOTESTAT_ABR;


        public string m_sDOCENV_ID;
        public string m_sDOCENV_ZONA5;
        public string m_sDOCENV_ZONA4;
        public string m_sDOCENV_ZONA3;
        public string m_sDOCENV_ZONA2;
        public decimal m_dDOCENV_IMPORT;
        public string m_sDOCENV_ZONA1;
        public string m_sDOCENV_REFARQ;
        public string m_sREFARQ_ORI;
        public string m_sDOCENV_ANOMAL;
        public string m_sESTADO_DESC;
        public string m_sDOCENV_DUPLICADO;
        public string m_sDOCENV_CODANA;
        public string m_sDOCENV_CHAVEH;

        public string m_sDOCENV_REAPRESENTADO;
        public string m_sREAPRESENTADO_EFECTUADO;
        public string m_sREAPRESENTADO_ESTADO;
        public string m_sREAPRESENTADO_ERRO;

        public string m_sDOCENV_CANCELADO;
        public string m_sCANCELA_EFECTUADO;
        public string m_sCANCELA_ESTADO;
        public string m_sCANCELA_ERRO;
        public string m_sCANCELA_DESCRICAO;

        public string m_sDOCENV_NOTIFICADO;
        public string m_sNOTIFICA_EFECTUADO;
        public string m_sNOTIFICA_ESTADO;
        public string m_sNOTIFICA_ERRO;
        public string m_sNOTIFICA_DESCRICAO;

        /*
         * SDCIM 7
         */
        public String m_sDocOrigemID { get; set; }
        public String m_sDocOrigemDesc { get; set; }
        public String m_sDocEnv_ImgQual { get; set; }
        public String m_sLoteEnv_AnomaliaID { get; set; }
        public String m_sLoteEnv_DescAnomalia { get; set; }
        /*
         * SDCIM 7
         */

        private void InitVars()
        {
            m_sFICH_ID = "";
            m_sFICH_NSEQ = "";
            m_dtFICH_DATA = DateTime.MinValue;
            m_sFICH_REFCMP = "";

            m_sLOTEENV_ID = "";
            m_sLOTEENV_NUMERO = "";
            m_sLOTEENV_CODBAL = "";
            m_sLOTEENV_NREM = "";
            m_dtLOTEENV_DTREM = DateTime.MinValue;
            m_sLOTEENV_TCAP = "";
            m_sLOTEENV_TREM = "";
            m_sLOTESTATUS_ID = "";
            m_sLOTESTAT_ABR = "";

            m_sDOCENV_ID = "";
            m_sDOCENV_ZONA5 = "";
            m_sDOCENV_ZONA4 = "";
            m_sDOCENV_ZONA3 = "";
            m_sDOCENV_ZONA2 = "";
            m_dDOCENV_IMPORT = -1;
            m_sDOCENV_ZONA1 = "";
            m_sDOCENV_REFARQ = "";
            m_sREFARQ_ORI = "";
            m_sDOCENV_ANOMAL = "";
            m_sESTADO_DESC = "";
            m_sDOCENV_DUPLICADO = "";
            m_sDOCENV_CODANA = "";
            m_sDOCENV_CHAVEH = "";

            m_sDOCENV_REAPRESENTADO = "";
            m_sREAPRESENTADO_EFECTUADO = "";
            m_sREAPRESENTADO_ESTADO = "";
            m_sREAPRESENTADO_ERRO = "";

            m_sDOCENV_CANCELADO = "";
            m_sCANCELA_EFECTUADO = "";
            m_sCANCELA_ESTADO = "";
            m_sCANCELA_ERRO = "";
            m_sCANCELA_DESCRICAO = "";

            m_sDOCENV_NOTIFICADO = "";
            m_sNOTIFICA_EFECTUADO = "";
            m_sNOTIFICA_ESTADO = "";
            m_sNOTIFICA_ERRO = "";
            m_sNOTIFICA_DESCRICAO = "";

            this.m_sDocOrigemDesc = String.Empty;
            this.m_sDocOrigemID = String.Empty;
            this.m_sDocEnv_ImgQual = String.Empty;
            this.m_sLoteEnv_AnomaliaID = String.Empty;
            this.m_sLoteEnv_DescAnomalia = String.Empty;
        }

        public PesquisaDocumentoENVM()
        {
            InitVars();
        }

        public PesquisaDocumentoENVM(SqlDataReader dr)
        {
            InitVars();

            try
            {
                m_sFICH_ID = Convert.ToString(dr["FICH_ID"]);
                m_sFICH_NSEQ = Convert.ToString(dr["FICH_NSEQ"]);
                m_dtFICH_DATA = Convert.ToDateTime(dr["FICH_DATA"]);
                m_sFICH_REFCMP = Convert.ToString(dr["FICH_REFCMP"]);

                m_sLOTEENV_ID = Convert.ToString(dr["LOTEENV_ID"]);
                m_sLOTEENV_NUMERO = Convert.ToString(dr["LOTEENV_NUMERO"]);
                m_sLOTEENV_CODBAL = Convert.ToString(dr["LOTEENV_CODBAL"]);
                m_sLOTEENV_NREM = Convert.ToString(dr["LOTEENV_NREM"]);
                m_dtLOTEENV_DTREM = Convert.ToDateTime(dr["LOTEENV_DTREM"]);
                m_sLOTEENV_TCAP = Convert.ToString(dr["LOTEENV_TCAP"]);
                m_sLOTEENV_TREM = Convert.ToString(dr["LOTEENV_TREM"]);
                m_sLOTESTATUS_ID = Convert.ToString(dr["LOTESTATUS_ID"]);
                m_sLOTESTAT_ABR = Convert.ToString(dr["LOTESTAT_ABR"]);

                m_sDOCENV_ID = Convert.ToString(dr["DOCENV_ID"]);
                m_sDOCENV_ZONA5 = Convert.ToString(dr["DOCENV_ZONA5"]);
                m_sDOCENV_ZONA4 = Convert.ToString(dr["DOCENV_ZONA4"]);
                m_sDOCENV_ZONA3 = Convert.ToString(dr["DOCENV_ZONA3"]);
                m_sDOCENV_ZONA2 = Convert.ToString(dr["DOCENV_ZONA2"]);
                m_dDOCENV_IMPORT = Convert.ToDecimal(dr["DOCENV_ZONA2"]);
                m_sDOCENV_ZONA1 = Convert.ToString(dr["DOCENV_ZONA1"]);
                m_sDOCENV_REFARQ = Convert.ToString(dr["REFARQ"]);
                if (dr["REFARQ_ORI"] != DBNull.Value)
                {
                    m_sREFARQ_ORI = Convert.ToString(dr["REFARQ_ORI"]);
                }
                m_sDOCENV_ANOMAL = Convert.ToString(dr["DOCENV_ANOMAL"]);
                m_sESTADO_DESC = Convert.ToString(dr["ESTADO_DESC"]);
                m_sDOCENV_DUPLICADO = Convert.ToString(dr["DOCENV_DUPLICADO"]);
                m_sDOCENV_CODANA = Convert.ToString(dr["DOCENV_CODANA"]);

                m_sDOCENV_REAPRESENTADO = Convert.ToString(dr["DOCENV_REAPRESENTADO"]);
                m_sREAPRESENTADO_EFECTUADO = Convert.ToString(dr["REAPRESENTADO_EFECTUADO"]);
                m_sREAPRESENTADO_ESTADO = Convert.ToString(dr["REAPRESENTADO_ESTADO"]);
                m_sREAPRESENTADO_ERRO = Convert.ToString(dr["REAPRESENTADO_ERRO"]);

                m_sDOCENV_CANCELADO = Convert.ToString(dr["DOCENV_CANCELADO"]);
                m_sCANCELA_EFECTUADO = Convert.ToString(dr["CANCELA_EFECTUADO"]);
                m_sCANCELA_ESTADO = Convert.ToString(dr["CANCELA_ESTADO"]);
                m_sCANCELA_ERRO = Convert.ToString(dr["CANCELA_ERRO"]);
                if (dr["CANCELA_DESCRICAO"] != DBNull.Value)
                {
                    m_sCANCELA_DESCRICAO = Convert.ToString(dr["CANCELA_DESCRICAO"]);
                }
                m_sDOCENV_NOTIFICADO = Convert.ToString(dr["DOCENV_NOTIFICADO"]);
                m_sNOTIFICA_EFECTUADO = Convert.ToString(dr["NOTIFICA_EFECTUADO"]);
                m_sNOTIFICA_ESTADO = Convert.ToString(dr["NOTIFICA_ESTADO"]);
                m_sNOTIFICA_ERRO = Convert.ToString(dr["NOTIFICA_ERRO"]);
                if (dr["NOTIFICA_DESCRICAO"] != DBNull.Value)
                {
                    m_sNOTIFICA_DESCRICAO = Convert.ToString(dr["NOTIFICA_DESCRICAO"]);
                }
                m_sDOCENV_CHAVEH = Convert.ToString(dr["DOCENV_CHAVEH"]);
                this.m_sDocOrigemID = Convert.ToString(dr["DOC_ORIGEM_ID"]);
                this.m_sDocOrigemDesc = Convert.ToString(dr["DOC_ORIGEM_D"]);

                if (dr["DOCENV_IMGQUAL"] != DBNull.Value)
                {
                    this.m_sDocEnv_ImgQual = Convert.ToString(dr["DOCENV_IMGQUAL"]);
                }
                this.m_sLoteEnv_AnomaliaID = Convert.ToString(dr["LOTEENV_ANOMAL"]);
                this.m_sLoteEnv_DescAnomalia = Convert.ToString(dr["LOTEENV_ANOMAL_D"]);
            }
            catch
            {
            }
        }

        public ListViewItem MakeListViewItem(string sDateFormat)
        {
            ListViewItem olvItem = new ListViewItem();
            olvItem.Text = m_sFICH_ID;
            olvItem.SubItems.Add(m_sFICH_NSEQ);
            olvItem.SubItems.Add(m_dtFICH_DATA.ToString(sDateFormat));
            olvItem.SubItems.Add(m_sFICH_REFCMP);
            olvItem.SubItems.Add(m_sLOTEENV_ID);
            olvItem.SubItems.Add(m_sLOTEENV_NUMERO);
            olvItem.SubItems.Add(this.m_sDocOrigemDesc);//sdcim 7
            olvItem.SubItems.Add(m_sLOTEENV_CODBAL.PadLeft(4, '0'));
            olvItem.SubItems.Add(m_sLOTEENV_NREM.PadLeft(11, '0'));
            olvItem.SubItems.Add(m_dtLOTEENV_DTREM.ToString(sDateFormat));
            olvItem.SubItems.Add(m_sLOTEENV_TCAP);
            olvItem.SubItems.Add(m_sLOTEENV_TREM);
            olvItem.SubItems.Add(m_sLOTESTATUS_ID + " " + m_sLOTESTAT_ABR);
            olvItem.SubItems.Add(this.m_sLoteEnv_AnomaliaID + " " + this.m_sLoteEnv_DescAnomalia);
            olvItem.SubItems.Add(m_sDOCENV_ID);
            olvItem.SubItems.Add(m_sDOCENV_ZONA5);
            olvItem.SubItems.Add(m_sDOCENV_ZONA4);
            olvItem.SubItems.Add(m_sDOCENV_ZONA3);
            string montanteToInsert = m_dDOCENV_IMPORT.ToString().Equals("0") ? m_dDOCENV_IMPORT.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(m_dDOCENV_IMPORT).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dDOCENV_IMPORT).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(m_sDOCENV_ZONA1);
            olvItem.SubItems.Add(m_sDOCENV_REFARQ);
            olvItem.SubItems.Add(m_sREFARQ_ORI);
            olvItem.SubItems.Add(this.m_sDocEnv_ImgQual);
            olvItem.SubItems.Add(m_sDOCENV_ANOMAL + " " + m_sESTADO_DESC);
            olvItem.SubItems.Add(m_sDOCENV_CODANA);
            olvItem.SubItems.Add(m_sDOCENV_DUPLICADO);
            olvItem.SubItems.Add(m_sREAPRESENTADO_EFECTUADO + " " + m_sREAPRESENTADO_ESTADO + " " + m_sREAPRESENTADO_ERRO);
            olvItem.SubItems.Add(m_sDOCENV_REAPRESENTADO);
            olvItem.SubItems.Add(m_sCANCELA_EFECTUADO + " " + m_sCANCELA_ESTADO + " " + m_sCANCELA_DESCRICAO + " " + m_sCANCELA_ERRO);
            olvItem.SubItems.Add(m_sDOCENV_CANCELADO);
            olvItem.SubItems.Add(m_sNOTIFICA_EFECTUADO + " " + m_sNOTIFICA_ESTADO + " " + m_sNOTIFICA_DESCRICAO + " " + m_sNOTIFICA_ERRO);
            olvItem.SubItems.Add(m_sDOCENV_NOTIFICADO);
            olvItem.SubItems.Add(m_sDOCENV_CHAVEH);
            return olvItem;
        }
    }
}
