﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIActividades
{
    public abstract class ListViewDetalhes
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;

//        public string m_sID;
        public string m_sRemessaID;
        public string m_sNumero;
        public DateTime m_dtTimer;
        public int m_iStatus;
        public string  m_sStatusAbr;
        public int m_iQt;
        public decimal m_dMt;
        public string m_sErro;
        public string m_sErroDescricao;

        public abstract string GetTableName();
        public abstract void ChangeEstado(int iNewStatus, string m_sSPProcessa, string m_sSPValida);
        public abstract ListViewItem MakeListViewItem(string sDateFormat, string sDateTimeFormat);
        public abstract string GetWhereClause2ViewDetails();

        public ListViewDetalhes()
        {
//            m_sID = "";
            m_sNumero = "";
            m_dtTimer = new DateTime(0);
            m_iStatus = -9999;
            m_sStatusAbr = "";
            m_iQt = 0;
            m_dMt = 0;
            m_sErro = "";
            m_sErroDescricao = "";

            this.m_oParameters = null;
        }

        public ListViewDetalhes(SqlDataReader oReader, CIConfigGP.CIGlobalParameters oParameters)
        {
//            m_sID = "";
            m_sNumero = "";
            m_dtTimer = new DateTime(0);
            m_iStatus = -9999;
            m_sStatusAbr = "";
            m_iQt = 0;
            m_dMt = 0;
            m_sErro = "";
            m_sErroDescricao = "";

            this.m_oParameters = oParameters;
        }

        public ListViewDetalhes(DataRow oRow, CIConfigGP.CIGlobalParameters oParameters)
        {
//            m_sID = "";
            m_sNumero = "";
            m_dtTimer = new DateTime(0);
            m_iStatus = -9999;
            m_sStatusAbr = "";
            m_iQt = 0;
            m_dMt = 0;
            m_sErro = "";
            m_sErroDescricao = "";
            this.m_oParameters = oParameters;
        }
      
    }
}
