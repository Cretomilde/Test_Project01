﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CIActividades
{

    public partial class MudarEstadoRemessa : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        public int id;
        public string estado;
        public int estadoId;
        public MudarEstadoRemessa(CIConfigGP.CIGlobalParameters oParameters, int id, string estado, int estadoId)
        {
            this.estadoId = estadoId;
            this.id = id;
            this.estado = estado;
            m_oParameters = oParameters;
            InitializeComponent();
            preenheComboBox();
            preencherTexbox();
        }
        private void preencherTexbox()
        {

            this.tbCurrentEstado.Text = estado;

        }

        private void preenheComboBox()
        {
            DataSet ds = null;


            if (cbEstadoNovo.Items.Count > 0)
            {
                return;
            }

            try
            {

                //string sComm = "select * from dbo.REMESSAIN_STATUS";
                //ds = m_oParameters.DirectSqlDataSet(sComm, "TRANCHEOUT_STATUS");
                string m_sTableName = "REMESSA_IN";
                string sComm = "Select ACTCHANGE_ID, ACTIVITY_NEW, ACTIVITY_NEW_DESC, ACTIVITY_SPVALIDA, ACTIVITY_SPPROCESSA, TAG from view_activity_change_desc where ACTIVITY_OLD=" + estadoId + " AND ACTIVITY_TABLE='" + m_sTableName + "' order by ACTIVITY_NEW";
                ds = m_oParameters.DirectSqlDataSet(sComm, "ChangeEstado");
                cbEstadoNovo.Items.Clear();

                cbEstadoNovo.DataSource = ds.Tables[0];
                cbEstadoNovo.DisplayMember = "ACTIVITY_NEW_DESC";
                /*cbEstadoNovo.DisplayMember = "REMINSTAT_DESC";
                cbEstadoNovo.ValueMember = "REMINSTAT_ID";*/

                if (cbEstadoNovo.Items.Count > 0)
                    cbEstadoNovo.SelectedIndex = 0;
                else
                {
                    btOK.Enabled = false;
                    cbEstadoNovo.Enabled = false;
                }

            }
            finally
            {
                if (ds != null)
                {
                    ds.Dispose();

                    ds = null;
                }
            }
        }

        private void cbEstadoNovo_SelectedIndexChanged(object sender, EventArgs e)
        {

            this.tbCurrentEstado.Text = cbEstadoNovo.Text;


        }

        private void btOK_Click(object sender, EventArgs e)
        {
            estado = cbEstadoNovo.Text;
            estadoId = Convert.ToInt32(cbEstadoNovo.SelectedValue);
            SqlDataReader dr = null;
            string sQuery = "update  REMESSA_BALCAO Set REMBALCAO_STAT_ID =" + estadoId + "where ID =" + id;
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
            }
            catch
            {
                MessageBox.Show("Não foi possivel mudar o estado");
            }

            DialogResult = DialogResult.OK;
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}




