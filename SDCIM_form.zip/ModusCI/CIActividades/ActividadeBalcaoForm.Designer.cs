﻿namespace CIActividades
{
    partial class ActividadeBalcaoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            m_oMenuInterface.actividadeBalcaoEnable(true);
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ActividadeBalcaoForm));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonFechados = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonEspMaquinas = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonProcessamento = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonProcessado = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonEnviada = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonENVM = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonErro = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonRefresh = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonExitJanela = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsBtnRemessa = new System.Windows.Forms.ToolStripButton();
            this.tsBtnEstorno = new System.Windows.Forms.ToolStripButton();
            this.contextMenuStripRemessasResumo = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.verRemessasDetalheToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripRemessa = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuRemessaMudarEstado = new System.Windows.Forms.ToolStripMenuItem();
            this.verTranchesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verDocumentosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripTranche = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.contextMenuStripTrancheMudaEstado = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripTrancheVerDocs = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripDocumento = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuDocumentosVerImagem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripResumoEstornos = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItemResumoEstornos = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripRemessaEstorno = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItemRemessaEstorno = new System.Windows.Forms.ToolStripMenuItem();
            this.mudarEstadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripDocumentoEstorno = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuDocumentosEstornosVerImagem = new System.Windows.Forms.ToolStripMenuItem();
            this.label5 = new System.Windows.Forms.Label();
            this.lbBalcao = new System.Windows.Forms.Label();
            this.lbRemessaCI = new System.Windows.Forms.Label();
            this.lbTipoRemessa = new System.Windows.Forms.Label();
            this.lbDeposito = new System.Windows.Forms.Label();
            this.txBalcao = new System.Windows.Forms.TextBox();
            this.txRemessaCI = new System.Windows.Forms.TextBox();
            this.m_ctrldtFim = new System.Windows.Forms.DateTimePicker();
            this.txDeposito = new System.Windows.Forms.TextBox();
            this.m_ctrldtInicio = new System.Windows.Forms.DateTimePicker();
            this.cbTRemessa = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.spContainer = new System.Windows.Forms.SplitContainer();
            this.spContRemessas = new System.Windows.Forms.SplitContainer();
            this.spContAgrRemessas = new System.Windows.Forms.SplitContainer();
            this.listViewResumoRemessas = new NBIISNET.ListViewBase();
            this.Process = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Remessa = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.EstadoRemessas = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tpRemessa = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Rems = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Docs = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Montante = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ENVM = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.m_btRefreshRemessas = new System.Windows.Forms.Button();
            this.btnRemessasErro = new System.Windows.Forms.Button();
            this.listViewDetalhesRemessa = new NBIISNET.ListViewBase();
            this.colRemID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemTimer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTimerEnviada = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemnum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRem = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemTP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemDeposito = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemStat = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemTrans = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemChaveH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemCGDError = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemQT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemMT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemErro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemMaquina = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.labelCountRemessas = new System.Windows.Forms.Label();
            this.spContTranDoc = new System.Windows.Forms.SplitContainer();
            this.listViewDetalhesTranche = new NBIISNET.ListViewBase();
            this.colTransRemID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransTimer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransNumero = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransEstado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransQt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransMt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransErro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransChaveWS = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTIBCOEstado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.labelCountTranches = new System.Windows.Forms.Label();
            this.lblCountDocumentos = new System.Windows.Forms.Label();
            this.listViewDetalhesDocumentos = new NBIISNET.ListViewBase();
            this.detDocColDocId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocStat = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocNIB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocRefarq = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocNSeq = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColChaveH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocIndex = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocMaquina = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocBaltom = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColChaveHext = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocTipo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocTimer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColReminData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColReminID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColTranoutID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColBalcao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColRemNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColTranoutStatId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColTranNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnDocColErro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocDeposito = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.spContEstorno = new System.Windows.Forms.SplitContainer();
            this.listViewEstornoResumo = new NBIISNET.ListViewBase();
            this.colZProcess = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colZEstorno = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstadoEstr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTpRemessa = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colQtEstorno = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colQtDocs = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colMontante = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colENVM = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btEstorno = new System.Windows.Forms.Button();
            this.btnEstonoErro = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.spContEstRemDoc = new System.Windows.Forms.SplitContainer();
            this.listViewRemessaEstorno = new NBIISNET.ListViewBase();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader22 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader23 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader24 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader25 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader26 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lblCountRemessasEstornos = new System.Windows.Forms.Label();
            this.listViewDocumentoEstorno = new NBIISNET.ListViewBase();
            this.colEstDocId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstZIB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstNConta = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstNCheque = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstMontante = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstTpDoc = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstEstDoc = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstNIB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstRefarq = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstNSeq = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstChvH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstIndex = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstMaquina = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstBalcaoTom = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstChvHext = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstTipo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstTimer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstZRemessa = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstRemID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstTranId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstBalcaoDesb = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstRemNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstEstTran = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstTranNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstDocErro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEstDep = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lblCountDocumentosEstornos = new System.Windows.Forms.Label();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.toolStrip1.SuspendLayout();
            this.contextMenuStripRemessasResumo.SuspendLayout();
            this.contextMenuStripRemessa.SuspendLayout();
            this.contextMenuStripTranche.SuspendLayout();
            this.contextMenuStripDocumento.SuspendLayout();
            this.contextMenuStripResumoEstornos.SuspendLayout();
            this.contextMenuStripRemessaEstorno.SuspendLayout();
            this.contextMenuStripDocumentoEstorno.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spContainer)).BeginInit();
            this.spContainer.Panel1.SuspendLayout();
            this.spContainer.Panel2.SuspendLayout();
            this.spContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spContRemessas)).BeginInit();
            this.spContRemessas.Panel1.SuspendLayout();
            this.spContRemessas.Panel2.SuspendLayout();
            this.spContRemessas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spContAgrRemessas)).BeginInit();
            this.spContAgrRemessas.Panel1.SuspendLayout();
            this.spContAgrRemessas.Panel2.SuspendLayout();
            this.spContAgrRemessas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spContTranDoc)).BeginInit();
            this.spContTranDoc.Panel1.SuspendLayout();
            this.spContTranDoc.Panel2.SuspendLayout();
            this.spContTranDoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spContEstorno)).BeginInit();
            this.spContEstorno.Panel1.SuspendLayout();
            this.spContEstorno.Panel2.SuspendLayout();
            this.spContEstorno.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spContEstRemDoc)).BeginInit();
            this.spContEstRemDoc.Panel1.SuspendLayout();
            this.spContEstRemDoc.Panel2.SuspendLayout();
            this.spContEstRemDoc.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonFechados,
            this.toolStripButtonEspMaquinas,
            this.toolStripButtonProcessamento,
            this.toolStripButtonProcessado,
            this.toolStripButtonEnviada,
            this.toolStripButtonENVM,
            this.toolStripSeparator5,
            this.toolStripButtonErro,
            this.toolStripSeparator1,
            this.toolStripButtonRefresh,
            this.toolStripSeparator3,
            this.toolStripButtonExitJanela,
            this.toolStripSeparator2,
            this.tsBtnRemessa,
            this.tsBtnEstorno});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0);
            this.toolStrip1.Size = new System.Drawing.Size(940, 39);
            this.toolStrip1.TabIndex = 79;
            this.toolStrip1.Text = "toolStripActividades";
            // 
            // toolStripButtonFechados
            // 
            this.toolStripButtonFechados.CheckOnClick = true;
            this.toolStripButtonFechados.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonFechados.Image = global::CIActividades.Properties.Resources.LOCKUP;
            this.toolStripButtonFechados.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonFechados.Margin = new System.Windows.Forms.Padding(10, 1, 10, 2);
            this.toolStripButtonFechados.Name = "toolStripButtonFechados";
            this.toolStripButtonFechados.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonFechados.Text = "toolStripButton2";
            this.toolStripButtonFechados.ToolTipText = "Fechados";
            // 
            // toolStripButtonEspMaquinas
            // 
            this.toolStripButtonEspMaquinas.CheckOnClick = true;
            this.toolStripButtonEspMaquinas.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonEspMaquinas.Image = global::CIActividades.Properties.Resources.Maquina;
            this.toolStripButtonEspMaquinas.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonEspMaquinas.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonEspMaquinas.Name = "toolStripButtonEspMaquinas";
            this.toolStripButtonEspMaquinas.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonEspMaquinas.Text = "toolStripButton3";
            this.toolStripButtonEspMaquinas.ToolTipText = "Espera de Maquinas";
            // 
            // toolStripButtonProcessamento
            // 
            this.toolStripButtonProcessamento.CheckOnClick = true;
            this.toolStripButtonProcessamento.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonProcessamento.Image = global::CIActividades.Properties.Resources.Par;
            this.toolStripButtonProcessamento.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonProcessamento.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonProcessamento.Name = "toolStripButtonProcessamento";
            this.toolStripButtonProcessamento.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonProcessamento.Text = "toolStripButton4";
            this.toolStripButtonProcessamento.ToolTipText = "Em Processamento";
            // 
            // toolStripButtonProcessado
            // 
            this.toolStripButtonProcessado.CheckOnClick = true;
            this.toolStripButtonProcessado.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonProcessado.Image = global::CIActividades.Properties.Resources.OK;
            this.toolStripButtonProcessado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonProcessado.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonProcessado.Name = "toolStripButtonProcessado";
            this.toolStripButtonProcessado.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonProcessado.Text = "toolStripButton5";
            this.toolStripButtonProcessado.ToolTipText = "Processado";
            // 
            // toolStripButtonEnviada
            // 
            this.toolStripButtonEnviada.CheckOnClick = true;
            this.toolStripButtonEnviada.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonEnviada.Image = global::CIActividades.Properties.Resources.Transmissao;
            this.toolStripButtonEnviada.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonEnviada.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonEnviada.Name = "toolStripButtonEnviada";
            this.toolStripButtonEnviada.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonEnviada.Text = "toolStripButton8";
            this.toolStripButtonEnviada.ToolTipText = "Enviada";
            // 
            // toolStripButtonENVM
            // 
            this.toolStripButtonENVM.CheckOnClick = true;
            this.toolStripButtonENVM.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonENVM.Image = global::CIActividades.Properties.Resources.ENVM_Status;
            this.toolStripButtonENVM.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonENVM.Name = "toolStripButtonENVM";
            this.toolStripButtonENVM.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonENVM.Text = "Ficheiro ENVM";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButtonErro
            // 
            this.toolStripButtonErro.CheckOnClick = true;
            this.toolStripButtonErro.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonErro.Image = global::CIActividades.Properties.Resources.Erro;
            this.toolStripButtonErro.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonErro.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonErro.Name = "toolStripButtonErro";
            this.toolStripButtonErro.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonErro.Text = "toolStripButton6";
            this.toolStripButtonErro.ToolTipText = "Erro";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButtonRefresh
            // 
            this.toolStripButtonRefresh.AutoSize = false;
            this.toolStripButtonRefresh.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonRefresh.Image = global::CIActividades.Properties.Resources.Refresh;
            this.toolStripButtonRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRefresh.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonRefresh.Name = "toolStripButtonRefresh";
            this.toolStripButtonRefresh.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonRefresh.Text = "toolStripButton7";
            this.toolStripButtonRefresh.ToolTipText = "Refresh";
            this.toolStripButtonRefresh.Click += new System.EventHandler(this.toolStripButtonRefresh_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButtonExitJanela
            // 
            this.toolStripButtonExitJanela.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonExitJanela.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonExitJanela.Image")));
            this.toolStripButtonExitJanela.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonExitJanela.Name = "toolStripButtonExitJanela";
            this.toolStripButtonExitJanela.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonExitJanela.Click += new System.EventHandler(this.toolStripButtonExitJanela_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // tsBtnRemessa
            // 
            this.tsBtnRemessa.BackColor = System.Drawing.SystemColors.Info;
            this.tsBtnRemessa.Checked = true;
            this.tsBtnRemessa.CheckOnClick = true;
            this.tsBtnRemessa.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsBtnRemessa.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsBtnRemessa.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsBtnRemessa.Image = ((System.Drawing.Image)(resources.GetObject("tsBtnRemessa.Image")));
            this.tsBtnRemessa.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtnRemessa.Name = "tsBtnRemessa";
            this.tsBtnRemessa.Size = new System.Drawing.Size(40, 36);
            this.tsBtnRemessa.Text = "Rem.";
            this.tsBtnRemessa.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.tsBtnRemessa.Click += new System.EventHandler(this.tsBtnRemessa_Click);
            // 
            // tsBtnEstorno
            // 
            this.tsBtnEstorno.BackColor = System.Drawing.SystemColors.Info;
            this.tsBtnEstorno.Checked = true;
            this.tsBtnEstorno.CheckOnClick = true;
            this.tsBtnEstorno.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsBtnEstorno.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsBtnEstorno.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsBtnEstorno.Image = ((System.Drawing.Image)(resources.GetObject("tsBtnEstorno.Image")));
            this.tsBtnEstorno.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtnEstorno.Name = "tsBtnEstorno";
            this.tsBtnEstorno.Size = new System.Drawing.Size(31, 36);
            this.tsBtnEstorno.Text = "Est.";
            this.tsBtnEstorno.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.tsBtnEstorno.Click += new System.EventHandler(this.tsBtnEstorno_Click);
            // 
            // contextMenuStripRemessasResumo
            // 
            this.contextMenuStripRemessasResumo.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.verRemessasDetalheToolStripMenuItem});
            this.contextMenuStripRemessasResumo.Name = "contextMenuStripRemessas";
            this.contextMenuStripRemessasResumo.Size = new System.Drawing.Size(155, 26);
            this.contextMenuStripRemessasResumo.Text = "Remessas";
            this.contextMenuStripRemessasResumo.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripRemessasResumo_Opening);
            this.contextMenuStripRemessasResumo.Opened += new System.EventHandler(this.contextMenuStripRemessasResumo_Opened);
            // 
            // verRemessasDetalheToolStripMenuItem
            // 
            this.verRemessasDetalheToolStripMenuItem.Enabled = false;
            this.verRemessasDetalheToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.verRemessasDetalheToolStripMenuItem.Name = "verRemessasDetalheToolStripMenuItem";
            this.verRemessasDetalheToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.verRemessasDetalheToolStripMenuItem.Text = "Ver Remessas";
            this.verRemessasDetalheToolStripMenuItem.Click += new System.EventHandler(this.verRemessasDetalheToolStripMenuItem_Click);
            // 
            // contextMenuStripRemessa
            // 
            this.contextMenuStripRemessa.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuRemessaMudarEstado,
            this.verTranchesToolStripMenuItem,
            this.verDocumentosToolStripMenuItem});
            this.contextMenuStripRemessa.Name = "contextMenuStripRemTrans";
            this.contextMenuStripRemessa.Size = new System.Drawing.Size(168, 70);
            this.contextMenuStripRemessa.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripRemessa_Opening);
            this.contextMenuStripRemessa.Opened += new System.EventHandler(this.contextMenuStripRemessa_Opened);
            // 
            // toolStripMenuRemessaMudarEstado
            // 
            this.toolStripMenuRemessaMudarEstado.Enabled = false;
            this.toolStripMenuRemessaMudarEstado.Name = "toolStripMenuRemessaMudarEstado";
            this.toolStripMenuRemessaMudarEstado.Size = new System.Drawing.Size(167, 22);
            this.toolStripMenuRemessaMudarEstado.Text = "Mudar Estado";
            this.toolStripMenuRemessaMudarEstado.Click += new System.EventHandler(this.toolStripMenuRemessaMudarEstado_Click);
            // 
            // verTranchesToolStripMenuItem
            // 
            this.verTranchesToolStripMenuItem.Enabled = false;
            this.verTranchesToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.verTranchesToolStripMenuItem.Name = "verTranchesToolStripMenuItem";
            this.verTranchesToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.verTranchesToolStripMenuItem.Text = "Ver Tranches";
            this.verTranchesToolStripMenuItem.Click += new System.EventHandler(this.verTranchesToolStripMenuItem_Click);
            // 
            // verDocumentosToolStripMenuItem
            // 
            this.verDocumentosToolStripMenuItem.Enabled = false;
            this.verDocumentosToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.verDocumentosToolStripMenuItem.Name = "verDocumentosToolStripMenuItem";
            this.verDocumentosToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.verDocumentosToolStripMenuItem.Text = "Ver Documentos";
            this.verDocumentosToolStripMenuItem.Click += new System.EventHandler(this.verDocumentosToolStripMenuItem_Click);
            // 
            // contextMenuStripTranche
            // 
            this.contextMenuStripTranche.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contextMenuStripTrancheMudaEstado,
            this.contextMenuStripTrancheVerDocs});
            this.contextMenuStripTranche.Name = "contextMenuStripRemTrans";
            this.contextMenuStripTranche.Size = new System.Drawing.Size(168, 48);
            this.contextMenuStripTranche.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripTranche_Opening);
            this.contextMenuStripTranche.Opened += new System.EventHandler(this.contextMenuStripTranche_Opened);
            // 
            // contextMenuStripTrancheMudaEstado
            // 
            this.contextMenuStripTrancheMudaEstado.Enabled = false;
            this.contextMenuStripTrancheMudaEstado.Name = "contextMenuStripTrancheMudaEstado";
            this.contextMenuStripTrancheMudaEstado.Size = new System.Drawing.Size(167, 22);
            this.contextMenuStripTrancheMudaEstado.Text = "Mudar Estado";
            this.contextMenuStripTrancheMudaEstado.Click += new System.EventHandler(this.contextMenuStripTrancheMudaEstado_Click);
            // 
            // contextMenuStripTrancheVerDocs
            // 
            this.contextMenuStripTrancheVerDocs.Enabled = false;
            this.contextMenuStripTrancheVerDocs.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contextMenuStripTrancheVerDocs.Name = "contextMenuStripTrancheVerDocs";
            this.contextMenuStripTrancheVerDocs.Size = new System.Drawing.Size(167, 22);
            this.contextMenuStripTrancheVerDocs.Text = "Ver Documentos";
            this.contextMenuStripTrancheVerDocs.Click += new System.EventHandler(this.contextMenuStripTrancheVerDocs_Click);
            // 
            // contextMenuStripDocumento
            // 
            this.contextMenuStripDocumento.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuDocumentosVerImagem});
            this.contextMenuStripDocumento.Name = "contextMenuStripRemessas";
            this.contextMenuStripDocumento.Size = new System.Drawing.Size(227, 26);
            this.contextMenuStripDocumento.Text = "Ver imagem do documento";
            this.contextMenuStripDocumento.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripDocumento_Opening);
            this.contextMenuStripDocumento.Opened += new System.EventHandler(this.contextMenuStripDocumento_Opened);
            // 
            // toolStripMenuDocumentosVerImagem
            // 
            this.toolStripMenuDocumentosVerImagem.Enabled = false;
            this.toolStripMenuDocumentosVerImagem.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuDocumentosVerImagem.Name = "toolStripMenuDocumentosVerImagem";
            this.toolStripMenuDocumentosVerImagem.Size = new System.Drawing.Size(226, 22);
            this.toolStripMenuDocumentosVerImagem.Text = "Ver imagem do documento";
            this.toolStripMenuDocumentosVerImagem.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // contextMenuStripResumoEstornos
            // 
            this.contextMenuStripResumoEstornos.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemResumoEstornos});
            this.contextMenuStripResumoEstornos.Name = "contextMenuStripRemessas";
            this.contextMenuStripResumoEstornos.Size = new System.Drawing.Size(146, 26);
            this.contextMenuStripResumoEstornos.Text = "Remessas";
            this.contextMenuStripResumoEstornos.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripResumoEstornos_Opening);
            this.contextMenuStripResumoEstornos.Opened += new System.EventHandler(this.contextMenuStripResumoEstornos_Opened);
            // 
            // toolStripMenuItemResumoEstornos
            // 
            this.toolStripMenuItemResumoEstornos.Enabled = false;
            this.toolStripMenuItemResumoEstornos.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItemResumoEstornos.Name = "toolStripMenuItemResumoEstornos";
            this.toolStripMenuItemResumoEstornos.Size = new System.Drawing.Size(145, 22);
            this.toolStripMenuItemResumoEstornos.Text = "Ver Estornos";
            this.toolStripMenuItemResumoEstornos.Click += new System.EventHandler(this.toolStripMenuItemResumoEstornos_Click);
            // 
            // contextMenuStripRemessaEstorno
            // 
            this.contextMenuStripRemessaEstorno.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemRemessaEstorno,
            this.mudarEstadoToolStripMenuItem});
            this.contextMenuStripRemessaEstorno.Name = "contextMenuStripRemTrans";
            this.contextMenuStripRemessaEstorno.Size = new System.Drawing.Size(168, 48);
            this.contextMenuStripRemessaEstorno.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripRemessaEstorno_Opening);
            this.contextMenuStripRemessaEstorno.Opened += new System.EventHandler(this.contextMenuStripRemessaEstorno_Opened);
            // 
            // toolStripMenuItemRemessaEstorno
            // 
            this.toolStripMenuItemRemessaEstorno.Enabled = false;
            this.toolStripMenuItemRemessaEstorno.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItemRemessaEstorno.Name = "toolStripMenuItemRemessaEstorno";
            this.toolStripMenuItemRemessaEstorno.Size = new System.Drawing.Size(167, 22);
            this.toolStripMenuItemRemessaEstorno.Text = "Ver Documentos";
            this.toolStripMenuItemRemessaEstorno.Click += new System.EventHandler(this.toolStripMenuItemRemessaEstorno_Click);
            // 
            // mudarEstadoToolStripMenuItem
            // 
            this.mudarEstadoToolStripMenuItem.Enabled = false;
            this.mudarEstadoToolStripMenuItem.Name = "mudarEstadoToolStripMenuItem";
            this.mudarEstadoToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.mudarEstadoToolStripMenuItem.Text = "Mudar Estado";
            this.mudarEstadoToolStripMenuItem.Click += new System.EventHandler(this.mudarEstadoToolStripMenuItem_Click);
            // 
            // contextMenuStripDocumentoEstorno
            // 
            this.contextMenuStripDocumentoEstorno.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuDocumentosEstornosVerImagem});
            this.contextMenuStripDocumentoEstorno.Name = "contextMenuStripRemessas";
            this.contextMenuStripDocumentoEstorno.Size = new System.Drawing.Size(227, 26);
            this.contextMenuStripDocumentoEstorno.Text = "Ver imagem do documento";
            this.contextMenuStripDocumentoEstorno.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripDocumentoEstorno_Opening);
            this.contextMenuStripDocumentoEstorno.Opened += new System.EventHandler(this.contextMenuStripDocumentoEstorno_Opened);
            // 
            // toolStripMenuDocumentosEstornosVerImagem
            // 
            this.toolStripMenuDocumentosEstornosVerImagem.Enabled = false;
            this.toolStripMenuDocumentosEstornosVerImagem.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuDocumentosEstornosVerImagem.Name = "toolStripMenuDocumentosEstornosVerImagem";
            this.toolStripMenuDocumentosEstornosVerImagem.Size = new System.Drawing.Size(226, 22);
            this.toolStripMenuDocumentosEstornosVerImagem.Text = "Ver imagem do documento";
            this.toolStripMenuDocumentosEstornosVerImagem.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(9, 64);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 106;
            this.label5.Text = "De:";
            // 
            // lbBalcao
            // 
            this.lbBalcao.AutoSize = true;
            this.lbBalcao.Location = new System.Drawing.Point(432, 45);
            this.lbBalcao.Name = "lbBalcao";
            this.lbBalcao.Size = new System.Drawing.Size(40, 13);
            this.lbBalcao.TabIndex = 98;
            this.lbBalcao.Text = "Balcão";
            // 
            // lbRemessaCI
            // 
            this.lbRemessaCI.AutoSize = true;
            this.lbRemessaCI.Location = new System.Drawing.Point(482, 45);
            this.lbRemessaCI.Name = "lbRemessaCI";
            this.lbRemessaCI.Size = new System.Drawing.Size(64, 13);
            this.lbRemessaCI.TabIndex = 99;
            this.lbRemessaCI.Text = "Remessa CI";
            // 
            // lbTipoRemessa
            // 
            this.lbTipoRemessa.AutoSize = true;
            this.lbTipoRemessa.Location = new System.Drawing.Point(610, 44);
            this.lbTipoRemessa.Name = "lbTipoRemessa";
            this.lbTipoRemessa.Size = new System.Drawing.Size(75, 13);
            this.lbTipoRemessa.TabIndex = 100;
            this.lbTipoRemessa.Text = "Tipo Remessa";
            // 
            // lbDeposito
            // 
            this.lbDeposito.AutoSize = true;
            this.lbDeposito.Location = new System.Drawing.Point(549, 45);
            this.lbDeposito.Name = "lbDeposito";
            this.lbDeposito.Size = new System.Drawing.Size(49, 13);
            this.lbDeposito.TabIndex = 101;
            this.lbDeposito.Text = "Depósito";
            // 
            // txBalcao
            // 
            this.txBalcao.Location = new System.Drawing.Point(435, 61);
            this.txBalcao.MaxLength = 4;
            this.txBalcao.Name = "txBalcao";
            this.txBalcao.Size = new System.Drawing.Size(44, 20);
            this.txBalcao.TabIndex = 102;
            // 
            // txRemessaCI
            // 
            this.txRemessaCI.Location = new System.Drawing.Point(485, 61);
            this.txRemessaCI.MaxLength = 6;
            this.txRemessaCI.Name = "txRemessaCI";
            this.txRemessaCI.Size = new System.Drawing.Size(61, 20);
            this.txRemessaCI.TabIndex = 103;
            // 
            // m_ctrldtFim
            // 
            this.m_ctrldtFim.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrldtFim.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrldtFim.Location = new System.Drawing.Point(257, 61);
            this.m_ctrldtFim.Name = "m_ctrldtFim";
            this.m_ctrldtFim.Size = new System.Drawing.Size(172, 20);
            this.m_ctrldtFim.TabIndex = 109;
            // 
            // txDeposito
            // 
            this.txDeposito.Location = new System.Drawing.Point(552, 61);
            this.txDeposito.MaxLength = 7;
            this.txDeposito.Name = "txDeposito";
            this.txDeposito.Size = new System.Drawing.Size(55, 20);
            this.txDeposito.TabIndex = 104;
            // 
            // m_ctrldtInicio
            // 
            this.m_ctrldtInicio.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrldtInicio.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrldtInicio.Location = new System.Drawing.Point(42, 61);
            this.m_ctrldtInicio.Name = "m_ctrldtInicio";
            this.m_ctrldtInicio.Size = new System.Drawing.Size(185, 20);
            this.m_ctrldtInicio.TabIndex = 108;
            // 
            // cbTRemessa
            // 
            this.cbTRemessa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTRemessa.FormattingEnabled = true;
            this.cbTRemessa.Location = new System.Drawing.Point(613, 61);
            this.cbTRemessa.Name = "cbTRemessa";
            this.cbTRemessa.Size = new System.Drawing.Size(208, 21);
            this.cbTRemessa.TabIndex = 105;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(233, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(18, 13);
            this.label6.TabIndex = 107;
            this.label6.Text = "a:";
            // 
            // spContainer
            // 
            this.spContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.spContainer.Location = new System.Drawing.Point(0, 87);
            this.spContainer.Name = "spContainer";
            // 
            // spContainer.Panel1
            // 
            this.spContainer.Panel1.Controls.Add(this.spContRemessas);
            // 
            // spContainer.Panel2
            // 
            this.spContainer.Panel2.Controls.Add(this.spContEstorno);
            this.spContainer.Size = new System.Drawing.Size(940, 511);
            this.spContainer.SplitterDistance = 470;
            this.spContainer.TabIndex = 110;
            // 
            // spContRemessas
            // 
            this.spContRemessas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spContRemessas.Location = new System.Drawing.Point(0, 0);
            this.spContRemessas.Name = "spContRemessas";
            this.spContRemessas.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spContRemessas.Panel1
            // 
            this.spContRemessas.Panel1.Controls.Add(this.spContAgrRemessas);
            // 
            // spContRemessas.Panel2
            // 
            this.spContRemessas.Panel2.Controls.Add(this.spContTranDoc);
            this.spContRemessas.Size = new System.Drawing.Size(470, 511);
            this.spContRemessas.SplitterDistance = 274;
            this.spContRemessas.TabIndex = 0;
            // 
            // spContAgrRemessas
            // 
            this.spContAgrRemessas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spContAgrRemessas.Location = new System.Drawing.Point(0, 0);
            this.spContAgrRemessas.Name = "spContAgrRemessas";
            this.spContAgrRemessas.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spContAgrRemessas.Panel1
            // 
            this.spContAgrRemessas.Panel1.Controls.Add(this.listViewResumoRemessas);
            this.spContAgrRemessas.Panel1.Controls.Add(this.label1);
            this.spContAgrRemessas.Panel1.Controls.Add(this.m_btRefreshRemessas);
            this.spContAgrRemessas.Panel1.Controls.Add(this.btnRemessasErro);
            // 
            // spContAgrRemessas.Panel2
            // 
            this.spContAgrRemessas.Panel2.Controls.Add(this.listViewDetalhesRemessa);
            this.spContAgrRemessas.Panel2.Controls.Add(this.labelCountRemessas);
            this.spContAgrRemessas.Size = new System.Drawing.Size(470, 274);
            this.spContAgrRemessas.SplitterDistance = 154;
            this.spContAgrRemessas.TabIndex = 0;
            // 
            // listViewResumoRemessas
            // 
            this.listViewResumoRemessas.AllowColumnReorder = true;
            this.listViewResumoRemessas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewResumoRemessas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Process,
            this.Remessa,
            this.EstadoRemessas,
            this.tpRemessa,
            this.Rems,
            this.Docs,
            this.Montante,
            this.ENVM});
            this.listViewResumoRemessas.ContextMenuStrip = this.contextMenuStripRemessasResumo;
            this.listViewResumoRemessas.EnableExportar = true;
            this.listViewResumoRemessas.FullRowSelect = true;
            this.listViewResumoRemessas.GridLines = true;
            this.listViewResumoRemessas.HideSelection = false;
            this.listViewResumoRemessas.Location = new System.Drawing.Point(10, 42);
            this.listViewResumoRemessas.Margin = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.listViewResumoRemessas.Name = "listViewResumoRemessas";
            this.listViewResumoRemessas.Size = new System.Drawing.Size(457, 109);
            this.listViewResumoRemessas.TabIndex = 92;
            this.listViewResumoRemessas.TabStop = false;
            this.listViewResumoRemessas.UseCompatibleStateImageBehavior = false;
            this.listViewResumoRemessas.View = System.Windows.Forms.View.Details;
            this.listViewResumoRemessas.DoubleClick += new System.EventHandler(this.listViewResumoRemessas_DoubleClick);
            // 
            // Process
            // 
            this.Process.Text = "Dt. Processamento";
            this.Process.Width = 105;
            // 
            // Remessa
            // 
            this.Remessa.Text = "Dt. Remessa";
            this.Remessa.Width = 76;
            // 
            // EstadoRemessas
            // 
            this.EstadoRemessas.Text = "Estado";
            this.EstadoRemessas.Width = 130;
            // 
            // tpRemessa
            // 
            this.tpRemessa.Text = "Tipo Remessa";
            this.tpRemessa.Width = 115;
            // 
            // Rems
            // 
            this.Rems.Text = "#Rems";
            this.Rems.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Rems.Width = 45;
            // 
            // Docs
            // 
            this.Docs.Text = "#Docs";
            this.Docs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Docs.Width = 45;
            // 
            // Montante
            // 
            this.Montante.Text = "Montante";
            this.Montante.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Montante.Width = 85;
            // 
            // ENVM
            // 
            this.ENVM.Text = "ENVM";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 91;
            this.label1.Text = "Depósito-Resumo";
            // 
            // m_btRefreshRemessas
            // 
            this.m_btRefreshRemessas.Location = new System.Drawing.Point(12, 0);
            this.m_btRefreshRemessas.Name = "m_btRefreshRemessas";
            this.m_btRefreshRemessas.Size = new System.Drawing.Size(86, 23);
            this.m_btRefreshRemessas.TabIndex = 89;
            this.m_btRefreshRemessas.Text = "Remessas";
            this.m_btRefreshRemessas.UseVisualStyleBackColor = true;
            this.m_btRefreshRemessas.Click += new System.EventHandler(this.m_btRefreshRemessas_Click);
            // 
            // btnRemessasErro
            // 
            this.btnRemessasErro.Location = new System.Drawing.Point(104, 0);
            this.btnRemessasErro.Name = "btnRemessasErro";
            this.btnRemessasErro.Size = new System.Drawing.Size(157, 23);
            this.btnRemessasErro.TabIndex = 90;
            this.btnRemessasErro.Text = "Reenviar remessas em erro";
            this.btnRemessasErro.UseVisualStyleBackColor = true;
            this.btnRemessasErro.Click += new System.EventHandler(this.btnRemessasErro_Click);
            // 
            // listViewDetalhesRemessa
            // 
            this.listViewDetalhesRemessa.AllowColumnReorder = true;
            this.listViewDetalhesRemessa.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewDetalhesRemessa.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colRemID,
            this.colRemData,
            this.colRemTimer,
            this.colTimerEnviada,
            this.colRemnum,
            this.colRem,
            this.colRemTP,
            this.colRemDeposito,
            this.colRemStat,
            this.colRemTrans,
            this.colRemChaveH,
            this.colRemCGDError,
            this.colRemQT,
            this.colRemMT,
            this.colRemErro,
            this.colRemMaquina});
            this.listViewDetalhesRemessa.ContextMenuStrip = this.contextMenuStripRemessa;
            this.listViewDetalhesRemessa.EnableExportar = true;
            this.listViewDetalhesRemessa.FullRowSelect = true;
            this.listViewDetalhesRemessa.GridLines = true;
            this.listViewDetalhesRemessa.HideSelection = false;
            this.listViewDetalhesRemessa.Location = new System.Drawing.Point(10, 19);
            this.listViewDetalhesRemessa.Name = "listViewDetalhesRemessa";
            this.listViewDetalhesRemessa.Size = new System.Drawing.Size(457, 97);
            this.listViewDetalhesRemessa.TabIndex = 91;
            this.listViewDetalhesRemessa.TabStop = false;
            this.listViewDetalhesRemessa.UseCompatibleStateImageBehavior = false;
            this.listViewDetalhesRemessa.View = System.Windows.Forms.View.Details;
            this.listViewDetalhesRemessa.DoubleClick += new System.EventHandler(this.listViewDetalhesRemessa_DoubleClick);
            // 
            // colRemID
            // 
            this.colRemID.Text = "Rem ID";
            this.colRemID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colRemID.Width = 54;
            // 
            // colRemData
            // 
            this.colRemData.Text = "Dt. Remessa";
            this.colRemData.Width = 76;
            // 
            // colRemTimer
            // 
            this.colRemTimer.Text = "Timer";
            this.colRemTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colRemTimer.Width = 115;
            // 
            // colTimerEnviada
            // 
            this.colTimerEnviada.Text = "Dt. Envio";
            this.colTimerEnviada.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colTimerEnviada.Width = 115;
            // 
            // colRemnum
            // 
            this.colRemnum.Text = "Banco";
            this.colRemnum.Width = 0;
            // 
            // colRem
            // 
            this.colRem.Text = "Balcão";
            this.colRem.Width = 120;
            // 
            // colRemTP
            // 
            this.colRemTP.Text = "Tipo Remessa";
            this.colRemTP.Width = 185;
            // 
            // colRemDeposito
            // 
            this.colRemDeposito.Text = "#Depósito";
            this.colRemDeposito.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colRemDeposito.Width = 70;
            // 
            // colRemStat
            // 
            this.colRemStat.Text = "Estado";
            this.colRemStat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colRemStat.Width = 130;
            // 
            // colRemTrans
            // 
            this.colRemTrans.Text = "#Tranches";
            this.colRemTrans.Width = 70;
            // 
            // colRemChaveH
            // 
            this.colRemChaveH.Text = "ChaveH";
            this.colRemChaveH.Width = 0;
            // 
            // colRemCGDError
            // 
            this.colRemCGDError.Text = "CGD Error";
            // 
            // colRemQT
            // 
            this.colRemQT.Text = "Quant.";
            this.colRemQT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // colRemMT
            // 
            this.colRemMT.Text = "Montante";
            this.colRemMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colRemMT.Width = 94;
            // 
            // colRemErro
            // 
            this.colRemErro.Text = "Erro";
            this.colRemErro.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colRemErro.Width = 283;
            // 
            // colRemMaquina
            // 
            this.colRemMaquina.Text = "Maquina";
            // 
            // labelCountRemessas
            // 
            this.labelCountRemessas.AutoSize = true;
            this.labelCountRemessas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountRemessas.Location = new System.Drawing.Point(9, 3);
            this.labelCountRemessas.Name = "labelCountRemessas";
            this.labelCountRemessas.Size = new System.Drawing.Size(64, 13);
            this.labelCountRemessas.TabIndex = 74;
            this.labelCountRemessas.Text = "Remessas";
            // 
            // spContTranDoc
            // 
            this.spContTranDoc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.spContTranDoc.Location = new System.Drawing.Point(0, 0);
            this.spContTranDoc.Name = "spContTranDoc";
            this.spContTranDoc.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spContTranDoc.Panel1
            // 
            this.spContTranDoc.Panel1.Controls.Add(this.listViewDetalhesTranche);
            this.spContTranDoc.Panel1.Controls.Add(this.labelCountTranches);
            // 
            // spContTranDoc.Panel2
            // 
            this.spContTranDoc.Panel2.Controls.Add(this.lblCountDocumentos);
            this.spContTranDoc.Panel2.Controls.Add(this.listViewDetalhesDocumentos);
            this.spContTranDoc.Size = new System.Drawing.Size(470, 233);
            this.spContTranDoc.SplitterDistance = 104;
            this.spContTranDoc.TabIndex = 0;
            // 
            // listViewDetalhesTranche
            // 
            this.listViewDetalhesTranche.AllowColumnReorder = true;
            this.listViewDetalhesTranche.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewDetalhesTranche.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colTransRemID,
            this.colTransID,
            this.colTransTimer,
            this.colTransNumero,
            this.colTransEstado,
            this.colTransQt,
            this.colTransMt,
            this.colTransErro,
            this.colTransChaveWS,
            this.colTIBCOEstado});
            this.listViewDetalhesTranche.ContextMenuStrip = this.contextMenuStripTranche;
            this.listViewDetalhesTranche.EnableExportar = true;
            this.listViewDetalhesTranche.FullRowSelect = true;
            this.listViewDetalhesTranche.GridLines = true;
            this.listViewDetalhesTranche.HideSelection = false;
            this.listViewDetalhesTranche.Location = new System.Drawing.Point(10, 22);
            this.listViewDetalhesTranche.Name = "listViewDetalhesTranche";
            this.listViewDetalhesTranche.Size = new System.Drawing.Size(457, 82);
            this.listViewDetalhesTranche.TabIndex = 92;
            this.listViewDetalhesTranche.TabStop = false;
            this.listViewDetalhesTranche.UseCompatibleStateImageBehavior = false;
            this.listViewDetalhesTranche.View = System.Windows.Forms.View.Details;
            this.listViewDetalhesTranche.DoubleClick += new System.EventHandler(this.listViewDetalhesTranche_DoubleClick);
            // 
            // colTransRemID
            // 
            this.colTransRemID.Text = "Rem ID";
            this.colTransRemID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colTransRemID.Width = 54;
            // 
            // colTransID
            // 
            this.colTransID.Text = "Trans ID";
            this.colTransID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colTransID.Width = 131;
            // 
            // colTransTimer
            // 
            this.colTransTimer.Text = "Timer";
            this.colTransTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colTransTimer.Width = 145;
            // 
            // colTransNumero
            // 
            this.colTransNumero.Text = "Número";
            this.colTransNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colTransNumero.Width = 107;
            // 
            // colTransEstado
            // 
            this.colTransEstado.Text = "Estado";
            this.colTransEstado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colTransEstado.Width = 90;
            // 
            // colTransQt
            // 
            this.colTransQt.Text = "Quantidade";
            this.colTransQt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colTransQt.Width = 94;
            // 
            // colTransMt
            // 
            this.colTransMt.Text = "Montante";
            this.colTransMt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colTransMt.Width = 100;
            // 
            // colTransErro
            // 
            this.colTransErro.Text = "Erro";
            // 
            // colTransChaveWS
            // 
            this.colTransChaveWS.Text = "ChaveWS";
            this.colTransChaveWS.Width = 70;
            // 
            // colTIBCOEstado
            // 
            this.colTIBCOEstado.Text = "TIBCO Estado";
            this.colTIBCOEstado.Width = 90;
            // 
            // labelCountTranches
            // 
            this.labelCountTranches.AutoSize = true;
            this.labelCountTranches.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountTranches.Location = new System.Drawing.Point(9, 6);
            this.labelCountTranches.Name = "labelCountTranches";
            this.labelCountTranches.Size = new System.Drawing.Size(60, 13);
            this.labelCountTranches.TabIndex = 75;
            this.labelCountTranches.Text = "Tranches";
            // 
            // lblCountDocumentos
            // 
            this.lblCountDocumentos.AutoSize = true;
            this.lblCountDocumentos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountDocumentos.Location = new System.Drawing.Point(12, 6);
            this.lblCountDocumentos.Name = "lblCountDocumentos";
            this.lblCountDocumentos.Size = new System.Drawing.Size(77, 13);
            this.lblCountDocumentos.TabIndex = 93;
            this.lblCountDocumentos.Text = "Documentos";
            // 
            // listViewDetalhesDocumentos
            // 
            this.listViewDetalhesDocumentos.AllowColumnReorder = true;
            this.listViewDetalhesDocumentos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewDetalhesDocumentos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.detDocColDocId,
            this.detDocColDocZona5,
            this.detDocColDocZona4,
            this.detDocColDocZona3,
            this.detDocColDocZona2,
            this.detDocColDocZona1,
            this.detDocColDocStat,
            this.detDocColDocNIB,
            this.detDocColDocRefarq,
            this.detDocColDocNSeq,
            this.detDocColChaveH,
            this.detDocColDocIndex,
            this.detDocColDocMaquina,
            this.detDocColDocBaltom,
            this.detDocColChaveHext,
            this.detDocColDocTipo,
            this.detDocColDocTimer,
            this.detDocColReminData,
            this.detDocColReminID,
            this.detDocColTranoutID,
            this.detDocColBalcao,
            this.detDocColRemNum,
            this.detDocColTranoutStatId,
            this.detDocColTranNum,
            this.columnDocColErro,
            this.detDocDeposito});
            this.listViewDetalhesDocumentos.ContextMenuStrip = this.contextMenuStripDocumento;
            this.listViewDetalhesDocumentos.EnableExportar = true;
            this.listViewDetalhesDocumentos.FullRowSelect = true;
            this.listViewDetalhesDocumentos.GridLines = true;
            this.listViewDetalhesDocumentos.HideSelection = false;
            this.listViewDetalhesDocumentos.Location = new System.Drawing.Point(10, 22);
            this.listViewDetalhesDocumentos.MultiSelect = false;
            this.listViewDetalhesDocumentos.Name = "listViewDetalhesDocumentos";
            this.listViewDetalhesDocumentos.Size = new System.Drawing.Size(457, 100);
            this.listViewDetalhesDocumentos.TabIndex = 94;
            this.listViewDetalhesDocumentos.TabStop = false;
            this.listViewDetalhesDocumentos.UseCompatibleStateImageBehavior = false;
            this.listViewDetalhesDocumentos.View = System.Windows.Forms.View.Details;
            this.listViewDetalhesDocumentos.DoubleClick += new System.EventHandler(this.listViewDetalhesDocumentos_DoubleClick);
            // 
            // detDocColDocId
            // 
            this.detDocColDocId.Text = "Doc ID";
            this.detDocColDocId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.detDocColDocId.Width = 62;
            // 
            // detDocColDocZona5
            // 
            this.detDocColDocZona5.Text = "ZIB";
            this.detDocColDocZona5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocZona5.Width = 100;
            // 
            // detDocColDocZona4
            // 
            this.detDocColDocZona4.Text = "N. Conta";
            this.detDocColDocZona4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocZona4.Width = 100;
            // 
            // detDocColDocZona3
            // 
            this.detDocColDocZona3.Text = "N.Cheque";
            this.detDocColDocZona3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocZona3.Width = 100;
            // 
            // detDocColDocZona2
            // 
            this.detDocColDocZona2.Text = "Montante";
            this.detDocColDocZona2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.detDocColDocZona2.Width = 100;
            // 
            // detDocColDocZona1
            // 
            this.detDocColDocZona1.Text = "Tp";
            this.detDocColDocZona1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocZona1.Width = 90;
            // 
            // detDocColDocStat
            // 
            this.detDocColDocStat.Text = "Estado";
            this.detDocColDocStat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocStat.Width = 90;
            // 
            // detDocColDocNIB
            // 
            this.detDocColDocNIB.Text = "Conta/NIB";
            this.detDocColDocNIB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocNIB.Width = 150;
            // 
            // detDocColDocRefarq
            // 
            this.detDocColDocRefarq.Text = "Refarq";
            this.detDocColDocRefarq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocRefarq.Width = 150;
            // 
            // detDocColDocNSeq
            // 
            this.detDocColDocNSeq.Text = "N Seq";
            this.detDocColDocNSeq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // detDocColChaveH
            // 
            this.detDocColChaveH.Text = "ChaveH";
            this.detDocColChaveH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColChaveH.Width = 350;
            // 
            // detDocColDocIndex
            // 
            this.detDocColDocIndex.Text = "Index";
            this.detDocColDocIndex.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocIndex.Width = 100;
            // 
            // detDocColDocMaquina
            // 
            this.detDocColDocMaquina.Text = "Maquina";
            this.detDocColDocMaquina.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // detDocColDocBaltom
            // 
            this.detDocColDocBaltom.Text = "Balcão Tom";
            this.detDocColDocBaltom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocBaltom.Width = 150;
            // 
            // detDocColChaveHext
            // 
            this.detDocColChaveHext.Text = "ChaveH ext";
            this.detDocColChaveHext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColChaveHext.Width = 200;
            // 
            // detDocColDocTipo
            // 
            this.detDocColDocTipo.Text = "Tipo";
            this.detDocColDocTipo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocTipo.Width = 185;
            // 
            // detDocColDocTimer
            // 
            this.detDocColDocTimer.Text = "Timer";
            this.detDocColDocTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocTimer.Width = 120;
            // 
            // detDocColReminData
            // 
            this.detDocColReminData.Text = "Data Remessa";
            this.detDocColReminData.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColReminData.Width = 100;
            // 
            // detDocColReminID
            // 
            this.detDocColReminID.Text = "Rem ID";
            this.detDocColReminID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // detDocColTranoutID
            // 
            this.detDocColTranoutID.Text = "Tran ID";
            this.detDocColTranoutID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // detDocColBalcao
            // 
            this.detDocColBalcao.Text = "Balcão";
            this.detDocColBalcao.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColBalcao.Width = 150;
            // 
            // detDocColRemNum
            // 
            this.detDocColRemNum.Text = "Rem Num";
            this.detDocColRemNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColRemNum.Width = 80;
            // 
            // detDocColTranoutStatId
            // 
            this.detDocColTranoutStatId.Text = "Tran Estado";
            this.detDocColTranoutStatId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColTranoutStatId.Width = 80;
            // 
            // detDocColTranNum
            // 
            this.detDocColTranNum.Text = "Tran Num";
            this.detDocColTranNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnDocColErro
            // 
            this.columnDocColErro.Text = "Erro";
            this.columnDocColErro.Width = 256;
            // 
            // detDocDeposito
            // 
            this.detDocDeposito.Text = "Depósito";
            // 
            // spContEstorno
            // 
            this.spContEstorno.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.spContEstorno.Location = new System.Drawing.Point(3, 1);
            this.spContEstorno.Name = "spContEstorno";
            this.spContEstorno.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spContEstorno.Panel1
            // 
            this.spContEstorno.Panel1.Controls.Add(this.listViewEstornoResumo);
            this.spContEstorno.Panel1.Controls.Add(this.btEstorno);
            this.spContEstorno.Panel1.Controls.Add(this.btnEstonoErro);
            this.spContEstorno.Panel1.Controls.Add(this.label7);
            // 
            // spContEstorno.Panel2
            // 
            this.spContEstorno.Panel2.Controls.Add(this.spContEstRemDoc);
            this.spContEstorno.Size = new System.Drawing.Size(470, 510);
            this.spContEstorno.SplitterDistance = 228;
            this.spContEstorno.TabIndex = 0;
            // 
            // listViewEstornoResumo
            // 
            this.listViewEstornoResumo.AllowColumnReorder = true;
            this.listViewEstornoResumo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewEstornoResumo.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colZProcess,
            this.colZEstorno,
            this.colEstadoEstr,
            this.colTpRemessa,
            this.colQtEstorno,
            this.colQtDocs,
            this.colMontante,
            this.colENVM});
            this.listViewEstornoResumo.ContextMenuStrip = this.contextMenuStripResumoEstornos;
            this.listViewEstornoResumo.EnableExportar = true;
            this.listViewEstornoResumo.FullRowSelect = true;
            this.listViewEstornoResumo.GridLines = true;
            this.listViewEstornoResumo.HideSelection = false;
            this.listViewEstornoResumo.Location = new System.Drawing.Point(6, 42);
            this.listViewEstornoResumo.Name = "listViewEstornoResumo";
            this.listViewEstornoResumo.Size = new System.Drawing.Size(461, 183);
            this.listViewEstornoResumo.TabIndex = 94;
            this.listViewEstornoResumo.TabStop = false;
            this.listViewEstornoResumo.UseCompatibleStateImageBehavior = false;
            this.listViewEstornoResumo.View = System.Windows.Forms.View.Details;
            this.listViewEstornoResumo.DoubleClick += new System.EventHandler(this.listViewEstornoResumo_DoubleClick);
            // 
            // colZProcess
            // 
            this.colZProcess.Text = "Dt. Processamento";
            this.colZProcess.Width = 105;
            // 
            // colZEstorno
            // 
            this.colZEstorno.Text = "Dt. Estorno";
            this.colZEstorno.Width = 66;
            // 
            // colEstadoEstr
            // 
            this.colEstadoEstr.Text = "Estado Estorno";
            this.colEstadoEstr.Width = 130;
            // 
            // colTpRemessa
            // 
            this.colTpRemessa.Text = "Tipo Remessa";
            this.colTpRemessa.Width = 115;
            // 
            // colQtEstorno
            // 
            this.colQtEstorno.Text = "#Est";
            this.colQtEstorno.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colQtEstorno.Width = 45;
            // 
            // colQtDocs
            // 
            this.colQtDocs.Text = "#Docs";
            this.colQtDocs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colQtDocs.Width = 45;
            // 
            // colMontante
            // 
            this.colMontante.Text = "Montante";
            this.colMontante.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colMontante.Width = 85;
            // 
            // colENVM
            // 
            this.colENVM.Text = "ENVM";
            // 
            // btEstorno
            // 
            this.btEstorno.Location = new System.Drawing.Point(6, -1);
            this.btEstorno.Name = "btEstorno";
            this.btEstorno.Size = new System.Drawing.Size(86, 23);
            this.btEstorno.TabIndex = 85;
            this.btEstorno.Text = "Estornos";
            this.btEstorno.UseVisualStyleBackColor = true;
            this.btEstorno.Click += new System.EventHandler(this.btEstorno_Click);
            // 
            // btnEstonoErro
            // 
            this.btnEstonoErro.Location = new System.Drawing.Point(98, -1);
            this.btnEstonoErro.Name = "btnEstonoErro";
            this.btnEstonoErro.Size = new System.Drawing.Size(151, 23);
            this.btnEstonoErro.TabIndex = 86;
            this.btnEstonoErro.Text = "Reenviar estorno em erro";
            this.btnEstonoErro.UseVisualStyleBackColor = true;
            this.btnEstonoErro.Click += new System.EventHandler(this.btnEstonoErro_Click);
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 25);
            this.label7.MaximumSize = new System.Drawing.Size(111, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 13);
            this.label7.TabIndex = 87;
            this.label7.Text = "Estornos-Resumos";
            // 
            // spContEstRemDoc
            // 
            this.spContEstRemDoc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.spContEstRemDoc.Location = new System.Drawing.Point(4, 4);
            this.spContEstRemDoc.Name = "spContEstRemDoc";
            this.spContEstRemDoc.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spContEstRemDoc.Panel1
            // 
            this.spContEstRemDoc.Panel1.Controls.Add(this.listViewRemessaEstorno);
            this.spContEstRemDoc.Panel1.Controls.Add(this.lblCountRemessasEstornos);
            // 
            // spContEstRemDoc.Panel2
            // 
            this.spContEstRemDoc.Panel2.Controls.Add(this.listViewDocumentoEstorno);
            this.spContEstRemDoc.Panel2.Controls.Add(this.lblCountDocumentosEstornos);
            this.spContEstRemDoc.Size = new System.Drawing.Size(466, 274);
            this.spContEstRemDoc.SplitterDistance = 151;
            this.spContEstRemDoc.TabIndex = 0;
            // 
            // listViewRemessaEstorno
            // 
            this.listViewRemessaEstorno.AllowColumnReorder = true;
            this.listViewRemessaEstorno.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewRemessaEstorno.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader8,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader17,
            this.columnHeader18,
            this.columnHeader19,
            this.columnHeader20,
            this.columnHeader21,
            this.columnHeader22,
            this.columnHeader23,
            this.columnHeader24,
            this.columnHeader25,
            this.columnHeader26});
            this.listViewRemessaEstorno.ContextMenuStrip = this.contextMenuStripRemessaEstorno;
            this.listViewRemessaEstorno.EnableExportar = true;
            this.listViewRemessaEstorno.FullRowSelect = true;
            this.listViewRemessaEstorno.GridLines = true;
            this.listViewRemessaEstorno.HideSelection = false;
            this.listViewRemessaEstorno.Location = new System.Drawing.Point(2, 20);
            this.listViewRemessaEstorno.Name = "listViewRemessaEstorno";
            this.listViewRemessaEstorno.Size = new System.Drawing.Size(461, 128);
            this.listViewRemessaEstorno.TabIndex = 95;
            this.listViewRemessaEstorno.TabStop = false;
            this.listViewRemessaEstorno.UseCompatibleStateImageBehavior = false;
            this.listViewRemessaEstorno.View = System.Windows.Forms.View.Details;
            this.listViewRemessaEstorno.DoubleClick += new System.EventHandler(this.listViewRemessaEstorno_DoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Rem ID";
            this.columnHeader1.Width = 66;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Rem Data";
            this.columnHeader2.Width = 66;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Rem Timer";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Enviada";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 100;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Est Rem";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 90;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Est Doc";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader6.Width = 50;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Balcão Tom";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader7.Width = 100;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Número";
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Tipo Remessa";
            this.columnHeader18.Width = 185;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "Depósito";
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "Estado";
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "ChaveH";
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "CGD Error";
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "Quant.";
            // 
            // columnHeader24
            // 
            this.columnHeader24.Text = "Montante";
            this.columnHeader24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader24.Width = 100;
            // 
            // columnHeader25
            // 
            this.columnHeader25.Text = "Erro";
            // 
            // columnHeader26
            // 
            this.columnHeader26.Text = "Máquina";
            // 
            // lblCountRemessasEstornos
            // 
            this.lblCountRemessasEstornos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCountRemessasEstornos.AutoSize = true;
            this.lblCountRemessasEstornos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountRemessasEstornos.Location = new System.Drawing.Point(-1, 4);
            this.lblCountRemessasEstornos.Name = "lblCountRemessasEstornos";
            this.lblCountRemessasEstornos.Size = new System.Drawing.Size(117, 13);
            this.lblCountRemessasEstornos.TabIndex = 86;
            this.lblCountRemessasEstornos.Text = "Remessas-Estornos";
            // 
            // listViewDocumentoEstorno
            // 
            this.listViewDocumentoEstorno.AllowColumnReorder = true;
            this.listViewDocumentoEstorno.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewDocumentoEstorno.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colEstDocId,
            this.colEstZIB,
            this.colEstNConta,
            this.colEstNCheque,
            this.colEstMontante,
            this.colEstTpDoc,
            this.colEstEstDoc,
            this.colEstNIB,
            this.colEstRefarq,
            this.colEstNSeq,
            this.colEstChvH,
            this.colEstIndex,
            this.colEstMaquina,
            this.colEstBalcaoTom,
            this.colEstChvHext,
            this.colEstTipo,
            this.colEstTimer,
            this.colEstZRemessa,
            this.colEstRemID,
            this.colEstTranId,
            this.colEstBalcaoDesb,
            this.colEstRemNum,
            this.colEstEstTran,
            this.colEstTranNum,
            this.colEstDocErro,
            this.colEstDep});
            this.listViewDocumentoEstorno.ContextMenuStrip = this.contextMenuStripDocumentoEstorno;
            this.listViewDocumentoEstorno.EnableExportar = true;
            this.listViewDocumentoEstorno.FullRowSelect = true;
            this.listViewDocumentoEstorno.GridLines = true;
            this.listViewDocumentoEstorno.HideSelection = false;
            this.listViewDocumentoEstorno.Location = new System.Drawing.Point(2, 16);
            this.listViewDocumentoEstorno.MultiSelect = false;
            this.listViewDocumentoEstorno.Name = "listViewDocumentoEstorno";
            this.listViewDocumentoEstorno.Size = new System.Drawing.Size(461, 100);
            this.listViewDocumentoEstorno.TabIndex = 96;
            this.listViewDocumentoEstorno.TabStop = false;
            this.listViewDocumentoEstorno.UseCompatibleStateImageBehavior = false;
            this.listViewDocumentoEstorno.View = System.Windows.Forms.View.Details;
            this.listViewDocumentoEstorno.DoubleClick += new System.EventHandler(this.listViewDocumentoEstorno_DoubleClick);
            // 
            // colEstDocId
            // 
            this.colEstDocId.Text = "Doc ID";
            // 
            // colEstZIB
            // 
            this.colEstZIB.Text = "ZIB";
            this.colEstZIB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstZIB.Width = 100;
            // 
            // colEstNConta
            // 
            this.colEstNConta.Text = "N. Conta";
            this.colEstNConta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstNConta.Width = 100;
            // 
            // colEstNCheque
            // 
            this.colEstNCheque.Text = "N.Cheque";
            this.colEstNCheque.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstNCheque.Width = 100;
            // 
            // colEstMontante
            // 
            this.colEstMontante.Text = "Montante";
            this.colEstMontante.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colEstMontante.Width = 100;
            // 
            // colEstTpDoc
            // 
            this.colEstTpDoc.Text = "Tp";
            this.colEstTpDoc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstTpDoc.Width = 90;
            // 
            // colEstEstDoc
            // 
            this.colEstEstDoc.Text = "Estado";
            this.colEstEstDoc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstEstDoc.Width = 80;
            // 
            // colEstNIB
            // 
            this.colEstNIB.Text = "Conta/NIB";
            this.colEstNIB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstNIB.Width = 150;
            // 
            // colEstRefarq
            // 
            this.colEstRefarq.Text = "Refarq";
            this.colEstRefarq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstRefarq.Width = 150;
            // 
            // colEstNSeq
            // 
            this.colEstNSeq.Text = "N Seq";
            this.colEstNSeq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colEstChvH
            // 
            this.colEstChvH.Text = "ChaveH";
            this.colEstChvH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstChvH.Width = 350;
            // 
            // colEstIndex
            // 
            this.colEstIndex.Text = "Index";
            this.colEstIndex.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstIndex.Width = 100;
            // 
            // colEstMaquina
            // 
            this.colEstMaquina.Text = "Maquina";
            this.colEstMaquina.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colEstBalcaoTom
            // 
            this.colEstBalcaoTom.Text = "Balcao Tom";
            this.colEstBalcaoTom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstBalcaoTom.Width = 150;
            // 
            // colEstChvHext
            // 
            this.colEstChvHext.Text = "ChaveH ext";
            this.colEstChvHext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstChvHext.Width = 200;
            // 
            // colEstTipo
            // 
            this.colEstTipo.Text = "Tipo";
            this.colEstTipo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstTipo.Width = 120;
            // 
            // colEstTimer
            // 
            this.colEstTimer.Text = "Timer";
            this.colEstTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstTimer.Width = 120;
            // 
            // colEstZRemessa
            // 
            this.colEstZRemessa.Text = "Data Remessa";
            this.colEstZRemessa.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstZRemessa.Width = 100;
            // 
            // colEstRemID
            // 
            this.colEstRemID.Text = "Rem ID";
            this.colEstRemID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colEstTranId
            // 
            this.colEstTranId.Text = "Tran ID";
            this.colEstTranId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colEstBalcaoDesb
            // 
            this.colEstBalcaoDesb.Text = "Balcão";
            this.colEstBalcaoDesb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstBalcaoDesb.Width = 150;
            // 
            // colEstRemNum
            // 
            this.colEstRemNum.Text = "Rem Num";
            this.colEstRemNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstRemNum.Width = 80;
            // 
            // colEstEstTran
            // 
            this.colEstEstTran.Text = "Tran Estado";
            this.colEstEstTran.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colEstEstTran.Width = 80;
            // 
            // colEstTranNum
            // 
            this.colEstTranNum.Text = "Tran Num";
            this.colEstTranNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colEstDocErro
            // 
            this.colEstDocErro.Text = "Erro";
            this.colEstDocErro.Width = 256;
            // 
            // colEstDep
            // 
            this.colEstDep.Text = "Depósito";
            // 
            // lblCountDocumentosEstornos
            // 
            this.lblCountDocumentosEstornos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCountDocumentosEstornos.AutoSize = true;
            this.lblCountDocumentosEstornos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountDocumentosEstornos.Location = new System.Drawing.Point(-3, 0);
            this.lblCountDocumentosEstornos.Name = "lblCountDocumentosEstornos";
            this.lblCountDocumentosEstornos.Size = new System.Drawing.Size(130, 13);
            this.lblCountDocumentosEstornos.TabIndex = 87;
            this.lblCountDocumentosEstornos.Text = "Documentos-Estornos";
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Est Timer";
            this.columnHeader8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader8.Width = 100;
            // 
            // ActividadeBalcaoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 602);
            this.Controls.Add(this.spContainer);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbBalcao);
            this.Controls.Add(this.lbRemessaCI);
            this.Controls.Add(this.lbTipoRemessa);
            this.Controls.Add(this.lbDeposito);
            this.Controls.Add(this.txBalcao);
            this.Controls.Add(this.txRemessaCI);
            this.Controls.Add(this.m_ctrldtFim);
            this.Controls.Add(this.txDeposito);
            this.Controls.Add(this.m_ctrldtInicio);
            this.Controls.Add(this.cbTRemessa);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.toolStrip1);
            this.Name = "ActividadeBalcaoForm";
            this.Text = "Actividades Balcão";
            this.Load += new System.EventHandler(this.ActvBalcaoForm_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.contextMenuStripRemessasResumo.ResumeLayout(false);
            this.contextMenuStripRemessa.ResumeLayout(false);
            this.contextMenuStripTranche.ResumeLayout(false);
            this.contextMenuStripDocumento.ResumeLayout(false);
            this.contextMenuStripResumoEstornos.ResumeLayout(false);
            this.contextMenuStripRemessaEstorno.ResumeLayout(false);
            this.contextMenuStripDocumentoEstorno.ResumeLayout(false);
            this.spContainer.Panel1.ResumeLayout(false);
            this.spContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spContainer)).EndInit();
            this.spContainer.ResumeLayout(false);
            this.spContRemessas.Panel1.ResumeLayout(false);
            this.spContRemessas.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spContRemessas)).EndInit();
            this.spContRemessas.ResumeLayout(false);
            this.spContAgrRemessas.Panel1.ResumeLayout(false);
            this.spContAgrRemessas.Panel1.PerformLayout();
            this.spContAgrRemessas.Panel2.ResumeLayout(false);
            this.spContAgrRemessas.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spContAgrRemessas)).EndInit();
            this.spContAgrRemessas.ResumeLayout(false);
            this.spContTranDoc.Panel1.ResumeLayout(false);
            this.spContTranDoc.Panel1.PerformLayout();
            this.spContTranDoc.Panel2.ResumeLayout(false);
            this.spContTranDoc.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spContTranDoc)).EndInit();
            this.spContTranDoc.ResumeLayout(false);
            this.spContEstorno.Panel1.ResumeLayout(false);
            this.spContEstorno.Panel1.PerformLayout();
            this.spContEstorno.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spContEstorno)).EndInit();
            this.spContEstorno.ResumeLayout(false);
            this.spContEstRemDoc.Panel1.ResumeLayout(false);
            this.spContEstRemDoc.Panel1.PerformLayout();
            this.spContEstRemDoc.Panel2.ResumeLayout(false);
            this.spContEstRemDoc.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spContEstRemDoc)).EndInit();
            this.spContEstRemDoc.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonEspMaquinas;
        private System.Windows.Forms.ToolStripButton toolStripButtonProcessamento;
        private System.Windows.Forms.ToolStripButton toolStripButtonProcessado;
        private System.Windows.Forms.ToolStripButton toolStripButtonEnviada;
        private System.Windows.Forms.ToolStripButton toolStripButtonENVM;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButtonErro;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButtonRefresh;
        private System.Windows.Forms.ToolStripButton toolStripButtonFechados;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripRemessa;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuRemessaMudarEstado;
        private System.Windows.Forms.ToolStripMenuItem verTranchesToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripRemessasResumo;
        private System.Windows.Forms.ToolStripMenuItem verRemessasDetalheToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripTranche;
        private System.Windows.Forms.ToolStripMenuItem contextMenuStripTrancheMudaEstado;
        private System.Windows.Forms.ToolStripMenuItem contextMenuStripTrancheVerDocs;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripResumoEstornos;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemResumoEstornos;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripRemessaEstorno;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemRemessaEstorno;
        private System.Windows.Forms.ToolStripMenuItem mudarEstadoToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripDocumentoEstorno;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuDocumentosEstornosVerImagem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripDocumento;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuDocumentosVerImagem;
        private System.Windows.Forms.ToolStripButton toolStripButtonExitJanela;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton tsBtnRemessa;
        private System.Windows.Forms.ToolStripButton tsBtnEstorno;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbBalcao;
        private System.Windows.Forms.Label lbRemessaCI;
        private System.Windows.Forms.Label lbTipoRemessa;
        private System.Windows.Forms.Label lbDeposito;
        private System.Windows.Forms.TextBox txBalcao;
        private System.Windows.Forms.TextBox txRemessaCI;
        private System.Windows.Forms.DateTimePicker m_ctrldtFim;
        private System.Windows.Forms.TextBox txDeposito;
        private System.Windows.Forms.DateTimePicker m_ctrldtInicio;
        private System.Windows.Forms.ComboBox cbTRemessa;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.SplitContainer spContainer;
        private System.Windows.Forms.ToolStripMenuItem verDocumentosToolStripMenuItem;
        private System.Windows.Forms.SplitContainer spContRemessas;
        private System.Windows.Forms.SplitContainer spContAgrRemessas;
        private System.Windows.Forms.Button m_btRefreshRemessas;
        private System.Windows.Forms.Button btnRemessasErro;
        private System.Windows.Forms.Label label1;
        private NBIISNET.ListViewBase listViewResumoRemessas;
        private System.Windows.Forms.ColumnHeader Process;
        private System.Windows.Forms.ColumnHeader Remessa;
        private System.Windows.Forms.ColumnHeader EstadoRemessas;
        private System.Windows.Forms.ColumnHeader Rems;
        private System.Windows.Forms.ColumnHeader Docs;
        private System.Windows.Forms.ColumnHeader Montante;
        private System.Windows.Forms.ColumnHeader ENVM;
        private System.Windows.Forms.ColumnHeader tpRemessa;
        private System.Windows.Forms.Label labelCountRemessas;
        private NBIISNET.ListViewBase listViewDetalhesRemessa;
        private System.Windows.Forms.ColumnHeader colRemID;
        private System.Windows.Forms.ColumnHeader colRemData;
        private System.Windows.Forms.ColumnHeader colRemTimer;
        private System.Windows.Forms.ColumnHeader colTimerEnviada;
        private System.Windows.Forms.ColumnHeader colRemnum;
        private System.Windows.Forms.ColumnHeader colRem;
        private System.Windows.Forms.ColumnHeader colRemTP;
        private System.Windows.Forms.ColumnHeader colRemDeposito;
        private System.Windows.Forms.ColumnHeader colRemStat;
        private System.Windows.Forms.ColumnHeader colRemTrans;
        private System.Windows.Forms.ColumnHeader colRemChaveH;
        private System.Windows.Forms.ColumnHeader colRemCGDError;
        private System.Windows.Forms.ColumnHeader colRemQT;
        private System.Windows.Forms.ColumnHeader colRemMT;
        private System.Windows.Forms.ColumnHeader colRemErro;
        private System.Windows.Forms.ColumnHeader colRemMaquina;
        private System.Windows.Forms.SplitContainer spContTranDoc;
        private System.Windows.Forms.Label labelCountTranches;
        private NBIISNET.ListViewBase listViewDetalhesTranche;
        private System.Windows.Forms.ColumnHeader colTransRemID;
        private System.Windows.Forms.ColumnHeader colTransID;
        private System.Windows.Forms.ColumnHeader colTransTimer;
        private System.Windows.Forms.ColumnHeader colTransNumero;
        private System.Windows.Forms.ColumnHeader colTransEstado;
        private System.Windows.Forms.ColumnHeader colTransQt;
        private System.Windows.Forms.ColumnHeader colTransMt;
        private System.Windows.Forms.ColumnHeader colTransErro;
        private System.Windows.Forms.ColumnHeader colTransChaveWS;
        private System.Windows.Forms.ColumnHeader colTIBCOEstado;
        private System.Windows.Forms.Label lblCountDocumentos;
        private NBIISNET.ListViewBase listViewDetalhesDocumentos;
        private System.Windows.Forms.ColumnHeader detDocColDocId;
        private System.Windows.Forms.ColumnHeader detDocColDocZona5;
        private System.Windows.Forms.ColumnHeader detDocColDocZona4;
        private System.Windows.Forms.ColumnHeader detDocColDocZona3;
        private System.Windows.Forms.ColumnHeader detDocColDocZona2;
        private System.Windows.Forms.ColumnHeader detDocColDocZona1;
        private System.Windows.Forms.ColumnHeader detDocColDocStat;
        private System.Windows.Forms.ColumnHeader detDocColDocNIB;
        private System.Windows.Forms.ColumnHeader detDocColDocRefarq;
        private System.Windows.Forms.ColumnHeader detDocColDocNSeq;
        private System.Windows.Forms.ColumnHeader detDocColChaveH;
        private System.Windows.Forms.ColumnHeader detDocColDocIndex;
        private System.Windows.Forms.ColumnHeader detDocColDocMaquina;
        private System.Windows.Forms.ColumnHeader detDocColDocBaltom;
        private System.Windows.Forms.ColumnHeader detDocColChaveHext;
        private System.Windows.Forms.ColumnHeader detDocColDocTipo;
        private System.Windows.Forms.ColumnHeader detDocColDocTimer;
        private System.Windows.Forms.ColumnHeader detDocColReminData;
        private System.Windows.Forms.ColumnHeader detDocColReminID;
        private System.Windows.Forms.ColumnHeader detDocColTranoutID;
        private System.Windows.Forms.ColumnHeader detDocColBalcao;
        private System.Windows.Forms.ColumnHeader detDocColRemNum;
        private System.Windows.Forms.ColumnHeader detDocColTranoutStatId;
        private System.Windows.Forms.ColumnHeader detDocColTranNum;
        private System.Windows.Forms.ColumnHeader columnDocColErro;
        private System.Windows.Forms.ColumnHeader detDocDeposito;
        private System.Windows.Forms.SplitContainer spContEstorno;
        private System.Windows.Forms.SplitContainer spContEstRemDoc;
        private System.Windows.Forms.Button btEstorno;
        private System.Windows.Forms.Button btnEstonoErro;
        private System.Windows.Forms.Label label7;
        private NBIISNET.ListViewBase listViewEstornoResumo;
        private System.Windows.Forms.ColumnHeader colZProcess;
        private System.Windows.Forms.ColumnHeader colZEstorno;
        private System.Windows.Forms.ColumnHeader colEstadoEstr;
        private System.Windows.Forms.ColumnHeader colTpRemessa;
        private System.Windows.Forms.ColumnHeader colQtEstorno;
        private System.Windows.Forms.ColumnHeader colQtDocs;
        private System.Windows.Forms.ColumnHeader colMontante;
        private System.Windows.Forms.ColumnHeader colENVM;
        private System.Windows.Forms.Label lblCountRemessasEstornos;
        private NBIISNET.ListViewBase listViewRemessaEstorno;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.ColumnHeader columnHeader23;
        private System.Windows.Forms.ColumnHeader columnHeader24;
        private System.Windows.Forms.ColumnHeader columnHeader25;
        private System.Windows.Forms.ColumnHeader columnHeader26;
        private System.Windows.Forms.Label lblCountDocumentosEstornos;
        private NBIISNET.ListViewBase listViewDocumentoEstorno;
        private System.Windows.Forms.ColumnHeader colEstDocId;
        private System.Windows.Forms.ColumnHeader colEstZIB;
        private System.Windows.Forms.ColumnHeader colEstNConta;
        private System.Windows.Forms.ColumnHeader colEstNCheque;
        private System.Windows.Forms.ColumnHeader colEstMontante;
        private System.Windows.Forms.ColumnHeader colEstTpDoc;
        private System.Windows.Forms.ColumnHeader colEstEstDoc;
        private System.Windows.Forms.ColumnHeader colEstNIB;
        private System.Windows.Forms.ColumnHeader colEstRefarq;
        private System.Windows.Forms.ColumnHeader colEstNSeq;
        private System.Windows.Forms.ColumnHeader colEstChvH;
        private System.Windows.Forms.ColumnHeader colEstIndex;
        private System.Windows.Forms.ColumnHeader colEstMaquina;
        private System.Windows.Forms.ColumnHeader colEstBalcaoTom;
        private System.Windows.Forms.ColumnHeader colEstChvHext;
        private System.Windows.Forms.ColumnHeader colEstTipo;
        private System.Windows.Forms.ColumnHeader colEstTimer;
        private System.Windows.Forms.ColumnHeader colEstZRemessa;
        private System.Windows.Forms.ColumnHeader colEstRemID;
        private System.Windows.Forms.ColumnHeader colEstTranId;
        private System.Windows.Forms.ColumnHeader colEstBalcaoDesb;
        private System.Windows.Forms.ColumnHeader colEstRemNum;
        private System.Windows.Forms.ColumnHeader colEstEstTran;
        private System.Windows.Forms.ColumnHeader colEstTranNum;
        private System.Windows.Forms.ColumnHeader colEstDocErro;
        private System.Windows.Forms.ColumnHeader colEstDep;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        
    }
}
