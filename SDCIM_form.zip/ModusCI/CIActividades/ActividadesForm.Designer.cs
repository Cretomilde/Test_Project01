﻿namespace CIActividades
{
    partial class ActividadesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);

            m_oMenuInterface.actividadesEnable(true);

        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ActividadesForm));
            this.m_ctrldtFim = new System.Windows.Forms.DateTimePicker();
            this.m_ctrldtInicio = new System.Windows.Forms.DateTimePicker();
            this.m_btRefreshRemessas = new System.Windows.Forms.Button();
            this.contextMenuStripRemessa = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuMudarEstado = new System.Windows.Forms.ToolStripMenuItem();
            this.verDocumentosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verTranchesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultaRemessasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripDetalheDoc = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItemMudar = new System.Windows.Forms.ToolStripMenuItem();
            this.verImagemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultaDocumentosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripRemessasResumo = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.verRemessasDetalheToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btTranches = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonAbertas = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonFechados = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonEspMaquinas = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonProcessamento = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonProcessado = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonEnviada = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonENVM = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonErro = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonRefresh = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.m_toolStripButtonShowResumo = new System.Windows.Forms.ToolStripButton();
            this.m_toolStripButtonShowDocs = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonExitJanela = new System.Windows.Forms.ToolStripButton();
            this.textBoxFiltroNRemessa = new System.Windows.Forms.TextBox();
            this.textBoxFiltroBalcao = new System.Windows.Forms.TextBox();
            this.textBoxFiltroReminID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.m_groupBoxRemessas = new System.Windows.Forms.GroupBox();
            this.labelCountRem = new System.Windows.Forms.Label();
            this.labelCountDocs = new System.Windows.Forms.Label();
            this.m_splitContainerMain = new System.Windows.Forms.SplitContainer();
            this.listViewResumoTranches = new NBIISNET.ListViewBase();
            this.resTranColDataProc = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.resTranColData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.resTranColRemEstado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.resTranColTranEstado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.resTranColTranches = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.resTranColTranQtDocs = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.resTranColTranMTDocs = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewResumoRemessas = new NBIISNET.ListViewBase();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.m_splitContainerRemDocs = new System.Windows.Forms.SplitContainer();
            this.m_splitContainerRemessaTranche = new System.Windows.Forms.SplitContainer();
            this.listViewDetalhesRemessa = new NBIISNET.ListViewBase();
            this.colRemID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemTimer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTimerEnviada = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemPais = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemBanco = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemBalcao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemNumero = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemStat = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemChaveH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemChaveHExt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemCGDError = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemQT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemMT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemErro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRemMaquina = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewDetalhesTranche = new NBIISNET.ListViewBase();
            this.colTransRemID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransTimer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransNumero = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransEstado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransQt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransMt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransErro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTransChaveWS = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTIBCOEstado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStripTranche = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.contextMenuStripTrancheMudaEstado = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripTrancheVerDocs = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripTrancheVerRemessas = new System.Windows.Forms.ToolStripMenuItem();
            this.labelCountTran = new System.Windows.Forms.Label();
            this.listViewDetalhesDocumentos = new NBIISNET.ListViewBase();
            this.detDocColDocId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocStat = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocNIB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocRefarq = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocNSeq = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColChaveH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocIndex = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocMaquina = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocBaltom = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColChaveHext = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocTipo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocTimer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColReminData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColReminID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColTranoutID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColPais = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColBanco = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColBalcao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColRemNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColTranoutStatId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColTranNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnDocColErro = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.buttonReenviarRemessas = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.contextMenuStripRemessa.SuspendLayout();
            this.contextMenuStripDetalheDoc.SuspendLayout();
            this.contextMenuStripRemessasResumo.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.m_groupBoxRemessas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.m_splitContainerMain)).BeginInit();
            this.m_splitContainerMain.Panel1.SuspendLayout();
            this.m_splitContainerMain.Panel2.SuspendLayout();
            this.m_splitContainerMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.m_splitContainerRemDocs)).BeginInit();
            this.m_splitContainerRemDocs.Panel1.SuspendLayout();
            this.m_splitContainerRemDocs.Panel2.SuspendLayout();
            this.m_splitContainerRemDocs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.m_splitContainerRemessaTranche)).BeginInit();
            this.m_splitContainerRemessaTranche.Panel1.SuspendLayout();
            this.m_splitContainerRemessaTranche.Panel2.SuspendLayout();
            this.m_splitContainerRemessaTranche.SuspendLayout();
            this.contextMenuStripTranche.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // m_ctrldtFim
            // 
            this.m_ctrldtFim.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrldtFim.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrldtFim.Location = new System.Drawing.Point(257, 54);
            this.m_ctrldtFim.Name = "m_ctrldtFim";
            this.m_ctrldtFim.Size = new System.Drawing.Size(172, 20);
            this.m_ctrldtFim.TabIndex = 2;
            // 
            // m_ctrldtInicio
            // 
            this.m_ctrldtInicio.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrldtInicio.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrldtInicio.Location = new System.Drawing.Point(41, 53);
            this.m_ctrldtInicio.Name = "m_ctrldtInicio";
            this.m_ctrldtInicio.Size = new System.Drawing.Size(174, 20);
            this.m_ctrldtInicio.TabIndex = 1;
            // 
            // m_btRefreshRemessas
            // 
            this.m_btRefreshRemessas.Location = new System.Drawing.Point(12, 84);
            this.m_btRefreshRemessas.Name = "m_btRefreshRemessas";
            this.m_btRefreshRemessas.Size = new System.Drawing.Size(75, 23);
            this.m_btRefreshRemessas.TabIndex = 4;
            this.m_btRefreshRemessas.Text = "&Remessas";
            this.m_btRefreshRemessas.UseVisualStyleBackColor = true;
            this.m_btRefreshRemessas.Click += new System.EventHandler(this.m_btRefreshRemessas_Click);
            // 
            // contextMenuStripRemessa
            // 
            this.contextMenuStripRemessa.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuMudarEstado,
            this.verDocumentosToolStripMenuItem,
            this.verTranchesToolStripMenuItem,
            this.consultaRemessasToolStripMenuItem});
            this.contextMenuStripRemessa.Name = "contextMenuStripRemTrans";
            this.contextMenuStripRemessa.Size = new System.Drawing.Size(201, 92);
            this.contextMenuStripRemessa.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripRemTrans_Opening);
            // 
            // toolStripMenuMudarEstado
            // 
            this.toolStripMenuMudarEstado.Name = "toolStripMenuMudarEstado";
            this.toolStripMenuMudarEstado.Size = new System.Drawing.Size(200, 22);
            this.toolStripMenuMudarEstado.Text = "Mudar Estado";
            this.toolStripMenuMudarEstado.Click += new System.EventHandler(this.toolStripMenuMudarEstado_Click);
            // 
            // verDocumentosToolStripMenuItem
            // 
            this.verDocumentosToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.verDocumentosToolStripMenuItem.Name = "verDocumentosToolStripMenuItem";
            this.verDocumentosToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.verDocumentosToolStripMenuItem.Text = "Ver Documentos";
            this.verDocumentosToolStripMenuItem.Click += new System.EventHandler(this.verDocumentosToolStripMenuItem_Click);
            // 
            // verTranchesToolStripMenuItem
            // 
            this.verTranchesToolStripMenuItem.Name = "verTranchesToolStripMenuItem";
            this.verTranchesToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.verTranchesToolStripMenuItem.Text = "Ver Tranches";
            this.verTranchesToolStripMenuItem.Click += new System.EventHandler(this.verTranchesToolStripMenuItem_Click);
            // 
            // consultaRemessasToolStripMenuItem
            // 
            this.consultaRemessasToolStripMenuItem.Name = "consultaRemessasToolStripMenuItem";
            this.consultaRemessasToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.consultaRemessasToolStripMenuItem.Text = "Consulta Remessas SIBS";
            this.consultaRemessasToolStripMenuItem.Click += new System.EventHandler(this.consultaRemessasToolStripMenuItem_Click);
            // 
            // contextMenuStripDetalheDoc
            // 
            this.contextMenuStripDetalheDoc.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemMudar,
            this.verImagemToolStripMenuItem,
            this.consultaDocumentosToolStripMenuItem});
            this.contextMenuStripDetalheDoc.Name = "contextMenuStripDetalheDoc";
            this.contextMenuStripDetalheDoc.Size = new System.Drawing.Size(216, 70);
            this.contextMenuStripDetalheDoc.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripDetalheDoc_Opening);
            // 
            // toolStripMenuItemMudar
            // 
            this.toolStripMenuItemMudar.Name = "toolStripMenuItemMudar";
            this.toolStripMenuItemMudar.Size = new System.Drawing.Size(215, 22);
            this.toolStripMenuItemMudar.Text = "Mudar Estado";
            this.toolStripMenuItemMudar.Click += new System.EventHandler(this.toolStripMenuItemMudar_Click);
            // 
            // verImagemToolStripMenuItem
            // 
            this.verImagemToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.verImagemToolStripMenuItem.Name = "verImagemToolStripMenuItem";
            this.verImagemToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.verImagemToolStripMenuItem.Text = "Ver Imagem";
            this.verImagemToolStripMenuItem.Click += new System.EventHandler(this.verImagemToolStripMenuItem_Click);
            // 
            // consultaDocumentosToolStripMenuItem
            // 
            this.consultaDocumentosToolStripMenuItem.Name = "consultaDocumentosToolStripMenuItem";
            this.consultaDocumentosToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.consultaDocumentosToolStripMenuItem.Text = "consulta Documentos SIBS";
            this.consultaDocumentosToolStripMenuItem.Click += new System.EventHandler(this.consultaDocumentosToolStripMenuItem_Click);
            // 
            // contextMenuStripRemessasResumo
            // 
            this.contextMenuStripRemessasResumo.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.verRemessasDetalheToolStripMenuItem});
            this.contextMenuStripRemessasResumo.Name = "contextMenuStripRemessas";
            this.contextMenuStripRemessasResumo.Size = new System.Drawing.Size(155, 26);
            this.contextMenuStripRemessasResumo.Text = "Remessas";
            this.contextMenuStripRemessasResumo.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripRemessas_Opening);
            // 
            // verRemessasDetalheToolStripMenuItem
            // 
            this.verRemessasDetalheToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.verRemessasDetalheToolStripMenuItem.Name = "verRemessasDetalheToolStripMenuItem";
            this.verRemessasDetalheToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.verRemessasDetalheToolStripMenuItem.Text = "Ver Remessas";
            this.verRemessasDetalheToolStripMenuItem.Click += new System.EventHandler(this.verRemessasDetalheToolStripMenuItem_Click_1);
            // 
            // btTranches
            // 
            this.btTranches.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btTranches.Location = new System.Drawing.Point(482, 84);
            this.btTranches.Name = "btTranches";
            this.btTranches.Size = new System.Drawing.Size(75, 23);
            this.btTranches.TabIndex = 15;
            this.btTranches.Text = "&Tranches";
            this.btTranches.UseVisualStyleBackColor = true;
            this.btTranches.Click += new System.EventHandler(this.btTranches_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonAbertas,
            this.toolStripButtonFechados,
            this.toolStripButtonEspMaquinas,
            this.toolStripButtonProcessamento,
            this.toolStripButtonProcessado,
            this.toolStripButtonEnviada,
            this.toolStripButtonENVM,
            this.toolStripSeparator5,
            this.toolStripButtonErro,
            this.toolStripSeparator1,
            this.toolStripButtonRefresh,
            this.toolStripSeparator2,
            this.m_toolStripButtonShowResumo,
            this.m_toolStripButtonShowDocs,
            this.toolStripSeparator3,
            this.toolStripButtonExitJanela});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0);
            this.toolStrip1.Size = new System.Drawing.Size(940, 39);
            this.toolStrip1.TabIndex = 23;
            this.toolStrip1.Text = "toolStripActividades";
            // 
            // toolStripButtonAbertas
            // 
            this.toolStripButtonAbertas.CheckOnClick = true;
            this.toolStripButtonAbertas.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonAbertas.Image = global::CIActividades.Properties.Resources.Abrir;
            this.toolStripButtonAbertas.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAbertas.Name = "toolStripButtonAbertas";
            this.toolStripButtonAbertas.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonAbertas.ToolTipText = "Abertas";
            // 
            // toolStripButtonFechados
            // 
            this.toolStripButtonFechados.CheckOnClick = true;
            this.toolStripButtonFechados.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonFechados.Image = global::CIActividades.Properties.Resources.LOCKUP;
            this.toolStripButtonFechados.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonFechados.Margin = new System.Windows.Forms.Padding(10, 1, 10, 2);
            this.toolStripButtonFechados.Name = "toolStripButtonFechados";
            this.toolStripButtonFechados.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonFechados.Text = "toolStripButton2";
            this.toolStripButtonFechados.ToolTipText = "Fechados";
            // 
            // toolStripButtonEspMaquinas
            // 
            this.toolStripButtonEspMaquinas.CheckOnClick = true;
            this.toolStripButtonEspMaquinas.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonEspMaquinas.Image = global::CIActividades.Properties.Resources.Maquina;
            this.toolStripButtonEspMaquinas.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonEspMaquinas.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonEspMaquinas.Name = "toolStripButtonEspMaquinas";
            this.toolStripButtonEspMaquinas.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonEspMaquinas.Text = "toolStripButton3";
            this.toolStripButtonEspMaquinas.ToolTipText = "Espera de Maquinas";
            // 
            // toolStripButtonProcessamento
            // 
            this.toolStripButtonProcessamento.CheckOnClick = true;
            this.toolStripButtonProcessamento.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonProcessamento.Image = global::CIActividades.Properties.Resources.Par;
            this.toolStripButtonProcessamento.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonProcessamento.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonProcessamento.Name = "toolStripButtonProcessamento";
            this.toolStripButtonProcessamento.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonProcessamento.Text = "toolStripButton4";
            this.toolStripButtonProcessamento.ToolTipText = "Em Processamento";
            // 
            // toolStripButtonProcessado
            // 
            this.toolStripButtonProcessado.CheckOnClick = true;
            this.toolStripButtonProcessado.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonProcessado.Image = global::CIActividades.Properties.Resources.OK;
            this.toolStripButtonProcessado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonProcessado.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonProcessado.Name = "toolStripButtonProcessado";
            this.toolStripButtonProcessado.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonProcessado.Text = "toolStripButton5";
            this.toolStripButtonProcessado.ToolTipText = "Processado";
            // 
            // toolStripButtonEnviada
            // 
            this.toolStripButtonEnviada.CheckOnClick = true;
            this.toolStripButtonEnviada.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonEnviada.Image = global::CIActividades.Properties.Resources.Transmissao;
            this.toolStripButtonEnviada.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonEnviada.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonEnviada.Name = "toolStripButtonEnviada";
            this.toolStripButtonEnviada.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonEnviada.Text = "toolStripButton8";
            this.toolStripButtonEnviada.ToolTipText = "Enviada";
            // 
            // toolStripButtonENVM
            // 
            this.toolStripButtonENVM.CheckOnClick = true;
            this.toolStripButtonENVM.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonENVM.Image = global::CIActividades.Properties.Resources.ENVM_Status;
            this.toolStripButtonENVM.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonENVM.Name = "toolStripButtonENVM";
            this.toolStripButtonENVM.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonENVM.Text = "Ficheiro ENVM";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButtonErro
            // 
            this.toolStripButtonErro.CheckOnClick = true;
            this.toolStripButtonErro.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonErro.Image = global::CIActividades.Properties.Resources.Erro;
            this.toolStripButtonErro.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonErro.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonErro.Name = "toolStripButtonErro";
            this.toolStripButtonErro.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonErro.Text = "toolStripButton6";
            this.toolStripButtonErro.ToolTipText = "Erro";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButtonRefresh
            // 
            this.toolStripButtonRefresh.AutoSize = false;
            this.toolStripButtonRefresh.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonRefresh.Image = global::CIActividades.Properties.Resources.Refresh;
            this.toolStripButtonRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRefresh.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonRefresh.Name = "toolStripButtonRefresh";
            this.toolStripButtonRefresh.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonRefresh.Text = "toolStripButton7";
            this.toolStripButtonRefresh.ToolTipText = "Refresh";
            this.toolStripButtonRefresh.Click += new System.EventHandler(this.toolStripButtonRefresh_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // m_toolStripButtonShowResumo
            // 
            this.m_toolStripButtonShowResumo.Checked = true;
            this.m_toolStripButtonShowResumo.CheckOnClick = true;
            this.m_toolStripButtonShowResumo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.m_toolStripButtonShowResumo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.m_toolStripButtonShowResumo.Image = ((System.Drawing.Image)(resources.GetObject("m_toolStripButtonShowResumo.Image")));
            this.m_toolStripButtonShowResumo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.m_toolStripButtonShowResumo.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.m_toolStripButtonShowResumo.Name = "m_toolStripButtonShowResumo";
            this.m_toolStripButtonShowResumo.Size = new System.Drawing.Size(36, 36);
            this.m_toolStripButtonShowResumo.ToolTipText = "Mostra\\Esconder Resumos";
            this.m_toolStripButtonShowResumo.Click += new System.EventHandler(this.m_toolStripButtonShowResumo_Click);
            // 
            // m_toolStripButtonShowDocs
            // 
            this.m_toolStripButtonShowDocs.CheckOnClick = true;
            this.m_toolStripButtonShowDocs.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.m_toolStripButtonShowDocs.Image = ((System.Drawing.Image)(resources.GetObject("m_toolStripButtonShowDocs.Image")));
            this.m_toolStripButtonShowDocs.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.m_toolStripButtonShowDocs.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.m_toolStripButtonShowDocs.Name = "m_toolStripButtonShowDocs";
            this.m_toolStripButtonShowDocs.Size = new System.Drawing.Size(36, 36);
            this.m_toolStripButtonShowDocs.ToolTipText = "Mostrar\\Esconde Documentos";
            this.m_toolStripButtonShowDocs.Click += new System.EventHandler(this.m_toolStripButtonShowDocs_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButtonExitJanela
            // 
            this.toolStripButtonExitJanela.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonExitJanela.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonExitJanela.Image")));
            this.toolStripButtonExitJanela.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonExitJanela.Name = "toolStripButtonExitJanela";
            this.toolStripButtonExitJanela.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonExitJanela.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // textBoxFiltroNRemessa
            // 
            this.textBoxFiltroNRemessa.Location = new System.Drawing.Point(79, 33);
            this.textBoxFiltroNRemessa.MaxLength = 7;
            this.textBoxFiltroNRemessa.Name = "textBoxFiltroNRemessa";
            this.textBoxFiltroNRemessa.Size = new System.Drawing.Size(53, 20);
            this.textBoxFiltroNRemessa.TabIndex = 4;
            // 
            // textBoxFiltroBalcao
            // 
            this.textBoxFiltroBalcao.Location = new System.Drawing.Point(36, 33);
            this.textBoxFiltroBalcao.MaxLength = 4;
            this.textBoxFiltroBalcao.Name = "textBoxFiltroBalcao";
            this.textBoxFiltroBalcao.Size = new System.Drawing.Size(37, 20);
            this.textBoxFiltroBalcao.TabIndex = 3;
            // 
            // textBoxFiltroReminID
            // 
            this.textBoxFiltroReminID.BackColor = System.Drawing.Color.Yellow;
            this.textBoxFiltroReminID.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxFiltroReminID.Location = new System.Drawing.Point(138, 33);
            this.textBoxFiltroReminID.Name = "textBoxFiltroReminID";
            this.textBoxFiltroReminID.Size = new System.Drawing.Size(62, 20);
            this.textBoxFiltroReminID.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 27;
            this.label1.Text = "Balcão";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(76, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "Numero";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(135, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 13);
            this.label3.TabIndex = 29;
            this.label3.Text = "ID";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(219, 30);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 30;
            this.button1.Text = "Pesquisa";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // m_groupBoxRemessas
            // 
            this.m_groupBoxRemessas.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.m_groupBoxRemessas.Controls.Add(this.textBoxFiltroNRemessa);
            this.m_groupBoxRemessas.Controls.Add(this.textBoxFiltroReminID);
            this.m_groupBoxRemessas.Controls.Add(this.label3);
            this.m_groupBoxRemessas.Controls.Add(this.button1);
            this.m_groupBoxRemessas.Controls.Add(this.textBoxFiltroBalcao);
            this.m_groupBoxRemessas.Controls.Add(this.label1);
            this.m_groupBoxRemessas.Controls.Add(this.label2);
            this.m_groupBoxRemessas.Location = new System.Drawing.Point(612, 42);
            this.m_groupBoxRemessas.Name = "m_groupBoxRemessas";
            this.m_groupBoxRemessas.Size = new System.Drawing.Size(316, 65);
            this.m_groupBoxRemessas.TabIndex = 31;
            this.m_groupBoxRemessas.TabStop = false;
            this.m_groupBoxRemessas.Text = "Pesquisa de Remessas";
            // 
            // labelCountRem
            // 
            this.labelCountRem.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.labelCountRem.AutoSize = true;
            this.labelCountRem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountRem.Location = new System.Drawing.Point(3, 0);
            this.labelCountRem.Name = "labelCountRem";
            this.labelCountRem.Size = new System.Drawing.Size(64, 13);
            this.labelCountRem.TabIndex = 32;
            this.labelCountRem.Text = "Remessas";
            // 
            // labelCountDocs
            // 
            this.labelCountDocs.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.labelCountDocs.AutoSize = true;
            this.labelCountDocs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountDocs.Location = new System.Drawing.Point(3, 0);
            this.labelCountDocs.Name = "labelCountDocs";
            this.labelCountDocs.Size = new System.Drawing.Size(77, 13);
            this.labelCountDocs.TabIndex = 33;
            this.labelCountDocs.Text = "Documentos";
            // 
            // m_splitContainerMain
            // 
            this.m_splitContainerMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_splitContainerMain.Location = new System.Drawing.Point(12, 113);
            this.m_splitContainerMain.Name = "m_splitContainerMain";
            this.m_splitContainerMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // m_splitContainerMain.Panel1
            // 
            this.m_splitContainerMain.Panel1.Controls.Add(this.listViewResumoTranches);
            this.m_splitContainerMain.Panel1.Controls.Add(this.listViewResumoRemessas);
            // 
            // m_splitContainerMain.Panel2
            // 
            this.m_splitContainerMain.Panel2.Controls.Add(this.m_splitContainerRemDocs);
            this.m_splitContainerMain.Size = new System.Drawing.Size(919, 487);
            this.m_splitContainerMain.SplitterDistance = 191;
            this.m_splitContainerMain.TabIndex = 34;
            // 
            // listViewResumoTranches
            // 
            this.listViewResumoTranches.AllowColumnReorder = true;
            this.listViewResumoTranches.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewResumoTranches.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.resTranColDataProc,
            this.resTranColData,
            this.resTranColRemEstado,
            this.resTranColTranEstado,
            this.resTranColTranches,
            this.resTranColTranQtDocs,
            this.resTranColTranMTDocs});
            this.listViewResumoTranches.EnableExportar = true;
            this.listViewResumoTranches.FullRowSelect = true;
            this.listViewResumoTranches.GridLines = true;
            this.listViewResumoTranches.HideSelection = false;
            this.listViewResumoTranches.Location = new System.Drawing.Point(470, 3);
            this.listViewResumoTranches.Name = "listViewResumoTranches";
            this.listViewResumoTranches.Size = new System.Drawing.Size(446, 187);
            this.listViewResumoTranches.TabIndex = 5;
            this.listViewResumoTranches.TabStop = false;
            this.listViewResumoTranches.UseCompatibleStateImageBehavior = false;
            this.listViewResumoTranches.View = System.Windows.Forms.View.Details;
            this.listViewResumoTranches.SelectedIndexChanged += new System.EventHandler(this.listViewResumoTranches_SelectedIndexChanged);
            // 
            // resTranColDataProc
            // 
            this.resTranColDataProc.Text = "Process.";
            this.resTranColDataProc.Width = 66;
            // 
            // resTranColData
            // 
            this.resTranColData.Text = "Remessa";
            this.resTranColData.Width = 66;
            // 
            // resTranColRemEstado
            // 
            this.resTranColRemEstado.Text = "Estado Remessas";
            this.resTranColRemEstado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.resTranColRemEstado.Width = 100;
            // 
            // resTranColTranEstado
            // 
            this.resTranColTranEstado.Text = "Estado Tranches";
            this.resTranColTranEstado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.resTranColTranEstado.Width = 100;
            // 
            // resTranColTranches
            // 
            this.resTranColTranches.Text = "#Trans";
            this.resTranColTranches.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.resTranColTranches.Width = 50;
            // 
            // resTranColTranQtDocs
            // 
            this.resTranColTranQtDocs.Text = "#Docs";
            this.resTranColTranQtDocs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.resTranColTranQtDocs.Width = 50;
            // 
            // resTranColTranMTDocs
            // 
            this.resTranColTranMTDocs.Text = "Montante";
            this.resTranColTranMTDocs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.resTranColTranMTDocs.Width = 100;
            // 
            // listViewResumoRemessas
            // 
            this.listViewResumoRemessas.AllowColumnReorder = true;
            this.listViewResumoRemessas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewResumoRemessas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader15,
            this.columnHeader21,
            this.columnHeader18,
            this.columnHeader20,
            this.columnHeader16,
            this.columnHeader2});
            this.listViewResumoRemessas.ContextMenuStrip = this.contextMenuStripRemessasResumo;
            this.listViewResumoRemessas.EnableExportar = true;
            this.listViewResumoRemessas.FullRowSelect = true;
            this.listViewResumoRemessas.GridLines = true;
            this.listViewResumoRemessas.HideSelection = false;
            this.listViewResumoRemessas.Location = new System.Drawing.Point(3, 3);
            this.listViewResumoRemessas.Name = "listViewResumoRemessas";
            this.listViewResumoRemessas.Size = new System.Drawing.Size(461, 187);
            this.listViewResumoRemessas.TabIndex = 8;
            this.listViewResumoRemessas.TabStop = false;
            this.listViewResumoRemessas.UseCompatibleStateImageBehavior = false;
            this.listViewResumoRemessas.View = System.Windows.Forms.View.Details;
            this.listViewResumoRemessas.SelectedIndexChanged += new System.EventHandler(this.listViewRemessaResumo1_SelectedIndexChanged);
            this.listViewResumoRemessas.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listViewResumoRemessas_MouseDoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Process.";
            this.columnHeader1.Width = 66;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Remessa";
            this.columnHeader15.Width = 66;
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "Estado Remessas";
            this.columnHeader21.Width = 130;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "#Rems";
            this.columnHeader18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader18.Width = 50;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "#Docs";
            this.columnHeader20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader20.Width = 50;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Montante";
            this.columnHeader16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader16.Width = 93;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "ENVM";
            // 
            // m_splitContainerRemDocs
            // 
            this.m_splitContainerRemDocs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_splitContainerRemDocs.Location = new System.Drawing.Point(0, 3);
            this.m_splitContainerRemDocs.Name = "m_splitContainerRemDocs";
            this.m_splitContainerRemDocs.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // m_splitContainerRemDocs.Panel1
            // 
            this.m_splitContainerRemDocs.Panel1.Controls.Add(this.m_splitContainerRemessaTranche);
            // 
            // m_splitContainerRemDocs.Panel2
            // 
            this.m_splitContainerRemDocs.Panel2.Controls.Add(this.listViewDetalhesDocumentos);
            this.m_splitContainerRemDocs.Panel2.Controls.Add(this.labelCountDocs);
            this.m_splitContainerRemDocs.Size = new System.Drawing.Size(916, 289);
            this.m_splitContainerRemDocs.SplitterDistance = 162;
            this.m_splitContainerRemDocs.TabIndex = 34;
            // 
            // m_splitContainerRemessaTranche
            // 
            this.m_splitContainerRemessaTranche.Dock = System.Windows.Forms.DockStyle.Fill;
            this.m_splitContainerRemessaTranche.Location = new System.Drawing.Point(0, 0);
            this.m_splitContainerRemessaTranche.Name = "m_splitContainerRemessaTranche";
            // 
            // m_splitContainerRemessaTranche.Panel1
            // 
            this.m_splitContainerRemessaTranche.Panel1.Controls.Add(this.labelCountRem);
            this.m_splitContainerRemessaTranche.Panel1.Controls.Add(this.listViewDetalhesRemessa);
            // 
            // m_splitContainerRemessaTranche.Panel2
            // 
            this.m_splitContainerRemessaTranche.Panel2.Controls.Add(this.listViewDetalhesTranche);
            this.m_splitContainerRemessaTranche.Panel2.Controls.Add(this.labelCountTran);
            this.m_splitContainerRemessaTranche.Size = new System.Drawing.Size(916, 162);
            this.m_splitContainerRemessaTranche.SplitterDistance = 467;
            this.m_splitContainerRemessaTranche.TabIndex = 33;
            // 
            // listViewDetalhesRemessa
            // 
            this.listViewDetalhesRemessa.AllowColumnReorder = true;
            this.listViewDetalhesRemessa.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewDetalhesRemessa.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colRemID,
            this.colRemData,
            this.colRemTimer,
            this.colTimerEnviada,
            this.colRemPais,
            this.colRemBanco,
            this.colRemBalcao,
            this.colRemNumero,
            this.colRemStat,
            this.colRemChaveH,
            this.colRemChaveHExt,
            this.colRemCGDError,
            this.colRemQT,
            this.colRemMT,
            this.colRemErro,
            this.colRemMaquina});
            this.listViewDetalhesRemessa.ContextMenuStrip = this.contextMenuStripRemessa;
            this.listViewDetalhesRemessa.EnableExportar = true;
            this.listViewDetalhesRemessa.FullRowSelect = true;
            this.listViewDetalhesRemessa.GridLines = true;
            this.listViewDetalhesRemessa.HideSelection = false;
            this.listViewDetalhesRemessa.Location = new System.Drawing.Point(3, 16);
            this.listViewDetalhesRemessa.Name = "listViewDetalhesRemessa";
            this.listViewDetalhesRemessa.Size = new System.Drawing.Size(461, 143);
            this.listViewDetalhesRemessa.TabIndex = 6;
            this.listViewDetalhesRemessa.TabStop = false;
            this.listViewDetalhesRemessa.UseCompatibleStateImageBehavior = false;
            this.listViewDetalhesRemessa.View = System.Windows.Forms.View.Details;
            this.listViewDetalhesRemessa.DoubleClick += new System.EventHandler(this.listViewDetalhesRemessas_DoubleClick);
            // 
            // colRemID
            // 
            this.colRemID.Text = "Rem ID";
            this.colRemID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colRemID.Width = 54;
            // 
            // colRemData
            // 
            this.colRemData.Text = "RemData";
            this.colRemData.Width = 70;
            // 
            // colRemTimer
            // 
            this.colRemTimer.Text = "Timer";
            this.colRemTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colRemTimer.Width = 120;
            // 
            // colTimerEnviada
            // 
            this.colTimerEnviada.Text = "Enviada";
            this.colTimerEnviada.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colTimerEnviada.Width = 120;
            // 
            // colRemPais
            // 
            this.colRemPais.Text = "Pais";
            this.colRemPais.Width = 0;
            // 
            // colRemBanco
            // 
            this.colRemBanco.Text = "Banco";
            this.colRemBanco.Width = 0;
            // 
            // colRemBalcao
            // 
            this.colRemBalcao.Text = "Balcao";
            this.colRemBalcao.Width = 120;
            // 
            // colRemNumero
            // 
            this.colRemNumero.Text = "Numero";
            this.colRemNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colRemStat
            // 
            this.colRemStat.Text = "Estado";
            this.colRemStat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colRemStat.Width = 107;
            // 
            // colRemChaveH
            // 
            this.colRemChaveH.Text = "ChaveH";
            // 
            // colRemChaveHExt
            // 
            this.colRemChaveHExt.Text = "Chave H Ext";
            this.colRemChaveHExt.Width = 0;
            // 
            // colRemCGDError
            // 
            this.colRemCGDError.Text = "CGD Error";
            // 
            // colRemQT
            // 
            this.colRemQT.Text = "Quant.";
            this.colRemQT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // colRemMT
            // 
            this.colRemMT.Text = "Montante";
            this.colRemMT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colRemMT.Width = 94;
            // 
            // colRemErro
            // 
            this.colRemErro.Text = "Erro";
            this.colRemErro.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colRemErro.Width = 283;
            // 
            // colRemMaquina
            // 
            this.colRemMaquina.Text = "Maquina";
            // 
            // listViewDetalhesTranche
            // 
            this.listViewDetalhesTranche.AllowColumnReorder = true;
            this.listViewDetalhesTranche.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewDetalhesTranche.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colTransRemID,
            this.colTransID,
            this.colTransTimer,
            this.colTransNumero,
            this.colTransEstado,
            this.colTransQt,
            this.colTransMt,
            this.colTransErro,
            this.colTransChaveWS,
            this.colTIBCOEstado});
            this.listViewDetalhesTranche.ContextMenuStrip = this.contextMenuStripTranche;
            this.listViewDetalhesTranche.EnableExportar = true;
            this.listViewDetalhesTranche.FullRowSelect = true;
            this.listViewDetalhesTranche.GridLines = true;
            this.listViewDetalhesTranche.HideSelection = false;
            this.listViewDetalhesTranche.Location = new System.Drawing.Point(6, 16);
            this.listViewDetalhesTranche.Name = "listViewDetalhesTranche";
            this.listViewDetalhesTranche.Size = new System.Drawing.Size(439, 143);
            this.listViewDetalhesTranche.TabIndex = 33;
            this.listViewDetalhesTranche.TabStop = false;
            this.listViewDetalhesTranche.UseCompatibleStateImageBehavior = false;
            this.listViewDetalhesTranche.View = System.Windows.Forms.View.Details;
            this.listViewDetalhesTranche.DoubleClick += new System.EventHandler(this.listViewDetalhesTranche_DoubleClick);
            // 
            // colTransRemID
            // 
            this.colTransRemID.Text = "Rem ID";
            this.colTransRemID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colTransRemID.Width = 54;
            // 
            // colTransID
            // 
            this.colTransID.Text = "Trans ID";
            this.colTransID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colTransID.Width = 131;
            // 
            // colTransTimer
            // 
            this.colTransTimer.Text = "Timer";
            this.colTransTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colTransNumero
            // 
            this.colTransNumero.Text = "Numero";
            this.colTransNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colTransNumero.Width = 107;
            // 
            // colTransEstado
            // 
            this.colTransEstado.Text = "Estado";
            this.colTransEstado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // colTransQt
            // 
            this.colTransQt.Text = "Quantidade";
            this.colTransQt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colTransQt.Width = 94;
            // 
            // colTransMt
            // 
            this.colTransMt.Text = "Montante";
            this.colTransMt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colTransMt.Width = 283;
            // 
            // colTransErro
            // 
            this.colTransErro.Text = "Erro";
            // 
            // colTransChaveWS
            // 
            this.colTransChaveWS.Text = "ChaveWS";
            // 
            // colTIBCOEstado
            // 
            this.colTIBCOEstado.Text = "TIBCO Estado";
            // 
            // contextMenuStripTranche
            // 
            this.contextMenuStripTranche.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contextMenuStripTrancheMudaEstado,
            this.contextMenuStripTrancheVerDocs,
            this.contextMenuStripTrancheVerRemessas});
            this.contextMenuStripTranche.Name = "contextMenuStripRemTrans";
            this.contextMenuStripTranche.Size = new System.Drawing.Size(168, 70);
            // 
            // contextMenuStripTrancheMudaEstado
            // 
            this.contextMenuStripTrancheMudaEstado.Name = "contextMenuStripTrancheMudaEstado";
            this.contextMenuStripTrancheMudaEstado.Size = new System.Drawing.Size(167, 22);
            this.contextMenuStripTrancheMudaEstado.Text = "Mudar Estado";
            this.contextMenuStripTrancheMudaEstado.Click += new System.EventHandler(this.contextMenuStripTrancheMudaEstado_Click);
            // 
            // contextMenuStripTrancheVerDocs
            // 
            this.contextMenuStripTrancheVerDocs.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contextMenuStripTrancheVerDocs.Name = "contextMenuStripTrancheVerDocs";
            this.contextMenuStripTrancheVerDocs.Size = new System.Drawing.Size(167, 22);
            this.contextMenuStripTrancheVerDocs.Text = "Ver Documentos";
            this.contextMenuStripTrancheVerDocs.Click += new System.EventHandler(this.contextMenuStripTrancheVerDocs_Click);
            // 
            // contextMenuStripTrancheVerRemessas
            // 
            this.contextMenuStripTrancheVerRemessas.Name = "contextMenuStripTrancheVerRemessas";
            this.contextMenuStripTrancheVerRemessas.Size = new System.Drawing.Size(167, 22);
            this.contextMenuStripTrancheVerRemessas.Text = "Ver Remessas";
            this.contextMenuStripTrancheVerRemessas.Click += new System.EventHandler(this.contextMenuStripTrancheVerRemessas_Click);
            // 
            // labelCountTran
            // 
            this.labelCountTran.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.labelCountTran.AutoSize = true;
            this.labelCountTran.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountTran.Location = new System.Drawing.Point(3, 0);
            this.labelCountTran.Name = "labelCountTran";
            this.labelCountTran.Size = new System.Drawing.Size(60, 13);
            this.labelCountTran.TabIndex = 33;
            this.labelCountTran.Text = "Tranches";
            // 
            // listViewDetalhesDocumentos
            // 
            this.listViewDetalhesDocumentos.AllowColumnReorder = true;
            this.listViewDetalhesDocumentos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewDetalhesDocumentos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.detDocColDocId,
            this.detDocColDocZona5,
            this.detDocColDocZona4,
            this.detDocColDocZona3,
            this.detDocColDocZona2,
            this.detDocColDocZona1,
            this.detDocColDocStat,
            this.detDocColDocNIB,
            this.detDocColDocRefarq,
            this.detDocColDocNSeq,
            this.detDocColChaveH,
            this.detDocColDocIndex,
            this.detDocColDocMaquina,
            this.detDocColDocBaltom,
            this.detDocColChaveHext,
            this.detDocColDocTipo,
            this.detDocColDocTimer,
            this.detDocColReminData,
            this.detDocColReminID,
            this.detDocColTranoutID,
            this.detDocColPais,
            this.detDocColBanco,
            this.detDocColBalcao,
            this.detDocColRemNum,
            this.detDocColTranoutStatId,
            this.detDocColTranNum,
            this.columnDocColErro});
            this.listViewDetalhesDocumentos.ContextMenuStrip = this.contextMenuStripDetalheDoc;
            this.listViewDetalhesDocumentos.EnableExportar = true;
            this.listViewDetalhesDocumentos.FullRowSelect = true;
            this.listViewDetalhesDocumentos.GridLines = true;
            this.listViewDetalhesDocumentos.HideSelection = false;
            this.listViewDetalhesDocumentos.Location = new System.Drawing.Point(3, 14);
            this.listViewDetalhesDocumentos.MultiSelect = false;
            this.listViewDetalhesDocumentos.Name = "listViewDetalhesDocumentos";
            this.listViewDetalhesDocumentos.Size = new System.Drawing.Size(913, 106);
            this.listViewDetalhesDocumentos.TabIndex = 7;
            this.listViewDetalhesDocumentos.TabStop = false;
            this.listViewDetalhesDocumentos.UseCompatibleStateImageBehavior = false;
            this.listViewDetalhesDocumentos.View = System.Windows.Forms.View.Details;
            this.listViewDetalhesDocumentos.DoubleClick += new System.EventHandler(this.listViewDetalhesDocumentos_DoubleClick);
            // 
            // detDocColDocId
            // 
            this.detDocColDocId.Text = "Doc ID";
            this.detDocColDocId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // detDocColDocZona5
            // 
            this.detDocColDocZona5.Text = "ZIB";
            this.detDocColDocZona5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocZona5.Width = 100;
            // 
            // detDocColDocZona4
            // 
            this.detDocColDocZona4.Text = "N. Conta";
            this.detDocColDocZona4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocZona4.Width = 100;
            // 
            // detDocColDocZona3
            // 
            this.detDocColDocZona3.Text = "N.Cheque";
            this.detDocColDocZona3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocZona3.Width = 100;
            // 
            // detDocColDocZona2
            // 
            this.detDocColDocZona2.Text = "Montante";
            this.detDocColDocZona2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.detDocColDocZona2.Width = 100;
            // 
            // detDocColDocZona1
            // 
            this.detDocColDocZona1.Text = "Tp";
            this.detDocColDocZona1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocZona1.Width = 90;
            // 
            // detDocColDocStat
            // 
            this.detDocColDocStat.Text = "Estado";
            this.detDocColDocStat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocStat.Width = 80;
            // 
            // detDocColDocNIB
            // 
            this.detDocColDocNIB.Text = "Conta/NIB";
            this.detDocColDocNIB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocNIB.Width = 150;
            // 
            // detDocColDocRefarq
            // 
            this.detDocColDocRefarq.Text = "Refarq";
            this.detDocColDocRefarq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocRefarq.Width = 150;
            // 
            // detDocColDocNSeq
            // 
            this.detDocColDocNSeq.Text = "N Seq";
            this.detDocColDocNSeq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // detDocColChaveH
            // 
            this.detDocColChaveH.Text = "ChaveH";
            this.detDocColChaveH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColChaveH.Width = 350;
            // 
            // detDocColDocIndex
            // 
            this.detDocColDocIndex.Text = "Index";
            this.detDocColDocIndex.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocIndex.Width = 100;
            // 
            // detDocColDocMaquina
            // 
            this.detDocColDocMaquina.Text = "Maquina";
            this.detDocColDocMaquina.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // detDocColDocBaltom
            // 
            this.detDocColDocBaltom.Text = "Balcao Tom";
            this.detDocColDocBaltom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocBaltom.Width = 75;
            // 
            // detDocColChaveHext
            // 
            this.detDocColChaveHext.Text = "ChaveH ext";
            this.detDocColChaveHext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColChaveHext.Width = 200;
            // 
            // detDocColDocTipo
            // 
            this.detDocColDocTipo.Text = "Tipo";
            this.detDocColDocTipo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocTipo.Width = 50;
            // 
            // detDocColDocTimer
            // 
            this.detDocColDocTimer.Text = "Timer";
            this.detDocColDocTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocTimer.Width = 120;
            // 
            // detDocColReminData
            // 
            this.detDocColReminData.Text = "Data Remessa";
            this.detDocColReminData.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColReminData.Width = 100;
            // 
            // detDocColReminID
            // 
            this.detDocColReminID.Text = "Rem ID";
            this.detDocColReminID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // detDocColTranoutID
            // 
            this.detDocColTranoutID.Text = "Tran ID";
            this.detDocColTranoutID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // detDocColPais
            // 
            this.detDocColPais.Text = "País";
            this.detDocColPais.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColPais.Width = 0;
            // 
            // detDocColBanco
            // 
            this.detDocColBanco.Text = "Banco";
            this.detDocColBanco.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColBanco.Width = 0;
            // 
            // detDocColBalcao
            // 
            this.detDocColBalcao.Text = "Balcão";
            this.detDocColBalcao.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // detDocColRemNum
            // 
            this.detDocColRemNum.Text = "Rem Num";
            this.detDocColRemNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColRemNum.Width = 80;
            // 
            // detDocColTranoutStatId
            // 
            this.detDocColTranoutStatId.Text = "Tran Estado";
            this.detDocColTranoutStatId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColTranoutStatId.Width = 80;
            // 
            // detDocColTranNum
            // 
            this.detDocColTranNum.Text = "Tran Num";
            this.detDocColTranNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnDocColErro
            // 
            this.columnDocColErro.Text = "Erro";
            this.columnDocColErro.Width = 256;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 35;
            this.label4.Text = "de:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(237, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 13);
            this.label5.TabIndex = 36;
            this.label5.Text = "a:";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 39);
            // 
            // buttonReenviarRemessas
            // 
            this.buttonReenviarRemessas.Location = new System.Drawing.Point(257, 84);
            this.buttonReenviarRemessas.Name = "buttonReenviarRemessas";
            this.buttonReenviarRemessas.Size = new System.Drawing.Size(172, 23);
            this.buttonReenviarRemessas.TabIndex = 37;
            this.buttonReenviarRemessas.Text = "Reen&viar remessas em erro";
            this.buttonReenviarRemessas.UseVisualStyleBackColor = true;
            this.buttonReenviarRemessas.Click += new System.EventHandler(this.buttonReenviarRemessas_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(631, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 38;
            this.pictureBox1.TabStop = false;
            // 
            // ActividadesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 602);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonReenviarRemessas);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.m_btRefreshRemessas);
            this.Controls.Add(this.m_ctrldtFim);
            this.Controls.Add(this.m_ctrldtInicio);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.btTranches);
            this.Controls.Add(this.m_groupBoxRemessas);
            this.Controls.Add(this.m_splitContainerMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ActividadesForm";
            this.ShowInTaskbar = false;
            this.Text = "Actividades";
            this.Load += new System.EventHandler(this.ResumoForm_Load);
            this.contextMenuStripRemessa.ResumeLayout(false);
            this.contextMenuStripDetalheDoc.ResumeLayout(false);
            this.contextMenuStripRemessasResumo.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.m_groupBoxRemessas.ResumeLayout(false);
            this.m_groupBoxRemessas.PerformLayout();
            this.m_splitContainerMain.Panel1.ResumeLayout(false);
            this.m_splitContainerMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.m_splitContainerMain)).EndInit();
            this.m_splitContainerMain.ResumeLayout(false);
            this.m_splitContainerRemDocs.Panel1.ResumeLayout(false);
            this.m_splitContainerRemDocs.Panel2.ResumeLayout(false);
            this.m_splitContainerRemDocs.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.m_splitContainerRemDocs)).EndInit();
            this.m_splitContainerRemDocs.ResumeLayout(false);
            this.m_splitContainerRemessaTranche.Panel1.ResumeLayout(false);
            this.m_splitContainerRemessaTranche.Panel1.PerformLayout();
            this.m_splitContainerRemessaTranche.Panel2.ResumeLayout(false);
            this.m_splitContainerRemessaTranche.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.m_splitContainerRemessaTranche)).EndInit();
            this.m_splitContainerRemessaTranche.ResumeLayout(false);
            this.contextMenuStripTranche.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker m_ctrldtFim;
        private System.Windows.Forms.DateTimePicker m_ctrldtInicio;
        private System.Windows.Forms.Button m_btRefreshRemessas;
        private NBIISNET.ListViewBase listViewResumoTranches;
        private System.Windows.Forms.ColumnHeader resTranColTranQtDocs;
        private System.Windows.Forms.ColumnHeader resTranColTranEstado;
        private System.Windows.Forms.ColumnHeader resTranColTranches;
        private System.Windows.Forms.ColumnHeader resTranColData;
        private NBIISNET.ListViewBase listViewDetalhesRemessa;
        private NBIISNET.ListViewBase listViewDetalhesDocumentos;
        private System.Windows.Forms.ColumnHeader detDocColDocId;
        private System.Windows.Forms.ColumnHeader detDocColDocBaltom;
        private System.Windows.Forms.ColumnHeader detDocColDocTipo;
        private System.Windows.Forms.ColumnHeader detDocColDocZona5;
        private System.Windows.Forms.ColumnHeader detDocColDocNSeq;
        private System.Windows.Forms.ColumnHeader detDocColDocRefarq;
        private System.Windows.Forms.ColumnHeader detDocColDocIndex;
        private NBIISNET.ListViewBase listViewResumoRemessas;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader resTranColTranMTDocs;
        private System.Windows.Forms.Button btTranches;
        private System.Windows.Forms.ColumnHeader detDocColDocZona4;
        private System.Windows.Forms.ColumnHeader detDocColDocZona3;
        private System.Windows.Forms.ColumnHeader detDocColDocZona2;
        private System.Windows.Forms.ColumnHeader detDocColDocZona1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripRemessasResumo;
        private System.Windows.Forms.ToolStripMenuItem verRemessasDetalheToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader colRemID;
        private System.Windows.Forms.ColumnHeader resTranColRemEstado;
        private System.Windows.Forms.ColumnHeader detDocColDocMaquina;
        private System.Windows.Forms.ColumnHeader detDocColChaveH;
        private System.Windows.Forms.ColumnHeader detDocColChaveHext;
        private System.Windows.Forms.ColumnHeader detDocColDocNIB;
        private System.Windows.Forms.ColumnHeader detDocColDocStat;
        private System.Windows.Forms.ColumnHeader detDocColDocTimer;
        private System.Windows.Forms.ColumnHeader detDocColReminData;
        private System.Windows.Forms.ColumnHeader detDocColReminID;
        private System.Windows.Forms.ColumnHeader detDocColTranoutID;
        private System.Windows.Forms.ColumnHeader detDocColPais;
        private System.Windows.Forms.ColumnHeader detDocColBanco;
        private System.Windows.Forms.ColumnHeader detDocColBalcao;
        private System.Windows.Forms.ColumnHeader detDocColRemNum;
        private System.Windows.Forms.ColumnHeader detDocColTranoutStatId;
        private System.Windows.Forms.ColumnHeader detDocColTranNum;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripRemessa;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuMudarEstado;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripDetalheDoc;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemMudar;
        private System.Windows.Forms.ToolStripMenuItem verDocumentosToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonAbertas;
        private System.Windows.Forms.ToolStripButton toolStripButtonFechados;
        private System.Windows.Forms.ToolStripButton toolStripButtonEspMaquinas;
        private System.Windows.Forms.ToolStripButton toolStripButtonProcessamento;
        private System.Windows.Forms.ToolStripButton toolStripButtonProcessado;
        private System.Windows.Forms.ToolStripButton toolStripButtonErro;
        private System.Windows.Forms.ToolStripButton toolStripButtonEnviada;
        private System.Windows.Forms.ToolStripButton toolStripButtonRefresh;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader resTranColDataProc;
        private System.Windows.Forms.ColumnHeader colRemNumero;
        private System.Windows.Forms.ColumnHeader colRemTimer;
        private System.Windows.Forms.ColumnHeader colRemStat;
        private System.Windows.Forms.ColumnHeader colRemQT;
        private System.Windows.Forms.ColumnHeader colRemMT;
        private System.Windows.Forms.ColumnHeader colRemErro;
        private System.Windows.Forms.ColumnHeader columnDocColErro;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.TextBox textBoxFiltroNRemessa;
        private System.Windows.Forms.TextBox textBoxFiltroBalcao;
        private System.Windows.Forms.TextBox textBoxFiltroReminID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripMenuItem verTranchesToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox m_groupBoxRemessas;
        private System.Windows.Forms.Label labelCountRem;
        private System.Windows.Forms.Label labelCountDocs;
        private System.Windows.Forms.ToolStripMenuItem consultaRemessasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultaDocumentosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verImagemToolStripMenuItem;
        private System.Windows.Forms.SplitContainer m_splitContainerMain;
        private System.Windows.Forms.SplitContainer m_splitContainerRemDocs;
        private System.Windows.Forms.ToolStripButton m_toolStripButtonShowDocs;
        private System.Windows.Forms.ToolStripButton m_toolStripButtonShowResumo;
        private System.Windows.Forms.ToolStripButton toolStripButtonExitJanela;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolStripButton toolStripButtonENVM;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ColumnHeader colRemMaquina;
        private System.Windows.Forms.SplitContainer m_splitContainerRemessaTranche;
        private System.Windows.Forms.Label labelCountTran;
        private NBIISNET.ListViewBase listViewDetalhesTranche;
        private System.Windows.Forms.ColumnHeader colTransRemID;
        private System.Windows.Forms.ColumnHeader colTransID;
        private System.Windows.Forms.ColumnHeader colTransTimer;
        private System.Windows.Forms.ColumnHeader colTransNumero;
        private System.Windows.Forms.ColumnHeader colTransEstado;
        private System.Windows.Forms.ColumnHeader colTransQt;
        private System.Windows.Forms.ColumnHeader colTransMt;
        private System.Windows.Forms.ColumnHeader colTransErro;
        private System.Windows.Forms.ColumnHeader colRemPais;
        private System.Windows.Forms.ColumnHeader colRemBanco;
        private System.Windows.Forms.ColumnHeader colRemBalcao;
        private System.Windows.Forms.ColumnHeader colRemChaveH;
        private System.Windows.Forms.ColumnHeader colRemChaveHExt;
        private System.Windows.Forms.ColumnHeader colRemCGDError;
        private System.Windows.Forms.ColumnHeader colTransChaveWS;
        private System.Windows.Forms.ColumnHeader colTIBCOEstado;
        private System.Windows.Forms.ColumnHeader colRemData;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripTranche;
        private System.Windows.Forms.ToolStripMenuItem contextMenuStripTrancheMudaEstado;
        private System.Windows.Forms.ToolStripMenuItem contextMenuStripTrancheVerDocs;
        private System.Windows.Forms.ToolStripMenuItem contextMenuStripTrancheVerRemessas;
        private System.Windows.Forms.ColumnHeader colTimerEnviada;
        private System.Windows.Forms.Button buttonReenviarRemessas;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}