﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace CIActividades
{
    public class PesquisaDocumento : InterfaceDocs
    {

        public string m_sREMIN_ID;
        public DateTime m_dtREMIN_DATA;
        public DateTime m_dtREMPROC_TIMER;
        public string m_sREMIN_BALCAO;
        public string m_sREMESSA_NUMERO;
        public int m_iREMINSTAT_ID;
        public string m_sREMINSTAT_ABR;
        public string m_sREMPROC_TIPOPROD;

        public int m_sDOC_ID;
        public string m_sDOC_ZONA5;
        public string m_sDOC_ZONA4;
        public string m_sDOC_ZONA3;
        public string m_sDOC_ZONA2;
        public decimal m_dDOC_IMPORT;
        public string m_sDOC_ZONA1;
        public string m_sDOC_NIB;
        public string m_sREFARQ;
        public string m_sREFARQ_ORI;
        public string m_sDOC_CHAVEH;

        public string m_sDOC_REAPRESENTADO;
        public string m_sREAPRESENTADO_EFECTUADO;
        public string m_sREAPRESENTADO_ESTADO;
        public string m_sREAPRESENTADO_ERRO;

        public string m_sDOC_ISREAPRESENTADO;

        public string m_sDOC_CANCELADO;
        public string m_sCANCELA_EFECTUADO;
        public string m_sCANCELA_ESTADO;
        public string m_sCANCELA_ERRO;

        public string m_sCANCELA_DESCRICAO;

        /*
         * SDCIM 7
         */
        public String m_sDocOrigemID { get; set; }
        public String m_sDocOrigemDesc { get; set; }


        private void InitVars()
        {
            m_sREMIN_ID = "";
            m_dtREMIN_DATA = DateTime.MinValue;
            m_dtREMPROC_TIMER = DateTime.MinValue;
            m_sREMIN_BALCAO = "";
            m_sREMESSA_NUMERO = "";
            m_iREMINSTAT_ID = -1;
            m_sREMINSTAT_ABR = "";
            m_sREMPROC_TIPOPROD = "";

            m_sDOC_ID = 0;
            m_sDOC_ZONA5 = "";
            m_sDOC_ZONA4 = "";
            m_sDOC_ZONA3 = "";
            m_sDOC_ZONA2 = "";
            m_dDOC_IMPORT = 0;
            m_sDOC_ZONA1 = "";
            m_sDOC_NIB = "";
            m_sREFARQ = "";
            m_sREFARQ_ORI = "";
            m_sDOC_CHAVEH = "";

            m_sDOC_REAPRESENTADO = "";
            m_sREAPRESENTADO_EFECTUADO = "";
            m_sREAPRESENTADO_ESTADO = "";
            m_sREAPRESENTADO_ERRO = "";

            m_sDOC_ISREAPRESENTADO = "";

            m_sDOC_CANCELADO = "";
            m_sCANCELA_EFECTUADO = "";
            m_sCANCELA_ESTADO = "";
            m_sCANCELA_ERRO = "";

            m_sCANCELA_DESCRICAO = "";

            this.m_sDocOrigemDesc = String.Empty;
            this.m_sDocOrigemID = String.Empty;
        }

        public PesquisaDocumento()
        {
            InitVars();
        }

        public PesquisaDocumento(SqlDataReader dr)
        {
            InitVars();

            m_sREMIN_ID = Convert.ToString(dr["REMIN_ID"]);
            m_dtREMIN_DATA = Convert.ToDateTime(dr["REMIN_DATA"]);
            if (dr["REMPROC_TIMER"] == DBNull.Value)
            {

                m_dtREMPROC_TIMER = DateTime.Now;
            }
            else
            {

                m_dtREMPROC_TIMER = Convert.ToDateTime(dr["REMPROC_TIMER"]);
            }
            m_sREMIN_BALCAO = Convert.ToString(dr["REMIN_BALCAO"]);
            m_sREMESSA_NUMERO = Convert.ToString(dr["REMESSA_NUMERO"]);
            m_iREMINSTAT_ID = Convert.ToInt32(dr["REMINSTAT_ID"]);
            m_sREMINSTAT_ABR = Convert.ToString(dr["REMINSTAT_ABR"]);
            m_sREMPROC_TIPOPROD = Convert.ToString(dr["REMPROC_TIPOPROD"]);
            m_sDOC_ID = Convert.ToInt32(dr["DOC_ID"]);
            m_sDOC_ZONA5 = Convert.ToString(dr["DOC_ZONA5"]);
            m_sDOC_ZONA4 = Convert.ToString(dr["DOC_ZONA4"]);
            m_sDOC_ZONA3 = Convert.ToString(dr["DOC_ZONA3"]);
            m_sDOC_ZONA2 = Convert.ToString(dr["DOC_ZONA2"]);
            m_dDOC_IMPORT = Convert.ToDecimal(dr["DOC_ZONA2"]);// / (decimal)100.0;
            m_sDOC_ZONA1 = Convert.ToString(dr["DOC_ZONA1"]);
            m_sDOC_NIB = Convert.ToString(dr["DOC_NIB"]);
            m_sREFARQ = Convert.ToString(dr["REFARQ"]);
            if (dr["REFARQ_ORI"] == DBNull.Value)
            {
                m_sREFARQ_ORI = string.Empty;
            }
            else
            {
                m_sREFARQ_ORI = Convert.ToString(dr["REFARQ_ORI"]);
            }
            m_sDOC_REAPRESENTADO = Convert.ToString(dr["DOC_REAPRESENTADO"]);
            m_sREAPRESENTADO_EFECTUADO = Convert.ToString(dr["REAPRESENTADO_EFECTUADO"]);
            m_sREAPRESENTADO_ESTADO = Convert.ToString(dr["REAPRESENTADO_ESTADO"]);
            m_sREAPRESENTADO_ERRO = Convert.ToString(dr["REAPRESENTADO_ERRO"]);
            m_sDOC_ISREAPRESENTADO = Convert.ToString(dr["DOC_ISREAPRESENTADO"]);
            m_sDOC_CANCELADO = Convert.ToString(dr["DOC_CANCELADO"]);
            m_sCANCELA_EFECTUADO = Convert.ToString(dr["CANCELA_EFECTUADO"]);
            m_sCANCELA_ESTADO = Convert.ToString(dr["CANCELA_ESTADO"]);
            m_sCANCELA_ERRO = Convert.ToString(dr["CANCELA_ERRO"]);
            if (dr["CANCELA_DESCRICAO"] == DBNull.Value)
            {
                m_sCANCELA_DESCRICAO = string.Empty;
            }
            else
            {
                m_sCANCELA_DESCRICAO = Convert.ToString(dr["CANCELA_DESCRICAO"]);
            }
            m_sDOC_CHAVEH = Convert.ToString(dr["DOC_CHAVEH"]);
            this.m_sDocOrigemID = Convert.ToString(dr["DOC_ORIGEM_ID"]);
            this.m_sDocOrigemDesc = Convert.ToString(dr["DOC_ORIGEM_D"]);
        }

        public ListViewItem MakeListViewItem(string sDateFormat, string sDateTimeFormat)
        {
            ListViewItem olvItem = new ListViewItem();
            olvItem.Text = m_sREMIN_ID;
            olvItem.SubItems.Add(m_dtREMIN_DATA.ToString(sDateFormat));
            olvItem.SubItems.Add(m_dtREMPROC_TIMER.ToString(sDateTimeFormat));
            olvItem.SubItems.Add(this.m_sDocOrigemDesc);
            olvItem.SubItems.Add(m_sREMIN_BALCAO.PadLeft(4, '0'));
            olvItem.SubItems.Add(m_sREMESSA_NUMERO.PadLeft(11, '0'));
            olvItem.SubItems.Add(m_iREMINSTAT_ID.ToString() + " " + m_sREMINSTAT_ABR);            
            olvItem.SubItems.Add(m_sDOC_ID.ToString());
            olvItem.SubItems.Add(m_sDOC_ZONA5);
            olvItem.SubItems.Add(m_sDOC_ZONA4);
            olvItem.SubItems.Add(m_sDOC_ZONA3);
            string montanteToInsert = m_dDOC_IMPORT.ToString().Equals("0") ? m_dDOC_IMPORT.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(m_dDOC_IMPORT).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dDOC_IMPORT).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(m_sDOC_ZONA1);
            olvItem.SubItems.Add(m_sDOC_NIB);
            olvItem.SubItems.Add(m_sREFARQ);
            olvItem.SubItems.Add(m_sREFARQ_ORI);
            olvItem.SubItems.Add(m_sDOC_ISREAPRESENTADO);
            olvItem.SubItems.Add(m_sREAPRESENTADO_EFECTUADO + " " + m_sREAPRESENTADO_ESTADO + " " + m_sREAPRESENTADO_ERRO);
            olvItem.SubItems.Add(m_sDOC_REAPRESENTADO);
            olvItem.SubItems.Add(m_sCANCELA_EFECTUADO + " " + m_sCANCELA_ESTADO + " " + m_sCANCELA_DESCRICAO + " " + m_sCANCELA_ERRO);
            olvItem.SubItems.Add(m_sDOC_CANCELADO);
            olvItem.SubItems.Add(m_sDOC_CHAVEH.ToString());
            return olvItem;
        }
        public string getImgFrente(CIConfigGP.CIGlobalParameters oParameters, Int32? origem = null)
        {
            string sFileNameFrente, sWhereClauseFront;
            byte[] aImgF = null;
            if (origem.HasValue && origem.Value == (Int32)RemessaOrigem.Balcao)
            {
                sWhereClauseFront = " WHERE DOCBALCAO_ID = " + m_sDOC_ID + " AND IMGBALCAO_SIDE = 0 AND IMGBALCAO_TYPE = 'JPG'";
                aImgF = (byte[])oParameters.DirectSqlScalar("select IMGBALCAO_IMAGE from dbo.IMAGEM_BALCAO " + sWhereClauseFront);

            }
            else
            {
                sWhereClauseFront = " where DOC_ID= " + m_sDOC_ID + " and IMG_SIDE = 0 and IMG_TYPE= 'JPG'";
                aImgF = (byte[])oParameters.DirectSqlScalar("select IMG_IMAGE from dbo.Imagem " + sWhereClauseFront);
            }
            

            if (aImgF == null)
                return null;

            sFileNameFrente = oParameters.GetTempFileName("IMGPesqFront") + ".jpg";

            WriteImage(aImgF, sFileNameFrente);

            return sFileNameFrente;

        }

        public string getImgBack(CIConfigGP.CIGlobalParameters oParameters, Int32? origem = null)
        {
            string sFileNameBack, sWhereClauseBack;
            byte[] aImgB = null;

            if (origem.HasValue && origem.Value == (Int32)RemessaOrigem.Balcao)
            {
                sWhereClauseBack = " WHERE DOCBALCAO_ID = " + m_sDOC_ID + " AND IMGBALCAO_SIDE = 1 AND IMGBALCAO_TYPE = 'JPG'";
                aImgB = (byte[])oParameters.DirectSqlScalar("select IMGBALCAO_IMAGE from dbo.IMAGEM_BALCAO " + sWhereClauseBack);
            }
            else
            {
                sWhereClauseBack = " where DOC_ID= " + m_sDOC_ID + " and IMG_SIDE = 1 and IMG_TYPE= 'JPG'";
                aImgB = (byte[])oParameters.DirectSqlScalar("select IMG_IMAGE from dbo.Imagem " + sWhereClauseBack);
            }
            

            if (aImgB == null)
                return null;

            sFileNameBack = oParameters.GetTempFileName("IMGPesqBack") + ".jpg";
            WriteImage(aImgB, sFileNameBack);

            return sFileNameBack;
        }

        protected void WriteImage(byte[] aBytes, string sFileName)
        {
            StreamWriter sw = new StreamWriter(sFileName, false);
            BinaryWriter bw = new BinaryWriter(sw.BaseStream);
            bw.Write(aBytes);
            sw.Close();
            bw.Close();
        }

    }
}
