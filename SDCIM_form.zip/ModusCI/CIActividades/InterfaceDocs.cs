﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIActividades
{
    public interface InterfaceDocs
    {
        string getImgFrente(CIConfigGP.CIGlobalParameters oParameters, Int32? origem = null);
        string getImgBack(CIConfigGP.CIGlobalParameters oParameters, Int32? origem = null);
    }
}
