﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace CIActividades
{
    class TranchesResumo
    {
        public DateTime m_dtTRANOUT_DATA;
        public DateTime m_dtREMIN_DATA;
        public int m_iREMINSTAT_ID;
        public string m_sREMINSTAT_ABR;
        public int m_iTRANOUTSTAT_ID;
        public string m_sTRANOUTSTAT_ABR;
        public int m_iTRANOUT_QT;
        public int m_iTRANOUT_QT_DOCS;
        public decimal m_dTRANOUT_MT_DOCS;
        public int m_iLOTEENV_ANOMAL;

        private void InitVars()
        {
            m_dtTRANOUT_DATA = DateTime.MinValue;
            m_dtREMIN_DATA = DateTime.MinValue;
            m_iREMINSTAT_ID = -1;
            m_iTRANOUTSTAT_ID = -1;
            m_sTRANOUTSTAT_ABR = "ND";
            m_iTRANOUT_QT = 0;
            m_iTRANOUT_QT_DOCS = 0;
            m_dTRANOUT_MT_DOCS = 0;
            m_iLOTEENV_ANOMAL = 0;
        }

        public TranchesResumo()
        {
            InitVars();
        }

        public TranchesResumo(SqlDataReader dr)
        {
            InitVars();

            try
            {
                m_dtTRANOUT_DATA = Convert.ToDateTime(dr["TRANOUT_DATA"]);
                m_dtREMIN_DATA = Convert.ToDateTime(dr["REMIN_DATA"]);
                m_iREMINSTAT_ID = Convert.ToInt32(dr["REMINSTAT_ID"]);
                m_sREMINSTAT_ABR = Convert.ToString(dr["REMINSTAT_ABR"]);
                m_iTRANOUTSTAT_ID = Convert.ToInt32(dr["TRANOUTSTAT_ID"]);
                m_sTRANOUTSTAT_ABR = Convert.ToString(dr["TRANOUTSTAT_ABR"]);
                m_iTRANOUT_QT = Convert.ToInt32(dr["TRANOUT_QT"]);
                m_iTRANOUT_QT_DOCS = Convert.ToInt32(dr["TRANOUT_QT_DOCS"]);
                m_dTRANOUT_MT_DOCS = Convert.ToDecimal(dr["TRANOUT_MT_DOCS"]);
                m_iLOTEENV_ANOMAL = Convert.ToInt16(dr["LOTEENV_ANOMAL"]);
            }
            catch
            { 
            }
        }

        public ListViewItem MakeListViewItemResumoTranches(string sDateFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_dtTRANOUT_DATA.ToString(sDateFormat);
            olvItem.SubItems.Add(m_dtREMIN_DATA.ToString(sDateFormat));
            olvItem.SubItems.Add(m_iREMINSTAT_ID + " " + m_sREMINSTAT_ABR);
            olvItem.SubItems.Add(m_iTRANOUTSTAT_ID + " " + m_sTRANOUTSTAT_ABR);
            olvItem.SubItems.Add(m_iTRANOUT_QT.ToString().PadLeft(4, ' '));
            olvItem.SubItems.Add(m_iTRANOUT_QT_DOCS.ToString().PadLeft(6, ' '));
            string montanteToInsert = this.m_dTRANOUT_MT_DOCS.ToString().Equals("0") ? this.m_dTRANOUT_MT_DOCS.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.m_dTRANOUT_MT_DOCS).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dTRANOUT_MT_DOCS).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);

            return olvItem;
        }

    }
}
