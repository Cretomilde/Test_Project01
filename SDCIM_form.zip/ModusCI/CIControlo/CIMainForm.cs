﻿/*
 * $Copyright:$
 * Copyright(c) 2008 Novabase
 * Todos os direitos reservados
 *
 * Este software e fornecido sob licenca e deve ser usado em
 * conformidade com os termos da mesma. Este software nao pode ser
 * fornecido ou disponibilizado por qualquer outra entidade. Por
 * consequinte o titulo ou dono nao podem ser transferidos.
 * 
 * Versão 1.0 - Paulo Rodrigues  20080401
 *              Criação da estrutura base
 * 
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


using NBIISNET;
using NBiis;
using NBiis.Generic;
using CIFicheirosControlo;
using CIActividades;
//using CIDepositoErro;

namespace CIControlo
{
    public partial class CIMainForm : Form, CIConfigGlobalParameters.CIMenuInterface
    {
        protected CIControloParameters m_oParameters;

        protected CIControloParameters m_oParametersGCAA9601;
        protected CIControloParameters m_oParametersGCAA9604;
        protected CIControloParameters m_oParametersGCAA;

        public CIMainForm()
        {
            InitializeComponent();
        }

        private void CIMainForm_Load(object sender, EventArgs e)
        {
            /*
             * E001212 adicionado para só os powers admin conseguirem ver
             */
            this.btnDVPImportarRemessas.Visible = false;
            this.btnDVPImportarRemessas.Enabled = false;
            this.btnErroDeposito.Visible = false;
            this.btnErroDeposito.Enabled = false;
            this.importarRemessaToolStripMenuItem.Visible = false;
            this.importarRemessaToolStripMenuItem.Enabled = false;
            try
            {
                m_oParameters = null;
                m_oParameters = new CIControloParameters();

                //if (m_oParameters.UserLogged.m_iUserGroup < 1)
                //{
                //    try
                //    {
                //        m_oParametersGCAA9601 = new CIControloParameters("GCAA9601");
                //        m_oParametersGCAA9604 = new CIControloParameters("GCAA9604");
                //        this.btnDVPImportarRemessas.Visible = true;
                //        this.btnDVPImportarRemessas.Enabled = true;
                //        this.btnErroDeposito.Visible = true;
                //        this.btnErroDeposito.Enabled = true;
                //        this.importarRemessaToolStripMenuItem.Visible = true;
                //        this.importarRemessaToolStripMenuItem.Enabled = true;
                //    }
                //    catch (Exception ex)
                //    {
                //        MessageBox.Show(this, "Erro na ligação às BDs da GCAA\n" + ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //    }
                //}
                m_oParameters.InitGenericLog();
                //importarRemessaToolStripMenuItem.Visible = (m_oParameters.UserLogged.m_iUserGroup == 0);
                consultasToolStripMenuItem.Visible = (m_oParameters.UserLogged.m_iUserGroup == 0);
                MDIsToolStripMenuItem.Visible = (m_oParameters.UserLogged.m_iUserGroup <= 1);
                processamentoAutomaticoToolStripMenuItem.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);
                sQLToolStripMenuItem.Visible = (m_oParameters.UserLogged.m_iUserGroup < 10);
                manutençãoToolStripMenuItem.Visible = (m_oParameters.UserLogged.m_iUserGroup < 10);
                ConstroiMyTimer();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Dispose();
            }
        }

        private void Help()
        {
            try
            {
                NBIISAboutBoxDlg oHelp = new NBIISAboutBoxDlg();

                oHelp.m_ctrlAplicationIcon.Image = this.Icon.ToBitmap();
                oHelp.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void créditosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Help();
        }

        private void sQLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                QueryForm.QueryForm oObj = new QueryForm.QueryForm(m_oParameters);
                oObj.MdiParent = this;
                oObj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Sair()
        {
            Dispose();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sair();
        }

        private void cascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void tileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void tileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void toolStripButtonHelp_Click(object sender, EventArgs e)
        {
            try
            {
                Help();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButtonSair_Click(object sender, EventArgs e)
        {
            Sair();
        }

        private void ConstroiMyTimer()
        {
            timer1 = new Timer();
            timer1.Interval = 500;
            timer1.Tick += new EventHandler(OnTimedEvent);
            timer1.Start();
        }

        private void OnTimedEvent(object source, EventArgs e)
        {
            PreencheStatusBar();
        }

        private void PreencheStatusBar()
        {
            this.toolStripStatusData.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            this.toolStripStatusUser.Text = System.Windows.Forms.SystemInformation.UserDomainName + "\\" + System.Windows.Forms.SystemInformation.UserName;
            this.toolStripStatusUserFullName.Text = m_oParameters.UserLogged.m_sUserFullName;
            this.toolStripStatusGroup.Text = m_oParameters.UserLogged.m_sGroupName;
            this.toolStripStatusConnect.Text = "";
            if (m_oParameters.UserLogged.m_iUserGroup == 0)
            {
                this.toolStripStatusConnect.Text = m_oParameters.Host + "/" + m_oParameters.DatabaseName;
            }
        }

        private void balcoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIConfiguration.Config oConf = new CIConfiguration.Config(m_oParameters, this);

                oConf.BalcaoConfig();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void configuracaoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIConfiguration.Config oConf = new CIConfiguration.Config(m_oParameters, this);

                oConf.CIConfiguracao();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void resumoActividadesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIActividades.Actividades oAct = new CIActividades.Actividades(m_oParameters, this);

                oAct.ControloActividades();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void utilisadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIConfiguration.Config oConf = new CIConfiguration.Config(m_oParameters, this);
                oConf.UtilizadorConfig();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void alertasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIActividades.Actividades oAct = new CIActividades.Actividades(m_oParameters, this);
                oAct.Alertas();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void importarRemessaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this.AbrirImportGCCAForm();
        }

        private void loadENVMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIFicheirosControlo.FicheiroFormCentralENVM oFicheiroForm = new CIFicheirosControlo.FicheiroFormCentralENVM(m_oParameters, this);
                oFicheiroForm.MdiParent = this;

                oFicheiroForm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void loadACOMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIFicheirosControlo.FicheiroFormCentralACOM oFicheiroForm = new CIFicheirosControlo.FicheiroFormCentralACOM(m_oParameters, this);
                oFicheiroForm.MdiParent = this;
                oFicheiroForm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ListagemRemessasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIReports.Relatorios oRep = new CIReports.Relatorios(m_oParameters, this);
                oRep.ListagemRemessas();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void resumoDeEnviosToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            try
            {
                CIReports.Relatorios oRep = new CIReports.Relatorios(m_oParameters, this);
                oRep.resumoDeEnvios();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void listaLotesAcomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIReports.Relatorios oRep = new CIReports.Relatorios(m_oParameters, this);
                oRep.lotesAcomDetalhe();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void resumoAcomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIReports.Relatorios oRep = new CIReports.Relatorios(m_oParameters, this);
                oRep.lotesAcomResumo();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void consultasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIActividades.ConsultasForm oConsulta = new CIActividades.ConsultasForm(m_oParameters, this);
                oConsulta.MdiParent = this;
                oConsulta.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public Form GetMainForm()
        {
            return this;
        }

        public void alertasToolStripMenuItemEnable(bool bEnable)
        {
            try
            {
                alertasToolStripMenuItem.Enabled = bEnable;
                toolStripButtonAlertas.Enabled = bEnable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void processarEnvmEnable(bool bEnable)
        {
            try
            {
                loadENVMToolStripMenuItem.Enabled = bEnable;
                toolStripButtonEnvm.Enabled = bEnable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void processaAcomEnable(bool bEnable)
        {
            try
            {
                loadACOMToolStripMenuItem.Enabled = bEnable;
                toolStripButtonAcom.Enabled = bEnable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void PesquisasEnable(bool bEnable)
        {
            try
            {
                pesquisasEReenviosToolStripMenuItem.Enabled = bEnable;
                toolStripButtonPesquisas2.Enabled = bEnable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void actividadesEnable(bool bEnable)
        {
            try
            {
                resumoActividadesToolStripMenuItem.Enabled = bEnable;
                toolStripButtonActividades.Enabled = bEnable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void consultasEnable(bool bEnable)
        {
            consultasToolStripMenuItem.Enabled = bEnable;
        }

        public void balcoesEnable(bool bEnable)
        {
            balcoesToolStripMenuItem.Enabled = bEnable;
        }

        public void utilizadoresEnable(bool bEnable)
        {
            utilisadoToolStripMenuItem.Enabled = bEnable;
        }

        public void configuracaoEnable(bool bEnable)
        {
            configuracaoToolStripMenuItem.Enabled = bEnable;
        }

        private void toolStripButtonActividades_Click(object sender, EventArgs e)
        {
            try
            {
                resumoActividadesToolStripMenuItem_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButtonAlertas_Click(object sender, EventArgs e)
        {
            try
            {
                alertasToolStripMenuItem_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButtonEnvm_Click(object sender, EventArgs e)
        {
            try
            {
                loadENVMToolStripMenuItem_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButtonAcom_Click(object sender, EventArgs e)
        {
            try
            {
                loadACOMToolStripMenuItem_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButtonListRem_Click(object sender, EventArgs e)
        {
            try
            {
                ListagemRemessasToolStripMenuItem_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButtonResEnvio_Click(object sender, EventArgs e)
        {
            try
            {
                resumoDeEnviosToolStripMenuItem_Click_1(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButtonLtAcom_Click(object sender, EventArgs e)
        {
            try
            {
                listaLotesAcomToolStripMenuItem_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButtonResAcom_Click(object sender, EventArgs e)
        {
            try
            {
                resumoAcomToolStripMenuItem_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void jobMinutoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                m_oParameters.DirectSqlNonQuery("exec dbo.Job_Minuto");

                string sMsg = "Processamento Automatico Efectuado Manualmente Job_Minuto";
                GenericLog.GenLogRegistarAlerta(sMsg, "Job_Minuto()", 700);
                m_oParameters.EnviarAlertaSituacao(700, sMsg);

                MessageBox.Show(sMsg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void jobHoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                frmEspereUmMomento.ShowWaitForm();

                m_oParameters.DirectSqlNonQuery("exec dbo.Job_Hora");

                string sMsg = "Processamento Automatico Efectuado Manualmente Job_Hora";
                GenericLog.GenLogRegistarAlerta(sMsg, "Job_Hora()", 700);
                m_oParameters.EnviarAlertaSituacao(700, sMsg);

                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
                MessageBox.Show(sMsg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
        }

        private void jobDiarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                frmEspereUmMomento.ShowWaitForm();

                m_oParameters.DirectSqlNonQuery("exec dbo.Job_Diario");

                string sMsg = "Processamento Automatico Efectuado Manualmente Job_Diario";
                GenericLog.GenLogRegistarAlerta(sMsg, "Job_Diario()", 700);
                m_oParameters.EnviarAlertaSituacao(700, sMsg);

                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
                MessageBox.Show(sMsg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
        }

        private void ControloMDIsForm()
        {
            try
            {
                MDIsControlo.MDIsControloForm oForm = new MDIsControlo.MDIsControloForm(m_oParameters, m_oParametersGCAA9601, m_oParametersGCAA9604, this);
                oForm.MdiParent = this;
                oForm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MDIsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ControloMDIsForm();
        }

        private void toolStripButtonMDI_Click(object sender, EventArgs e)
        {
            ControloMDIsForm();
        }

        public void ControloMDIsFormMenuItemEnable(bool bEnable)
        {
            try
            {
                toolStripButtonMDI.Enabled = bEnable;
                MDIsToolStripMenuItem.Enabled = bEnable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButtonPesquisas2_Click(object sender, EventArgs e)
        {
            try
            {
                pesquisasEReenviosToolStripMenuItem_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pesquisasEReenviosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIActividades.Actividades oAct = new CIActividades.Actividades(m_oParameters, this);

                oAct.ControloPesquisas();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //SDCIM 7  
        private void atividadesToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            try
            {
                CIActividades.Actividades oAct = new CIActividades.Actividades(m_oParameters, this);
                oAct.ControloBalcao();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        //SDCIM 7 
        public void actividadeBalcaoEnable(bool bEnable)
        {
            try
            {
                atividadesToolStripMenuItem.Enabled = bEnable;
                toolStripButtonActividadesBalcao.Enabled = bEnable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        //SDCIM 7 
        public void acoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIActividades.Actividades oAct = new CIActividades.Actividades(m_oParameters, this);

                oAct.ControloBalcaoAcoes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void controloBalcaoAcoesEnable(bool bEnable)
        {
            try
            {
                acoesToolStripMenuItem.Enabled = bEnable;
                toolStripButtonAccoesBalcao.Enabled = bEnable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //SDCIM 7 
        private void sacoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIActividades.Actividades oAct = new CIActividades.Actividades(m_oParameters, this);

                oAct.ControloSaco();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        public void sacoEnable(bool bEnable)
        {
            try
            {
                sacoToolStripMenuItem.Enabled = bEnable;
                toolStripButtonSacoBalcao.Enabled = bEnable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDVPImportarRemessas_Click(object sender, EventArgs e)
        {
            //this.AbrirImportGCCAForm();
        }

        /// <summary>
        /// Normalização código... botões de dev apenas
        /// </summary>
        private void AbrirImportGCCAForm()
        {
            try
            {
                ImportGCAAForm oForm = new ImportGCAAForm(m_oParameters);
                oForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnErroDeposito_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    DepositoErroForm deForm = new DepositoErroForm(m_oParameters, this);
            //    deForm.Show();
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
        }

        private void toolStripButtonActividadesBalcao_Click(object sender, EventArgs e)
        {
            try
            {
                atividadesToolStripMenuItem_Click_1(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButtonAccoesBalcao_Click(object sender, EventArgs e)
        {
            acoesToolStripMenuItem_Click(sender, e);
        }

        private void toolStripButtonSacoBalcao_Click(object sender, EventArgs e)
        {
            sacoToolStripMenuItem_Click(sender, e);
        }

        private void FichACOMPesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.openPesquisasReenviosAcomDialog();
        }

        private void faturaçãoMensalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                CIReports.Relatorios oRep = new CIReports.Relatorios(m_oParameters, this);
                oRep.FaturacaoMensal();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void tsbtnPesReACOM_Click(object sender, EventArgs e)
        {
            this.openPesquisasReenviosAcomDialog();
        }

        private void openPesquisasReenviosAcomDialog()
        {

            PesqFicheiroACOM pFichACOM = new PesqFicheiroACOM(m_oParameters, this);
            pFichACOM.MdiParent = this;
            pFichACOM.Show();
        }

        public void enablePesqFicheiroAcom(bool bEnable)
        {
            this.tsbtnPesReACOM.Enabled = bEnable;
            this.fToolStripMenuItem1.Enabled = bEnable;
        }
    }
}