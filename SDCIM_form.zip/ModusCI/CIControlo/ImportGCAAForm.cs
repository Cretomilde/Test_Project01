﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using CIServTester;
using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIControlo
{
    public partial class ImportGCAAForm : Form
    {

        class Remessa
        {
            public string sOrigem;
            public long lREMIN_ID;
            public string sREMCOMP_ID;         //@RemID as bigint = null,
            public string sREMCOMP_PAIS;       //@Pais as char(4) = null,
            public string sREMCOMP_BANCO;      //@Banco as int = null,
            public string sREMCOMP_BALCAO;     //@Balcao as int = null,
            public string sREMCOMP_BALCAO_DEST;
            public string sREMCOMP_NUMERO;     //@Numero as float = null,
            public DateTime dtREMCOMP_DATA;    //@Data as datetime = null,
            public string sOperador;
            public string sREMCOMP_QT;
            public decimal dREMCOMP_VALOR;
            public string sREMCOMP_APLICACAO;
            public string sTipo;
            public string sChaveHost;
            public string sChaveHostExt;
            public string sNIB;
            public string sNumProp;

            public Remessa(SqlDataReader dr)
            {
                sOrigem = "1";
                sTipo = "1";
                sREMCOMP_ID = Convert.ToString(dr["REMCOMP_ID"]);
                sREMCOMP_PAIS = Convert.ToString(dr["REMCOMP_PAIS"]);
                sREMCOMP_BANCO = Convert.ToString(dr["REMCOMP_BANCO"]);
                sREMCOMP_BALCAO = Convert.ToString(dr["REMCOMP_BALCAO"]);
                sREMCOMP_BALCAO_DEST = Convert.ToString(dr["REMCOMP_BALCAO_DEST"]);
                sREMCOMP_NUMERO = Convert.ToString(dr["REMCOMP_NUMERO"]);
                dtREMCOMP_DATA = Convert.ToDateTime(dr["REMCOMP_DATA"]);
                sOperador = Convert.ToString(dr["CADEPR_USER_CORRECCAO"]);
                sREMCOMP_QT = Convert.ToString(dr["REMCOMP_QT"]);
                dREMCOMP_VALOR = Convert.ToDecimal(dr["REMCOMP_VALOR"]);
                sREMCOMP_APLICACAO = Convert.ToString(dr["REMCOMP_APLICACAO"]);
                sChaveHost = sREMCOMP_BALCAO + sREMCOMP_NUMERO;
                sChaveHostExt = sREMCOMP_NUMERO + ".EXTENDED";
                sNIB = "003500000000000000000";
                sNumProp = sREMCOMP_ID;

                lREMIN_ID = 0;
            }
        }
        Remessa m_oCurrRemessa;

        class Documento
        {
            //public string sDOCORI_ID;
            public DateTime dtDOC_DATADIGIT;

            public string sDOCFIS_ID;
            public string sTipo;
            public string sDOCFIS_ZON5;
            public string sDOCFIS_ZON4;
            public string sDOCFIS_ZON3;
            public decimal dDOCFIS_IMPORT;
            public string sDOCFIS_ZON1;
            public string sDOCFIS_NRDIGITALIZADOR;
            public string sDOCFIS_INDX;
            
            public string sRefArq;
            public string sNIB;
            public string sChaveHost;
            public string sChaveHostExt;
            
            public string sFrontImgType;
            public byte[] iFrontImg;
            public string sRearImgType;
            public byte[] iRearImg;

            public Documento(SqlDataReader dr)
            {
                sDOCFIS_ID = Convert.ToString(dr["DOCFIS_ID"]);

                dtDOC_DATADIGIT = Convert.ToDateTime(dr["DOCFIS_WKDATA_LEITURA"]);
                sTipo = "0";
                sDOCFIS_ZON5 = Convert.ToString(dr["DOCFIS_ZON5"]);
                sDOCFIS_ZON4 = Convert.ToString(dr["DOCFIS_ZON4"]);
                sDOCFIS_ZON3 = Convert.ToString(dr["DOCFIS_ZON3"]);
                dDOCFIS_IMPORT = Convert.ToDecimal(dr["DOCFIS_IMPORT"]);
                sDOCFIS_ZON1 = Convert.ToString(dr["DOCFIS_ZON1"]);
                sDOCFIS_NRDIGITALIZADOR = Convert.ToInt32(dr["DOCFIS_NRDIGITALIZADOR"]).ToString("00000");
                sDOCFIS_INDX = Convert.ToInt64(dr["DOCFIS_INDX"]).ToString("000000");

                //sRefArq = DateTime.Now.Year.ToString("0000");
                //sRefArq += DateTime.Now.DayOfYear.ToString("000");
                //sRefArq += sDOCFIS_NRDIGITALIZADOR + sDOCFIS_INDX;


                sRefArq = (DateTime.Now.AddDays(-2).Year % 100).ToString("00");
                sRefArq += DateTime.Now.AddDays(-2).DayOfYear.ToString("000");
                //sRefArq += iBalcaoTomador.ToString("0000");
                //sRefArq += NBiis.CCAGeneric.Documento.BuildRefArqMaqIndex(Convert.ToInt32(oRow["DOCFIS_NRDIGITALIZADOR"]), Convert.ToInt64(oRow["DOCFIS_INDX"]));
                sRefArq += sDOCFIS_NRDIGITALIZADOR.Substring(0,4);
                sRefArq += sDOCFIS_INDX.PadLeft(6,'0').Substring(2, 4);
                sRefArq += "3";

                //sNIB = Convert.ToInt32(dr["CADEPC_CONTA_BANCO"]).ToString("0000");
                //sNIB += Convert.ToInt32(dr["CADEPC_CONTA_BALCAO"]).ToString("0000");
                //sNIB += "00" + Convert.ToString(dr["CADEPC_CONTA_NUMERO"]);
                //sNIB += Convert.ToString(dr["CADEPC_CONTA_TIPO"]);
                //sNIB += "00";

                sNIB = Convert.ToInt32(dr["CADEPC_CONTA_BALCAO"]).ToString("0000");
                sNIB += Convert.ToString(dr["CADEPC_CONTA_NUMERO"]);
                sNIB += Convert.ToString(dr["CADEPC_CONTA_TIPO"]);

                sChaveHost = Convert.ToString(dr["CADEPC_TIMESTAMP"]);
                sChaveHostExt = sChaveHost + ".EXTENDED";
            
                sFrontImgType="JPG";
                sRearImgType="JPG";

                iFrontImg = LoadImage(@"D:\gccacq\DOC_FRONT.JPG");
                iRearImg = LoadImage(@"D:\gccacq\DOC_REAR.JPG");
            }

            public byte[] LoadImage(string sFileName)
            {
                StreamReader sr = new StreamReader(sFileName);
                BinaryReader br = new BinaryReader(sr.BaseStream);

                byte[] aBytes = br.ReadBytes((int)sr.BaseStream.Length);

                sr.Close();
                br.Close();
                return aBytes;
            }
        }

        Documento m_oCurrDocumento;

        int m_iNDocs;
        int m_iNRemessas;

        protected CIConfigGP.CIGlobalParameters m_oParameters;
        protected CIControloParameters m_oParametersGCAA;

        public ImportGCAAForm(CIConfigGP.CIGlobalParameters oParameters)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_oParametersGCAA = new CIControloParameters("GCAA9601");
            m_oCurrRemessa = null;
            m_oCurrDocumento = null;
        }

        private void ImportGCAAForm_Load(object sender, EventArgs e)
        {
            this.Text = m_oParametersGCAA.GetProfileString("Genericos","Config","BalcaoGestor","ND");  
        }

        private void Update_FecharRemessa()
        { 
            try
            {
                int iForcarFecho = 0;

                string sSPName = "dbo.Update_FecharRemessa";
                ArrayList oParam = new ArrayList();

                //oParam.Add(new GeneralDBParameters("@RemID", m_oCurrRemessa.lREMIN_ID));

                oParam.Add(new GeneralDBParameters("@Pais", m_oCurrRemessa.sREMCOMP_PAIS));
                oParam.Add(new GeneralDBParameters("@Banco", m_oCurrRemessa.sREMCOMP_BANCO));
                oParam.Add(new GeneralDBParameters("@Balcao", m_oCurrRemessa.sREMCOMP_BALCAO));
                oParam.Add(new GeneralDBParameters("@Numero", m_oCurrRemessa.sREMCOMP_NUMERO));
                //oParam.Add(new GeneralDBParameters("@DataIn", m_oCurrRemessa.dtREMCOMP_DATA));
                oParam.Add(new GeneralDBParameters("@DataIn", DateTime.Now.AddDays(-2)));
                
                oParam.Add(new GeneralDBParameters("@ForcarFecho", iForcarFecho));

                m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref oParam);

            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }

        }

        private void Insert_AdicionarDocumento(SqlDataReader oDr)
        {
            m_iNDocs++;

            m_oCurrDocumento = null;
            m_oCurrDocumento = new Documento(oDr);

            labelInfoDoc.Text = m_iNRemessas.ToString() + "  " + m_iNDocs.ToString() + "  " + m_oCurrDocumento.sDOCFIS_ID + " " + m_oCurrDocumento.sChaveHost;

            Refresh();

            string sSPName = "dbo.Insert_AdicionarDocumento";
            ArrayList oParam = new ArrayList();

            try
            {

                oParam.Add(new GeneralDBParameters("@RemID", m_oCurrRemessa.lREMIN_ID));
                oParam.Add(new GeneralDBParameters("@Pais", m_oCurrRemessa.sREMCOMP_PAIS));
                oParam.Add(new GeneralDBParameters("@Banco", m_oCurrRemessa.sREMCOMP_BANCO));
                oParam.Add(new GeneralDBParameters("@Balcao", m_oCurrRemessa.sREMCOMP_BALCAO));
                oParam.Add(new GeneralDBParameters("@Numero", m_oCurrRemessa.sREMCOMP_NUMERO));
                //oParam.Add(new GeneralDBParameters("@DataIn", m_oCurrRemessa.dtREMCOMP_DATA));
                oParam.Add(new GeneralDBParameters("@DataIn", DateTime.Now.AddDays(-2)));
                
                oParam.Add(new GeneralDBParameters("@BalTom","963"));
                oParam.Add(new GeneralDBParameters("@DocOriID", m_oCurrDocumento.sDOCFIS_ID));
                //oParam.Add(new GeneralDBParameters("@Tipo",m_oCurrDocumento.sTipo)); 
                oParam.Add(new GeneralDBParameters("@Lo_ZIB", m_oCurrDocumento.sDOCFIS_ZON5));
                oParam.Add(new GeneralDBParameters("@Lo_NConta",m_oCurrDocumento.sDOCFIS_ZON4));
                oParam.Add(new GeneralDBParameters("@Lo_NCheque",m_oCurrDocumento.sDOCFIS_ZON3));
                oParam.Add(new GeneralDBParameters("@Lo_Montante",m_oCurrDocumento.dDOCFIS_IMPORT));
                oParam.Add(new GeneralDBParameters("@Lo_Tipo",m_oCurrDocumento.sDOCFIS_ZON1));
                //oParam.Add(new GeneralDBParameters("@DataDigitalizacaoIn", m_oCurrDocumento.dtDOC_DATADIGIT));
                oParam.Add(new GeneralDBParameters("@DataDigitalizacaoIn", DateTime.Now.AddDays(-2)));
                oParam.Add(new GeneralDBParameters("@Maquina",m_oCurrDocumento.sDOCFIS_NRDIGITALIZADOR));
                oParam.Add(new GeneralDBParameters("@Index",m_oCurrDocumento.sDOCFIS_INDX));
                oParam.Add(new GeneralDBParameters("@RefArq",m_oCurrDocumento.sRefArq));
                oParam.Add(new GeneralDBParameters("@NIB",m_oCurrDocumento.sNIB));
                //oParam.Add(new GeneralDBParameters("@ChaveHost", m_oCurrDocumento.sChaveHost));
                //oParam.Add(new GeneralDBParameters("@ChaveHostExt", m_oCurrDocumento.sChaveHostExt));
                
                oParam.Add(new GeneralDBParameters("@FrontImgType", m_oCurrDocumento.sFrontImgType));
                oParam.Add(new GeneralDBParameters("@RearImgType",m_oCurrDocumento.sRearImgType));
                
                oParam.Add(new GeneralDBParameters("@FrontImage", m_oCurrDocumento.iFrontImg));
                oParam.Add(new GeneralDBParameters("@RearImage", m_oCurrDocumento.iRearImg));

                m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref oParam);

            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }
        }

        private void Insert_AbrirRemessa(SqlDataReader oDr)
        {
            m_iNDocs = 0;
            m_oCurrRemessa = null;
            m_oCurrRemessa = new Remessa(oDr);

            try
            {
                string sSPName = "dbo.Insert_AbrirRemessa";
                ArrayList oParam = new ArrayList();

                oParam.Add(new GeneralDBParameters("@Origem",m_oCurrRemessa.sOrigem));
                oParam.Add(new GeneralDBParameters("@Pais",m_oCurrRemessa.sREMCOMP_PAIS));
                oParam.Add(new GeneralDBParameters("@Banco",m_oCurrRemessa.sREMCOMP_BANCO));
                oParam.Add(new GeneralDBParameters("@Balcao",m_oCurrRemessa.sREMCOMP_BALCAO));
                oParam.Add(new GeneralDBParameters("@Numero",m_oCurrRemessa.sREMCOMP_NUMERO));
                //oParam.Add(new GeneralDBParameters("@DataIn", m_oCurrRemessa.dtREMCOMP_DATA));
                oParam.Add(new GeneralDBParameters("@DataIn", DateTime.Now.AddDays(-2)));
                oParam.Add(new GeneralDBParameters("@Operador",m_oCurrRemessa.sOperador));
                oParam.Add(new GeneralDBParameters("@Aplicacao",m_oCurrRemessa.sREMCOMP_APLICACAO));
                oParam.Add(new GeneralDBParameters("@QtDocs",m_oCurrRemessa.sREMCOMP_QT));
                oParam.Add(new GeneralDBParameters("@Montante",m_oCurrRemessa.dREMCOMP_VALOR));
                oParam.Add(new GeneralDBParameters("@Tipo",m_oCurrRemessa.sTipo));
                //oParam.Add(new GeneralDBParameters("@ChaveHost",m_oCurrRemessa.sChaveHost));
                //oParam.Add(new GeneralDBParameters("@ChaveHostExt",m_oCurrRemessa.sChaveHostExt));
                //oParam.Add(new GeneralDBParameters("@NIB",m_oCurrRemessa.sNIB));
                //oParam.Add(new GeneralDBParameters("@NumProp",m_oCurrRemessa.sNumProp));

                object oObj = m_oParameters.DirectStoredProcedureScalar(sSPName, ref oParam);
                m_oCurrRemessa.lREMIN_ID = Convert.ToInt64(oObj);

            }
            catch(Exception ex)
            {
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }

        }

        private void ImportFromGCAA(string sREMCOMP_ID)
        {
            SqlDataReader oDr = null;
            string sQuery;
            bool bFirst = true;

            try
            {
                sQuery = "select * from docfisico ";
                sQuery += " inner join docfisico_ext1 on docfisico.docfis_id=docfisico_ext1.docfis_id ";
                sQuery += " inner join remessa_vt on remessa_vt.remcomp_id=docfisico_ext1.remcomp_id ";
                sQuery += " inner join ca_deposito_recolha on ca_deposito_recolha.cadepr_id=docfisico.cadepr_id ";
                sQuery += " inner join ca_deposito_central on ca_deposito_recolha.cadepc_id=ca_deposito_central.cadepc_id ";
                sQuery += " where docfisico_ext1.remcomp_id=" + sREMCOMP_ID;

                oDr = m_oParametersGCAA.DirectSqlDataReader(sQuery);
                while (oDr.Read())
                {
                    if (bFirst)
                    { 
                        Insert_AbrirRemessa(oDr);
                    }

                    Insert_AdicionarDocumento(oDr);
                    bFirst = false;
                }

                Update_FecharRemessa();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }
            finally
            {
                if (oDr != null)
                {
                    oDr.Close();
                    oDr = null;
                }
            }
        }


        private void btImport_Click(object sender, EventArgs e)
        {
            SqlDataReader oDr = null;

            try
            {
                btImport.Enabled = false; 
                m_oCurrRemessa = null;
                m_oCurrDocumento = null;
                // string sQuery = "select top 5 remcomp_id from remessa_vt ";
                string sQuery = "select top 1 remcomp_id from remessa_vt ";
                sQuery += "where remcomp_motivo=0 and remcomp_balcao_dest=9320 and remcomp_status=3";
                sQuery += "order by REMCOMP_ID desc";

                ArrayList alRemCompIds = new ArrayList();

                oDr = m_oParametersGCAA.DirectSqlDataReader(sQuery);
                while (oDr.Read())
                {
                    alRemCompIds.Add(oDr["REMCOMP_ID"]);  
                }
                oDr.Close();
                oDr = null;

                for (int i = 0; i < alRemCompIds.Count; i++)
                {
                    m_iNRemessas++;
                    try
                    {
                        ImportFromGCAA(alRemCompIds[i].ToString());
                    }
                    catch { }
                }

                this.labelInfoDoc.Text += " FIM"; 
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (oDr != null)
                {
                    oDr.Close();
                    oDr = null;
                }
                btImport.Enabled = true;
            }
        }

        private void btProcessRemessa_Click(object sender, EventArgs e)
        {
            m_oParameters.OpenConnection();  
            CIServTester.ProcessarRemessas oProc = new ProcessarRemessas(m_oParameters);
            m_oParameters.CloseConnection();  
        }

        private void btProcessarAlerta_Click(object sender, EventArgs e)
        {
            m_oParameters.OpenConnection();
            CIServTester.ProcessarAlertas oProc = new ProcessarAlertas(m_oParameters);
            m_oParameters.CloseConnection();
        }

        public byte[] LoadImage(string sFileName)
        {
            StreamReader sr = new StreamReader(sFileName);
            BinaryReader br = new BinaryReader(sr.BaseStream);

            byte[] aBytes = br.ReadBytes((int)sr.BaseStream.Length);

            sr.Close();
            br.Close();
            return aBytes;
        }

        private void button1_Click(object sender, EventArgs e)
        {
                try
            {
                string sSPName = "dbo.Insert_AdicionarDocumento";
                ArrayList oParam = new ArrayList();

                byte[] aBytes = LoadImage(@"D:\gccacq\DOC_FRONT.JPG");

                oParam.Add(new GeneralDBParameters("@RemID", 7329));
                oParam.Add(new GeneralDBParameters("@BalTom",9604));
                oParam.Add(new GeneralDBParameters("@DocOriID",0));
                oParam.Add(new GeneralDBParameters("@Lo_ZIB","00351234"));
                oParam.Add(new GeneralDBParameters("@Lo_NConta","12345678901"));
                oParam.Add(new GeneralDBParameters("@Lo_NCheque","1234567890"));
                oParam.Add(new GeneralDBParameters("@Lo_Montante",123));
                oParam.Add(new GeneralDBParameters("@Lo_Tipo","23"));
                oParam.Add(new GeneralDBParameters("@DataDigitalizacaoIn","2008/10/21"));
                oParam.Add(new GeneralDBParameters("@Maquina",30));
                oParam.Add(new GeneralDBParameters("@RefArq","1"));
                oParam.Add(new GeneralDBParameters("@FrontImgType","JPG"));
                oParam.Add(new GeneralDBParameters("@RearImgType","JPG"));
                oParam.Add(new GeneralDBParameters("@FrontImage", aBytes));
                oParam.Add(new GeneralDBParameters("@RearImage", aBytes));

                object o=m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref oParam);

            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        decimal m_dMontLote;
        decimal m_dMontFicheiro;
        int m_iQtLote;
        int m_iQtFicheiro;
        int m_iNLote = 0;
        
        private void button2_Click(object sender, EventArgs e)
        {
            string sRemin_id = textBoxRemin_ID.Text;
            int iNSeqFich = int.Parse(textBoxNSeqFich.Text);
            Int32 OrigemID = 1;
            if (this.cbOrigem.SelectedIndex.Equals(1))
                OrigemID = 2;


            string sLastRemin = "";
            string sCurrRemin = "";

            StreamWriter sw1 = new StreamWriter("d:\\tmp\\envm" + sRemin_id + ".txt", false);
            StreamWriter sw2 = new StreamWriter("d:\\tmp\\acom" + sRemin_id + ".txt", false);

            DataSet ds = m_oParameters.DirectSqlDataSet("Select * from MAN_VW_ficheiro_ENVM_CRIAR WHERE REMIN_ID in ("
                                                         + sRemin_id + ") AND Origem_ID = " + OrigemID + " order by REMIN_id", "criarEnvm");
            EscreveHeaderFicheiro(sw1, sw2);
            foreach (DataRow oRow in ds.Tables[0].Rows)
            {
                sCurrRemin = oRow["REMIN_ID"].ToString();
                if (sLastRemin != sCurrRemin)
                {
                    if (sLastRemin != "")
                    {
                        EscreveTrailerLote(sw1, sw2);
                    }
                    sLastRemin = sCurrRemin;
                    EscreveHeaderLote(sw1, sw2, oRow);
                }
                EscreveDetalhe(sw1, sw2, oRow);
            }
            EscreveTrailerLote(sw1, sw2);
            EscreveTrailerFicheiro(sw1, sw2);


            sw1.Close();
            sw1.Dispose();
            sw2.Close();
            sw2.Dispose();


            MessageBox.Show("Ficheiros Criados", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

        }


        void EscreveHeaderFicheiro(StreamWriter sw1, StreamWriter sw2)
        {
            m_dMontFicheiro = 0;
            m_iQtFicheiro=0;
            sw1.WriteLine("0" // HDT	Tipo de Registo	Num	1
                + "ENVM" //FICH	Ficheiro	Char	4
                + "0035" //BANCO	Banco Tomador	Num	4
                + int.Parse(textBoxNSeqFich.Text).ToString("0000")//NSEQFICH	Número de Sequência do Ficheiro	Num	4 
                + DateTime.Now.ToString("yyyyMMddHHmm")//DTFICH	Data e hora de criação do Ficheiro	Num	12
                + DateTime.Now.ToString("yyyyMMdd")//REFCMP	Referência de Compensação	Num	8
            );
            sw2.WriteLine("0" // HDT	Tipo de Registo	Num	1
                + "ACOM" //FICH	Ficheiro	Char	4
                + "0035" //BANCO	Banco Tomador	Num	4
                + int.Parse(textBoxNSeqFich.Text).ToString("0000")//NSEQFICH	Número de Sequência do Ficheiro	Num	4 
                + DateTime.Now.ToString("yyyyMMddHHmm")//DTFICH	Data e hora de criação do Ficheiro	Num	12
                + "00000000"
            );

        }

        void EscreveHeaderLote(StreamWriter sw1, StreamWriter sw2, DataRow oRow)
        {

            m_dMontLote = 0;
            m_iQtLote = 0;

            sw1.WriteLine("1"          //HDT	Tipo de Registo	Num	1
                        + (++m_iNLote).ToString("000000")//NLOTE	Número de Lote	Num	6
                        + Convert.ToInt32(oRow["REMIN_BAlCAO"]).ToString("0000")//CODBAL	Código do Balcão	Num	4
                        + Convert.ToInt32(oRow["REMIN_NUMERO"]).ToString("00000000000")//NREM	Número da Remessa	Num	11
                        + Convert.ToDateTime(oRow["REMIN_DATA"]).ToString("yyyyMMdd")//DTREM	Data da Remessa	Num	8
                        + "1"//TCAP	Tipo de Captura	Num	1
                        + "001"//TREM	Tipo de Remessa	Num	3
                        + (Convert.ToDouble(oRow["REMIN_MT_DOCS"]) * 100.0).ToString("000000000000000") //MONTANTE	Montante Total Remessa Declarado	Num	15
                        + Convert.ToInt32(oRow["REMIN_QT_DOCS"]).ToString("000000")//NRDOCUM	Quantidade de Documentos declarado	Num	6
                        + "000"//ANOMAL	Anomalia Lote	Num	3
                        + oRow["REMPROC_CHAVEH"].ToString()//CHAHOST	Chave no Host	Char	51
                        + oRow["REMPROC_CHAVEHEXT"].ToString()//CHAHOSTEXT	Extensão ao Chave no Host	Char	77
                        + "000"//VALREQ	Validação de Requisitos	Num	3
                        + "0".PadRight(120, '0')//SERVADIC	Serviços Adicionais	Char	120
                );
            sw2.WriteLine("1"          //HDT	Tipo de Registo	Num	1
                        + (++m_iNLote).ToString("000000")//NLOTE	Número de Lote	Num	6
                        + "004"//PRODUTO	Produto	Num	3
                        + DateTime.Now.ToString("yyyyMMdd")//DATAPROC	Data de Processamento	Num	8
        
                );
        }

        void EscreveDetalhe(StreamWriter sw1, StreamWriter sw2, DataRow oRow)
        {
            m_dMontLote += Convert.ToInt64(Convert.ToDouble(oRow["DOC_ZONA2"]) * 100.0);
            m_iQtLote++;
            sw1.WriteLine(oRow["LInha"].ToString());
            sw2.WriteLine("2"//HDT	Tipo de Registo	Num	1
                          + oRow["DOC_REFARQ"].ToString()//REFARQCAP	Referência de Arquivo na Captura	Num	14
                          + m_iNLote.ToString("000000") + m_iQtLote.ToString("00000000")  //REFARQ	Referência de Arquivo	Num	14
                          + Convert.ToInt32(oRow["REMIN_BALCAO"]).ToString("0000")  //CODBAL	Código do Balcão Tomador	Num	4
                          + "02"  //CODANA	Código de Análise - acção tomada sobre o documento	Num	2
                          + oRow["DOC_CHAVEH"].ToString()  //CHAHOST	Chave no Host	Num	51
                          + oRow["DOC_CHAVEHEXT"].ToString() //CHAHOSTEXT	Extensão ao Chave no Host	Char	77
                          + (Convert.ToDouble(oRow["DOC_ZONA2"]) * 100.0).ToString("000000000000")  //IMPORT	Importância	Num	12
                          + oRow["DOC_ZONA5"].ToString()  //LINHAOPT	Linha Óptica	Num	31
                          + oRow["DOC_ZONA4"].ToString()  //LINHAOPT	Linha Óptica	Num	31
                          + oRow["DOC_ZONA3"].ToString()  //LINHAOPT	Linha Óptica	Num	31
                          + oRow["DOC_ZONA1"].ToString()  //LINHAOPT	Linha Óptica	Num	31

           );
        }


        void EscreveTrailerLote(StreamWriter sw1, StreamWriter sw2)
        {
            sw1.WriteLine("8"   //HDT	Tipo de Registo	Num	1
                +m_dMontLote//MONTAPU	Montante Apurado	Num	15
                +m_iQtLote//TOTREG	Quantidade de Registos do Lote	Num	6
                + m_dMontLote//MONTTOTAL	Montante do Total dos registos do lote	Num	15
                );
            sw2.WriteLine("8"   //HDT	Tipo de Registo	Num	1
                + m_iQtLote//TOTREG	Quantidade de Registos do Lote	Num	6
                + m_dMontLote//MONTTOTAL	Montante do Total dos registos do lote	Num	15
                );

            m_dMontFicheiro+=m_dMontLote;
            m_iQtFicheiro+=m_iQtLote;

        }

        void EscreveTrailerFicheiro(StreamWriter sw1, StreamWriter sw2)
        {
            sw1.WriteLine("9"//HDT	Tipo de Registo	Num	1
                        + m_iQtFicheiro//TOTREGFIS	Total de Registos do Ficheiro	Num	6
                        + m_dMontFicheiro//MONTTOTFIC	Montantes total do Ficheiro	Num	15
                        + "00"//ULTFICH	Último ficheiro	NUM	2
            );
            sw2.WriteLine("9"//HDT	Tipo de Registo	Num	1
                       + m_iQtFicheiro//TOTREGFIS	Total de Registos do Ficheiro	Num	6
                       + m_dMontFicheiro//MONTTOTFIC	Montantes total do Ficheiro	Num	15
                       + "00"//ULTFICH	Último ficheiro	NUM	2
           );
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string sSPName = "EXECUTE dbo.MAN_REPOR_BD_REMESSAS";
                object o = m_oParameters.DirectSqlScalar(sSPName);
                MessageBox.Show(this, "Recriados dados", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnProcessaBalcao_Click(object sender, EventArgs e)
        {
            m_oParameters.OpenConnection();
            CIServTester.ProcessarRemessasBalcao oProc = new ProcessarRemessasBalcao(m_oParameters);
            m_oParameters.CloseConnection();
        }
    }
}