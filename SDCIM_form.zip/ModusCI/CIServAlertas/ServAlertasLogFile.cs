﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace CIServAlertas
{
    class ServAlertasLogFile 
    {
        CIConfigGP.CIGlobalParameters m_oParameters;
        public int m_iTipoAccao;
        StreamWriter m_sw;

        public ServAlertasLogFile(CIConfigGP.CIGlobalParameters oParameters, int iTipoAccao)
        {
            m_oParameters = oParameters;
            m_iTipoAccao = iTipoAccao;

            m_sw = new StreamWriter(GetFileName(), true);

        }

        protected string GetFileName()
        {

            string sQuery = "Select TIPACCP_VALUE from ALERTA_TIPO_ACCAO_PARAM where TIPACCP_NAME= 'FileName' and TIPACC_ID = " + m_iTipoAccao.ToString();
           
            return m_oParameters.DirectSqlScalar(sQuery).ToString();
        }

        public void CloseFile()
        {
            m_sw.Close();
            m_sw.Dispose();
        }

        public void AddLineToFile(string sTxt)
        {
            m_sw.WriteLine(sTxt);
        }
    }
}
