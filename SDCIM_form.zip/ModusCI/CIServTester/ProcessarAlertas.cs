﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using Alerta;
using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIServTester
{
    public partial class ProcessarAlertas : CIComumInterface
    {
        public void ErrorMessage(string sMessage)
        {
            MessageBox.Show("ProcessarAlertas Error: " + sMessage);
        }
        public void WarningMessage(string sMessage)
        {
            MessageBox.Show("ProcessarAlertas Warning: " + sMessage);
        }
        public void InfoMessage(string sMessage, string sHeader)
        {
            MessageBox.Show("ProcessarAlertas Info: " + sMessage);
        }
        public void InfoMessageCount(string sMessage)
        {
        }

        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public ProcessarAlertas(CIConfigGP.CIGlobalParameters oParameters)
        {
            m_oParameters = oParameters;

            AlertaSituacaoAccao oAlSitAcc = null;
            try
            {
                CIServAlertas.ServAlerta oAl = new CIServAlertas.ServAlerta(this, m_oParameters);

                oAlSitAcc = oAl.AlertaSituacaoAccaoParaProcessar();
                if (oAlSitAcc == null)
                {
                    return;
                }
                oAl.ProcessaAlertaSituacaoAccao(oAlSitAcc);
            }
            catch (Exception ex)
            {
                string sMsg = "";
                if (oAlSitAcc != null)
                {
                    sMsg = "ALERT_ID e ACC_ID não identificados";
                }
                else
                {
                    sMsg = " ALERT_ID=" + oAlSitAcc.m_sALERT_ID;
                    sMsg += " ACC_ID=" + oAlSitAcc.m_oSituacaoAccao.m_oAccao.m_iACC_ID.ToString();
                }

                ErrorMessage("CheckForAlertas2Process: " + sMsg + " - " + ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "ServRemessa()", 500);
            }
        }
    }
}
