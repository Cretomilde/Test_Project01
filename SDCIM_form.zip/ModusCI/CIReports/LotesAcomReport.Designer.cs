﻿namespace CIReports
{
    partial class LotesAcomReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LotesAcomReport));
            this.btGenLog = new System.Windows.Forms.Button();
            this.m_ctrldtFim = new System.Windows.Forms.DateTimePicker();
            this.m_ctrdtInicio = new System.Windows.Forms.DateTimePicker();
            this.textBoxFiltroBalcao = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btGenLog
            // 
            this.btGenLog.Location = new System.Drawing.Point(137, 65);
            this.btGenLog.Name = "btGenLog";
            this.btGenLog.Size = new System.Drawing.Size(180, 23);
            this.btGenLog.TabIndex = 4;
            this.btGenLog.Text = "Gerar Relatório";
            this.btGenLog.UseVisualStyleBackColor = true;
            this.btGenLog.Click += new System.EventHandler(this.btGenLog_Click_1);
            // 
            // m_ctrldtFim
            // 
            this.m_ctrldtFim.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrldtFim.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrldtFim.Location = new System.Drawing.Point(254, 14);
            this.m_ctrldtFim.Name = "m_ctrldtFim";
            this.m_ctrldtFim.Size = new System.Drawing.Size(202, 20);
            this.m_ctrldtFim.TabIndex = 2;
            // 
            // m_ctrdtInicio
            // 
            this.m_ctrdtInicio.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrdtInicio.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrdtInicio.Location = new System.Drawing.Point(20, 13);
            this.m_ctrdtInicio.Name = "m_ctrdtInicio";
            this.m_ctrdtInicio.Size = new System.Drawing.Size(202, 20);
            this.m_ctrdtInicio.TabIndex = 1;
            // 
            // textBoxFiltroBalcao
            // 
            this.textBoxFiltroBalcao.Location = new System.Drawing.Point(73, 39);
            this.textBoxFiltroBalcao.Name = "textBoxFiltroBalcao";
            this.textBoxFiltroBalcao.Size = new System.Drawing.Size(64, 20);
            this.textBoxFiltroBalcao.TabIndex = 3;
            this.textBoxFiltroBalcao.TextChanged += new System.EventHandler(this.textBoxFiltroBalcao_TextChanged);
            this.textBoxFiltroBalcao.Leave += new System.EventHandler(this.textBoxFiltroBalcao_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 16);
            this.label1.TabIndex = 15;
            this.label1.Text = "Balcão";
            // 
            // LotesAcomReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 106);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxFiltroBalcao);
            this.Controls.Add(this.btGenLog);
            this.Controls.Add(this.m_ctrldtFim);
            this.Controls.Add(this.m_ctrdtInicio);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LotesAcomReport";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lotes Acom";
            this.Load += new System.EventHandler(this.LotesAcomReport_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btGenLog;
        private System.Windows.Forms.DateTimePicker m_ctrldtFim;
        private System.Windows.Forms.DateTimePicker m_ctrdtInicio;
        private System.Windows.Forms.TextBox textBoxFiltroBalcao;
        private System.Windows.Forms.Label label1;
    }
}