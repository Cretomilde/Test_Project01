select * from VW_REPORT_ENVIO_DETALHADO
Where 
%condition%
 --Remin_data between '2008-06-10 0:00:00' and '2008-06-15 0:00:00' 
order by REMIN_DATA, REMIN_BALCAO, REMIN_NUMERO 
