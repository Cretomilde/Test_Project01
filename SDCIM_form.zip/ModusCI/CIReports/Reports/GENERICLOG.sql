select top 1000 * from VW_GENERICLOG_REPORT
Where 
%condition%
order by 4 desc