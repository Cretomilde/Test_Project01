﻿namespace CIReports
{
    partial class FaturacaoMensal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbAno = new System.Windows.Forms.Label();
            this.lbMes = new System.Windows.Forms.Label();
            this.cbMes = new System.Windows.Forms.ComboBox();
            this.cbAno = new System.Windows.Forms.ComboBox();
            this.btGenLog = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbAno
            // 
            this.lbAno.AutoSize = true;
            this.lbAno.Location = new System.Drawing.Point(61, 15);
            this.lbAno.Name = "lbAno";
            this.lbAno.Size = new System.Drawing.Size(26, 13);
            this.lbAno.TabIndex = 0;
            this.lbAno.Text = "Ano";
            // 
            // lbMes
            // 
            this.lbMes.AutoSize = true;
            this.lbMes.Location = new System.Drawing.Point(60, 42);
            this.lbMes.Name = "lbMes";
            this.lbMes.Size = new System.Drawing.Size(27, 13);
            this.lbMes.TabIndex = 1;
            this.lbMes.Text = "Mês";
            // 
            // cbMes
            // 
            this.cbMes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMes.FormattingEnabled = true;
            this.cbMes.Items.AddRange(new object[] {
            "Janeiro",
            "Fevereiro",
            "Março",
            "Abril",
            "Maio",
            "Junho",
            "Julho",
            "Agosto",
            "Setembro",
            "Outubro",
            "Novembro",
            "Dezembro"});
            this.cbMes.Location = new System.Drawing.Point(93, 39);
            this.cbMes.Name = "cbMes";
            this.cbMes.Size = new System.Drawing.Size(220, 21);
            this.cbMes.TabIndex = 2;
            // 
            // cbAno
            // 
            this.cbAno.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAno.FormattingEnabled = true;
            this.cbAno.Location = new System.Drawing.Point(93, 12);
            this.cbAno.Name = "cbAno";
            this.cbAno.Size = new System.Drawing.Size(220, 21);
            this.cbAno.TabIndex = 3;
            // 
            // btGenLog
            // 
            this.btGenLog.Location = new System.Drawing.Point(115, 66);
            this.btGenLog.Name = "btGenLog";
            this.btGenLog.Size = new System.Drawing.Size(164, 23);
            this.btGenLog.TabIndex = 18;
            this.btGenLog.Text = "Gerar Relatório";
            this.btGenLog.UseVisualStyleBackColor = true;
            this.btGenLog.Click += new System.EventHandler(this.btGenLog_Click);
            // 
            // FaturacaoMensal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(388, 104);
            this.Controls.Add(this.btGenLog);
            this.Controls.Add(this.cbAno);
            this.Controls.Add(this.cbMes);
            this.Controls.Add(this.lbMes);
            this.Controls.Add(this.lbAno);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FaturacaoMensal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Faturação Mensal";
            this.Load += new System.EventHandler(this.ListagemChequesPorMes_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbAno;
        private System.Windows.Forms.Label lbMes;
        private System.Windows.Forms.ComboBox cbMes;
        private System.Windows.Forms.ComboBox cbAno;
        private System.Windows.Forms.Button btGenLog;
    }
}