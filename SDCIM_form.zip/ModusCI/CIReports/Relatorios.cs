﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIReports
{
    public class Relatorios
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        
        protected CIConfigGlobalParameters.CIMenuInterface m_oMenuInterface;

        public Relatorios(CIConfigGP.CIGlobalParameters oParameters, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
        {
            m_oParameters = oParameters;
            m_oMenuInterface = oMenuInterface;
        }

        public void EstatisticasReports()
        {
            EstatisticasForm oStat = new EstatisticasForm(m_oParameters);
            oStat.MdiParent = m_oMenuInterface.GetMainForm();
            oStat.Show();
        }


        public void ListagemRemessas()
        {
            ListagemRemessasForm oStat = new ListagemRemessasForm(m_oParameters, m_oMenuInterface);
            //oStat.MdiParent = m_oMainForm;
            oStat.ShowDialog();
        }

        public void resumoDeEnvios()
        {
            ResumoDeEnviosForm oRes = new ResumoDeEnviosForm(m_oParameters, m_oMenuInterface);
            //oRes.MdiParent = m_oMainForm;
            oRes.ShowDialog();
        }

        public void lotesAcomDetalhe()
        {
            LotesAcomReport oLa = new LotesAcomReport(m_oParameters, m_oMenuInterface);
            //oLa.MdiParent = m_oMainForm;
            oLa.ShowDialog();
        }

        public void lotesAcomResumo()
        {
            AcomResumoForm oLa = new AcomResumoForm(m_oParameters, m_oMenuInterface);
            //oLa.MdiParent = m_oMainForm;
            oLa.ShowDialog();
        }

        public void FaturacaoMensal()
        {
            FaturacaoMensal oLa = new FaturacaoMensal(m_oParameters, m_oMenuInterface);
            //oLa.MdiParent = m_oMainForm;
            oLa.ShowDialog();
        }
    }
}
