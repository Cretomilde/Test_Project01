﻿namespace CIReports
{
    partial class AcomResumoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AcomResumoForm));
            this.btGenLog = new System.Windows.Forms.Button();
            this.m_ctrldtFim = new System.Windows.Forms.DateTimePicker();
            this.m_ctrdtInicio = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.txBalcao = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btGenLog
            // 
            this.btGenLog.Location = new System.Drawing.Point(156, 77);
            this.btGenLog.Name = "btGenLog";
            this.btGenLog.Size = new System.Drawing.Size(180, 23);
            this.btGenLog.TabIndex = 17;
            this.btGenLog.Text = "Gerar Relatório";
            this.btGenLog.UseVisualStyleBackColor = true;
            this.btGenLog.Click += new System.EventHandler(this.btGenLog_Click);
            // 
            // m_ctrldtFim
            // 
            this.m_ctrldtFim.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrldtFim.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrldtFim.Location = new System.Drawing.Point(262, 17);
            this.m_ctrldtFim.Name = "m_ctrldtFim";
            this.m_ctrldtFim.Size = new System.Drawing.Size(202, 20);
            this.m_ctrldtFim.TabIndex = 16;
            // 
            // m_ctrdtInicio
            // 
            this.m_ctrdtInicio.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrdtInicio.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrdtInicio.Location = new System.Drawing.Point(28, 16);
            this.m_ctrdtInicio.Name = "m_ctrdtInicio";
            this.m_ctrdtInicio.Size = new System.Drawing.Size(202, 20);
            this.m_ctrdtInicio.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Balcão";
            // 
            // txBalcao
            // 
            this.txBalcao.Location = new System.Drawing.Point(82, 48);
            this.txBalcao.Name = "txBalcao";
            this.txBalcao.Size = new System.Drawing.Size(71, 20);
            this.txBalcao.TabIndex = 19;
            this.txBalcao.TextChanged += new System.EventHandler(this.txBalcao_TextChanged);
            this.txBalcao.Leave += new System.EventHandler(this.txBalcao_Leave);
            // 
            // AcomResumoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 112);
            this.Controls.Add(this.txBalcao);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btGenLog);
            this.Controls.Add(this.m_ctrldtFim);
            this.Controls.Add(this.m_ctrdtInicio);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AcomResumoForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Acom Resumo";
            this.Load += new System.EventHandler(this.AcomResumoForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btGenLog;
        private System.Windows.Forms.DateTimePicker m_ctrldtFim;
        private System.Windows.Forms.DateTimePicker m_ctrdtInicio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txBalcao;
    }
}