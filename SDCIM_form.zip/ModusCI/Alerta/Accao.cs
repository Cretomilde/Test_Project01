﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Alerta
{
    public class Accao
    {
        public enum enuTipoAccao { ND = 0, MAILWEBDAV = 1, SMS = 2, LOGDB = 3, LOGFILE = 4, EVENTVIEWER = 5, MAILEWS = 6, OUTRA = 99 };

        public int m_iACC_ID;
        public string m_sACC_DESC;
        public enuTipoAccao m_enuTIPACC_ID;
        public string m_sTIPACC_DESC;


        private void InitVars()
        {
            m_iACC_ID = 0;
            m_sACC_DESC = "ND";
            m_enuTIPACC_ID = enuTipoAccao.ND;
            m_sTIPACC_DESC = "ND";
        }

        public Accao()
        {
            InitVars();
        }

        public Accao(SqlDataReader dr)
        {
            InitVars();

            try
            {
                m_enuTIPACC_ID = (enuTipoAccao)Convert.ToInt16(dr["TIPACC_ID"]);
                m_sTIPACC_DESC = Convert.ToString(dr["TIPACC_DESC"]);
                m_iACC_ID = Convert.ToInt16(dr["ACC_ID"]);
                m_sACC_DESC = Convert.ToString(dr["ACC_DESC"]);
            }
            catch
            { 
            }
        }
        public ListViewItem MakeListViewItemAccao()
        {
            ListViewItem olvItem = new ListViewItem();
            olvItem.Text = m_iACC_ID.ToString();
            olvItem.SubItems.Add(m_sACC_DESC);
            //olvItem.SubItems.Add(m_enuTIPACC_ID.ToString());
            olvItem.SubItems.Add(m_sTIPACC_DESC);

            return olvItem;
        }

    }
}
