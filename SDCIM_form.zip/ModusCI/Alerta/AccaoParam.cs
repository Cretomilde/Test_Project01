﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Alerta
{
    public class AccaoParam
    {
        public Accao m_oAccao;

        public string m_sTIPACCP_NAME;
        public string m_sTIPACCP_VALUE;

        public string m_sACCP_NAME;
        public string m_sACCP_VALUE;

        private void InitTipAccPVars()
        {
            m_sTIPACCP_NAME = "";
            m_sTIPACCP_VALUE = "";
        }
        private void InitAccPVars()
        {
            m_sACCP_NAME = "";
            m_sACCP_VALUE = "";
        }

        public AccaoParam()
        {
            m_oAccao = new Accao();
            InitAccPVars();
            InitTipAccPVars();
        }

        public AccaoParam(SqlDataReader dr)
        {
            m_oAccao = new Accao(dr);

            InitAccPVars();
            InitTipAccPVars();

            try
            {
                m_sTIPACCP_NAME = Convert.ToString(dr["TIPACCP_NAME"]);
                m_sTIPACCP_VALUE = Convert.ToString(dr["TIPACCP_VALUE"]);
            }
            catch
            {
            }
            try
            {
                m_sACCP_NAME = Convert.ToString(dr["ACCP_NAME"]);
                m_sACCP_VALUE = Convert.ToString(dr["ACCP_VALUE"]);
            }
            catch
            {
            }
        }

        public ListViewItem MakeListViewItemParam1()
        {
            string sTipaccp_codificado = "********";
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_oAccao.m_sTIPACC_DESC.ToString();
                       
            olvItem.SubItems.Add(m_sTIPACCP_NAME);
            if (m_sTIPACCP_NAME.Equals("passwd"))
            {
                m_sTIPACCP_VALUE = sTipaccp_codificado;
            }
            olvItem.SubItems.Add(m_sTIPACCP_VALUE);

            return olvItem;
        }

        public ListViewItem MakeListViewItemParam2()
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_oAccao.m_sTIPACC_DESC.ToString();

            olvItem.SubItems.Add(m_oAccao.m_iACC_ID.ToString());
            olvItem.SubItems.Add(m_oAccao.m_sACC_DESC);

            olvItem.SubItems.Add(m_sACCP_NAME);
            olvItem.SubItems.Add(m_sACCP_VALUE);

            return olvItem;
        }


    }
}
