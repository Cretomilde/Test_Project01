﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Alerta
{
    public class AlertaSituacaoAccao
    {
        public string m_sALERT_ID;
        public DateTime m_dtAL_TIMER;
        public string m_sAL_TEXT;
        public string m_sAL_VARCHAR;

        public int m_iALACC_STATUS;
        public string m_sALACC_STATUS;
        public DateTime m_dtALACC_TIMER;
        
        public SituacaoAccao m_oSituacaoAccao;
        //public Accao m_oAccao; não necessita porque está Incluido em SituacaoAccao

        public AlertaSituacaoAccao()
        {
            m_oSituacaoAccao = new SituacaoAccao();

            m_sALERT_ID="";
            m_dtAL_TIMER=DateTime.MinValue;
            m_sAL_TEXT = "";
            m_sAL_VARCHAR = "";

            m_iALACC_STATUS=-1;
            m_sALACC_STATUS = "";
            m_dtALACC_TIMER = DateTime.MinValue;
        }

        public AlertaSituacaoAccao(SqlDataReader dr)
        {
            m_oSituacaoAccao = new SituacaoAccao(dr);

            m_sALERT_ID = dr["ALERT_ID"].ToString();
            m_dtAL_TIMER = Convert.ToDateTime(dr["AL_TIMER"]);
            m_sAL_TEXT = Convert.ToString(dr["AL_TEXT"]);
            m_sAL_VARCHAR = Convert.ToString(dr["AL_VARCHAR"]);

            m_iALACC_STATUS = Convert.ToInt16(dr["ALACC_STATUS"]);
            m_sALACC_STATUS = dr["ALERTA_STATUS_DESC"].ToString();
            m_dtALACC_TIMER = Convert.ToDateTime(dr["ALACC_TIMER"]);
        }

        public ListViewItem MakeListViewItemAlerta(string sDateTimeSysFmt)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_sALERT_ID;
            olvItem.SubItems.Add(m_dtAL_TIMER.ToString(sDateTimeSysFmt));
            olvItem.SubItems.Add(m_sAL_TEXT);
            olvItem.SubItems.Add(m_sAL_VARCHAR);

            olvItem.SubItems.Add(m_oSituacaoAccao.m_iSITUACAO_ID.ToString());
            olvItem.SubItems.Add(m_oSituacaoAccao.m_sSITUACAO_DESC);

            olvItem.SubItems.Add(m_oSituacaoAccao.m_oAccao.m_enuTIPACC_ID.ToString());
            olvItem.SubItems.Add(m_oSituacaoAccao.m_oAccao.m_sTIPACC_DESC);

            olvItem.SubItems.Add(m_oSituacaoAccao.m_oAccao.m_iACC_ID.ToString());
            olvItem.SubItems.Add(m_oSituacaoAccao.m_oAccao.m_sACC_DESC);

            olvItem.SubItems.Add(m_iALACC_STATUS.ToString() + " - " + m_sALACC_STATUS);
            olvItem.SubItems.Add(m_dtALACC_TIMER.ToString(sDateTimeSysFmt));

            return olvItem;
        }

        public void SetProcessado(CIConfigGP.CIGlobalParameters oParameters)
        {
            string sQuery = "";

            sQuery = "UPDATE ALERTA_ALERTA_ACCAO set ALACC_STATUS=1, ALACC_TIMER= getdate()";
            sQuery += " where ALERT_ID=" + m_sALERT_ID;
            sQuery += " and ACC_ID=" + m_oSituacaoAccao.m_oAccao.m_iACC_ID.ToString();

            oParameters.DirectSqlNonQuery(sQuery);
        }

        public void SetErroProcessamento(CIConfigGP.CIGlobalParameters oParameters, string sErro)
        {
            try
            {
                string sQuery = "";

                //sQuery = "UPDATE ALERTA_ALERTA_ACCAO set ALACC_STATUS=-1, ALACC_TIMER= getdate(), ALACC_ERRO='" + sErro + "'";
                sQuery = "UPDATE ALERTA_ALERTA_ACCAO set ALACC_STATUS=-1, ALACC_TIMER= getdate() ";
                sQuery += " where ALERT_ID=" + m_sALERT_ID;
                sQuery += " and ACC_ID=" + m_oSituacaoAccao.m_oAccao.m_iACC_ID.ToString();

                oParameters.DirectSqlNonQuery(sQuery);
            }
            catch 
            { 
            }
        }

    }
}
