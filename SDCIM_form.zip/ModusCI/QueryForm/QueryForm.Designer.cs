﻿namespace QueryForm
{
    partial class QueryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QueryForm));
            this.m_ctrdtInicio = new System.Windows.Forms.DateTimePicker();
            this.m_ctrldtFim = new System.Windows.Forms.DateTimePicker();
            this.m_dgrigQuery = new NBIISNET.DataGridViewBase(this.components);
            this.m_label = new NBIISNET.LabelGradient();
            this.m_btExport = new System.Windows.Forms.Button();
            this.m_cbQuery = new System.Windows.Forms.ComboBox();
            this.btRun = new System.Windows.Forms.Button();
            this.splitContainerQuerie = new System.Windows.Forms.SplitContainer();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxQuerie = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.m_dgrigQuery)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerQuerie)).BeginInit();
            this.splitContainerQuerie.Panel1.SuspendLayout();
            this.splitContainerQuerie.Panel2.SuspendLayout();
            this.splitContainerQuerie.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_ctrdtInicio
            // 
            this.m_ctrdtInicio.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrdtInicio.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrdtInicio.Location = new System.Drawing.Point(36, 16);
            this.m_ctrdtInicio.Name = "m_ctrdtInicio";
            this.m_ctrdtInicio.Size = new System.Drawing.Size(200, 20);
            this.m_ctrdtInicio.TabIndex = 0;
            // 
            // m_ctrldtFim
            // 
            this.m_ctrldtFim.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrldtFim.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrldtFim.Location = new System.Drawing.Point(36, 38);
            this.m_ctrldtFim.Name = "m_ctrldtFim";
            this.m_ctrldtFim.Size = new System.Drawing.Size(200, 20);
            this.m_ctrldtFim.TabIndex = 1;
            // 
            // m_dgrigQuery
            // 
            this.m_dgrigQuery.AllowUserToAddRows = false;
            this.m_dgrigQuery.AllowUserToDeleteRows = false;
            this.m_dgrigQuery.AllowUserToOrderColumns = true;
            this.m_dgrigQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_dgrigQuery.EnableExportar = true;
            this.m_dgrigQuery.ExportarHeader = true;
            this.m_dgrigQuery.ExportFilename = "export_%name%_%now%";
            this.m_dgrigQuery.ExportPath = "";
            this.m_dgrigQuery.Location = new System.Drawing.Point(0, 25);
            this.m_dgrigQuery.Name = "m_dgrigQuery";
            this.m_dgrigQuery.ReadOnly = true;
            this.m_dgrigQuery.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.m_dgrigQuery.Size = new System.Drawing.Size(917, 314);
            this.m_dgrigQuery.TabIndex = 4;
            // 
            // m_label
            // 
            this.m_label.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_label.ForeColor = System.Drawing.Color.White;
            this.m_label.GradientColorOne = System.Drawing.Color.Blue;
            this.m_label.GradientColorTwo = System.Drawing.Color.White;
            this.m_label.Location = new System.Drawing.Point(0, 0);
            this.m_label.Name = "m_label";
            this.m_label.Size = new System.Drawing.Size(920, 22);
            this.m_label.TabIndex = 3;
            this.m_label.Text = "Label";
            this.m_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // m_btExport
            // 
            this.m_btExport.Location = new System.Drawing.Point(158, 81);
            this.m_btExport.Name = "m_btExport";
            this.m_btExport.Size = new System.Drawing.Size(75, 23);
            this.m_btExport.TabIndex = 0;
            this.m_btExport.Text = "&Export";
            this.m_btExport.UseVisualStyleBackColor = true;
            this.m_btExport.Click += new System.EventHandler(this.m_btExport_Click);
            // 
            // m_cbQuery
            // 
            this.m_cbQuery.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.m_cbQuery.FormattingEnabled = true;
            this.m_cbQuery.Location = new System.Drawing.Point(12, 61);
            this.m_cbQuery.Name = "m_cbQuery";
            this.m_cbQuery.Size = new System.Drawing.Size(225, 21);
            this.m_cbQuery.TabIndex = 2;
            this.m_cbQuery.SelectedIndexChanged += new System.EventHandler(this.m_cbQuery_SelectedIndexChanged);
            // 
            // btRun
            // 
            this.btRun.Location = new System.Drawing.Point(51, 84);
            this.btRun.Name = "btRun";
            this.btRun.Size = new System.Drawing.Size(75, 23);
            this.btRun.TabIndex = 3;
            this.btRun.Text = "&Run";
            this.btRun.UseVisualStyleBackColor = true;
            this.btRun.Click += new System.EventHandler(this.btRun_Click);
            // 
            // splitContainerQuerie
            // 
            this.splitContainerQuerie.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainerQuerie.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainerQuerie.Location = new System.Drawing.Point(15, 1);
            this.splitContainerQuerie.Name = "splitContainerQuerie";
            this.splitContainerQuerie.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainerQuerie.Panel1
            // 
            this.splitContainerQuerie.Panel1.Controls.Add(this.label2);
            this.splitContainerQuerie.Panel1.Controls.Add(this.btRun);
            this.splitContainerQuerie.Panel1.Controls.Add(this.textBoxQuerie);
            this.splitContainerQuerie.Panel1.Controls.Add(this.m_cbQuery);
            this.splitContainerQuerie.Panel1.Controls.Add(this.label1);
            this.splitContainerQuerie.Panel1.Controls.Add(this.m_ctrdtInicio);
            this.splitContainerQuerie.Panel1.Controls.Add(this.m_ctrldtFim);
            this.splitContainerQuerie.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainerQuerie.Panel2
            // 
            this.splitContainerQuerie.Panel2.Controls.Add(this.m_label);
            this.splitContainerQuerie.Panel2.Controls.Add(this.m_dgrigQuery);
            this.splitContainerQuerie.Size = new System.Drawing.Size(920, 458);
            this.splitContainerQuerie.SplitterDistance = 112;
            this.splitContainerQuerie.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "a:";
            // 
            // textBoxQuerie
            // 
            this.textBoxQuerie.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxQuerie.Location = new System.Drawing.Point(253, 3);
            this.textBoxQuerie.Multiline = true;
            this.textBoxQuerie.Name = "textBoxQuerie";
            this.textBoxQuerie.Size = new System.Drawing.Size(664, 106);
            this.textBoxQuerie.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "de:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.m_btExport);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.groupBox1.Location = new System.Drawing.Point(4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(243, 107);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Consultas";
            // 
            // QueryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(947, 471);
            this.Controls.Add(this.splitContainerQuerie);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "QueryForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Query";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.QueryForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.m_dgrigQuery)).EndInit();
            this.splitContainerQuerie.Panel1.ResumeLayout(false);
            this.splitContainerQuerie.Panel1.PerformLayout();
            this.splitContainerQuerie.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerQuerie)).EndInit();
            this.splitContainerQuerie.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker m_ctrdtInicio;
        private System.Windows.Forms.DateTimePicker m_ctrldtFim;
        private NBIISNET.LabelGradient m_label;
        private NBIISNET.DataGridViewBase m_dgrigQuery;
        private System.Windows.Forms.Button m_btExport;
        private System.Windows.Forms.ComboBox m_cbQuery;
        private System.Windows.Forms.Button btRun;
        private System.Windows.Forms.SplitContainer splitContainerQuerie;
        private System.Windows.Forms.TextBox textBoxQuerie;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

