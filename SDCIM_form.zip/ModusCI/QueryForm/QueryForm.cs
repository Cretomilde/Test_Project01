﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace QueryForm
{
    public partial class QueryForm : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public QueryForm(CIConfigGP.CIGlobalParameters oParameters)
        {
            InitializeComponent();
            m_oParameters = oParameters;
        }

        private void QueryForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = System.Windows.Forms.FormWindowState.Maximized;

                try
                {
                    LoadComboboxQuery();
                }
                catch 
                { 
                }

                DefinirDatas();

                m_label.Text = "";

                m_dgrigQuery.ExportPath = m_oParameters.GetProfileString("Query","PATHS","PathExport","");

                GenericLog.GenLogRegistarInfo("QueryForm_Load", "QueryForm.cs", 47);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Dispose();
            }
        }

        protected void LoadComboboxQuery()
        {
            DataSet oDataSet = null;

            string sQuery = "select Q_DESCRICAO, Q_QUERY from QUERY where Q_GRUPO >= " + m_oParameters.UserLogged.m_iUserGroup.ToString() + " order by q_grupo, q_descricao";
            oDataSet = m_oParameters.DirectSqlDataSet(sQuery, "Query");

            m_cbQuery.DataSource = oDataSet.Tables[0];
            m_cbQuery.DisplayMember = "Q_DESCRICAO";
            m_cbQuery.ValueMember = "Q_QUERY";

            if (m_oParameters.UserLogged.m_iUserGroup != 0)
            {
                //btMyRun.Visible = false;
                textBoxQuerie.Enabled = false;
                //m_cbQuery.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            }
            textBoxQuerie.Text = m_cbQuery.SelectedValue.ToString();

        }

        protected void DefinirDatas()
        {
            m_ctrldtFim.Value = DateTime.Now.Date.AddDays(+1);
            m_ctrdtInicio.Value = DateTime.Now.Date;
        }


        protected string Translate(string sQuerieIni)
        {
            string sQuerieFinal = sQuerieIni;

            sQuerieFinal = sQuerieFinal.Replace("%AAAA%", m_ctrdtInicio.Value.Year.ToString());
            sQuerieFinal = sQuerieFinal.Replace("%MM%", m_ctrdtInicio.Value.Month.ToString());

            sQuerieFinal = sQuerieFinal.Replace("%DATAINI%", "'" +  m_ctrdtInicio.Value.ToString(m_oParameters.DateFormat) + "'");
            sQuerieFinal = sQuerieFinal.Replace("%DATAFIM%", "'" + m_ctrldtFim.Value.ToString(m_oParameters.DateFormat) + "'");

            return sQuerieFinal;
        }

        private void m_btExport_Click(object sender, EventArgs e)
        {
            try
            {
                m_dgrigQuery.ExportarParaExcel(false);
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();

                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btRun_Click(object sender, EventArgs e)
        {
            string sQuery;
            DataSet oDs = null;

            try
            {
                Cursor = Cursors.WaitCursor;
                frmEspereUmMomento.ShowWaitForm();

                m_label.Text = "";

                //sQuery = Translate(Convert.ToString(m_cbQuery.Text));
                sQuery = Translate(Convert.ToString(textBoxQuerie.Text));

//                GenericLog.GenLogRegistarAlerta(sQuery, "QueryForm.cs", 49);

                oDs = m_oParameters.DirectSqlDataSet(sQuery, "QUERY");

                m_dgrigQuery.DataSource = oDs.Tables[0];

                m_label.Text = oDs.Tables[0].Rows.Count.ToString() + " Linhas retornadas";

                m_dgrigQuery.ExportFilename = "Query_%now%";

                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();

                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void m_cbQuery_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                textBoxQuerie.Text = m_cbQuery.SelectedValue.ToString();
            }
            catch 
            { 
            }
        }
    }
}