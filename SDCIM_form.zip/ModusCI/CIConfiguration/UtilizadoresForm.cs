﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;
using System.Collections;

namespace CIConfiguration
{
    public partial class UtilizadoresForm : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        protected CIConfigGlobalParameters.CIMenuInterface m_oMenuInterface;
        protected CIConfigGP.User m_oCurrUser;

        public UtilizadoresForm(CIConfigGP.CIGlobalParameters oParameters, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_oMenuInterface = oMenuInterface;
        }

        private void UtilizadoresForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = System.Windows.Forms.FormWindowState.Maximized;

                btDelete.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);
                btInsert.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);
                btUpdate.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);
                m_oMenuInterface.utilizadoresEnable(false);
                RefreshUsers();
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "UtilizadoresForm.cs", 29);
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Dispose();
            }
        }
        private void RefreshUsers()
        {
            listViewUsers.MyClear();

            SqlDataReader drU = null;
            string sQuery = "select * from VW_PASSWD_GROUP order by GROUP_ID";

            try
            {
                comboBoxUserGroup.DataSource = null;
                comboBoxUserGroup.Items.Clear();
                textBoxFullName.Text = "";
                textBoxLogin.Text = "";

                preenheComboBox();

                drU = m_oParameters.DirectSqlDataReader(sQuery);
                while (drU.Read())
                {
                    AddUser2ListView(drU);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (drU != null)
                {
                    drU.Close();
                }
            }
        }

        private ListViewItem MakeListViewItemUser(CIConfigGP.User oUser)
        {
            ListViewItem olvItem = new ListViewItem();
            olvItem.Text = oUser.m_sUserName;
            olvItem.SubItems.Add(oUser.m_sUserFullName);
            olvItem.SubItems.Add(oUser.m_sGroupName);

            return olvItem;
        }

        private void AddUser2ListView(SqlDataReader dr)
        {
            CIConfigGP.User oUser = new CIConfigGP.User(dr);

            ListViewItem olvItem = MakeListViewItemUser(oUser);

            olvItem.Tag = oUser;

            listViewUsers.Items.Add(olvItem);
        }

        private void preenheComboBox()
        {
            DataSet ds = null;

            if (comboBoxUserGroup.Items.Count > 0)
            {
                return;
            }

            try
            {
                string sComm = "select * from dbo.VW_GRUPO";

                ds = m_oParameters.DirectSqlDataSet(sComm, "GRUPO");
                comboBoxUserGroup.DataSource = ds.Tables[0];
                comboBoxUserGroup.DisplayMember = "GROUP_NAME";
                comboBoxUserGroup.ValueMember = "GROUP_ID";
            }
            finally
            {
                if (ds != null)
                {
                    ds.Dispose();
                    ds = null;
                }
            }
        }

        private void DisplaySelectedUser()
        {
            ArrayList aoItems = new ArrayList();

            DataTable dt = null;

            int iSelected=0;

            try
            {
                if (listViewUsers.SelectedItems.Count != 1)
                    return;

                m_oCurrUser = (CIConfigGP.User)listViewUsers.GetTag();
                textBoxLogin.Text = m_oCurrUser.m_sUserName;
                textBoxFullName.Text = m_oCurrUser.m_sUserFullName;

                preenheComboBox();

                dt = (DataTable)comboBoxUserGroup.DataSource;
                for (int iIndex = 0; iIndex < dt.Rows.Count; iIndex++ )
                {
                    if (dt.Rows[iIndex]["GROUP_ID"].ToString() == m_oCurrUser.m_iUserGroup.ToString())
                    {
                        iSelected = iIndex;
                    }
                }

                if (comboBoxUserGroup.Items.Count > 0)
                {
                    comboBoxUserGroup.SelectedIndex = iSelected;
                }
   
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void listViewUsers_SelectedIndexChanged(object sender, EventArgs e)
        {
            DisplaySelectedUser();
        }

        private void btRefresh_Click(object sender, EventArgs e)
        {
            RefreshUsers();
        }

        private void btInsert_Click(object sender, EventArgs e)
        {
            try
            {   
                ArrayList oParam = new ArrayList();
                string sSpNome = "dbo.Insert_Utilizadores";

                oParam.Add(new GeneralDBParameters("@LoginName", textBoxLogin.Text));

                oParam.Add(new GeneralDBParameters("@GroupId", comboBoxUserGroup.SelectedValue.ToString()));
                oParam.Add(new GeneralDBParameters("@UserFullName", textBoxFullName.Text));
                if(MessageBox.Show("Tem a certeza que deseja inserir o utilizador " + textBoxLogin.Text, Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes)
                {
                    m_oParameters.DirectStoredProcedureNonQuery(sSpNome, ref oParam);
                    MessageBox.Show("Utilizador inserido com sucesso", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                RefreshUsers();
                string sSmg = "User: " + textBoxLogin.Text + " Perfil: " + comboBoxUserGroup.SelectedValue.ToString() + " Inserido";
                GenericLog.GenLogRegistarAlerta(sSmg, "InsertUser()", 100);
                m_oParameters.EnviarAlertaSituacao(100, sSmg);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void btUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                ArrayList oParam = new ArrayList();
                string sSpNome = "dbo.Update_Utilizadores";
    

                oParam.Add(new GeneralDBParameters("@LoginName", textBoxLogin.Text));
                oParam.Add(new GeneralDBParameters("@GroupId", comboBoxUserGroup.SelectedValue.ToString()));
                oParam.Add(new GeneralDBParameters("@UserFullName", textBoxFullName.Text));
                if (MessageBox.Show("Tem a certeza que deseja actualizar o utilizador" + textBoxLogin.Text, Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) ==DialogResult.Yes)
                {
                    m_oParameters.DirectStoredProcedureNonQuery(sSpNome, ref oParam);
                }
                RefreshUsers();

                string sSmg = "User: " + textBoxLogin.Text + " Perfil: " + comboBoxUserGroup.SelectedValue.ToString() + " alterado";
                GenericLog.GenLogRegistarAlerta(sSmg, "UpdateUser()", 100);
                m_oParameters.EnviarAlertaSituacao(100, sSmg);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btDelete_Click(object sender, EventArgs e)
        {
            try
            {                
                ArrayList oParam = new ArrayList();
                string sSpNome = "dbo.Delete_Utilizadores";

                if (MessageBox.Show("Tem a certeza que deseja eleminar o utilizador" + textBoxLogin.Text, Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) 
                {
                    oParam.Add(new GeneralDBParameters("@LoginName", textBoxLogin.Text));
                    m_oParameters.DirectStoredProcedureNonQuery(sSpNome, ref oParam);
                }
                RefreshUsers();

                string sSmg = "User: " + textBoxLogin.Text + " Perfil: " + comboBoxUserGroup.SelectedValue.ToString() + " Removido";
                GenericLog.GenLogRegistarAlerta(sSmg, "DeleteUser()", 100);
                m_oParameters.EnviarAlertaSituacao(100, sSmg);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonExitJanela_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

    }
}