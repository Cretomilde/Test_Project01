﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIConfiguration
{
    public class Config
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        //protected Form m_oMainForm;
        protected CIConfigGlobalParameters.CIMenuInterface m_oMenuInterface;

        public Config(CIConfigGP.CIGlobalParameters oParameters, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
        {
            m_oParameters = oParameters;
           // m_oMainForm = oMainForm;
            m_oMenuInterface = oMenuInterface;
     
        }

        public void BalcaoConfig()
        {
            BalcaoForm oForm = new BalcaoForm(m_oParameters, m_oMenuInterface);
            oForm.MdiParent = m_oMenuInterface.GetMainForm();
            oForm.Show();
        }

        public void UtilizadorConfig()
        {
            UtilizadoresForm oForm = new UtilizadoresForm(m_oParameters, m_oMenuInterface);
            oForm.MdiParent = m_oMenuInterface.GetMainForm();
            oForm.Show();
        }

        public void CIConfiguracao()
        {
            CIConfigForm oForm = new CIConfigForm(m_oParameters, m_oMenuInterface);
            oForm.MdiParent = m_oMenuInterface.GetMainForm();
            oForm.Show();
        }
    }
}
