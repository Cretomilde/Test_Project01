﻿namespace CIConfiguration
{
    partial class CIConfigForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            m_oMenuInterface.configuracaoEnable(true);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CIConfigForm));
            this.label1 = new System.Windows.Forms.Label();
            this.maskedTextBoxIteracao = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.maskedTextBoxMaxDocsTranche = new System.Windows.Forms.MaskedTextBox();
            this.listViewSituacoesAccoes = new NBIISNET.ListViewBase();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewAccoes = new NBIISNET.ListViewBase();
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btLigar = new System.Windows.Forms.Button();
            this.btDesligar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.maskedTextBoxFimTemp = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxInicioTemp = new System.Windows.Forms.MaskedTextBox();
            this.buttonActualizar = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.listViewBaseSituacoes = new NBIISNET.ListViewBase();
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewAccaoParam1 = new NBIISNET.ListViewBase();
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader26 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader27 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewAccaoParam2 = new NBIISNET.ListViewBase();
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.maskedTextBoxPercentagemAlerta = new System.Windows.Forms.MaskedTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btActualizarAlertas = new System.Windows.Forms.Button();
            this.maskedTextBoxHoraEsperaRemin = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxHoraEsperaEnvm = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxHoraFim = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxHoraIni = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.maskedTextBoxMinDias = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxMaxDias = new System.Windows.Forms.MaskedTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(95, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tempo entre cada iteração (minutos)";
            // 
            // maskedTextBoxIteracao
            // 
            this.maskedTextBoxIteracao.AllowDrop = true;
            this.maskedTextBoxIteracao.Location = new System.Drawing.Point(277, 6);
            this.maskedTextBoxIteracao.Mask = "000";
            this.maskedTextBoxIteracao.Name = "maskedTextBoxIteracao";
            this.maskedTextBoxIteracao.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBoxIteracao.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(321, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Max Documentos por tranche";
            // 
            // maskedTextBoxMaxDocsTranche
            // 
            this.maskedTextBoxMaxDocsTranche.Location = new System.Drawing.Point(469, 6);
            this.maskedTextBoxMaxDocsTranche.Mask = "000";
            this.maskedTextBoxMaxDocsTranche.Name = "maskedTextBoxMaxDocsTranche";
            this.maskedTextBoxMaxDocsTranche.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBoxMaxDocsTranche.TabIndex = 2;
            // 
            // listViewSituacoesAccoes
            // 
            this.listViewSituacoesAccoes.AllowColumnReorder = true;
            this.listViewSituacoesAccoes.AutoArrange = false;
            this.listViewSituacoesAccoes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader3,
            this.columnHeader2,
            this.columnHeader4});
            this.listViewSituacoesAccoes.EnableExportar = true;
            this.listViewSituacoesAccoes.FullRowSelect = true;
            this.listViewSituacoesAccoes.GridLines = true;
            this.listViewSituacoesAccoes.HideSelection = false;
            this.listViewSituacoesAccoes.Location = new System.Drawing.Point(15, 48);
            this.listViewSituacoesAccoes.MultiSelect = false;
            this.listViewSituacoesAccoes.Name = "listViewSituacoesAccoes";
            this.listViewSituacoesAccoes.Size = new System.Drawing.Size(292, 329);
            this.listViewSituacoesAccoes.TabIndex = 15;
            this.listViewSituacoesAccoes.TabStop = false;
            this.listViewSituacoesAccoes.UseCompatibleStateImageBehavior = false;
            this.listViewSituacoesAccoes.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Situacao ID";
            this.columnHeader1.Width = 58;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Situação Desc";
            this.columnHeader3.Width = 88;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Acção ID";
            this.columnHeader2.Width = 45;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Acção Desc";
            this.columnHeader4.Width = 94;
            // 
            // listViewAccoes
            // 
            this.listViewAccoes.AllowColumnReorder = true;
            this.listViewAccoes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader6});
            this.listViewAccoes.EnableExportar = true;
            this.listViewAccoes.FullRowSelect = true;
            this.listViewAccoes.GridLines = true;
            this.listViewAccoes.HideSelection = false;
            this.listViewAccoes.Location = new System.Drawing.Point(418, 19);
            this.listViewAccoes.MultiSelect = false;
            this.listViewAccoes.Name = "listViewAccoes";
            this.listViewAccoes.Size = new System.Drawing.Size(251, 159);
            this.listViewAccoes.TabIndex = 16;
            this.listViewAccoes.TabStop = false;
            this.listViewAccoes.UseCompatibleStateImageBehavior = false;
            this.listViewAccoes.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "ID";
            this.columnHeader7.Width = 43;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Acção Descrição";
            this.columnHeader8.Width = 125;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Tipo";
            this.columnHeader6.Width = 67;
            // 
            // btLigar
            // 
            this.btLigar.Location = new System.Drawing.Point(419, 184);
            this.btLigar.Name = "btLigar";
            this.btLigar.Size = new System.Drawing.Size(250, 23);
            this.btLigar.TabIndex = 14;
            this.btLigar.Text = "&Associar Situação / Acção";
            this.btLigar.UseVisualStyleBackColor = true;
            this.btLigar.Click += new System.EventHandler(this.btLigar_Click);
            // 
            // btDesligar
            // 
            this.btDesligar.Location = new System.Drawing.Point(15, 18);
            this.btDesligar.Name = "btDesligar";
            this.btDesligar.Size = new System.Drawing.Size(292, 24);
            this.btDesligar.TabIndex = 15;
            this.btDesligar.Text = "&Desassociar Acção";
            this.btDesligar.UseVisualStyleBackColor = true;
            this.btDesligar.Click += new System.EventHandler(this.btDesligar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(510, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 13);
            this.label3.TabIndex = 24;
            this.label3.Text = "Inicio/Fim de Paragem";
            // 
            // maskedTextBoxFimTemp
            // 
            this.maskedTextBoxFimTemp.Location = new System.Drawing.Point(669, 6);
            this.maskedTextBoxFimTemp.Mask = "00:00";
            this.maskedTextBoxFimTemp.Name = "maskedTextBoxFimTemp";
            this.maskedTextBoxFimTemp.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBoxFimTemp.TabIndex = 4;
            this.maskedTextBoxFimTemp.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBoxInicioTemp
            // 
            this.maskedTextBoxInicioTemp.BeepOnError = true;
            this.maskedTextBoxInicioTemp.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePrompt;
            this.maskedTextBoxInicioTemp.Location = new System.Drawing.Point(624, 6);
            this.maskedTextBoxInicioTemp.Mask = "00:00";
            this.maskedTextBoxInicioTemp.Name = "maskedTextBoxInicioTemp";
            this.maskedTextBoxInicioTemp.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBoxInicioTemp.TabIndex = 3;
            this.maskedTextBoxInicioTemp.ValidatingType = typeof(System.DateTime);
            // 
            // buttonActualizar
            // 
            this.buttonActualizar.Location = new System.Drawing.Point(941, 3);
            this.buttonActualizar.Name = "buttonActualizar";
            this.buttonActualizar.Size = new System.Drawing.Size(75, 23);
            this.buttonActualizar.TabIndex = 7;
            this.buttonActualizar.Text = "Actualizar";
            this.buttonActualizar.UseVisualStyleBackColor = true;
            this.buttonActualizar.Click += new System.EventHandler(this.buttonActualizar_Click_1);
            // 
            // listViewBaseSituacoes
            // 
            this.listViewBaseSituacoes.AllowColumnReorder = true;
            this.listViewBaseSituacoes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader10});
            this.listViewBaseSituacoes.EnableExportar = true;
            this.listViewBaseSituacoes.FullRowSelect = true;
            this.listViewBaseSituacoes.GridLines = true;
            this.listViewBaseSituacoes.HideSelection = false;
            this.listViewBaseSituacoes.Location = new System.Drawing.Point(6, 19);
            this.listViewBaseSituacoes.MultiSelect = false;
            this.listViewBaseSituacoes.Name = "listViewBaseSituacoes";
            this.listViewBaseSituacoes.Size = new System.Drawing.Size(402, 358);
            this.listViewBaseSituacoes.TabIndex = 29;
            this.listViewBaseSituacoes.TabStop = false;
            this.listViewBaseSituacoes.UseCompatibleStateImageBehavior = false;
            this.listViewBaseSituacoes.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Situacao ID";
            this.columnHeader9.Width = 39;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Situação Desc";
            this.columnHeader10.Width = 349;
            // 
            // listViewAccaoParam1
            // 
            this.listViewAccaoParam1.AllowColumnReorder = true;
            this.listViewAccaoParam1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader16,
            this.columnHeader26,
            this.columnHeader27});
            this.listViewAccaoParam1.EnableExportar = true;
            this.listViewAccaoParam1.FullRowSelect = true;
            this.listViewAccaoParam1.GridLines = true;
            this.listViewAccaoParam1.HideSelection = false;
            this.listViewAccaoParam1.Location = new System.Drawing.Point(6, 23);
            this.listViewAccaoParam1.MultiSelect = false;
            this.listViewAccaoParam1.Name = "listViewAccaoParam1";
            this.listViewAccaoParam1.Size = new System.Drawing.Size(390, 169);
            this.listViewAccaoParam1.TabIndex = 30;
            this.listViewAccaoParam1.TabStop = false;
            this.listViewAccaoParam1.UseCompatibleStateImageBehavior = false;
            this.listViewAccaoParam1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Tipo Acção Desc";
            this.columnHeader16.Width = 89;
            // 
            // columnHeader26
            // 
            this.columnHeader26.Text = "Tipo Acção Name";
            this.columnHeader26.Width = 102;
            // 
            // columnHeader27
            // 
            this.columnHeader27.Text = "Tipo Acção Value";
            this.columnHeader27.Width = 191;
            // 
            // listViewAccaoParam2
            // 
            this.listViewAccaoParam2.AllowColumnReorder = true;
            this.listViewAccaoParam2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader19});
            this.listViewAccaoParam2.EnableExportar = true;
            this.listViewAccaoParam2.FullRowSelect = true;
            this.listViewAccaoParam2.GridLines = true;
            this.listViewAccaoParam2.HideSelection = false;
            this.listViewAccaoParam2.Location = new System.Drawing.Point(457, 23);
            this.listViewAccaoParam2.MultiSelect = false;
            this.listViewAccaoParam2.Name = "listViewAccaoParam2";
            this.listViewAccaoParam2.Size = new System.Drawing.Size(531, 169);
            this.listViewAccaoParam2.TabIndex = 31;
            this.listViewAccaoParam2.TabStop = false;
            this.listViewAccaoParam2.UseCompatibleStateImageBehavior = false;
            this.listViewAccaoParam2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Tipo Acção Desc";
            this.columnHeader11.Width = 101;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Acção ID";
            this.columnHeader12.Width = 62;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Acção desc";
            this.columnHeader13.Width = 85;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Acção Name";
            this.columnHeader14.Width = 84;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "Acção Value";
            this.columnHeader19.Width = 189;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listViewAccaoParam1);
            this.groupBox1.Controls.Add(this.listViewAccaoParam2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 445);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1004, 198);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Parametrização";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.listViewAccoes);
            this.groupBox2.Controls.Add(this.btLigar);
            this.groupBox2.Controls.Add(this.listViewBaseSituacoes);
            this.groupBox2.Location = new System.Drawing.Point(12, 56);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(675, 383);
            this.groupBox2.TabIndex = 33;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Situação / Acção";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.maskedTextBoxPercentagemAlerta);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.btActualizarAlertas);
            this.groupBox4.Controls.Add(this.maskedTextBoxHoraEsperaRemin);
            this.groupBox4.Controls.Add(this.maskedTextBoxHoraEsperaEnvm);
            this.groupBox4.Controls.Add(this.maskedTextBoxHoraFim);
            this.groupBox4.Controls.Add(this.maskedTextBoxHoraIni);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Location = new System.Drawing.Point(419, 213);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(250, 164);
            this.groupBox4.TabIndex = 42;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Alertas";
            // 
            // maskedTextBoxPercentagemAlerta
            // 
            this.maskedTextBoxPercentagemAlerta.AllowDrop = true;
            this.maskedTextBoxPercentagemAlerta.Location = new System.Drawing.Point(155, 98);
            this.maskedTextBoxPercentagemAlerta.Mask = "000";
            this.maskedTextBoxPercentagemAlerta.Name = "maskedTextBoxPercentagemAlerta";
            this.maskedTextBoxPercentagemAlerta.Size = new System.Drawing.Size(30, 20);
            this.maskedTextBoxPercentagemAlerta.TabIndex = 12;
            this.maskedTextBoxPercentagemAlerta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.Control;
            this.label11.Location = new System.Drawing.Point(6, 101);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(143, 13);
            this.label11.TabIndex = 45;
            this.label11.Text = "% de imagens sem qualidade";
            // 
            // btActualizarAlertas
            // 
            this.btActualizarAlertas.Location = new System.Drawing.Point(86, 126);
            this.btActualizarAlertas.Name = "btActualizarAlertas";
            this.btActualizarAlertas.Size = new System.Drawing.Size(66, 22);
            this.btActualizarAlertas.TabIndex = 13;
            this.btActualizarAlertas.Text = "Actualizar";
            this.btActualizarAlertas.UseVisualStyleBackColor = true;
            this.btActualizarAlertas.Click += new System.EventHandler(this.btActualizarAlertas_Click);
            // 
            // maskedTextBoxHoraEsperaRemin
            // 
            this.maskedTextBoxHoraEsperaRemin.AllowDrop = true;
            this.maskedTextBoxHoraEsperaRemin.Location = new System.Drawing.Point(138, 71);
            this.maskedTextBoxHoraEsperaRemin.Mask = "000";
            this.maskedTextBoxHoraEsperaRemin.Name = "maskedTextBoxHoraEsperaRemin";
            this.maskedTextBoxHoraEsperaRemin.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBoxHoraEsperaRemin.TabIndex = 11;
            this.maskedTextBoxHoraEsperaRemin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBoxHoraEsperaEnvm
            // 
            this.maskedTextBoxHoraEsperaEnvm.AllowDrop = true;
            this.maskedTextBoxHoraEsperaEnvm.Location = new System.Drawing.Point(117, 44);
            this.maskedTextBoxHoraEsperaEnvm.Mask = "000";
            this.maskedTextBoxHoraEsperaEnvm.Name = "maskedTextBoxHoraEsperaEnvm";
            this.maskedTextBoxHoraEsperaEnvm.Size = new System.Drawing.Size(32, 20);
            this.maskedTextBoxHoraEsperaEnvm.TabIndex = 10;
            this.maskedTextBoxHoraEsperaEnvm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBoxHoraFim
            // 
            this.maskedTextBoxHoraFim.Location = new System.Drawing.Point(170, 15);
            this.maskedTextBoxHoraFim.Mask = "00:00";
            this.maskedTextBoxHoraFim.Name = "maskedTextBoxHoraFim";
            this.maskedTextBoxHoraFim.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBoxHoraFim.TabIndex = 9;
            this.maskedTextBoxHoraFim.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.maskedTextBoxHoraFim.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBoxHoraIni
            // 
            this.maskedTextBoxHoraIni.BeepOnError = true;
            this.maskedTextBoxHoraIni.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePrompt;
            this.maskedTextBoxHoraIni.Location = new System.Drawing.Point(125, 15);
            this.maskedTextBoxHoraIni.Mask = "00:00";
            this.maskedTextBoxHoraIni.Name = "maskedTextBoxHoraIni";
            this.maskedTextBoxHoraIni.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBoxHoraIni.TabIndex = 8;
            this.maskedTextBoxHoraIni.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.maskedTextBoxHoraIni.ValidatingType = typeof(System.DateTime);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.Control;
            this.label10.Location = new System.Drawing.Point(6, 74);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(126, 13);
            this.label10.TabIndex = 41;
            this.label10.Text = "Horas Espera Remessas ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.Control;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(158, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(13, 20);
            this.label7.TabIndex = 39;
            this.label7.Text = "/";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(6, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 13);
            this.label9.TabIndex = 40;
            this.label9.Text = "Horas Espera ENVM";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(6, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 13);
            this.label8.TabIndex = 36;
            this.label8.Text = "Inicio/Fim de Paragem";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btDesligar);
            this.groupBox3.Controls.Add(this.listViewSituacoesAccoes);
            this.groupBox3.Location = new System.Drawing.Point(693, 56);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(323, 383);
            this.groupBox3.TabIndex = 34;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Associações";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(657, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 20);
            this.label4.TabIndex = 35;
            this.label4.Text = "/";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(710, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 13);
            this.label5.TabIndex = 36;
            this.label5.Text = "Min/Max Dias";
            // 
            // maskedTextBoxMinDias
            // 
            this.maskedTextBoxMinDias.Location = new System.Drawing.Point(783, 6);
            this.maskedTextBoxMinDias.Mask = "000";
            this.maskedTextBoxMinDias.Name = "maskedTextBoxMinDias";
            this.maskedTextBoxMinDias.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBoxMinDias.TabIndex = 5;
            // 
            // maskedTextBoxMaxDias
            // 
            this.maskedTextBoxMaxDias.Location = new System.Drawing.Point(828, 6);
            this.maskedTextBoxMaxDias.Mask = "000";
            this.maskedTextBoxMaxDias.Name = "maskedTextBoxMaxDias";
            this.maskedTextBoxMaxDias.Size = new System.Drawing.Size(35, 20);
            this.maskedTextBoxMaxDias.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.Control;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(817, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(13, 20);
            this.label6.TabIndex = 37;
            this.label6.Text = "/";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Margin = new System.Windows.Forms.Padding(0, 1, 5, 2);
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.AccessibleRole = System.Windows.Forms.AccessibleRole.Separator;
            this.toolStrip1.AllowDrop = true;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0);
            this.toolStrip1.Size = new System.Drawing.Size(1028, 39);
            this.toolStrip1.TabIndex = 23;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // CIConfigForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 655);
            this.Controls.Add(this.maskedTextBoxMaxDias);
            this.Controls.Add(this.maskedTextBoxMinDias);
            this.Controls.Add(this.maskedTextBoxFimTemp);
            this.Controls.Add(this.maskedTextBoxInicioTemp);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.buttonActualizar);
            this.Controls.Add(this.maskedTextBoxIteracao);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.maskedTextBoxMaxDocsTranche);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CIConfigForm";
            this.ShowInTaskbar = false;
            this.Text = "Configuração";
            this.Load += new System.EventHandler(this.CIConfigForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxIteracao;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxMaxDocsTranche;
        private NBIISNET.ListViewBase listViewSituacoesAccoes;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private NBIISNET.ListViewBase listViewAccoes;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Button btLigar;
        private System.Windows.Forms.Button btDesligar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonActualizar;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxFimTemp;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxInicioTemp;
        private System.Windows.Forms.ToolTip toolTip1;
        private NBIISNET.ListViewBase listViewBaseSituacoes;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private NBIISNET.ListViewBase listViewAccaoParam1;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader26;
        private System.Windows.Forms.ColumnHeader columnHeader27;
        private NBIISNET.ListViewBase listViewAccaoParam2;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxMinDias;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxMaxDias;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxHoraFim;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxHoraIni;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxHoraEsperaRemin;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxHoraEsperaEnvm;
        private System.Windows.Forms.Button btActualizarAlertas;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxPercentagemAlerta;
    }
}