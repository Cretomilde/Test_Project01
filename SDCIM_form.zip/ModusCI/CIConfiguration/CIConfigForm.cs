﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using Alerta;
using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIConfiguration
{
    public partial class CIConfigForm : Form
    {

        protected CIConfigGP.CIGlobalParameters m_oParameters;
        protected CIConfigGlobalParameters.CIMenuInterface m_oMenuInterface;

        protected int m_iLastSituacao;


        public CIConfigForm(CIConfigGP.CIGlobalParameters oParameters, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_oMenuInterface = oMenuInterface;
        }

        private void DisableButtons()
        {
            btLigar.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);
            btDesligar.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);
            buttonActualizar.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);
            btActualizarAlertas.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);

        }

        private void CIConfigForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
                m_oMenuInterface.configuracaoEnable(false);
                LoadParametros();

                DisableButtons();
                

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "CIConfigForm.cs", 19);
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Dispose();
            }
        }

        private void AddSituacao2ListViews(SqlDataReader dr)
        {
            SituacaoAccao oAlertaSit = new SituacaoAccao(dr);

            if (m_iLastSituacao != oAlertaSit.m_iSITUACAO_ID)
            {
                ListViewItem oItemSituacao = oAlertaSit.MakeListViewItemSituacao();
                oItemSituacao.Tag = oAlertaSit;
                listViewBaseSituacoes.Items.Add(oItemSituacao);
                m_iLastSituacao = oAlertaSit.m_iSITUACAO_ID;
            }

            ListViewItem oItemSituacaoAccao = oAlertaSit.MakeListViewItemSituacaoAccao();
            oItemSituacaoAccao.Tag = oAlertaSit;
            listViewSituacoesAccoes.Items.Add(oItemSituacaoAccao);
        }

        private void RefreshSituacoesAccoes()
        {
            string sQuery = "SELECT * FROM  VW_AL_SITUACAO_ACCAO order by SITUACAO_ID, ACC_id";
            SqlDataReader drS = null;

            try
            {
                listViewBaseSituacoes.MyClear();
                listViewSituacoesAccoes.MyClear();

                drS = m_oParameters.DirectSqlDataReader(sQuery);
                while (drS.Read())
                {
                    AddSituacao2ListViews(drS);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (drS != null)
                {
                    drS.Close();
                }
            }
        }

        private void AddAccao2ListView(SqlDataReader dr)
        {
            Accao oAccao= new Accao(dr);

            ListViewItem olvItem = oAccao.MakeListViewItemAccao();

            olvItem.Tag = oAccao;

            listViewAccoes.Items.Add(olvItem);
        }

        private void RefreshAccoes()
        {

            string sQuery = "select * from VW_AL_ACCAO_TIPO order by ACC_ID";
            
            SqlDataReader drA = null;

            try
            {
                listViewAccoes.MyClear();

                drA = m_oParameters.DirectSqlDataReader(sQuery);
                while (drA.Read())
                {
                    AddAccao2ListView(drA);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (drA != null)
                {
                    drA.Close();
                }
            }
        }

        private void RefreshParametros()
        {
            try
            {
                maskedTextBoxIteracao.Text = m_oParameters.m_iTempoEntreIteracoes.ToString();
                maskedTextBoxMaxDocsTranche.Text = m_oParameters.m_iMaxDocsTranche.ToString();
                maskedTextBoxInicioTemp.Text = m_oParameters.m_iParagemHoraInicio.ToString("00") + ":" + m_oParameters.m_iParagemMinutoInicio.ToString("00");
                maskedTextBoxFimTemp.Text = m_oParameters.m_iParagemHoraFim.ToString("00") + ":" + m_oParameters.m_iParagemMinutoFim.ToString("00");
                maskedTextBoxMinDias.Text = m_oParameters.m_iMinDias.ToString();
                maskedTextBoxMaxDias.Text = m_oParameters.m_iMaxDias.ToString();
                maskedTextBoxHoraIni.Text = m_oParameters.m_iParagemAlertaHoraInicio.ToString("00") + ":" + m_oParameters.m_iParagemAlertaMinutoInicio.ToString("00");
                maskedTextBoxHoraFim.Text = m_oParameters.m_iParagemAlertaHoraFim.ToString("00") + ":" + m_oParameters.m_iParagemAlertaMinutoFim.ToString("00");
                maskedTextBoxHoraEsperaEnvm.Text = m_oParameters.m_iHorasEsperaEnvm.ToString();
                maskedTextBoxHoraEsperaRemin.Text = m_oParameters.m_iHorasEsperaRemessa.ToString();
                maskedTextBoxPercentagemAlerta.Text = m_oParameters.m_iPercentagemAlerta.ToString();

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadParametros()
        {
            m_iLastSituacao = -1;
            RefreshParametros();
            criaListaParametros1();
            criaListaParametros2();
            RefreshSituacoesAccoes();
            RefreshAccoes();
        }

        private void btLigar_Click(object sender, EventArgs e)
        {
            if (listViewBaseSituacoes.SelectedItems.Count != 1 || listViewAccoes.SelectedItems.Count != 1)
            {
                MessageBox.Show("Tem de selecionar uma situação e uma acção", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                {
                    return;
                }

                int iSituacao, iAccao;
                iSituacao = ((SituacaoAccao)listViewBaseSituacoes.GetTag()).m_iSITUACAO_ID;
                iAccao = ((Accao)listViewAccoes.GetTag()).m_iACC_ID;

                string sQuery = "insert into ALERTA_SITUACAO_ACCAO (SITUACAO_ID, ACC_ID) values (" + iSituacao.ToString() + "," + iAccao + ")";

                m_oParameters.DirectSqlNonQuery(sQuery);

                string sMsg = "Ligada a Situação:" + iSituacao.ToString() + " a Acção: " + iAccao.ToString();
                GenericLog.GenLogRegistarAlerta(sMsg, "ligarSituacao()", 100);
                m_oParameters.EnviarAlertaSituacao(100, sMsg);
                MessageBox.Show(sMsg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            
                LoadParametros();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btDesligar_Click(object sender, EventArgs e)
        {
            if (listViewSituacoesAccoes.SelectedItems.Count != 1)
            {
                MessageBox.Show("Tem de selecionar uma situação", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                {
                    return;
                }

                int iSituacao, iAccao;
                iSituacao = ((SituacaoAccao)listViewSituacoesAccoes.GetTag()).m_iSITUACAO_ID;
                iAccao = ((SituacaoAccao)listViewSituacoesAccoes.GetTag()).m_oAccao.m_iACC_ID;

                string sQuery = "delete ALERTA_SITUACAO_ACCAO where SITUACAO_ID=" + iSituacao.ToString() + " and ACC_ID=" + iAccao.ToString();

                m_oParameters.DirectSqlNonQuery(sQuery);

                string sMsg = "Desligada a Situação:" + iSituacao.ToString() + " da Acção: " + iAccao.ToString();
                GenericLog.GenLogRegistarAlerta(sMsg, "CIConfigForm.cs", 100);
                m_oParameters.EnviarAlertaSituacao(100, sMsg);
                MessageBox.Show(sMsg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

                LoadParametros();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonActualizar_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                {
                    return;
                }

                string sMsgTempoIter, sMsgMaxDocs, sMsgDias;
                m_oParameters.m_iTempoEntreIteracoes = Convert.ToInt16(maskedTextBoxIteracao.Text);
                m_oParameters.WriteProfileInt("CI", "Tempos", "TempoEntreIteracoes", m_oParameters.m_iTempoEntreIteracoes);

                sMsgTempoIter = "Tempo entre Iterações actualizado para " + m_oParameters.m_iTempoEntreIteracoes.ToString();
                GenericLog.GenLogRegistarAlerta(sMsgTempoIter, "CIConfigForm.cs", 23);

                m_oParameters.m_iMaxDocsTranche = Convert.ToInt16(maskedTextBoxMaxDocsTranche.Text);
                m_oParameters.WriteProfileInt("CI", "Quantidades", "MaxDocsTranche", m_oParameters.m_iMaxDocsTranche);

                sMsgMaxDocs = "Max docs Tranche actualizado para " + m_oParameters.m_iMaxDocsTranche.ToString();
                GenericLog.GenLogRegistarAlerta(sMsgMaxDocs, "CIConfigForm.cs", 24);

                m_oParameters.m_iMinDias = Convert.ToInt16(maskedTextBoxMinDias.Text);
                m_oParameters.WriteProfileInt("CI", "RemessaValida", "MinDias", m_oParameters.m_iMinDias);
                m_oParameters.m_iMaxDias = Convert.ToInt16(maskedTextBoxMaxDias.Text);
                m_oParameters.WriteProfileInt("CI", "RemessaValida", "MaxDias", m_oParameters.m_iMaxDias);
                sMsgDias = "Diferença entre dias alterada para Min = " + m_oParameters.m_iMinDias.ToString() + " Max = " + m_oParameters.m_iMaxDias.ToString();
                GenericLog.GenLogRegistarAlerta(sMsgDias, "CIConfigForm.cs", 25);

                m_oParameters.m_iParagemHoraInicio = int.Parse(maskedTextBoxInicioTemp.Text.Substring(0, 2));
                m_oParameters.m_iParagemMinutoInicio = int.Parse(maskedTextBoxInicioTemp.Text.Substring(3, 2));
                m_oParameters.m_iParagemHoraFim = int.Parse(maskedTextBoxFimTemp.Text.Substring(0, 2));
                m_oParameters.m_iParagemMinutoFim = int.Parse(maskedTextBoxFimTemp.Text.Substring(3, 2));
                m_oParameters.WriteProfileInt("CI", "Paragem", "HoraInicio", m_oParameters.m_iParagemHoraInicio);
                m_oParameters.WriteProfileInt("CI", "Paragem", "MinutoInicio", m_oParameters.m_iParagemMinutoInicio);
                m_oParameters.WriteProfileInt("CI", "Paragem", "HoraFim", m_oParameters.m_iParagemHoraFim);
                m_oParameters.WriteProfileInt("CI", "Paragem", "MinutoFim", m_oParameters.m_iParagemMinutoFim);
               
                m_oParameters.HoradeParagem();

                string sMSGHoraParagem = "Hora de paragem alterada para das: " + m_oParameters.m_iParagemHoraInicio.ToString() + ":" + m_oParameters.m_iParagemMinutoInicio.ToString();
                sMSGHoraParagem += " até as " + m_oParameters.m_iParagemHoraFim.ToString() + ":" + m_oParameters.m_iParagemMinutoFim.ToString();

                GenericLog.GenLogRegistarAlerta(sMSGHoraParagem, "HoraParagem()", 26);
                m_oParameters.EnviarAlertaSituacao(100, sMSGHoraParagem);

                MessageBox.Show(sMSGHoraParagem, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            LoadParametros();
        }

        private void criaListaParametros1()
        {
            string sQuery = "select * from VW_AL_ACCAO_PARAM1 ";
            sQuery += " order by TIPACC_ID, ACC_ID, TIPACCP_NAME, TIPACCP_VALUE";

            SqlDataReader drP = null;

            try
            {
                listViewAccaoParam1.MyClear();

                drP = m_oParameters.DirectSqlDataReader(sQuery);
                while (drP.Read())
                {
                    AddParam2ListView1(drP);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (drP != null)
                {
                    drP.Close();
                }
            }
        }

        private void criaListaParametros2()
        {
            string sQuery = "select * from VW_AL_ACCAO_PARAM2 ";
            sQuery += " order by TIPACC_ID, ACC_ID, ACCP_NAME, ACCP_VALUE";

            SqlDataReader drP = null;

            try
            {
                listViewAccaoParam2.MyClear();

                drP = m_oParameters.DirectSqlDataReader(sQuery);
                while (drP.Read())
                {
                    AddParam2ListView2(drP);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "AlertasForm.cs", 28);
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (drP != null)
                {
                    drP.Close();
                }
            }
        }

        private void AddParam2ListView1(SqlDataReader dr)
        {
            AccaoParam oAccP = new AccaoParam(dr);

            ListViewItem olvItem = oAccP.MakeListViewItemParam1();

            olvItem.Tag = oAccP;

            listViewAccaoParam1.Items.Add(olvItem);

        }

        private void AddParam2ListView2(SqlDataReader dr)
        {
            AccaoParam oAccP = new AccaoParam(dr);

            ListViewItem olvItem = oAccP.MakeListViewItemParam2();

            olvItem.Tag = oAccP;

            listViewAccaoParam2.Items.Add(olvItem);
        }


        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btActualizarAlertas_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                {
                    return;
                }

                m_oParameters.m_iHorasEsperaEnvm = Convert.ToInt16(maskedTextBoxHoraEsperaEnvm.Text);
                m_oParameters.WriteProfileInt("CI", "ALERTAS", "MaxHorasEsperaENVM", m_oParameters.m_iHorasEsperaEnvm);
                m_oParameters.m_iHorasEsperaRemessa = Convert.ToInt16(maskedTextBoxHoraEsperaRemin.Text);
                m_oParameters.WriteProfileInt("CI", "ALERTAS", "MaxHorasEsperaRemessaCI", m_oParameters.m_iHorasEsperaRemessa);

                m_oParameters.m_iParagemAlertaHoraInicio = int.Parse(maskedTextBoxInicioTemp.Text.Substring(0, 2));
                m_oParameters.m_iParagemAlertaMinutoInicio = int.Parse(maskedTextBoxInicioTemp.Text.Substring(3, 2));
                m_oParameters.m_iParagemAlertaHoraFim = int.Parse(maskedTextBoxFimTemp.Text.Substring(0, 2));
                m_oParameters.m_iParagemAlertaMinutoFim = int.Parse(maskedTextBoxFimTemp.Text.Substring(3, 2));
                m_oParameters.WriteProfileInt("CI", "ALERTAS", "HoraInicio", m_oParameters.m_iParagemAlertaHoraInicio);
                m_oParameters.WriteProfileInt("CI", "ALERTAS", "MinutoInicio", m_oParameters.m_iParagemAlertaMinutoInicio);
                m_oParameters.WriteProfileInt("CI", "ALERTAS", "HoraFim", m_oParameters.m_iParagemAlertaHoraFim);
                m_oParameters.WriteProfileInt("CI", "ALERTAS", "MinutoFim", m_oParameters.m_iParagemAlertaMinutoFim);

                m_oParameters.m_iPercentagemAlerta = int.Parse(maskedTextBoxPercentagemAlerta.Text);
                m_oParameters.WriteProfileInt("CI", "ALERTAS", "ParamPercentagem", m_oParameters.m_iPercentagemAlerta);

                string sMsg = "Parametros de Alertas Alterados";
                GenericLog.GenLogRegistarAlerta(sMsg, "ActualizarParametrosAlertas()", 100);
                m_oParameters.EnviarAlertaSituacao(100, sMsg);
                MessageBox.Show(sMsg, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
         }
    }
}