﻿namespace MDIsControlo
{
    partial class MDIsControloForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);

            m_oMenuInterface.ControloMDIsFormMenuItemEnable(true);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MDIsControloForm));
            this.m_dateTimePickerMenor = new System.Windows.Forms.DateTimePicker();
            this.m_dateTimePickerMaior = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.m_buttonRefreshMDI = new System.Windows.Forms.Button();
            this.m_textBoxMenorData = new System.Windows.Forms.TextBox();
            this.m_textBoxMaiorData = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.m_listViewDocumentosMDI = new NBIISNET.ListViewBase();
            this.detDocColDoMDIcId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDoc02ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColPais = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColBanco = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColBalcao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocMaquina = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColIdDispositivo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocBalGestor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDepData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDepMovTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColSessao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColRecolha = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColNSeqOperacao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDepID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColQtDocs = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDepEstado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDepMontante = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDepConta = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDepAplicacao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColEstadoOper = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColIndicadorReenvio = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocNSeq = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocRefarq = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocStat = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnDocColCiTimer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColCIEstado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.m_textBoxNItemsMDI = new System.Windows.Forms.TextBox();
            this.m_buttonStopRefreshMDI = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label10 = new System.Windows.Forms.Label();
            this.buttonProcessaImportação = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxError = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.m_ctrlDataIni = new System.Windows.Forms.DateTimePicker();
            this.m_ctrlDataFim = new System.Windows.Forms.DateTimePicker();
            this.textBoxLXPT02 = new System.Windows.Forms.TextBox();
            this.m_labelDocumento02 = new System.Windows.Forms.Label();
            this.buttonStop02 = new System.Windows.Forms.Button();
            this.btImportarDocumento02 = new System.Windows.Forms.Button();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxSequencia = new NBIISNET.txtNumbersOnly();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxBalcao = new NBIISNET.txtNumbersOnly();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.m_textBoxNItems02 = new System.Windows.Forms.TextBox();
            this.m_buttonStopRefresh02 = new System.Windows.Forms.Button();
            this.m_buttonRefresh02 = new System.Windows.Forms.Button();
            this.m_listViewDocumentos02 = new NBIISNET.ListViewBase();
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader22 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader23 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader24 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader25 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader26 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader29 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader30 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_dateTimePickerMenor
            // 
            this.m_dateTimePickerMenor.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_dateTimePickerMenor.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_dateTimePickerMenor.Location = new System.Drawing.Point(80, 3);
            this.m_dateTimePickerMenor.Name = "m_dateTimePickerMenor";
            this.m_dateTimePickerMenor.Size = new System.Drawing.Size(176, 20);
            this.m_dateTimePickerMenor.TabIndex = 5;
            // 
            // m_dateTimePickerMaior
            // 
            this.m_dateTimePickerMaior.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_dateTimePickerMaior.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_dateTimePickerMaior.Location = new System.Drawing.Point(80, 29);
            this.m_dateTimePickerMaior.Name = "m_dateTimePickerMaior";
            this.m_dateTimePickerMaior.Size = new System.Drawing.Size(176, 20);
            this.m_dateTimePickerMaior.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(21, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Inicio:";
            // 
            // m_buttonRefreshMDI
            // 
            this.m_buttonRefreshMDI.Location = new System.Drawing.Point(277, 2);
            this.m_buttonRefreshMDI.Name = "m_buttonRefreshMDI";
            this.m_buttonRefreshMDI.Size = new System.Drawing.Size(75, 47);
            this.m_buttonRefreshMDI.TabIndex = 7;
            this.m_buttonRefreshMDI.Text = "Refresh";
            this.m_buttonRefreshMDI.UseVisualStyleBackColor = true;
            this.m_buttonRefreshMDI.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // m_textBoxMenorData
            // 
            this.m_textBoxMenorData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.m_textBoxMenorData.Location = new System.Drawing.Point(668, 2);
            this.m_textBoxMenorData.Name = "m_textBoxMenorData";
            this.m_textBoxMenorData.ReadOnly = true;
            this.m_textBoxMenorData.Size = new System.Drawing.Size(74, 20);
            this.m_textBoxMenorData.TabIndex = 31;
            this.m_textBoxMenorData.TabStop = false;
            this.m_textBoxMenorData.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // m_textBoxMaiorData
            // 
            this.m_textBoxMaiorData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.m_textBoxMaiorData.Location = new System.Drawing.Point(756, 2);
            this.m_textBoxMaiorData.Name = "m_textBoxMaiorData";
            this.m_textBoxMaiorData.ReadOnly = true;
            this.m_textBoxMaiorData.Size = new System.Drawing.Size(74, 20);
            this.m_textBoxMaiorData.TabIndex = 32;
            this.m_textBoxMaiorData.TabStop = false;
            this.m_textBoxMaiorData.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(554, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Menor/Maior Data:";
            // 
            // m_listViewDocumentosMDI
            // 
            this.m_listViewDocumentosMDI.AllowColumnReorder = true;
            this.m_listViewDocumentosMDI.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_listViewDocumentosMDI.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.detDocColDoMDIcId,
            this.detDocColDoc02ID,
            this.detDocColPais,
            this.detDocColBanco,
            this.detDocColBalcao,
            this.detDocColDocMaquina,
            this.detDocColIdDispositivo,
            this.detDocColDocBalGestor,
            this.detDocColDepData,
            this.detDocColDepMovTime,
            this.detDocColSessao,
            this.detDocColRecolha,
            this.detDocColNSeqOperacao,
            this.detDocColDepID,
            this.detDocColQtDocs,
            this.detDocColDepEstado,
            this.detDocColDepMontante,
            this.detDocColDepConta,
            this.detDocColDepAplicacao,
            this.detDocColEstadoOper,
            this.detDocColIndicadorReenvio,
            this.detDocColDocZona5,
            this.detDocColDocZona4,
            this.detDocColDocZona3,
            this.detDocColDocZona2,
            this.detDocColDocZona1,
            this.detDocColDocNSeq,
            this.detDocColDocRefarq,
            this.detDocColDocStat,
            this.columnDocColCiTimer,
            this.detDocColCIEstado});
            this.m_listViewDocumentosMDI.EnableExportar = true;
            this.m_listViewDocumentosMDI.FullRowSelect = true;
            this.m_listViewDocumentosMDI.GridLines = true;
            this.m_listViewDocumentosMDI.HideSelection = false;
            this.m_listViewDocumentosMDI.Location = new System.Drawing.Point(0, 56);
            this.m_listViewDocumentosMDI.MultiSelect = false;
            this.m_listViewDocumentosMDI.Name = "m_listViewDocumentosMDI";
            this.m_listViewDocumentosMDI.Size = new System.Drawing.Size(830, 256);
            this.m_listViewDocumentosMDI.TabIndex = 8;
            this.m_listViewDocumentosMDI.TabStop = false;
            this.m_listViewDocumentosMDI.UseCompatibleStateImageBehavior = false;
            this.m_listViewDocumentosMDI.View = System.Windows.Forms.View.Details;
            this.m_listViewDocumentosMDI.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listViewDocumentos_MouseDoubleClick);
            // 
            // detDocColDoMDIcId
            // 
            this.detDocColDoMDIcId.Text = "DocMDI ID";
            this.detDocColDoMDIcId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.detDocColDoMDIcId.Width = 70;
            // 
            // detDocColDoc02ID
            // 
            this.detDocColDoc02ID.Text = "Doc02 ID";
            // 
            // detDocColPais
            // 
            this.detDocColPais.Text = "País";
            this.detDocColPais.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColPais.Width = 5;
            // 
            // detDocColBanco
            // 
            this.detDocColBanco.Text = "Banco";
            this.detDocColBanco.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColBanco.Width = 5;
            // 
            // detDocColBalcao
            // 
            this.detDocColBalcao.Text = "Balcão";
            this.detDocColBalcao.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColBalcao.Width = 50;
            // 
            // detDocColDocMaquina
            // 
            this.detDocColDocMaquina.Text = "Seq.";
            this.detDocColDocMaquina.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocMaquina.Width = 50;
            // 
            // detDocColIdDispositivo
            // 
            this.detDocColIdDispositivo.Text = "Id Dispositivo";
            this.detDocColIdDispositivo.Width = 50;
            // 
            // detDocColDocBalGestor
            // 
            this.detDocColDocBalGestor.Text = "B. Gestor";
            this.detDocColDocBalGestor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocBalGestor.Width = 50;
            // 
            // detDocColDepData
            // 
            this.detDocColDepData.Text = "Dep Data";
            this.detDocColDepData.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDepData.Width = 50;
            // 
            // detDocColDepMovTime
            // 
            this.detDocColDepMovTime.Text = "MovTime";
            this.detDocColDepMovTime.Width = 100;
            // 
            // detDocColSessao
            // 
            this.detDocColSessao.Text = "Sessão";
            this.detDocColSessao.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColSessao.Width = 50;
            // 
            // detDocColRecolha
            // 
            this.detDocColRecolha.Text = "Recolha";
            this.detDocColRecolha.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColRecolha.Width = 50;
            // 
            // detDocColNSeqOperacao
            // 
            this.detDocColNSeqOperacao.Text = "NSeqOper";
            this.detDocColNSeqOperacao.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColNSeqOperacao.Width = 50;
            // 
            // detDocColDepID
            // 
            this.detDocColDepID.Text = "DepId";
            this.detDocColDepID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDepID.Width = 50;
            // 
            // detDocColQtDocs
            // 
            this.detDocColQtDocs.Text = "QtDocs";
            this.detDocColQtDocs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColQtDocs.Width = 50;
            // 
            // detDocColDepEstado
            // 
            this.detDocColDepEstado.Text = "Dep Estado";
            this.detDocColDepEstado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDepEstado.Width = 20;
            // 
            // detDocColDepMontante
            // 
            this.detDocColDepMontante.Text = "Dep Montante";
            this.detDocColDepMontante.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // detDocColDepConta
            // 
            this.detDocColDepConta.Text = "NConta";
            this.detDocColDepConta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDepConta.Width = 80;
            // 
            // detDocColDepAplicacao
            // 
            this.detDocColDepAplicacao.Text = "Aplic";
            this.detDocColDepAplicacao.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDepAplicacao.Width = 30;
            // 
            // detDocColEstadoOper
            // 
            this.detDocColEstadoOper.Text = "EstadoOper";
            this.detDocColEstadoOper.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColEstadoOper.Width = 20;
            // 
            // detDocColIndicadorReenvio
            // 
            this.detDocColIndicadorReenvio.Text = "Reenvio";
            this.detDocColIndicadorReenvio.Width = 20;
            // 
            // detDocColDocZona5
            // 
            this.detDocColDocZona5.Text = "ZIB";
            this.detDocColDocZona5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocZona5.Width = 80;
            // 
            // detDocColDocZona4
            // 
            this.detDocColDocZona4.Text = "N. Conta";
            this.detDocColDocZona4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocZona4.Width = 110;
            // 
            // detDocColDocZona3
            // 
            this.detDocColDocZona3.Text = "N.Cheque";
            this.detDocColDocZona3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocZona3.Width = 100;
            // 
            // detDocColDocZona2
            // 
            this.detDocColDocZona2.Text = "Montante";
            this.detDocColDocZona2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.detDocColDocZona2.Width = 100;
            // 
            // detDocColDocZona1
            // 
            this.detDocColDocZona1.Text = "Tp";
            this.detDocColDocZona1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocZona1.Width = 30;
            // 
            // detDocColDocNSeq
            // 
            this.detDocColDocNSeq.Text = "N Seq";
            this.detDocColDocNSeq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocNSeq.Width = 30;
            // 
            // detDocColDocRefarq
            // 
            this.detDocColDocRefarq.Text = "Refarq";
            this.detDocColDocRefarq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocRefarq.Width = 50;
            // 
            // detDocColDocStat
            // 
            this.detDocColDocStat.Text = "Estado";
            this.detDocColDocStat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocStat.Width = 30;
            // 
            // columnDocColCiTimer
            // 
            this.columnDocColCiTimer.Text = "CI Timer";
            this.columnDocColCiTimer.Width = 100;
            // 
            // detDocColCIEstado
            // 
            this.detDocColCIEstado.Text = "Ci Estado";
            this.detDocColCIEstado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColCIEstado.Width = 30;
            // 
            // m_textBoxNItemsMDI
            // 
            this.m_textBoxNItemsMDI.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.m_textBoxNItemsMDI.Location = new System.Drawing.Point(659, 29);
            this.m_textBoxNItemsMDI.Name = "m_textBoxNItemsMDI";
            this.m_textBoxNItemsMDI.ReadOnly = true;
            this.m_textBoxNItemsMDI.Size = new System.Drawing.Size(111, 20);
            this.m_textBoxNItemsMDI.TabIndex = 35;
            this.m_textBoxNItemsMDI.TabStop = false;
            this.m_textBoxNItemsMDI.Text = "0 Registos";
            this.m_textBoxNItemsMDI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // m_buttonStopRefreshMDI
            // 
            this.m_buttonStopRefreshMDI.Location = new System.Drawing.Point(358, 2);
            this.m_buttonStopRefreshMDI.Name = "m_buttonStopRefreshMDI";
            this.m_buttonStopRefreshMDI.Size = new System.Drawing.Size(75, 47);
            this.m_buttonStopRefreshMDI.TabIndex = 36;
            this.m_buttonStopRefreshMDI.Text = "Stop";
            this.m_buttonStopRefreshMDI.UseVisualStyleBackColor = true;
            this.m_buttonStopRefreshMDI.Click += new System.EventHandler(this.buttonStopRefresh_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(12, 12);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label10);
            this.splitContainer1.Panel1.Controls.Add(this.buttonProcessaImportação);
            this.splitContainer1.Panel1.Controls.Add(this.label9);
            this.splitContainer1.Panel1.Controls.Add(this.textBoxError);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.m_ctrlDataIni);
            this.splitContainer1.Panel1.Controls.Add(this.m_ctrlDataFim);
            this.splitContainer1.Panel1.Controls.Add(this.textBoxLXPT02);
            this.splitContainer1.Panel1.Controls.Add(this.m_labelDocumento02);
            this.splitContainer1.Panel1.Controls.Add(this.buttonStop02);
            this.splitContainer1.Panel1.Controls.Add(this.btImportarDocumento02);
            this.splitContainer1.Panel1.Margin = new System.Windows.Forms.Padding(1);
            this.splitContainer1.Panel1MinSize = 1;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1038, 497);
            this.splitContainer1.SplitterDistance = 192;
            this.splitContainer1.TabIndex = 37;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(13, 12);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(149, 13);
            this.label10.TabIndex = 40;
            this.label10.Text = "Importar da Aplicação 02";
            // 
            // buttonProcessaImportação
            // 
            this.buttonProcessaImportação.Location = new System.Drawing.Point(2, 240);
            this.buttonProcessaImportação.Name = "buttonProcessaImportação";
            this.buttonProcessaImportação.Size = new System.Drawing.Size(160, 23);
            this.buttonProcessaImportação.TabIndex = 39;
            this.buttonProcessaImportação.Text = "Processa Importação";
            this.buttonProcessaImportação.UseVisualStyleBackColor = true;
            this.buttonProcessaImportação.Click += new System.EventHandler(this.buttonProcessaImportação_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(31, 113);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 13);
            this.label9.TabIndex = 38;
            this.label9.Text = "Balcão:";
            // 
            // textBoxError
            // 
            this.textBoxError.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxError.BackColor = System.Drawing.SystemColors.Info;
            this.textBoxError.Enabled = false;
            this.textBoxError.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxError.Location = new System.Drawing.Point(4, 269);
            this.textBoxError.Multiline = true;
            this.textBoxError.Name = "textBoxError";
            this.textBoxError.Size = new System.Drawing.Size(161, 254);
            this.textBoxError.TabIndex = 37;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Data Inicio e Fim";
            // 
            // m_ctrlDataIni
            // 
            this.m_ctrlDataIni.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrlDataIni.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrlDataIni.Location = new System.Drawing.Point(4, 60);
            this.m_ctrlDataIni.Name = "m_ctrlDataIni";
            this.m_ctrlDataIni.Size = new System.Drawing.Size(185, 20);
            this.m_ctrlDataIni.TabIndex = 0;
            // 
            // m_ctrlDataFim
            // 
            this.m_ctrlDataFim.CustomFormat = " dddd - yyyy-MM-dd";
            this.m_ctrlDataFim.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrlDataFim.Location = new System.Drawing.Point(4, 82);
            this.m_ctrlDataFim.Name = "m_ctrlDataFim";
            this.m_ctrlDataFim.Size = new System.Drawing.Size(185, 20);
            this.m_ctrlDataFim.TabIndex = 0;
            // 
            // textBoxLXPT02
            // 
            this.textBoxLXPT02.Location = new System.Drawing.Point(100, 108);
            this.textBoxLXPT02.Name = "textBoxLXPT02";
            this.textBoxLXPT02.Size = new System.Drawing.Size(34, 20);
            this.textBoxLXPT02.TabIndex = 36;
            this.textBoxLXPT02.Text = "9601";
            this.textBoxLXPT02.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // m_labelDocumento02
            // 
            this.m_labelDocumento02.AutoSize = true;
            this.m_labelDocumento02.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_labelDocumento02.Location = new System.Drawing.Point(3, 152);
            this.m_labelDocumento02.Name = "m_labelDocumento02";
            this.m_labelDocumento02.Size = new System.Drawing.Size(89, 13);
            this.m_labelDocumento02.TabIndex = 18;
            this.m_labelDocumento02.Text = "Importados: ---";
            // 
            // buttonStop02
            // 
            this.buttonStop02.Location = new System.Drawing.Point(2, 197);
            this.buttonStop02.Name = "buttonStop02";
            this.buttonStop02.Size = new System.Drawing.Size(160, 23);
            this.buttonStop02.TabIndex = 2;
            this.buttonStop02.Text = "Stop Importação";
            this.buttonStop02.UseVisualStyleBackColor = true;
            this.buttonStop02.Click += new System.EventHandler(this.buttonStop02_Click);
            // 
            // btImportarDocumento02
            // 
            this.btImportarDocumento02.Location = new System.Drawing.Point(4, 168);
            this.btImportarDocumento02.Name = "btImportarDocumento02";
            this.btImportarDocumento02.Size = new System.Drawing.Size(158, 23);
            this.btImportarDocumento02.TabIndex = 1;
            this.btImportarDocumento02.Text = "Importar Documentos";
            this.btImportarDocumento02.UseVisualStyleBackColor = true;
            this.btImportarDocumento02.Click += new System.EventHandler(this.btImportarDocumento02_Click);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer2.Location = new System.Drawing.Point(3, 3);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.label11);
            this.splitContainer2.Panel1.Controls.Add(this.textBoxSequencia);
            this.splitContainer2.Panel1.Controls.Add(this.label8);
            this.splitContainer2.Panel1.Controls.Add(this.textBoxBalcao);
            this.splitContainer2.Panel1.Controls.Add(this.label4);
            this.splitContainer2.Panel1.Controls.Add(this.m_buttonStopRefreshMDI);
            this.splitContainer2.Panel1.Controls.Add(this.label7);
            this.splitContainer2.Panel1.Controls.Add(this.label5);
            this.splitContainer2.Panel1.Controls.Add(this.label3);
            this.splitContainer2.Panel1.Controls.Add(this.m_listViewDocumentosMDI);
            this.splitContainer2.Panel1.Controls.Add(this.m_dateTimePickerMenor);
            this.splitContainer2.Panel1.Controls.Add(this.m_textBoxMaiorData);
            this.splitContainer2.Panel1.Controls.Add(this.m_textBoxNItemsMDI);
            this.splitContainer2.Panel1.Controls.Add(this.m_dateTimePickerMaior);
            this.splitContainer2.Panel1.Controls.Add(this.label2);
            this.splitContainer2.Panel1.Controls.Add(this.m_textBoxMenorData);
            this.splitContainer2.Panel1.Controls.Add(this.m_buttonRefreshMDI);
            this.splitContainer2.Panel1.Margin = new System.Windows.Forms.Padding(1);
            this.splitContainer2.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitContainer2.Panel1MinSize = 50;
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.label6);
            this.splitContainer2.Panel2.Controls.Add(this.m_textBoxNItems02);
            this.splitContainer2.Panel2.Controls.Add(this.m_buttonStopRefresh02);
            this.splitContainer2.Panel2.Controls.Add(this.m_buttonRefresh02);
            this.splitContainer2.Panel2.Controls.Add(this.m_listViewDocumentos02);
            this.splitContainer2.Panel2.Margin = new System.Windows.Forms.Padding(1);
            this.splitContainer2.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitContainer2.Panel2MinSize = 1;
            this.splitContainer2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitContainer2.Size = new System.Drawing.Size(836, 491);
            this.splitContainer2.SplitterDistance = 315;
            this.splitContainer2.TabIndex = 37;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(551, 29);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 13);
            this.label11.TabIndex = 44;
            this.label11.Text = "/";
            // 
            // textBoxSequencia
            // 
            this.textBoxSequencia.BackgroundColorNoFocus = System.Drawing.Color.White;
            this.textBoxSequencia.BackgroundColorOnFocus = System.Drawing.Color.Yellow;
            this.textBoxSequencia.DecimalPlaces = false;
            this.textBoxSequencia.Location = new System.Drawing.Point(565, 25);
            this.textBoxSequencia.MaxLength = 4;
            this.textBoxSequencia.Name = "textBoxSequencia";
            this.textBoxSequencia.NegativeNumbers = false;
            this.textBoxSequencia.Size = new System.Drawing.Size(35, 20);
            this.textBoxSequencia.TabIndex = 43;
            this.textBoxSequencia.WildCards = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(438, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 13);
            this.label8.TabIndex = 42;
            this.label8.Text = "Balcão/Seq:";
            // 
            // textBoxBalcao
            // 
            this.textBoxBalcao.BackgroundColorNoFocus = System.Drawing.Color.White;
            this.textBoxBalcao.BackgroundColorOnFocus = System.Drawing.Color.Yellow;
            this.textBoxBalcao.DecimalPlaces = false;
            this.textBoxBalcao.Location = new System.Drawing.Point(516, 25);
            this.textBoxBalcao.MaxLength = 4;
            this.textBoxBalcao.Name = "textBoxBalcao";
            this.textBoxBalcao.NegativeNumbers = false;
            this.textBoxBalcao.Size = new System.Drawing.Size(35, 20);
            this.textBoxBalcao.TabIndex = 41;
            this.textBoxBalcao.WildCards = false;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(742, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 13);
            this.label4.TabIndex = 40;
            this.label4.Text = "/";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(24, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 13);
            this.label7.TabIndex = 39;
            this.label7.Text = "Fim:";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(776, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 38;
            this.label5.Text = "MDI";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(791, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 13);
            this.label6.TabIndex = 42;
            this.label6.Text = "02";
            // 
            // m_textBoxNItems02
            // 
            this.m_textBoxNItems02.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.m_textBoxNItems02.Location = new System.Drawing.Point(674, 5);
            this.m_textBoxNItems02.Name = "m_textBoxNItems02";
            this.m_textBoxNItems02.ReadOnly = true;
            this.m_textBoxNItems02.Size = new System.Drawing.Size(111, 20);
            this.m_textBoxNItems02.TabIndex = 41;
            this.m_textBoxNItems02.TabStop = false;
            this.m_textBoxNItems02.Text = "0 Registos";
            this.m_textBoxNItems02.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // m_buttonStopRefresh02
            // 
            this.m_buttonStopRefresh02.Location = new System.Drawing.Point(361, 3);
            this.m_buttonStopRefresh02.Name = "m_buttonStopRefresh02";
            this.m_buttonStopRefresh02.Size = new System.Drawing.Size(75, 22);
            this.m_buttonStopRefresh02.TabIndex = 40;
            this.m_buttonStopRefresh02.Text = "Stop";
            this.m_buttonStopRefresh02.UseVisualStyleBackColor = true;
            this.m_buttonStopRefresh02.Click += new System.EventHandler(this.m_buttonStopRefresh02_Click);
            // 
            // m_buttonRefresh02
            // 
            this.m_buttonRefresh02.Location = new System.Drawing.Point(280, 3);
            this.m_buttonRefresh02.Name = "m_buttonRefresh02";
            this.m_buttonRefresh02.Size = new System.Drawing.Size(75, 22);
            this.m_buttonRefresh02.TabIndex = 39;
            this.m_buttonRefresh02.Text = "Refresh";
            this.m_buttonRefresh02.UseVisualStyleBackColor = true;
            this.m_buttonRefresh02.Click += new System.EventHandler(this.m_buttonRefresh02_Click);
            // 
            // m_listViewDocumentos02
            // 
            this.m_listViewDocumentos02.AllowColumnReorder = true;
            this.m_listViewDocumentos02.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_listViewDocumentos02.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader18,
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader15,
            this.columnHeader21,
            this.columnHeader22,
            this.columnHeader23,
            this.columnHeader24,
            this.columnHeader25,
            this.columnHeader26,
            this.columnHeader29,
            this.columnHeader30});
            this.m_listViewDocumentos02.EnableExportar = true;
            this.m_listViewDocumentos02.FullRowSelect = true;
            this.m_listViewDocumentos02.GridLines = true;
            this.m_listViewDocumentos02.HideSelection = false;
            this.m_listViewDocumentos02.Location = new System.Drawing.Point(3, 29);
            this.m_listViewDocumentos02.MultiSelect = false;
            this.m_listViewDocumentos02.Name = "m_listViewDocumentos02";
            this.m_listViewDocumentos02.Size = new System.Drawing.Size(830, 140);
            this.m_listViewDocumentos02.TabIndex = 38;
            this.m_listViewDocumentos02.TabStop = false;
            this.m_listViewDocumentos02.UseCompatibleStateImageBehavior = false;
            this.m_listViewDocumentos02.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "DocMDI ID";
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Doc02 ID";
            this.columnHeader1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader1.Width = 70;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "País";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 5;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Banco";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 5;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Balcão";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 50;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Maquina";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 50;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Id Dispositivo";
            this.columnHeader6.Width = 50;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "B. Gestor";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader7.Width = 50;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Dep Data";
            this.columnHeader8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader8.Width = 50;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "MovTime";
            this.columnHeader9.Width = 100;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Sessão";
            this.columnHeader10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader10.Width = 50;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Recolha";
            this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader11.Width = 50;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "NSeqOper";
            this.columnHeader12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader12.Width = 50;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "DepC Id";
            this.columnHeader13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader13.Width = 50;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "QtDocs";
            this.columnHeader14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader14.Width = 50;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Dep Montante";
            this.columnHeader16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "NConta";
            this.columnHeader17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader17.Width = 80;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Dep Estado";
            this.columnHeader15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader15.Width = 20;
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "ZIB";
            this.columnHeader21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader21.Width = 80;
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "N. Conta";
            this.columnHeader22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader22.Width = 110;
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "N.Cheque";
            this.columnHeader23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader23.Width = 100;
            // 
            // columnHeader24
            // 
            this.columnHeader24.Text = "Montante";
            this.columnHeader24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader24.Width = 100;
            // 
            // columnHeader25
            // 
            this.columnHeader25.Text = "Tp";
            this.columnHeader25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader25.Width = 30;
            // 
            // columnHeader26
            // 
            this.columnHeader26.Text = "DocID";
            this.columnHeader26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader26.Width = 30;
            // 
            // columnHeader29
            // 
            this.columnHeader29.Text = "CI Timer";
            this.columnHeader29.Width = 100;
            // 
            // columnHeader30
            // 
            this.columnHeader30.Text = "Ci Estado";
            this.columnHeader30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader30.Width = 30;
            // 
            // MDIsControloForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1062, 521);
            this.Controls.Add(this.splitContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MDIsControloForm";
            this.ShowInTaskbar = false;
            this.Text = "MDIs Controlo";
            this.Load += new System.EventHandler(this.MDIsControloForm_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker m_dateTimePickerMenor;
        private System.Windows.Forms.DateTimePicker m_dateTimePickerMaior;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button m_buttonRefreshMDI;
        private System.Windows.Forms.TextBox m_textBoxMenorData;
        private System.Windows.Forms.TextBox m_textBoxMaiorData;
        private System.Windows.Forms.Label label3;
        private NBIISNET.ListViewBase m_listViewDocumentosMDI;
        private System.Windows.Forms.ColumnHeader detDocColDoMDIcId;
        private System.Windows.Forms.ColumnHeader detDocColDocZona5;
        private System.Windows.Forms.ColumnHeader detDocColDocZona4;
        private System.Windows.Forms.ColumnHeader detDocColDocZona3;
        private System.Windows.Forms.ColumnHeader detDocColDocZona2;
        private System.Windows.Forms.ColumnHeader detDocColDocZona1;
        private System.Windows.Forms.ColumnHeader detDocColDocStat;
        private System.Windows.Forms.ColumnHeader detDocColDepAplicacao;
        private System.Windows.Forms.ColumnHeader detDocColDocRefarq;
        private System.Windows.Forms.ColumnHeader detDocColDocNSeq;
        private System.Windows.Forms.ColumnHeader detDocColDepID;
        private System.Windows.Forms.ColumnHeader detDocColDepConta;
        private System.Windows.Forms.ColumnHeader detDocColDocMaquina;
        private System.Windows.Forms.ColumnHeader detDocColDocBalGestor;
        private System.Windows.Forms.ColumnHeader detDocColNSeqOperacao;
        private System.Windows.Forms.ColumnHeader detDocColRecolha;
        private System.Windows.Forms.ColumnHeader detDocColEstadoOper;
        private System.Windows.Forms.ColumnHeader detDocColDepData;
        private System.Windows.Forms.ColumnHeader detDocColDepMontante;
        private System.Windows.Forms.ColumnHeader detDocColQtDocs;
        private System.Windows.Forms.ColumnHeader detDocColPais;
        private System.Windows.Forms.ColumnHeader detDocColBanco;
        private System.Windows.Forms.ColumnHeader detDocColBalcao;
        private System.Windows.Forms.ColumnHeader detDocColCIEstado;
        private System.Windows.Forms.ColumnHeader detDocColDepEstado;
        private System.Windows.Forms.ColumnHeader detDocColSessao;
        private System.Windows.Forms.ColumnHeader columnDocColCiTimer;
        private System.Windows.Forms.ColumnHeader detDocColIdDispositivo;
        private System.Windows.Forms.ColumnHeader detDocColIndicadorReenvio;
        private System.Windows.Forms.ColumnHeader detDocColDepMovTime;
        private System.Windows.Forms.TextBox m_textBoxNItemsMDI;
        private System.Windows.Forms.Button m_buttonStopRefreshMDI;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker m_ctrlDataIni;
        private System.Windows.Forms.DateTimePicker m_ctrlDataFim;
        private System.Windows.Forms.TextBox textBoxLXPT02;
        private System.Windows.Forms.Label m_labelDocumento02;
        private System.Windows.Forms.Button buttonStop02;
        private System.Windows.Forms.Button btImportarDocumento02;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private NBIISNET.ListViewBase m_listViewDocumentos02;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.ColumnHeader columnHeader23;
        private System.Windows.Forms.ColumnHeader columnHeader24;
        private System.Windows.Forms.ColumnHeader columnHeader25;
        private System.Windows.Forms.ColumnHeader columnHeader26;
        private System.Windows.Forms.ColumnHeader columnHeader29;
        private System.Windows.Forms.ColumnHeader columnHeader30;
        private System.Windows.Forms.TextBox m_textBoxNItems02;
        private System.Windows.Forms.Button m_buttonStopRefresh02;
        private System.Windows.Forms.Button m_buttonRefresh02;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox textBoxError;
        private System.Windows.Forms.Label label8;
        private NBIISNET.txtNumbersOnly  textBoxBalcao;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button buttonProcessaImportação;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ColumnHeader detDocColDoc02ID;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.Label label11;
        private NBIISNET.txtNumbersOnly textBoxSequencia;
    }
}