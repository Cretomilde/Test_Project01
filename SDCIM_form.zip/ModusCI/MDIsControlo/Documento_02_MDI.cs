﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;

namespace MDIsControlo
{
    public class Documento_02_MDI
    {
        public string   m_sDOCMDI_ID;
        public string   m_sDOC02_ID;
        public string   m_sCA_PAIS;
        public int      m_iCA_BANCO;
        public int      m_iCA_BALCAO;
        public int      m_iCA_NUMERO;
        public string	m_sCA_IDDISPOSITIVO;
        public int      m_iCA_BALCAOGESTOR;
        public DateTime m_dtDEP_DATA;
        public DateTime m_dtDEP_MOVTIME;
        public int      m_iDEP_NSESSAO;
        public int      m_iDEP_NRECOLHA;
        public int      m_iDEP_NSEQOPERACAO;
        public string   m_sDEP_ID;  //apenas MDI
        public string   m_sDEPC_ID; //apenas 02
        public int      m_iDEP_QTDOCS;
        public int      m_iDEP_ESTADO; //apenas MDI
        public decimal  m_dDEP_MONTANTE;
        public string	m_sDEP_NUMCONTA;
        public string	m_sDEP_APLICACAO;   //apenas MDI
        public int      m_iDEP_ESTADO_OPER;
        public string   m_sDOC_INDICADORREENVIO;   //apenas MDI
        public string	m_sDOC_LOZIB;
        public string	m_sDOC_LONCONTA;
        public string	m_sDOC_LONCHEQUE;
        public decimal  m_dDOC_LOMONTANTE;
        public string	m_sDOC_LOTIPO;
        public string   m_sDOC_ID; //apenas 02
        public int      m_iDOC_NSEQ; //apenas MDI
        public string   m_sDOC_REFINDEX;   //apenas MDI
        public int      m_iDOC_ESTADO;  //apenas MDI
        public DateTime m_dtCI_TIMER;
        public int      m_iCI_ESTADO_PROC;

        public MDIsControloForm m_oForm = null;

        public Documento_02_MDI(DataRow oRow, int iMDI02 /*MDI=1,02=2*/, bool bCITables) 
        {
            if (bCITables)
            {
                if (iMDI02 == 1)
                {
                    m_sDOCMDI_ID = oRow["DOCMDI_ID"].ToString();
                    try
                    {
                        m_sDOC02_ID = oRow["DOC02_ID"].ToString();
                    }
                    catch
                    {
                        m_sDOC02_ID = "";
                    }
                }
                if (iMDI02 == 2)
                {
                    m_sDOC02_ID = oRow["DOC02_ID"].ToString();
                    m_sDOCMDI_ID = oRow["DOCMDI_ID"].ToString();
                }
                m_dtCI_TIMER = Convert.ToDateTime(oRow["CI_TIMER"]);
                m_iCI_ESTADO_PROC = Convert.ToInt32(oRow["CI_ESTADO_PROC"]);
            }

            m_sCA_PAIS = oRow["CA_PAIS"].ToString();
            m_iCA_BANCO = Convert.ToInt32(oRow["CA_BANCO"]);
            m_iCA_BALCAO = Convert.ToInt32(oRow["CA_BALCAO"]);
            m_iCA_NUMERO = Convert.ToInt32(oRow["CA_NUMERO"]);
            m_sCA_IDDISPOSITIVO = oRow["CA_IDDISPOSITIVO"].ToString();
            m_iCA_BALCAOGESTOR = Convert.ToInt32(oRow["CA_BALCAOGESTOR"]);
            m_dtDEP_DATA = Convert.ToDateTime(oRow["DEP_DATA"]);
            m_dtDEP_MOVTIME = Convert.ToDateTime(oRow["DEP_MOVTIME"]);
            m_iDEP_NSESSAO = Convert.ToInt32(oRow["DEP_NSESSAO"]);
            m_iDEP_NRECOLHA = Convert.ToInt32(oRow["DEP_NRECOLHA"]);
            m_iDEP_NSEQOPERACAO = Convert.ToInt32(oRow["DEP_NSEQOPERACAO"]);
            m_iDEP_QTDOCS = Convert.ToInt32(oRow["DEP_QTDOCS"]);
            m_dDEP_MONTANTE = Convert.ToDecimal(oRow["DEP_MONTANTE"]);
            m_sDEP_NUMCONTA = oRow["DEP_NUMCONTA"].ToString();
            m_iDEP_ESTADO_OPER = Convert.ToInt32(oRow["DEP_ESTADO_OPER"]);
            
            m_sDOC_LOZIB = oRow["DOC_LOZIB"].ToString();
            if (m_sDOC_LOZIB == "")
            {
                m_sDOC_LOZIB = null;
            }
            else
            {
                m_sDOC_LONCONTA = oRow["DOC_LONCONTA"].ToString();
                m_sDOC_LONCHEQUE = oRow["DOC_LONCHEQUE"].ToString();
                m_dDOC_LOMONTANTE = Convert.ToDecimal(oRow["DOC_LOMONTANTE"]);
                m_sDOC_LOTIPO = oRow["DOC_LOTIPO"].ToString();
            }

            if (iMDI02 == 1)
            {
                m_sDEP_ID = oRow["DEP_ID"].ToString();  //apenas MDI
                m_sDEP_APLICACAO = oRow["DEP_APLICACAO"].ToString();   //apenas MDI
                m_iDEP_ESTADO = Convert.ToInt32(oRow["DEP_ESTADO"]);  //apenas MDI

                if (m_sDOC_LOZIB != null)
                {
                    m_sDOC_INDICADORREENVIO = oRow["DOC_INDICADOR_REENVIO"].ToString();   //apenas MDI
                    m_iDOC_NSEQ = Convert.ToInt32(oRow["DOC_NSEQ"]); //apenas MDI
                    m_sDOC_REFINDEX = oRow["DOC_REFINDEX"].ToString();   //apenas MDI
                    m_iDOC_ESTADO = Convert.ToInt32(oRow["DOC_ESTADO"]);  //apenas MDI
                }
            }

            if (iMDI02 == 2)
            {
                m_sDEPC_ID = oRow["DEPC_ID"].ToString();   //apenas 02
                m_sDOC_ID = oRow["DOC_ID"].ToString();  //apenas 02
            }

            //Apenas existem na tabela do CI
            //m_sDOCMDI_ID = oRow["DOCMDI_ID"].ToString();
            //m_dtTIMER = Convert.ToDateTime(oRow["TIMER"]);
            //m_iESTADO_PROC = Convert.ToInt32(oRow["ESTADO_PROC"]);
        
        }

        public byte[] LoadImage(string sFileName)
        {
            StreamReader sr = new StreamReader(sFileName);
            BinaryReader br = new BinaryReader(sr.BaseStream);

            byte[] aBytes = br.ReadBytes((int)sr.BaseStream.Length);

            sr.Close();
            br.Close();
            return aBytes;
        }

        public void InsertDocumentoMDI02(CIConfigGP.CIGlobalParameters oParameters, int iMDI02 /*MDI=1,02=2*/, bool bImportarImagens)
        {
            string sSPName="";
            ArrayList oParam = new ArrayList();

            oParam.Add(new GeneralDBParameters("@CA_PAIS", m_sCA_PAIS));
            oParam.Add(new GeneralDBParameters("@CA_BANCO", m_iCA_BANCO));
            oParam.Add(new GeneralDBParameters("@CA_BALCAO", m_iCA_BALCAO));
            oParam.Add(new GeneralDBParameters("@CA_NUMERO", m_iCA_NUMERO));
            oParam.Add(new GeneralDBParameters("@CA_IDDISPOSITIVO", m_sCA_IDDISPOSITIVO));
            oParam.Add(new GeneralDBParameters("@CA_BALCAOGESTOR", m_iCA_BALCAOGESTOR));
            oParam.Add(new GeneralDBParameters("@DEP_DATA", m_dtDEP_MOVTIME));
//            oParam.Add(new GeneralDBParameters("@DEP_MOVTIME", m_dtDEP_MOVTIME));
            oParam.Add(new GeneralDBParameters("@DEP_NSESSAO", m_iDEP_NSESSAO));
            oParam.Add(new GeneralDBParameters("@DEP_NRECOLHA", m_iDEP_NRECOLHA));
            oParam.Add(new GeneralDBParameters("@DEP_NSEQOPERACAO", m_iDEP_NSEQOPERACAO));
            oParam.Add(new GeneralDBParameters("@DEP_QTDOCS", m_iDEP_QTDOCS));
            oParam.Add(new GeneralDBParameters("@DEP_MONTANTE", m_dDEP_MONTANTE));
            oParam.Add(new GeneralDBParameters("@DEP_NUMCONTA", m_sDEP_NUMCONTA));
            oParam.Add(new GeneralDBParameters("@DEP_ESTADO_OPER", m_iDEP_ESTADO_OPER));
            oParam.Add(new GeneralDBParameters("@DOC_LOZIB", m_sDOC_LOZIB));
            oParam.Add(new GeneralDBParameters("@DOC_LONCONTA", m_sDOC_LONCONTA));
            oParam.Add(new GeneralDBParameters("@DOC_LONCHEQUE", m_sDOC_LONCHEQUE));
            oParam.Add(new GeneralDBParameters("@DOC_LOMONTANTE", m_dDOC_LOMONTANTE));
            oParam.Add(new GeneralDBParameters("@DOC_LOTIPO", m_sDOC_LOTIPO));

            if (iMDI02 == 1)
            {
                sSPName = "mdi.Insert_DocumentoMDI";
                oParam.Add(new GeneralDBParameters("@DEP_ID", m_sDEP_ID));
                oParam.Add(new GeneralDBParameters("@DEP_APLICACAO", m_sDEP_APLICACAO));
                oParam.Add(new GeneralDBParameters("@DOC_INDICADOR_REENVIO", m_sDOC_INDICADORREENVIO));
                oParam.Add(new GeneralDBParameters("@DOC_NSEQ", m_iDOC_NSEQ));
                oParam.Add(new GeneralDBParameters("@DOC_REFINDEX", m_sDOC_REFINDEX));
                oParam.Add(new GeneralDBParameters("@DEP_ESTADO", m_iDEP_ESTADO));
                oParam.Add(new GeneralDBParameters("@DOC_ESTADO", m_iDOC_ESTADO));

                if (bImportarImagens &&
                    (m_sDOC_LOZIB != null || m_sDOC_LONCONTA != null || m_sDOC_LONCHEQUE != null))
                {
                    oParam.Add(new GeneralDBParameters("@DOC_TIPOIMAGEMFRENTE", "JPG"));
                    oParam.Add(new GeneralDBParameters("@DOC_TIPOIMAGEMVERSO", "JPG"));
                    oParam.Add(new GeneralDBParameters("@DOC_IMAGEMFRENTE", LoadImage("D:\\CGD\\ControloCA\\DVP\\NET2.0\\ModusCI\\Icons\\DOC_FRONT.JPG")));
                    oParam.Add(new GeneralDBParameters("@DOC_IMAGEMVERSO", LoadImage("D:\\CGD\\ControloCA\\DVP\\NET2.0\\ModusCI\\Icons\\DOC_REAR.JPG")));
                }
            }
            if (iMDI02 == 2)
            {
                sSPName = "mdi.Insert_Documento02";
                oParam.Add(new GeneralDBParameters("@DEPC_ID", m_sDEPC_ID));
                oParam.Add(new GeneralDBParameters("@DOC_ID", m_sDOC_ID));
            }

            int iTentativas = 0;
            Repete:
            iTentativas++;
            try
            {
                oParameters.DirectStoredProcedureNonQuery(sSPName, ref oParam);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, sSPName, 200);
                if (iTentativas < 4)
                {
                    goto Repete;
                }
                MessageBox.Show(ex.Message, sSPName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                DialogResult oRes = MessageBox.Show("Insistir?\nCancel para Skip", sSPName, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (oRes == DialogResult.No)
                {
                    throw;
                }
                if (oRes != DialogResult.Cancel)
                {
                    return;
                }
                goto Repete;
            }
        }

        public void WSInsertDocumentoMDI(GlobalParameters oParameters, bool bImportarImagens)
        {

            NBiis.CCAGeneric.Parameters oParam=null;
            ///U:NVB0047 /P:0 /S:1 /A:7  /H:GCXSQLPRDVS301 /D:BDSPGCCALX
            oParam = new NBiis.CCAGeneric.Parameters();

            oParam.DatabaseName = oParameters.DatabaseName;
            oParam.Host = oParameters.Host;
            oParam.DataBase = oParameters.DataBase;

            MDIWebTransmCI.TInsertDoc oWS = null;
            int iTentativas1 = 0;
        Repete1:
            iTentativas1++;
            try
            {
                oWS = null;
                oWS = new MDIWebTransmCI.TInsertDoc(oParam);
            }
            catch (Exception ex)
            {
                if (iTentativas1 < 4)
                {
                    goto Repete1;
                }
                if (MessageBox.Show(ex.Message + "\nContinuar?", "new MDIWebTransmCI.TInsertDoc(oParam)", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                {
                    throw;
                }
            }

            if (m_sDOC_INDICADORREENVIO == null) m_sDOC_INDICADORREENVIO = "";
            if (m_sDOC_LOZIB == null) m_sDOC_LOZIB = "";
            if (m_sDOC_LONCONTA == null) m_sDOC_LONCONTA = "";
            if (m_sDOC_LONCHEQUE == null) m_sDOC_LONCHEQUE = "";
            if (m_sDOC_LOTIPO == null) m_sDOC_LOTIPO = "";
            if (m_sDOC_REFINDEX == null) m_sDOC_REFINDEX = "";

            oWS.m_sCA_PAIS	=	m_sCA_PAIS;
            oWS.m_iCA_BANCO	=	m_iCA_BANCO;
            oWS.m_iCA_BALCAO	=	m_iCA_BALCAO;
            oWS.m_iCA_NUMERO	=	m_iCA_NUMERO;
            oWS.m_sCA_IDDISPOSITIVO	=	m_sCA_IDDISPOSITIVO;
            oWS.m_iCA_BALCAOGESTOR	=	m_iCA_BALCAOGESTOR;
            oWS.m_dtDEP_DATA	=	m_dtDEP_MOVTIME;
            oWS.m_iDEP_NSESSAO	=	m_iDEP_NSESSAO;
            oWS.m_iDEP_NRECOLHA	=	m_iDEP_NRECOLHA;
            oWS.m_iDEP_NSEQOPERACAO	=	m_iDEP_NSEQOPERACAO;
            oWS.m_sDEP_ID  	=	m_sDEP_ID;
            oWS.m_iDEP_QTDOCS	=	m_iDEP_QTDOCS;
            oWS.m_iDEP_ESTADO 	=	m_iDEP_ESTADO;
            oWS.m_dDEP_MONTANTE	=	m_dDEP_MONTANTE;
            oWS.m_sDEP_NUMCONTA	=	m_sDEP_NUMCONTA;
            oWS.m_sDEP_APLICACAO  	=	m_sDEP_APLICACAO;
            oWS.m_iDEP_ESTADO_OPER	=	m_iDEP_ESTADO_OPER;
            oWS.m_sDOC_INDICADORREENVIO  	=	m_sDOC_INDICADORREENVIO;
            oWS.m_sDOC_LOZIB	=	m_sDOC_LOZIB;
            oWS.m_sDOC_LONCONTA	=	m_sDOC_LONCONTA;
            oWS.m_sDOC_LONCHEQUE	=	m_sDOC_LONCHEQUE;
            oWS.m_dDOC_LOMONTANTE	=	m_dDOC_LOMONTANTE;
            oWS.m_sDOC_LOTIPO	=	m_sDOC_LOTIPO;
            oWS.m_iDOC_NSEQ 	=	m_iDOC_NSEQ;
            oWS.m_sDOC_REFINDEX   	=	m_sDOC_REFINDEX;
            oWS.m_iDOC_ESTADO  	=	m_iDOC_ESTADO;

            oWS.m_sImageTypeFrente = "JPG";
            oWS.m_sImageTypeVerso = "JPG";
            oWS.m_abImagemFrente = null;// new Byte[1];
            oWS.m_abImagemVerso = null;// new Byte[1];

            if (bImportarImagens &&
                (m_sDOC_LOZIB != "" || m_sDOC_LONCONTA != "" || m_sDOC_LONCHEQUE != ""))
            {
                oWS.m_abImagemFrente = LoadImage("D:\\CGD\\ControloCA\\DVP\\NET2.0\\ModusCI\\Icons\\DOC_FRONT.JPG");
                oWS.m_abImagemVerso = LoadImage("D:\\CGD\\ControloCA\\DVP\\NET2.0\\ModusCI\\Icons\\DOC_REAR.JPG");
            }

            int iTentativas = 0;
        Repete:
            iTentativas++;
            try
            {
                //GenericLog.GenLogRegistarInfo("Envio para " + m_iCA_BALCAOGESTOR.ToString() + " do DEP_ID", "WSInsertDocumentoMDI()", Convert.ToInt32(m_sDEP_ID));
                string sMsg = "";
                if (!oWS.Execute())
                {
                    sMsg = "Erro na invocação do WS";
                    sMsg += "\nErrorNumber: " + oWS.m_dErrorNumber;
                    sMsg += "\nErrorMessage: " + oWS.m_sErrorMessage;
                    sMsg += "\nErrorDscMessage: " + oWS.m_sErrorDscMessage;

                    if (oWS.m_dErrorNumber == 410)
                    {
                    }
                    else
                    {
                        throw new Exception(sMsg);
                    }
                }
                ShowError(sMsg);
            }
            catch (Exception ex)
            {
                ShowError(ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "WSInsertDocumentoMDI()", 201);
                if (iTentativas < 4)
                {
                    goto Repete;
                }
                MessageBox.Show(ex.Message, "WSInsertDocumentoMDI()", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DialogResult oRes = MessageBox.Show("Insistir?\nCancel para Skip", "WSInsertDocumentoMDI()", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (oRes == DialogResult.No)
                {
                    throw;
                }
                if (oRes == DialogResult.Cancel)
                {
                    oWS = null;
                    return;
                }
                goto Repete;
            }
            oWS = null;

        }

        void ShowError(string sMsg)
        {
            if (m_oForm != null)
            {
                m_oForm.textBoxError.Text = sMsg;
                if (sMsg.Length > 0)
                {
                    m_oForm.textBoxError.BackColor = Color.Red;
                }
                else
                {
                    m_oForm.textBoxError.BackColor = System.Drawing.SystemColors.GrayText;
                }
                System.Windows.Forms.Application.DoEvents();
            }
        }

        public ListViewItem MakeListViewItem(string sDateFormat, string sDateTimeFormat, int iMDI02 /*MDI=1,02=2*/ )
        {
            ListViewItem olvItem = new ListViewItem();

            //if (iMDI02 == 1) olvItem.Text = m_sDOCMDI_ID;
            //if (iMDI02 == 2) olvItem.Text = m_sDOC02_ID;

            olvItem.Text = m_sDOCMDI_ID;
            olvItem.SubItems.Add(m_sDOC02_ID);

            olvItem.SubItems.Add(m_sCA_PAIS);
            olvItem.SubItems.Add(m_iCA_BANCO.ToString().PadLeft(4, ' '));
            olvItem.SubItems.Add(m_iCA_BALCAO.ToString("0000"));
            olvItem.SubItems.Add(m_iCA_NUMERO.ToString().PadLeft(4, ' '));
            olvItem.SubItems.Add(m_sCA_IDDISPOSITIVO);
            olvItem.SubItems.Add(m_iCA_BALCAOGESTOR.ToString("0000"));
            olvItem.SubItems.Add(m_dtDEP_DATA.ToString(sDateFormat));
            olvItem.SubItems.Add(m_dtDEP_MOVTIME.ToString(sDateTimeFormat));
            olvItem.SubItems.Add(m_iDEP_NSESSAO.ToString().PadLeft(4, ' '));
            olvItem.SubItems.Add(m_iDEP_NRECOLHA.ToString().PadLeft(2, ' '));
            olvItem.SubItems.Add(m_iDEP_NSEQOPERACAO.ToString().PadLeft(5, ' '));
            if (iMDI02 == 1) olvItem.SubItems.Add(m_sDEP_ID);
            if (iMDI02 == 2) olvItem.SubItems.Add(m_sDEPC_ID);
            olvItem.SubItems.Add(m_iDEP_QTDOCS.ToString().PadLeft(4, ' '));
            if (iMDI02==1) olvItem.SubItems.Add(m_iDEP_ESTADO.ToString()); //apenas MDI
            olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dDEP_MONTANTE).PadLeft(16, ' '));
            olvItem.SubItems.Add(m_sDEP_NUMCONTA);
            if (iMDI02 == 1) olvItem.SubItems.Add(m_sDEP_APLICACAO);   //apenas MDI
            olvItem.SubItems.Add(m_iDEP_ESTADO_OPER.ToString());
            if (iMDI02 == 1) olvItem.SubItems.Add(m_sDOC_INDICADORREENVIO);   //apenas MDI
            olvItem.SubItems.Add(m_sDOC_LOZIB);
            olvItem.SubItems.Add(m_sDOC_LONCONTA);
            olvItem.SubItems.Add(m_sDOC_LONCHEQUE);
            olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dDOC_LOMONTANTE).PadLeft(16, ' '));
            olvItem.SubItems.Add(m_sDOC_LOTIPO);
            if (iMDI02 == 2) olvItem.SubItems.Add(m_sDOC_ID); //apenas 02
            if (iMDI02 == 1) olvItem.SubItems.Add(m_iDOC_NSEQ.ToString().PadLeft(3, ' ')); //apenas MDI
            if (iMDI02 == 1) olvItem.SubItems.Add(m_sDOC_REFINDEX);   //apenas MDI
            if (iMDI02 == 1) olvItem.SubItems.Add(m_iDOC_ESTADO.ToString());  //apenas MDI
            olvItem.SubItems.Add(m_dtCI_TIMER.ToString(sDateTimeFormat));
            olvItem.SubItems.Add(m_iCI_ESTADO_PROC.ToString());

            return olvItem;
        }

    }
}
