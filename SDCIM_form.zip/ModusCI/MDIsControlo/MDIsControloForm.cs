﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace MDIsControlo
{
    public partial class MDIsControloForm : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        protected CIConfigGP.CIGlobalParameters m_oParametersGCAA9601;
        protected CIConfigGP.CIGlobalParameters m_oParametersGCAA9604;
        protected CIConfigGP.CIGlobalParameters m_oParametersGCAA;
        protected CIConfigGlobalParameters.CIMenuInterface m_oMenuInterface;

        public MDIsControloForm(CIConfigGP.CIGlobalParameters oParameters, CIConfigGP.CIGlobalParameters oParameters9601, CIConfigGP.CIGlobalParameters oParameters9604, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_oParametersGCAA9601 = oParameters9601;
            m_oParametersGCAA9604 = oParameters9604;
            m_oParametersGCAA = m_oParametersGCAA9601;
            m_oMenuInterface = oMenuInterface;
        }

        void LoadInformacaoInicial()
        {
            m_textBoxMenorData.Text = Convert.ToDateTime(m_oParameters.DirectSqlScalar("select isnull(min(DEP_DATA), 0) from mdi.documento_mdi")).ToString(m_oParameters.DateFormat);
            m_textBoxMaiorData.Text = Convert.ToDateTime(m_oParameters.DirectSqlScalar("select isnull(max(DEP_DATA), 0) from mdi.documento_mdi")).ToString(m_oParameters.DateFormat);
        }


        // MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's
        // MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's
        // MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's MDI's

        private void btImportarDocumento02_Click(object sender, EventArgs e)
        {

            btImportarDocumento02.Enabled = false;

            m_oParametersGCAA = null;
            if (textBoxLXPT02.Text == "9601")
            {
                m_oParametersGCAA = m_oParametersGCAA9601;
            }
            if (textBoxLXPT02.Text == "9604")
            {
                m_oParametersGCAA = m_oParametersGCAA9604;
            }

            DataSet ds = null;

            m_oParameters.OpenConnection();

            ImportarGCAA_02_MDI oImport = new ImportarGCAA_02_MDI(m_oParameters, m_oParametersGCAA);
            //string sWhereClause = " where docfis_id is not null and TCA_TIPO=1 and ADEP_ID>=500 and CADEPC_DATA between '" + m_ctrlDataIni.Value.ToString(m_oParameters.DateFormat) + "' and '" + m_ctrlDataFim.Value.ToString(m_oParameters.DateFormat) + "' and CA_PULU in " + sMaquinas;
            string sWhereClause = " where docfis_id is not null and TCA_TIPO=1 and CA_IS_MDI = 1 and ADEP_ID>=500 and CADEPC_DATA between '" + m_ctrlDataIni.Value.ToString(m_oParameters.DateFormat) + "' and '" + m_ctrlDataFim.Value.ToString(m_oParameters.DateFormat) + "'";
            string sQuery = oImport.MakeQuery02(sWhereClause);

            try
            {
                int iCount = 0;
                ds = null;
                ds = m_oParametersGCAA.DirectSqlDataSet(sQuery, "Importar02");
                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    m_labelDocumento02.Text = "Importados: " + iCount++;
                    System.Windows.Forms.Application.DoEvents();
                    oImport.InsertDocumento02(oRow);

                    if (btImportarDocumento02.Enabled)
                    {
                        throw new Exception("Importar02 Canceled");
                    }
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "btImportarDocumento02_Click()", 100);
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ds.Dispose();
                ds = null;
            }

            m_oParameters.CloseConnection();

            btImportarDocumento02.Enabled = true;
        }


        private void buttonStop02_Click(object sender, EventArgs e)
        {
            btImportarDocumento02.Enabled = true;
        }

        private void MDIsControloForm_Load(object sender, EventArgs e)
        {
            m_oMenuInterface.ControloMDIsFormMenuItemEnable(false);

            this.m_ctrlDataIni.Value = DateTime.Now.AddDays(-3);
            //this.Text = m_oParametersGCAA.GetProfileString("Genericos", "Config", "BalcaoGestor", "ND");
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;

            this.btImportarDocumento02.Enabled = (m_oParameters.UserLogged.m_iUserGroup < 1);
            this.buttonStop02.Enabled = (m_oParameters.UserLogged.m_iUserGroup < 1);
            this.buttonProcessaImportação.Enabled = (m_oParameters.UserLogged.m_iUserGroup < 1);

            this.splitContainer1.Panel1.Enabled = (m_oParameters.UserLogged.m_iUserGroup < 1);
            this.splitContainer1.Panel1Collapsed = (m_oParameters.UserLogged.m_iUserGroup > 0);

            LoadInformacaoInicial();
        }

        private void AddRow2ListViewMDI(DataRow oRow)
        {
            Documento_02_MDI oDoc = new Documento_02_MDI(oRow, 1, true);

            ListViewItem olvItem = oDoc.MakeListViewItem(m_oParameters.DateFormat, m_oParameters.DateTimeSysFmt, 1);

            olvItem.Tag = oDoc;

            m_listViewDocumentosMDI.Items.Add(olvItem);

        }

        private void AddRow2ListView02(DataRow oRow)
        {
            Documento_02_MDI oDoc = new Documento_02_MDI(oRow, 2, true);

            ListViewItem olvItem = oDoc.MakeListViewItem(m_oParameters.DateFormat, m_oParameters.DateTimeSysFmt, 2);

            olvItem.Tag = oDoc;

            m_listViewDocumentos02.Items.Add(olvItem);

        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            string sQuery = "select * from mdi.DOCUMENTO_MDI where DEP_DATA between '" + m_dateTimePickerMenor.Value.ToString(m_oParameters.DateFormat) + "' and '" + m_dateTimePickerMaior.Value.ToString(m_oParameters.DateFormat) + "'";

            try
            {
                if (textBoxBalcao.Text.Trim().Length != 0)
                {
                    sQuery += " and CA_BALCAO=" + textBoxBalcao.Text;
                }
                if (textBoxSequencia.Text.Trim().Length != 0)
                {
                    sQuery += " and CA_NUMERO=" + textBoxSequencia.Text;
                }

                m_buttonRefreshMDI.Enabled = false;
                m_listViewDocumentosMDI.MyClear();
                
                m_listViewDocumentosMDI.BeginUpdate();

                DataSet ds = null;
                ds = m_oParameters.DirectSqlDataSet(sQuery, "DocumentoMDI");
                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    AddRow2ListViewMDI(oRow);
                    m_textBoxNItemsMDI.Text = m_listViewDocumentosMDI.Items.Count.ToString() + " Registos";
                    if (m_listViewDocumentosMDI.Items.Count % 10 == 0)
                    {
                        System.Windows.Forms.Application.DoEvents();
                    }

                    if (m_buttonRefreshMDI.Enabled)
                    {
                        throw new Exception("Refresh Canceled");
                    }
                }

                m_textBoxNItemsMDI.Text = m_listViewDocumentosMDI.Items.Count.ToString() + " Registos";
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "buttonRefresh_Click()", 100);
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                m_listViewDocumentosMDI.EndUpdate();
                m_buttonRefreshMDI.Enabled = true;
                m_textBoxNItemsMDI.Text = m_listViewDocumentosMDI.Items.Count.ToString() + " Registos";
                System.Windows.Forms.Application.DoEvents();
            }

        }

        private void buttonStopRefresh_Click(object sender, EventArgs e)
        {
            m_buttonRefreshMDI.Enabled = true;
        }

        private void listViewDocumentos_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Documento_02_MDI oDoc = (Documento_02_MDI)m_listViewDocumentosMDI.SelectedItems[0].Tag;
            MostraImagem fMostraImg = new MostraImagem(m_oParameters, oDoc.m_sDOCMDI_ID);
            fMostraImg.ShowDialog();
        }

        private void m_buttonRefresh02_Click(object sender, EventArgs e)
        {
            string sQuery = "select * from mdi.DOCUMENTO_02 where DEP_DATA between '" + m_dateTimePickerMenor.Value.ToString(m_oParameters.DateFormat) + "' and '" + m_dateTimePickerMaior.Value.ToString(m_oParameters.DateFormat) + "'";

            try
            {
                if (textBoxBalcao.Text.Trim().Length != 0)
                {
                    sQuery += " and CA_IDDISPOSITIVO like '" + textBoxBalcao.Text + "%'";
                }
                m_buttonRefresh02.Enabled = false;
                m_listViewDocumentos02.MyClear();

                m_listViewDocumentos02.BeginUpdate();

                DataSet ds = null;
                ds = m_oParameters.DirectSqlDataSet(sQuery, "Documento02");
                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    AddRow2ListView02(oRow);
                    m_textBoxNItems02.Text = m_listViewDocumentos02.Items.Count.ToString() + " Registos";
                    if (m_listViewDocumentos02.Items.Count % 10 == 0)
                    {
                        System.Windows.Forms.Application.DoEvents();
                    }

                    if (m_buttonRefresh02.Enabled)
                    {
                        throw new Exception("Refresh Canceled");
                    }
                }

                m_textBoxNItems02.Text = m_listViewDocumentos02.Items.Count.ToString() + " Registos";
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "m_buttonRefresh02_Click()", 100);
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                m_listViewDocumentos02.EndUpdate();
                m_buttonRefresh02.Enabled = true;
                m_textBoxNItems02.Text = m_listViewDocumentos02.Items.Count.ToString() + " Registos";
                System.Windows.Forms.Application.DoEvents();
            }

        }

        private void m_buttonStopRefresh02_Click(object sender, EventArgs e)
        {
            m_buttonRefresh02.Enabled = true;
        }

        private void buttonProcessaImportação_Click(object sender, EventArgs e)
        {

            try
            {
                Cursor = Cursors.WaitCursor;
                frmEspereUmMomento.ShowWaitForm();

                string sQuery = "exec [mdi].[Update_ProcessaDocumento02]";
                m_oParameters.DirectSqlNonQuery(sQuery);

                sQuery = "delete mdi.DOCUMENTO_02 where CI_ESTADO_PROC=-1";
                m_oParameters.DirectSqlNonQuery(sQuery);

                sQuery = "delete mdi.DOCUMENTO_MDI where CI_ESTADO_PROC=-1";
                m_oParameters.DirectSqlNonQuery(sQuery);

                UpdateDOCMDI_DOC02();

                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
                MessageBox.Show("Documentos 02 Processados", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "buttonProcessaImportação_Click()", 100);
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
        }

        private void UpdateDOCMDI_DOC02()
        {

            string sQuery;

            sQuery = "exec mdi.Update_AssociaDOCMDI_DOC02";
            m_oParameters.DirectSqlNonQuery(sQuery);
            return;

            sQuery = "";
            sQuery += "update mdi.DOCUMENTO_02 set DOCMDI_ID=lista.DOCMDI_ID ";
            sQuery += "from mdi.DOCUMENTO_02  ";
            sQuery += "inner join ";
            sQuery += "( ";
            sQuery += "	select d02.DOC02_ID, dmdi.DOCMDI_ID from mdi.DOCUMENTO_02 d02 inner join mdi.DOCUMENTO_MDI dmdi on  ";
            sQuery += "		d02.DOCMDI_ID is null and ";
            sQuery += "		d02.CA_BALCAO=dmdi.CA_BALCAO and ";
            sQuery += "		d02.CA_NUMERO=dmdi.CA_NUMERO and ";
            sQuery += "		d02.DEP_NSESSAO=dmdi.DEP_NSESSAO and ";
            sQuery += "		d02.DEP_NUMCONTA=dmdi.DEP_NUMCONTA and  ";
            sQuery += "		d02.DOC_LOMONTANTE=dmdi.DOC_LOMONTANTE ";
            sQuery += "	where d02.DOC02_ID not in ";
            sQuery += "	(select d02.DOC02_ID from mdi.DOCUMENTO_02 d02 inner join mdi.DOCUMENTO_MDI dmdi on  ";
            sQuery += "		d02.DOCMDI_ID is null and ";
            sQuery += "		d02.CA_BALCAO=dmdi.CA_BALCAO and ";
            sQuery += "		d02.CA_NUMERO=dmdi.CA_NUMERO and ";
            sQuery += "		d02.DEP_NSESSAO=dmdi.DEP_NSESSAO and ";
            sQuery += "		d02.DEP_NUMCONTA=dmdi.DEP_NUMCONTA and  ";
            sQuery += "		d02.DOC_LOMONTANTE=dmdi.DOC_LOMONTANTE ";
            sQuery += "	group by d02.DOC02_ID having count(*)>1) ";
            sQuery += "	and dmdi.DOCMDI_ID not in ";
            sQuery += "	(select dmdi.DOCMDI_id from mdi.DOCUMENTO_02 d02 inner join mdi.DOCUMENTO_MDI dmdi on  ";
            sQuery += "		d02.DOCMDI_ID is null and ";
            sQuery += "		d02.CA_BALCAO=dmdi.CA_BALCAO and ";
            sQuery += "		d02.CA_NUMERO=dmdi.CA_NUMERO and ";
            sQuery += "		d02.DEP_NSESSAO=dmdi.DEP_NSESSAO and ";
            sQuery += "		d02.DEP_NUMCONTA=dmdi.DEP_NUMCONTA and  ";
            sQuery += "		d02.DOC_LOMONTANTE=dmdi.DOC_LOMONTANTE ";
            sQuery += "	group by dmdi.DOCMDI_ID having count(*)>1) ";
            sQuery += ") lista on lista.DOC02_ID=mdi.DOCUMENTO_02.DOC02_ID ";
            m_oParameters.DirectSqlNonQuery(sQuery);

            sQuery = "";
            sQuery += "update mdi.DOCUMENTO_02 set DOCMDI_ID=lista.DOCMDI_ID ";
            sQuery += "from mdi.DOCUMENTO_02  ";
            sQuery += "inner join ";
            sQuery += "( ";
            sQuery += "	select d02.DOC02_ID, dmdi.DOCMDI_ID from mdi.DOCUMENTO_02 d02 inner join mdi.DOCUMENTO_MDI dmdi on ";
            sQuery += "	    d02.DOCMDI_ID is null and ";
            sQuery += "		d02.CA_BALCAO=dmdi.CA_BALCAO and ";
            sQuery += "		d02.CA_NUMERO=dmdi.CA_NUMERO and ";
            sQuery += "		d02.DEP_NSESSAO=dmdi.DEP_NSESSAO and ";
            sQuery += "		d02.DEP_NUMCONTA=dmdi.DEP_NUMCONTA and  ";
            sQuery += "		d02.DOC_LONCHEQUE=dmdi.DOC_LONCHEQUE and ";
            sQuery += "		d02.DOC_LOMONTANTE=dmdi.DOC_LOMONTANTE ";
            sQuery += "	where d02.DOC02_ID not in ";
            sQuery += "	(select d02.DOC02_ID from mdi.DOCUMENTO_02 d02 inner join mdi.DOCUMENTO_MDI dmdi on  ";
            sQuery += "		d02.DOCMDI_ID is null and ";
            sQuery += "		d02.CA_BALCAO=dmdi.CA_BALCAO and ";
            sQuery += "		d02.CA_NUMERO=dmdi.CA_NUMERO and ";
            sQuery += "		d02.DEP_NSESSAO=dmdi.DEP_NSESSAO and ";
            sQuery += "		d02.DEP_NUMCONTA=dmdi.DEP_NUMCONTA and  ";
            sQuery += "		d02.DOC_LONCHEQUE=dmdi.DOC_LONCHEQUE and ";
            sQuery += "		d02.DOC_LOMONTANTE=dmdi.DOC_LOMONTANTE ";
            sQuery += "	group by d02.DOC02_ID having count(*)>1) ";
            sQuery += "	and dmdi.DOCMDI_ID not in ";
            sQuery += "	(select dmdi.DOCMDI_id from mdi.DOCUMENTO_02 d02 inner join mdi.DOCUMENTO_MDI dmdi on  ";
            sQuery += "		d02.DOCMDI_ID is null and ";
            sQuery += "		d02.CA_BALCAO=dmdi.CA_BALCAO and ";
            sQuery += "		d02.CA_NUMERO=dmdi.CA_NUMERO and ";
            sQuery += "		d02.DEP_NSESSAO=dmdi.DEP_NSESSAO and ";
            sQuery += "		d02.DEP_NUMCONTA=dmdi.DEP_NUMCONTA and  ";
            sQuery += "		d02.DOC_LONCHEQUE=dmdi.DOC_LONCHEQUE and ";
            sQuery += "		d02.DOC_LOMONTANTE=dmdi.DOC_LOMONTANTE ";
            sQuery += "	group by dmdi.DOCMDI_ID having count(*)>1) ";
            sQuery += ") lista on lista.DOC02_ID=mdi.DOCUMENTO_02.DOC02_ID ";
            m_oParameters.DirectSqlNonQuery(sQuery);

        }
    }
}