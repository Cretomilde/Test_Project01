﻿Imports GCCA.CCAWebTransmCI


Public Class MDIOutputFixo
    Inherits OutputFixo

    Public Sub New(ByVal oOutPut As waiaccesstuInsertDoc.Insert_DocumentoMDIOutput)

        ' Processar os erros
        m_oErro = New OutputFixo.WebTransmCIErro()

        m_oErro.m_sErrorMsg = oOutPut.error.errorMsg
        m_oErro.m_iGeneralError = oOutPut.error.generalErrorCode
        m_oErro.m_sSpecificErrorCodeField = oOutPut.error.specificErrorCode

        m_iPageIndex = oOutPut.pageIndex
        m_iPageIndexSize = oOutPut.pageSize
        m_iRowsAffected = oOutPut.rowsAffected
        m_iRowsReturned = oOutPut.rowsReturned
        m_iSqlCode = oOutPut.sqlCode
        m_iSqlStatus = oOutPut.sqlState

    End Sub
End Class
