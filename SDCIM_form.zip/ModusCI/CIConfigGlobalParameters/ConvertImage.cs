﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Runtime.InteropServices;

namespace CIConfigGlobalParameters
{
    public class ConvertImage
    {
        [DllImport("NBImageConverter.DLL")]
        unsafe static extern public bool ConvertJPEGToGrayScale(String sImageSource, String sImageDest, long lQualidade, long lDPI, long lContrast, long lBrightness);
        
        [DllImport("NBImageConverter.DLL")]
        unsafe static extern public String GetLastErrorMessage();

        public static void _ConvertJPEGToGrayScale(String sImageSource, String sImageDest, long lQualidade, long lDPI, long lContrast, long lBrightness)
        {
            if (!ConvertJPEGToGrayScale(sImageSource, sImageDest, lQualidade, lDPI, lContrast, lBrightness))
            {
                String sErro = GetLastErrorMessage();

                throw new Exception(sErro);
            }
        }
    }
}
