﻿using System;
using System.Data;
using System.Windows.Forms;

namespace CIFicheirosControlo
{
    class ListViewImportLoteEnvm : ListViewImportLote
    {
        long m_lREM_ID;
        long m_lLoteEnvmNumero;
        int m_iLoteEnvmCodBal;
        string m_sLoteEnvmDescBal;
        string m_sLoteEnvmNREM;
        DateTime m_dtLoteEnvmDtRem;
        int m_iLoteEnvmTCAP;
        int m_iLoteEnvmTREM;
        double m_dLoteEnvmMontante;
        long m_lLoteEnvmNrDocum;
        int m_iLoteEnvmAnomal;
        string m_sLoteEnvmChaveH;
        string m_sLoteEnvmChaveHext;
        int m_iLoteEnvmValReq;
        string m_sLoteEnvmSERVADIC;
        double m_dLoteEnvmMontapu;
        int m_iLoteEnvmTotReg;
        double m_dLoteEnvmMontTotal;

        int m_iLoteEnvmCGDError;
        String m_OrigemDesc = string.Empty;
        public String m_sLoteEnv_DescAnomalia { get; set; }

        public ListViewImportLoteEnvm(DataRow oRow, CIConfigGP.CIGlobalParameters oParameters)
            :base(oRow, oParameters)
        {
            m_lLoteId = Convert.ToInt64(oRow["LOTEENV_ID"]);
            m_lFichId = Convert.ToInt64(oRow["FICH_ID"]);
            if (oRow["REMIN_ID"] != DBNull.Value)
            {
                this.m_lREM_ID = Convert.ToInt64(oRow["REMIN_ID"]);
            }
            else
            {
                this.m_lREM_ID = 0;
            }
            m_sLoteEnvmNREM = oRow["LOTEENV_NREM"].ToString();
            m_lLoteEnvmNumero = Convert.ToInt64(oRow["LOTEENV_NUMERO"]);
            m_iLoteEnvmCodBal = Convert.ToInt16(oRow["LOTEENV_CODBAL"]);
            m_dtLoteEnvmDtRem = Convert.ToDateTime(oRow["LOTEENV_DTREM"]);
            m_iLoteEnvmTCAP = Convert.ToInt16(oRow["LOTEENV_TCAP"]);
            m_iLoteEnvmTREM = Convert.ToInt16(oRow["LOTEENV_TREM"]);
            m_dLoteEnvmMontante = Convert.ToDouble(oRow["LOTEENV_MONTANTE"]);
            m_lLoteEnvmNrDocum = Convert.ToInt64(oRow["LOTEENV_NRDOCUM"]);
            m_iLoteEnvmCGDError = Convert.ToInt16(oRow["LOTEENV_CGDERROR"]);
            m_iLoteEnvmAnomal = Convert.ToInt16(oRow["LOTEENV_ANOMAL"]);
            m_sLoteEnvmChaveH = oRow["LOTEENV_CHAVEH"].ToString();
            m_sLoteEnvmChaveHext = oRow["LOTEENV_CHAVEHEXT"].ToString();
            m_iLoteEnvmValReq = Convert.ToInt16(oRow["LOTEENV_VALREQ"]);
            m_sLoteEnvmSERVADIC = oRow["LOTEENV_SERVADIC"].ToString();
            m_dLoteEnvmMontapu = Convert.ToDouble(oRow["LOTEENV_MONTAPU"]);
            m_iLoteEnvmTotReg = Convert.ToInt16(oRow["LOTEENV_TOTREG"]);
            m_dLoteEnvmMontTotal = Convert.ToDouble(oRow["LOTEENV_MONTTOTAL"]);
            m_iLoteStatus = Convert.ToInt16(oRow["LOTESTATUS_ID"]);
            m_sLoteStatusDesc = oRow["LOTESTAT_DESC"].ToString();
            this.m_OrigemDesc = oRow["REMORI_DESC"].ToString();
            this.m_sLoteEnvmDescBal = oRow["BALCAO_DESC"].ToString();
            this.m_sLoteEnv_DescAnomalia = oRow["LOTEENV_ANOMAL_D"].ToString();
        }

        public override ListViewItem makeListViewLote(string sDateFormat, string sDateTimeFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_lLoteId.ToString();
            olvItem.SubItems.Add(m_lFichId.ToString());
            olvItem.SubItems.Add(m_lLoteEnvmNumero.ToString());
            olvItem.SubItems.Add(this.m_OrigemDesc);
            olvItem.SubItems.Add(m_iLoteStatus.ToString() + " " + m_sLoteStatusDesc);
            olvItem.SubItems.Add(m_iLoteEnvmCodBal.ToString("0000") + " - " + m_sLoteEnvmDescBal);
            olvItem.SubItems.Add(m_lREM_ID.ToString());
            olvItem.SubItems.Add(m_sLoteEnvmNREM);
            olvItem.SubItems.Add(m_dtLoteEnvmDtRem.ToString(m_oParameters.DateFormat));
            string montanteToInsert = this.m_dLoteEnvmMontante.ToString().Equals("0") ? this.m_dLoteEnvmMontante.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.m_dLoteEnvmMontante).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dLoteEnvmMontante).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(m_iLoteEnvmTREM.ToString());
            olvItem.SubItems.Add(m_iLoteEnvmTCAP.ToString());
            olvItem.SubItems.Add(m_lLoteEnvmNrDocum.ToString().PadLeft(5, ' '));
            olvItem.SubItems.Add(m_iLoteEnvmTotReg.ToString().PadLeft(5, ' '));
            string montanteToInsert2 = this.m_dLoteEnvmMontTotal.ToString().Equals("0") ? this.m_dLoteEnvmMontTotal.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.m_dLoteEnvmMontTotal).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dLoteEnvmMontTotal).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert2);
            olvItem.SubItems.Add(m_iLoteEnvmCGDError.ToString());
            olvItem.SubItems.Add(m_iLoteEnvmAnomal.ToString() + " " + this.m_sLoteEnv_DescAnomalia);
            string montanteToInsert3 = this.m_dLoteEnvmMontapu.ToString().Equals("0") ? this.m_dLoteEnvmMontapu.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.m_dLoteEnvmMontapu).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dLoteEnvmMontapu).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert3);
            olvItem.SubItems.Add(m_sLoteEnvmChaveH);
            olvItem.SubItems.Add(m_sLoteEnvmChaveHext);
            olvItem.SubItems.Add(m_iLoteEnvmValReq.ToString());
            olvItem.SubItems.Add(m_sLoteEnvmSERVADIC);
            olvItem.SubItems.Add(this.m_OrigemDesc);
            return olvItem;
        }

        public override string getTipoLote()
        {
            return "ENVM";
        }
    }
}
