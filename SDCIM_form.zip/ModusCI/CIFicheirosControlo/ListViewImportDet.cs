﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIFicheirosControlo
{
    abstract class ListViewImportDet
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public long m_lLoteId;
        public long m_lDetID;
        public string m_sDocChaveH;
        public string m_sDocChaveHext;

        public long m_lDocID;

        //SDCIM 7 - Adição de coluna DOCENVM Origem
        public Int16 m_iDocOrigemID = 0;
        public String m_sDocOrigemD = String.Empty;
        //SDCIM 7 - Adição de coluna DOCENVM Origem 

        public abstract ListViewItem makeListViewDet(string sDateFormat, string sDateTimeFormat);
        public abstract string getTipoDet();

        public ListViewImportDet()
        {
            m_lDetID = 0;
            m_lLoteId = 0;
            m_sDocChaveH = "";
            m_sDocChaveHext = "";

            this.m_oParameters = null;

        }
        public ListViewImportDet(DataRow oRow, CIConfigGP.CIGlobalParameters oParameters)
        {
            m_lDetID = 0;
            m_lLoteId = 0;
            m_sDocChaveH = "";
            m_sDocChaveHext = "";

            this.m_oParameters = oParameters;
        }

    }
}
