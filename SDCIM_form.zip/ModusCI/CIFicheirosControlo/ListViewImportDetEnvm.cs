﻿using System;
using System.Data;
using System.Windows.Forms;

namespace CIFicheirosControlo
{
    class ListViewImportDetEnvm : ListViewImportDet
    {
        string m_sDocEnvmZona5;
        string m_sDocEnvmZona4;
        string m_sDocEnvmZona3;
        double m_dDocEnvmZona2;
        string m_sDocEnvmZona1;        
        string m_sDocEnvmRefarq;
        int m_iDocEnvmAnomal;
        string m_sDocEnvmAnomal;
        int m_iDocEnvmImgQual;
        int m_iDocEnvmCodana;
        string m_sDocEnvmReqDoc;
        int m_iDocEnvmDuplicado;
        string m_sDocEnvmServadic;             

        public ListViewImportDetEnvm(DataRow oRow, CIConfigGP.CIGlobalParameters oParameters)
            :base(oRow, oParameters)
        {
            m_lDetID = Convert.ToInt64(oRow["DOCENV_ID"]);
            m_lLoteId = Convert.ToInt64(oRow["LOTEENV_ID"]);

            if (oRow["DOC_ID"] == DBNull.Value)
            {
                m_lDocID = 0;
            }
            else
            {
                m_lDocID = Convert.ToInt64(oRow["DOC_ID"]);
            }

            m_sDocEnvmZona5 = oRow["DOCENV_ZONA5"].ToString();
            m_sDocEnvmZona4 = oRow["DOCENV_ZONA4"].ToString();
            m_sDocEnvmZona3 = oRow["DOCENV_ZONA3"].ToString();
            m_dDocEnvmZona2 = Convert.ToDouble(oRow["DOCENV_ZONA2"]);
            m_sDocEnvmZona1 = oRow["DOCENV_ZONA1"].ToString();
            m_sDocEnvmRefarq = oRow["DOCENV_REFARQ"].ToString();
            m_sDocChaveH = oRow["DOCENV_CHAVEH"].ToString();
            m_sDocChaveHext = oRow["DOCENV_CHAVEHEXT"].ToString();
            m_iDocEnvmImgQual = Convert.ToInt16(oRow["DOCENV_IMGQUAL"]);
            m_iDocEnvmAnomal = Convert.ToInt16(oRow["DOCENV_ANOMAL"]);
            m_sDocEnvmAnomal = oRow["DOCENV_ANOMAL"].ToString() + " - " + oRow["ESTADO_DESC"].ToString();
            m_iDocEnvmCodana = Convert.ToInt16(oRow["DOCENV_CODANA"]);
            m_sDocEnvmReqDoc = oRow["DOCENV_REQDOC"].ToString();
            m_iDocEnvmDuplicado = Convert.ToInt16(oRow["DOCENV_DUPLICADO"]);
            m_sDocEnvmServadic = oRow["DOCENV_SERVADIC"].ToString();
           
            //SDCIM 7 - Adição de coluna DOCENVM Origem
            this.m_iDocOrigemID = Convert.ToInt16(oRow["DOCENV_ORIGEM_ID"]);
            this.m_sDocOrigemD = oRow["DOCENV_ORIGEM_D"].ToString();
            //SDCIM 7 - Adição de coluna DOCENVM Origem 
        }

        public override ListViewItem makeListViewDet(string sDateFormat, string sDateTimeFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_lDetID.ToString();
            olvItem.SubItems.Add(m_lLoteId.ToString());
            olvItem.SubItems.Add(m_lDocID.ToString());
            //SDCIM 7 - Adição de coluna DOCENVM Origem 
            olvItem.SubItems.Add(m_sDocOrigemD);
            //SDCIM 7 - Adição de coluna DOCENVM Origem 
            olvItem.SubItems.Add(m_sDocEnvmZona5);
            olvItem.SubItems.Add(m_sDocEnvmZona4);
            olvItem.SubItems.Add(m_sDocEnvmZona3);
            string montanteToInsert = this.m_dDocEnvmZona2.ToString().Equals("0") ? this.m_dDocEnvmZona2.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.m_dDocEnvmZona2).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dDocEnvmZona2).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(m_sDocEnvmZona1);
            olvItem.SubItems.Add(m_sDocEnvmRefarq);            
            olvItem.SubItems.Add(m_sDocEnvmAnomal);
            olvItem.SubItems.Add(m_iDocEnvmDuplicado.ToString());
            olvItem.SubItems.Add(m_iDocEnvmCodana.ToString());
            olvItem.SubItems.Add(m_sDocEnvmReqDoc);
            olvItem.SubItems.Add(m_sDocEnvmServadic);
            olvItem.SubItems.Add(m_iDocEnvmImgQual.ToString());
            olvItem.SubItems.Add(m_sDocChaveH);
            olvItem.SubItems.Add(m_sDocChaveHext);
            
            return olvItem;
        }

        public override string getTipoDet()
        {
            return "ENVM";
        }

    }
}
