﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIFicheirosControlo
{
    abstract class ListViewImportLote
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public long m_lLoteId;
        public long m_lFichId;
        public int m_iLoteStatus;
        public string m_sLoteStatusDesc;

        public abstract ListViewItem makeListViewLote(string sDateFormat, string sDateTimeFormat);
        public abstract string getTipoLote();

        public ListViewImportLote()
        {
            m_lLoteId = 0;
            m_lFichId = 0;
            m_iLoteStatus = 0;
            m_sLoteStatusDesc = "";
            
            this.m_oParameters = null;
        }

        public ListViewImportLote(DataRow oRow, CIConfigGP.CIGlobalParameters oParameters)
        {
            m_lLoteId = 0;
            m_lFichId = 0;
            m_iLoteStatus = 0;
            m_sLoteStatusDesc = "";

            this.m_oParameters = oParameters;
        }

    }
}
