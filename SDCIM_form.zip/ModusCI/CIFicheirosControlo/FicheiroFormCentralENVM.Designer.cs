﻿namespace CIFicheirosControlo
{
    partial class FicheiroFormCentralENVM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);

            if (getFich().Equals("ENVM"))
            {
                m_oMenuInterface.processarEnvmEnable(true);
            }
            if (getFich().Equals("ACOM"))
            {
                m_oMenuInterface.processaAcomEnable(true);
            }
            
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FicheiroFormCentralENVM));
            this.buttonImportar = new System.Windows.Forms.Button();
            this.btRefresh = new System.Windows.Forms.Button();
            this.listViewFicheiro = new NBIISNET.ListViewBase();
            this.columnFICH_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFICHTIPO_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFichNome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFICHSTATUS = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFichData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFichNSeq = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFichBanco = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFichRefCmp = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFichTotReg = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFichMontTotal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFichUltimo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFichInTimer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFICH_FULLPATHNAME = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnFICHERRO = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStripMudarEstadoFich = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.desimportarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.associarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listViewLote = new NBIISNET.ListViewBase();
            this.columnLoteLoteID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnLoteFichID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnLoteStatus = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewDetalhe = new NBIISNET.ListViewBase();
            this.columnDetDetID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnDetLoteID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnDetRefarq = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnDetChaveH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnDetChaveHext = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.labelFicheiros = new System.Windows.Forms.Label();
            this.labelLotes = new System.Windows.Forms.Label();
            this.labelDetalhes = new System.Windows.Forms.Label();
            this.dateTimeDataIni = new System.Windows.Forms.DateTimePicker();
            this.dateTimeDataEND = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.buttonExitJanela = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.cbOrigem = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.contextMenuStripMudarEstadoFich.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonImportar
            // 
            this.buttonImportar.Location = new System.Drawing.Point(4, 9);
            this.buttonImportar.Name = "buttonImportar";
            this.buttonImportar.Size = new System.Drawing.Size(130, 25);
            this.buttonImportar.TabIndex = 3;
            this.buttonImportar.Text = "Importar";
            this.buttonImportar.UseVisualStyleBackColor = true;
            this.buttonImportar.Click += new System.EventHandler(this.buttonImportar_Click);
            // 
            // btRefresh
            // 
            this.btRefresh.Image = global::CIFicheirosControlo.Properties.Resources.Refresh;
            this.btRefresh.Location = new System.Drawing.Point(811, 4);
            this.btRefresh.Name = "btRefresh";
            this.btRefresh.Size = new System.Drawing.Size(49, 44);
            this.btRefresh.TabIndex = 4;
            this.toolTip1.SetToolTip(this.btRefresh, "Refresh");
            this.btRefresh.UseVisualStyleBackColor = true;
            this.btRefresh.Click += new System.EventHandler(this.btRefresh_Click);
            // 
            // listViewFicheiro
            // 
            this.listViewFicheiro.AllowColumnReorder = true;
            this.listViewFicheiro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewFicheiro.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnFICH_ID,
            this.columnFICHTIPO_ID,
            this.columnFichNome,
            this.columnFICHSTATUS,
            this.columnFichData,
            this.columnFichNSeq,
            this.columnFichBanco,
            this.columnFichRefCmp,
            this.columnFichTotReg,
            this.columnFichMontTotal,
            this.columnFichUltimo,
            this.columnFichInTimer,
            this.columnFICH_FULLPATHNAME,
            this.columnFICHERRO});
            this.listViewFicheiro.ContextMenuStrip = this.contextMenuStripMudarEstadoFich;
            this.listViewFicheiro.EnableExportar = true;
            this.listViewFicheiro.FullRowSelect = true;
            this.listViewFicheiro.GridLines = true;
            this.listViewFicheiro.HideSelection = false;
            this.listViewFicheiro.Location = new System.Drawing.Point(3, 65);
            this.listViewFicheiro.Name = "listViewFicheiro";
            this.listViewFicheiro.Size = new System.Drawing.Size(1014, 97);
            this.listViewFicheiro.TabIndex = 3;
            this.listViewFicheiro.TabStop = false;
            this.listViewFicheiro.UseCompatibleStateImageBehavior = false;
            this.listViewFicheiro.View = System.Windows.Forms.View.Details;
            this.listViewFicheiro.DoubleClick += new System.EventHandler(this.listViewFicheiro_DoubleClick);
            // 
            // columnFICH_ID
            // 
            this.columnFICH_ID.Text = "Fich ID";
            this.columnFICH_ID.Width = 53;
            // 
            // columnFICHTIPO_ID
            // 
            this.columnFICHTIPO_ID.Text = "Tipo";
            this.columnFICHTIPO_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnFICHTIPO_ID.Width = 78;
            // 
            // columnFichNome
            // 
            this.columnFichNome.Text = "Nome";
            this.columnFichNome.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnFICHSTATUS
            // 
            this.columnFICHSTATUS.Text = "Estado";
            this.columnFICHSTATUS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnFICHSTATUS.Width = 87;
            // 
            // columnFichData
            // 
            this.columnFichData.Text = "Data";
            this.columnFichData.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnFichData.Width = 112;
            // 
            // columnFichNSeq
            // 
            this.columnFichNSeq.Text = "NSeq";
            this.columnFichNSeq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnFichNSeq.Width = 47;
            // 
            // columnFichBanco
            // 
            this.columnFichBanco.Text = "Banco";
            this.columnFichBanco.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnFichBanco.Width = 49;
            // 
            // columnFichRefCmp
            // 
            this.columnFichRefCmp.Text = "Ref Cmp";
            this.columnFichRefCmp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnFichTotReg
            // 
            this.columnFichTotReg.Text = "Tot Reg";
            this.columnFichTotReg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // columnFichMontTotal
            // 
            this.columnFichMontTotal.Text = "Mont Total";
            this.columnFichMontTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnFichMontTotal.Width = 95;
            // 
            // columnFichUltimo
            // 
            this.columnFichUltimo.Text = "Ultimo";
            this.columnFichUltimo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnFichUltimo.Width = 45;
            // 
            // columnFichInTimer
            // 
            this.columnFichInTimer.Text = "Timer";
            this.columnFichInTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnFichInTimer.Width = 112;
            // 
            // columnFICH_FULLPATHNAME
            // 
            this.columnFICH_FULLPATHNAME.Text = "Full Path";
            this.columnFICH_FULLPATHNAME.Width = 200;
            // 
            // columnFICHERRO
            // 
            this.columnFICHERRO.Text = "Erro";
            this.columnFICHERRO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnFICHERRO.Width = 200;
            // 
            // contextMenuStripMudarEstadoFich
            // 
            this.contextMenuStripMudarEstadoFich.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.desimportarToolStripMenuItem,
            this.associarToolStripMenuItem});
            this.contextMenuStripMudarEstadoFich.Name = "contextMenuStripMudarEstadoFich";
            this.contextMenuStripMudarEstadoFich.Size = new System.Drawing.Size(140, 48);
            this.contextMenuStripMudarEstadoFich.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripMudarEstadoFich_Opening);
            // 
            // desimportarToolStripMenuItem
            // 
            this.desimportarToolStripMenuItem.Name = "desimportarToolStripMenuItem";
            this.desimportarToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.desimportarToolStripMenuItem.Text = "Desimportar";
            this.desimportarToolStripMenuItem.Click += new System.EventHandler(this.desimportarToolStripMenuItem_Click);
            // 
            // associarToolStripMenuItem
            // 
            this.associarToolStripMenuItem.Name = "associarToolStripMenuItem";
            this.associarToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.associarToolStripMenuItem.Text = "Associar";
            this.associarToolStripMenuItem.Click += new System.EventHandler(this.associarToolStripMenuItem_Click);
            // 
            // listViewLote
            // 
            this.listViewLote.AllowColumnReorder = true;
            this.listViewLote.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewLote.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnLoteLoteID,
            this.columnLoteFichID,
            this.columnLoteStatus});
            this.listViewLote.EnableExportar = true;
            this.listViewLote.FullRowSelect = true;
            this.listViewLote.GridLines = true;
            this.listViewLote.HideSelection = false;
            this.listViewLote.Location = new System.Drawing.Point(4, 17);
            this.listViewLote.Name = "listViewLote";
            this.listViewLote.Size = new System.Drawing.Size(1013, 92);
            this.listViewLote.TabIndex = 4;
            this.listViewLote.UseCompatibleStateImageBehavior = false;
            this.listViewLote.View = System.Windows.Forms.View.Details;
            this.listViewLote.DoubleClick += new System.EventHandler(this.listViewLote_DoubleClick);
            // 
            // columnLoteLoteID
            // 
            this.columnLoteLoteID.Text = "Lote Id";
            // 
            // columnLoteFichID
            // 
            this.columnLoteFichID.Text = "Fich ID";
            // 
            // columnLoteStatus
            // 
            this.columnLoteStatus.Text = "Lote Status";
            // 
            // listViewDetalhe
            // 
            this.listViewDetalhe.AllowColumnReorder = true;
            this.listViewDetalhe.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewDetalhe.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnDetDetID,
            this.columnDetLoteID,
            this.columnDetRefarq,
            this.columnDetChaveH,
            this.columnDetChaveHext});
            this.listViewDetalhe.EnableExportar = true;
            this.listViewDetalhe.FullRowSelect = true;
            this.listViewDetalhe.GridLines = true;
            this.listViewDetalhe.HideSelection = false;
            this.listViewDetalhe.Location = new System.Drawing.Point(3, 16);
            this.listViewDetalhe.Name = "listViewDetalhe";
            this.listViewDetalhe.Size = new System.Drawing.Size(1014, 96);
            this.listViewDetalhe.TabIndex = 5;
            this.listViewDetalhe.UseCompatibleStateImageBehavior = false;
            this.listViewDetalhe.View = System.Windows.Forms.View.Details;
            this.listViewDetalhe.DoubleClick += new System.EventHandler(this.listViewDetalhe_DoubleClick);
            // 
            // columnDetDetID
            // 
            this.columnDetDetID.Text = "Detalhe ID";
            // 
            // columnDetLoteID
            // 
            this.columnDetLoteID.Text = "LoteID";
            // 
            // columnDetRefarq
            // 
            this.columnDetRefarq.DisplayIndex = 4;
            this.columnDetRefarq.Text = "Refarq";
            // 
            // columnDetChaveH
            // 
            this.columnDetChaveH.DisplayIndex = 2;
            this.columnDetChaveH.Text = "Chave H";
            // 
            // columnDetChaveHext
            // 
            this.columnDetChaveHext.DisplayIndex = 3;
            this.columnDetChaveHext.Text = "Chave Hext";
            // 
            // labelFicheiros
            // 
            this.labelFicheiros.AutoSize = true;
            this.labelFicheiros.Location = new System.Drawing.Point(3, 49);
            this.labelFicheiros.Name = "labelFicheiros";
            this.labelFicheiros.Size = new System.Drawing.Size(49, 13);
            this.labelFicheiros.TabIndex = 6;
            this.labelFicheiros.Text = "Ficheiros";
            // 
            // labelLotes
            // 
            this.labelLotes.AutoSize = true;
            this.labelLotes.Location = new System.Drawing.Point(3, 1);
            this.labelLotes.Name = "labelLotes";
            this.labelLotes.Size = new System.Drawing.Size(33, 13);
            this.labelLotes.TabIndex = 7;
            this.labelLotes.Text = "Lotes";
            // 
            // labelDetalhes
            // 
            this.labelDetalhes.AutoSize = true;
            this.labelDetalhes.Location = new System.Drawing.Point(3, 0);
            this.labelDetalhes.Name = "labelDetalhes";
            this.labelDetalhes.Size = new System.Drawing.Size(49, 13);
            this.labelDetalhes.TabIndex = 8;
            this.labelDetalhes.Text = "Detalhes";
            // 
            // dateTimeDataIni
            // 
            this.dateTimeDataIni.Location = new System.Drawing.Point(182, 12);
            this.dateTimeDataIni.Name = "dateTimeDataIni";
            this.dateTimeDataIni.Size = new System.Drawing.Size(229, 20);
            this.dateTimeDataIni.TabIndex = 1;
            // 
            // dateTimeDataEND
            // 
            this.dateTimeDataEND.Location = new System.Drawing.Point(437, 12);
            this.dateTimeDataEND.Name = "dateTimeDataEND";
            this.dateTimeDataEND.Size = new System.Drawing.Size(229, 20);
            this.dateTimeDataEND.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(151, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "DE:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(417, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "A";
            // 
            // buttonExitJanela
            // 
            this.buttonExitJanela.Image = ((System.Drawing.Image)(resources.GetObject("buttonExitJanela.Image")));
            this.buttonExitJanela.Location = new System.Drawing.Point(866, 4);
            this.buttonExitJanela.Name = "buttonExitJanela";
            this.buttonExitJanela.Size = new System.Drawing.Size(49, 44);
            this.buttonExitJanela.TabIndex = 5;
            this.buttonExitJanela.UseVisualStyleBackColor = true;
            this.buttonExitJanela.Click += new System.EventHandler(this.buttonExitJanela_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(1, 1);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.cbOrigem);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.buttonImportar);
            this.splitContainer1.Panel1.Controls.Add(this.label4);
            this.splitContainer1.Panel1.Controls.Add(this.buttonExitJanela);
            this.splitContainer1.Panel1.Controls.Add(this.dateTimeDataIni);
            this.splitContainer1.Panel1.Controls.Add(this.labelFicheiros);
            this.splitContainer1.Panel1.Controls.Add(this.label5);
            this.splitContainer1.Panel1.Controls.Add(this.listViewFicheiro);
            this.splitContainer1.Panel1.Controls.Add(this.dateTimeDataEND);
            this.splitContainer1.Panel1.Controls.Add(this.btRefresh);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1020, 400);
            this.splitContainer1.SplitterDistance = 165;
            this.splitContainer1.TabIndex = 13;
            // 
            // cbOrigem
            // 
            this.cbOrigem.DisplayMember = "Text";
            this.cbOrigem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbOrigem.FormattingEnabled = true;
            this.cbOrigem.Location = new System.Drawing.Point(732, 10);
            this.cbOrigem.Name = "cbOrigem";
            this.cbOrigem.Size = new System.Drawing.Size(73, 21);
            this.cbOrigem.TabIndex = 14;
            this.cbOrigem.ValueMember = "Value";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(672, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "ORIGEM:";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.listViewLote);
            this.splitContainer2.Panel1.Controls.Add(this.labelLotes);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.labelDetalhes);
            this.splitContainer2.Panel2.Controls.Add(this.listViewDetalhe);
            this.splitContainer2.Size = new System.Drawing.Size(1020, 231);
            this.splitContainer2.SplitterDistance = 112;
            this.splitContainer2.TabIndex = 0;
            // 
            // FicheiroFormCentralENVM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1023, 404);
            this.Controls.Add(this.splitContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FicheiroFormCentralENVM";
            this.ShowInTaskbar = false;
            this.Text = "l";
            this.Load += new System.EventHandler(this.FicheiroFormCentral_Load);
            this.contextMenuStripMudarEstadoFich.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonImportar;
        private System.Windows.Forms.Button btRefresh;
        public NBIISNET.ListViewBase listViewFicheiro;
        private System.Windows.Forms.ColumnHeader columnFICH_FULLPATHNAME;
        private System.Windows.Forms.ColumnHeader columnFICH_ID;
        private System.Windows.Forms.ColumnHeader columnFICHTIPO_ID;
        public NBIISNET.ListViewBase listViewLote;
        public NBIISNET.ListViewBase listViewDetalhe;
        public System.Windows.Forms.Label labelFicheiros;
        public System.Windows.Forms.Label labelLotes;
        public System.Windows.Forms.Label labelDetalhes;
        private System.Windows.Forms.ColumnHeader columnFICHSTATUS;
        private System.Windows.Forms.ColumnHeader columnLoteLoteID;
        private System.Windows.Forms.ColumnHeader columnLoteFichID;
        private System.Windows.Forms.ColumnHeader columnLoteStatus;
        private System.Windows.Forms.ColumnHeader columnFICHERRO;
        private System.Windows.Forms.ColumnHeader columnDetDetID;
        private System.Windows.Forms.ColumnHeader columnDetLoteID;
        private System.Windows.Forms.ColumnHeader columnDetChaveH;
        private System.Windows.Forms.ColumnHeader columnDetChaveHext;
        private System.Windows.Forms.ColumnHeader columnDetRefarq;
        private System.Windows.Forms.ColumnHeader columnFichNome;
        private System.Windows.Forms.ColumnHeader columnFichBanco;
        private System.Windows.Forms.ColumnHeader columnFichNSeq;
        private System.Windows.Forms.ColumnHeader columnFichData;
        private System.Windows.Forms.ColumnHeader columnFichTotReg;
        private System.Windows.Forms.ColumnHeader columnFichMontTotal;
        private System.Windows.Forms.ColumnHeader columnFichUltimo;
        private System.Windows.Forms.ColumnHeader columnFichInTimer;
        private System.Windows.Forms.ColumnHeader columnFichRefCmp;
        public System.Windows.Forms.DateTimePicker dateTimeDataIni;
        public System.Windows.Forms.DateTimePicker dateTimeDataEND;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripMudarEstadoFich;
        private System.Windows.Forms.ToolStripMenuItem desimportarToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button buttonExitJanela;
        private System.Windows.Forms.ToolStripMenuItem associarToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Label label1;
        protected System.Windows.Forms.ComboBox cbOrigem;
    }
}

