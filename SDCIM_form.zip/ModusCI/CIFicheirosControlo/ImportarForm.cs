﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

using CIConfigGlobalParameters;
using CIFicheiro;

namespace CIFicheirosControlo
{

    public partial class ImportarForm : Form , CIComumInterface
    {
        CIConfigGP.CIGlobalParameters m_oParameters;
        public CIFicheiro.Ficheiro m_oFile;
        string m_sFileName;
        
        public ImportarForm(CIConfigGP.CIGlobalParameters oParameters, string sFileName)
        {
            m_oParameters = oParameters;
            m_sFileName = sFileName;
            InitializeComponent();

        }

        public void ErrorMessage(string sMessage) 
        {
            addMsg2Lista(sMessage);
            refreshEcra();
        }
        public void WarningMessage(string sMessage)
        {
            addMsg2Lista(sMessage);
            refreshEcra();
        }
        public void InfoMessage(string sMessage, string sHeader)
        {
            addMsg2Lista(sMessage);
            refreshEcra();
        }
        public void InfoMessageCount(string sMessage)
        {
            edCounter.Text = sMessage;
            refreshEcra();
        }

        public void addMsg2Lista(string sMsg)
        {
            ListViewItem olvItem = listViewMsgImportar.Items.Add(DateTime.Now.ToString(m_oParameters.TimeSysFmt));
            olvItem.SubItems.Add(sMsg);
            olvItem.EnsureVisible();
        }

        public void refreshEcra()
        {
            System.Windows.Forms.Application.DoEvents();
        }

        public void ImportarFile(string sFileName)
        {
            m_oFile.processaFile(sFileName, "Manual");
        }
        
        private void btParar_Click(object sender, EventArgs e)
        {
            if (m_oFile.m_bIsRunning)
                m_oFile.m_bIsRunning = false;
            else
                Dispose(); 
        }

        bool bFirst = true;// devido ao activate que inicia 2 vezes
        private void ImportarForm_Activated(object sender, EventArgs e)
        {
            if (bFirst)
            {
                bFirst = false;
                
                ImportarFile(m_sFileName);
                
                //MessageBox.Show("Ficheiro importado!!!");
                //Dispose();
            }
            
        }

    }
}