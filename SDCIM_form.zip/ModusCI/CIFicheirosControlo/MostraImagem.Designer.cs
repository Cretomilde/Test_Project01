﻿namespace CIFicheirosControlo
{
    partial class MostraImagem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.imgFrente = new System.Windows.Forms.PictureBox();
            this.imgVerso = new System.Windows.Forms.PictureBox();
            this.lblErro = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.imgFrente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgVerso)).BeginInit();
            this.SuspendLayout();
            // 
            // imgFrente
            // 
            this.imgFrente.Location = new System.Drawing.Point(12, 12);
            this.imgFrente.Name = "imgFrente";
            this.imgFrente.Size = new System.Drawing.Size(490, 230);
            this.imgFrente.TabIndex = 0;
            this.imgFrente.TabStop = false;
            // 
            // imgVerso
            // 
            this.imgVerso.Location = new System.Drawing.Point(12, 248);
            this.imgVerso.Name = "imgVerso";
            this.imgVerso.Size = new System.Drawing.Size(490, 242);
            this.imgVerso.TabIndex = 1;
            this.imgVerso.TabStop = false;
            // 
            // lblErro
            // 
            this.lblErro.AutoSize = true;
            this.lblErro.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold);
            this.lblErro.ForeColor = System.Drawing.Color.Red;
            this.lblErro.Location = new System.Drawing.Point(29, 214);
            this.lblErro.Name = "lblErro";
            this.lblErro.Size = new System.Drawing.Size(452, 56);
            this.lblErro.TabIndex = 2;
            this.lblErro.Text = "ERRO NA IMAGEM";
            // 
            // MostraImagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 502);
            this.Controls.Add(this.lblErro);
            this.Controls.Add(this.imgVerso);
            this.Controls.Add(this.imgFrente);
            this.Name = "MostraImagem";
            this.Text = "ImagemBalcaoForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MostraImagem_FormClosed);
            this.Load += new System.EventHandler(this.MostraImagem_FormLoad);
            ((System.ComponentModel.ISupportInitialize)(this.imgFrente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgVerso)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
                 
        private System.Windows.Forms.PictureBox imgFrente;
        private System.Windows.Forms.PictureBox imgVerso;
        private System.Windows.Forms.Label lblErro;
    }
}