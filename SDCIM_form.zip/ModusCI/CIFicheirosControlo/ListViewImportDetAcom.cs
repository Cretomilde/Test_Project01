﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIFicheirosControlo
{
    class ListViewImportDetAcom : ListViewImportDet
    { 
        string m_sDocAcomRefarq;
        string m_sDocAcomRefarq2;
        int m_iDocAcomBalcao;
        string m_sDocAcomBalcaoDescricao;
        int m_iDocAcomCodana;
        string m_sDocAcomCodana;
        double m_dDocAcomImport;
        string m_sDocAcomLinhaOpt; 

        public ListViewImportDetAcom(DataRow oRow, CIConfigGP.CIGlobalParameters oParameters)
            :base(oRow, oParameters)
        {
            m_lDetID = Convert.ToInt64(oRow["DOCACOM_ID"]);
            m_lLoteId = Convert.ToInt64(oRow["LOTEACOM_ID"]);

            if (oRow["DOC_ID"] == DBNull.Value)
            {
                m_lDocID = 0;
            }
            else
            {
                m_lDocID = Convert.ToInt64(oRow["DOC_ID"]);
            }

            m_sDocAcomRefarq = oRow["DOCACOM_REFARQ"].ToString();
            m_sDocAcomRefarq2 = oRow["DOCACOM_REFARQ2"].ToString();
            m_iDocAcomBalcao = Convert.ToInt16(oRow["DOCACOM_BALCAO"]);
            m_iDocAcomCodana = Convert.ToInt16(oRow["DOCACOM_CODANA"]);
            m_sDocAcomCodana = oRow["DOCACOM_CODANA"].ToString() + " - " + oRow["ESTADO_DESC"].ToString();
            m_dDocAcomImport = Convert.ToDouble(oRow["DOCACOM_IMPORT"]);
            m_sDocAcomLinhaOpt = oRow["DOCACOM_LINHAOPT"].ToString();
            m_sDocChaveH = oRow["DOCACOM_CHAVEH"].ToString();
            m_sDocChaveHext = oRow["DOCACOM_CHAVEHEXT"].ToString();

            //SDCIM 7 - Adição de coluna DOCACOM Origem
            this.m_sDocAcomBalcaoDescricao = oRow["BALCAO_DESC"].ToString();
            base.m_iDocOrigemID = Convert.ToInt16(oRow["DOCACOM_ORIGEM_ID"]);
            base.m_sDocOrigemD = oRow["DOCACOM_ORIGEM_D"].ToString();
            //SDCIM 7 - Adição de coluna DOCACOM Origem 
        }

        public override ListViewItem makeListViewDet(string sDateFormat, string sDateTimeFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_lDetID.ToString();
            olvItem.SubItems.Add(m_lLoteId.ToString());
            olvItem.SubItems.Add(m_lDocID.ToString());
            //SDCIM 7 - Adição de coluna DOCACOM Origem
            olvItem.SubItems.Add(base.m_sDocOrigemD);
            //SDCIM 7 - Adição de coluna DOCACOM Origem
            olvItem.SubItems.Add(m_sDocAcomRefarq);
            olvItem.SubItems.Add(m_sDocAcomRefarq2);
            olvItem.SubItems.Add(m_iDocAcomBalcao.ToString("0000") + " - " + m_sDocAcomBalcaoDescricao);
            olvItem.SubItems.Add(m_sDocAcomCodana);
            string montanteToInsert = this.m_dDocAcomImport.ToString().Equals("0") ? this.m_dDocAcomImport.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.m_dDocAcomImport).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dDocAcomImport).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(m_sDocAcomLinhaOpt);
            olvItem.SubItems.Add(m_sDocChaveH);
            olvItem.SubItems.Add(m_sDocChaveHext);
                      
            return olvItem;
        }


        public override string getTipoDet()
        {
            return "ACOM";
        }

    }
}
