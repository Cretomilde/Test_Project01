﻿using System;
using System.Data;
using System.Windows.Forms;



namespace CIFicheirosControlo
{
    class ListViewImportLoteAcom : ListViewImportLote
    {
        long m_lLoteAcomNumero;
        int m_iLoteAcomProduto;
        DateTime m_dtLoteAcomDtProc;
        int m_iLoteAcomTotReg;
        double m_dLoteAcomMontTotal;
        String m_OrigemDesc = String.Empty;
        public Int32 m_OrigemID = 0;
        public ListViewImportLoteAcom(DataRow oRow, CIConfigGP.CIGlobalParameters oParameters)
            : base(oRow, oParameters)
        {
            m_lLoteId = Convert.ToInt64(oRow["LOTEACOM_ID"]);
            m_lFichId = Convert.ToInt64(oRow["FICH_ID"]);
            m_lLoteAcomNumero = Convert.ToInt64(oRow["LOTEACOM_NUMERO"]);
            m_iLoteAcomProduto = Convert.ToInt16(oRow["LOTEACOM_PRODUTO"]);
            m_dtLoteAcomDtProc = Convert.ToDateTime(oRow["LOTEACOM_DATAPROC"]);
            m_iLoteAcomTotReg = Convert.ToInt16(oRow["LOTEACOM_TOTREG"]);
            m_dLoteAcomMontTotal = Convert.ToDouble(oRow["LOTEACOM_MONTTOTAL"]);
            m_iLoteStatus = Convert.ToInt16(oRow["LOTESTATUS_ID"]);
            m_sLoteStatusDesc = oRow["LOTESTAT_DESC"].ToString();
            this.m_OrigemDesc = oRow["REMORI_DESC"].ToString();
            this.m_OrigemID = Convert.ToInt32(oRow["DOCACOM_ORIGEM_ID"]);
        }

        public override ListViewItem makeListViewLote(string sDateFormat, string sDateTimeFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_lLoteId.ToString();
            olvItem.SubItems.Add(m_lFichId.ToString());
            olvItem.SubItems.Add(m_lLoteAcomNumero.ToString());
            olvItem.SubItems.Add(m_iLoteStatus.ToString() + " " + m_sLoteStatusDesc);
            olvItem.SubItems.Add(this.m_OrigemDesc);
            olvItem.SubItems.Add(m_iLoteAcomProduto.ToString());
            olvItem.SubItems.Add(m_dtLoteAcomDtProc.ToString(m_oParameters.DateFormat));
            olvItem.SubItems.Add(m_iLoteAcomTotReg.ToString().PadLeft(5, ' '));
            string montanteToInsert = this.m_dLoteAcomMontTotal.ToString().Equals("0") ? this.m_dLoteAcomMontTotal.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.m_dLoteAcomMontTotal).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dLoteAcomMontTotal).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);

            return olvItem;
        }


        public override string getTipoLote()
        {
            return "ACOM";
        }
    }
}