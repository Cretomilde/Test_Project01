﻿namespace CIFicheirosControlo
{
    partial class FormBalcao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormBalcao));
            this.buttonOK = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.listViewResumoLote = new NBIISNET.ListViewBase();
            this.columnBalcao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnQT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnImport = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.labelBalcoes = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txBalcao = new System.Windows.Forms.TextBox();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonOK
            // 
            this.buttonOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOK.Location = new System.Drawing.Point(298, 30);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(72, 23);
            this.buttonOK.TabIndex = 0;
            this.buttonOK.Text = "&OK";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Location = new System.Drawing.Point(298, 59);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(72, 23);
            this.buttonCancel.TabIndex = 1;
            this.buttonCancel.Text = "&Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // listViewResumoLote
            // 
            this.listViewResumoLote.AllowColumnReorder = true;
            this.listViewResumoLote.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewResumoLote.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnBalcao,
            this.columnQT,
            this.columnImport});
            this.listViewResumoLote.EnableExportar = true;
            this.listViewResumoLote.FullRowSelect = true;
            this.listViewResumoLote.GridLines = true;
            this.listViewResumoLote.HideSelection = false;
            this.listViewResumoLote.Location = new System.Drawing.Point(21, 30);
            this.listViewResumoLote.MultiSelect = false;
            this.listViewResumoLote.Name = "listViewResumoLote";
            this.listViewResumoLote.Size = new System.Drawing.Size(271, 324);
            this.listViewResumoLote.TabIndex = 9;
            this.listViewResumoLote.TabStop = false;
            this.listViewResumoLote.UseCompatibleStateImageBehavior = false;
            this.listViewResumoLote.View = System.Windows.Forms.View.Details;
            this.listViewResumoLote.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listViewResumoLote_MouseDoubleClick_1);
            // 
            // columnBalcao
            // 
            this.columnBalcao.Text = "Balcão";
            this.columnBalcao.Width = 66;
            // 
            // columnQT
            // 
            this.columnQT.Text = "QT";
            this.columnQT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // columnImport
            // 
            this.columnImport.Text = "Montante";
            this.columnImport.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnImport.Width = 130;
            // 
            // labelBalcoes
            // 
            this.labelBalcoes.AutoSize = true;
            this.labelBalcoes.Location = new System.Drawing.Point(21, 11);
            this.labelBalcoes.Name = "labelBalcoes";
            this.labelBalcoes.Size = new System.Drawing.Size(45, 13);
            this.labelBalcoes.TabIndex = 10;
            this.labelBalcoes.Text = "Balcões";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(188, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Balcão";
            // 
            // txBalcao
            // 
            this.txBalcao.Location = new System.Drawing.Point(234, 1);
            this.txBalcao.Name = "txBalcao";
            this.txBalcao.Size = new System.Drawing.Size(58, 20);
            this.txBalcao.TabIndex = 12;
            this.txBalcao.TextChanged += new System.EventHandler(this.txBalcao_TextChanged);
            this.txBalcao.Leave += new System.EventHandler(this.txBalcao_Leave);
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Location = new System.Drawing.Point(298, 1);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(75, 23);
            this.btnPesquisar.TabIndex = 13;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
            // 
            // FormBalcao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonCancel;
            this.ClientSize = new System.Drawing.Size(382, 378);
            this.Controls.Add(this.btnPesquisar);
            this.Controls.Add(this.txBalcao);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelBalcoes);
            this.Controls.Add(this.listViewResumoLote);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonOK);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormBalcao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Balcão";
            this.Load += new System.EventHandler(this.FormBalcao_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.Button buttonCancel;
        private NBIISNET.ListViewBase listViewResumoLote;
        private System.Windows.Forms.ColumnHeader columnBalcao;
        private System.Windows.Forms.ColumnHeader columnQT;
        private System.Windows.Forms.ColumnHeader columnImport;
        private System.Windows.Forms.Label labelBalcoes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txBalcao;
        private System.Windows.Forms.Button btnPesquisar;
    }
}