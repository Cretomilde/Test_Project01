﻿using System;
using System.Collections;
using System.IO;
using Alerta;
using CIConfigGlobalParameters;
using NBiis;

namespace CIServico
{
    public class CIServicoThread : CIServiceComumThread, CIServicoThreadInterface, CIComumInterface
    {
        protected int m_iNextThreadId;
        DateTime m_dtLastTime2ImportFile;

        public CIServicoThread(CIServiceInterface iInterface, CIServicosThreadParameters oParameters)
            : base(iInterface, oParameters)
        {
            m_iNextThreadId = 1;
            m_dtLastTime2ImportFile = DateTime.Now.AddMinutes(-m_oParameters.m_iTempoEntreIteracoesFicheiros);
        }

        protected override string GetThreadName()
        {
            return "CIServicos";
        }

        public void ThreadStoped(int iThreadID)
        {
        }

        public void ErrorMessage(string sMessage)
        {
            GenericLog.GenLogRegistarErro(sMessage, "CIServico", 41);
            m_iInterface.ServiceErrorMessage(sMessage);
            m_oParameters.EnviarAlertaSituacao(800, sMessage); 
        }

        public void WarningMessage(string sMessage)
        {
            GenericLog.GenLogRegistarAlerta(sMessage, "CIServico", 42);
            m_iInterface.ServiceWarningMessage(sMessage);
            m_oParameters.EnviarAlertaSituacao(810, sMessage);
        }

        public void InfoMessage(string sMessage, string sHeader)
        {
            GenericLog.GenLogRegistarInfo(sMessage, "CIServico", 43);
            m_iInterface.ServiceInfoMessage(sMessage, sHeader);
        }

        public void InfoMessageCount(string sMessage)
        {
        }

        protected override void InitProcessThread()
        {
            try
            {
                string sQuery = "dbo.UpdateDelete_RemessaIn_30_to_20";
                ArrayList aoParam = new ArrayList();

                m_oParameters.DirectStoredProcedureNonQuery(sQuery, ref aoParam);
            }
            catch 
            { 
            }
        }

        protected void MoverFicheirosImportadosNaoMovidos(string sFilePath, string sFileSintax)
        {
            try
            {
                string[] aFiles = Directory.GetFiles(sFilePath, sFileSintax);

                foreach (string sFile in aFiles)
                {
                    string sDestPath = m_oParameters.m_sFileBackupPath;
                    string sNewFileName = sDestPath + Path.GetFileName(sFile) + "." + DateTime.Now.ToString("yyyyMMddHHmmss") + ".Movido";
                    File.Move(sFile, sNewFileName);
                    WarningMessage(sFile + " Movido");
                }
            }
            catch(Exception ex)
            {
                WarningMessage(ex.Message);
            }
        }

        private DateTime m_dtLastWorking = DateTime.Now.AddMinutes(-15);

        protected override bool CheckForThingToDo()
        {
            try
            {
                bool bResult1 = false;
                bool bResult2 = false;
                bool bResult3 = false;
                bool bResult4 = false;
                bool bResult5 = false; // SDCIM 7

                string sMsg;

                m_oParameters.OpenConnection();

                if (m_dtLastWorking.AddMinutes(5)<DateTime.Now)
                {
                    sMsg = " Data " + File.GetLastWriteTime(System.Windows.Forms.Application.ExecutablePath).ToString() + "\n";
                    sMsg += " Versao " + System.Windows.Forms.Application.ProductVersion + "\n";
                    sMsg += " Machine " + System.Windows.Forms.SystemInformation.ComputerName + "\n";

                    GenericLog.RegistarApplicacaoLog();

                    m_dtLastWorking = DateTime.Now;
                    m_iInterface.ServiceInfoMessage(sMsg, "Working");
                }

                bResult1 = CheckForRemessas2Process();
                bResult2 = CheckForAlertas2Process();

                if (Time2ImportFile())
                {
                    bResult3 = CheckForFileENVM2Import();
                    MoverFicheirosImportadosNaoMovidos(m_oParameters.m_sFilePathENVM, "Auto*");
                    MoverFicheirosImportadosNaoMovidos(m_oParameters.m_sFilePathENVM, "Manual*");

                    bResult4 = CheckForFileACOM2Import();
                    MoverFicheirosImportadosNaoMovidos(m_oParameters.m_sFilePathACOM, "Auto*");
                    MoverFicheirosImportadosNaoMovidos(m_oParameters.m_sFilePathACOM, "Manual*");

                    if (bResult3 || bResult4)
                    {
                        m_dtLastTime2ImportFile = DateTime.Now.AddMinutes(-m_oParameters.m_iTempoEntreIteracoesFicheiros);
                    }
                }

                bResult5 = CheckForTranchesRemessasBalcao2Process(); // SDCIM 7

                m_oParameters.CloseConnection();

                m_iNextThreadId = m_iNextThreadId % 1000;

                return bResult1 || bResult2 || bResult3 || bResult4 || bResult5; // SDCIM 7
            }
            catch (Exception ex)
            {
                ErrorMessage("CheckForThingToDo: " + ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "CIServicThread()", 500);
                return true;
            }
            finally
            {
                m_oParameters.CloseConnection();
            }
        }

        protected bool Time2ImportFile()
        {
            if (m_dtLastTime2ImportFile.AddMinutes(m_oParameters.m_iTempoEntreIteracoesFicheiros) > DateTime.Now)
            {
                return false;
            }
            m_dtLastTime2ImportFile = DateTime.Now;
            return true;
        }

        protected bool CheckForFileENVM2Import()
        {
            try
            {

                string sFileSintax = m_oParameters.m_sSintaxFilesToImportENVM;
                string sFilePath = m_oParameters.m_sFilePathENVM;

                //m_iInterface.ServiceInfoMessage(sFilePath + sFileSintax);

                string[] aFiles = Directory.GetFiles(sFilePath, sFileSintax);

                if (aFiles.Length > 0)
                {
                    CIFicheiro.FicheiroEnvm oFile = new CIFicheiro.FicheiroEnvm(this, m_oParameters);
                    return oFile.processaFile(aFiles[0],"Auto");
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                ErrorMessage("Processa ENVM File2Import: " + ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "CIServicThread()", 500);
                m_oParameters.SetDefaultSleepTime();
                return false;
            }
        }
        protected bool CheckForFileACOM2Import()
        {
            try
            {
                string sFileSintax = m_oParameters.m_sSintaxFilesToImportACOM;
                string sFilePath = m_oParameters.m_sFilePathACOM;

              //m_iInterface.ServiceInfoMessage(sFilePath + sFileSintax);

                string[] aFiles = Directory.GetFiles(sFilePath, sFileSintax);

                if (aFiles.Length > 0)
                {
                    CIFicheiro.FicheiroAcom oFile = new CIFicheiro.FicheiroAcom(this, m_oParameters);
                    return oFile.processaFile(aFiles[0], "Auto");
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                ErrorMessage("Processa ACOM File2Import: " + ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "CIServicThread()", 500);
                m_oParameters.SetDefaultSleepTime();
                return false;
            }
        }

        protected bool CheckForAlertas2Process()
        {
            AlertaSituacaoAccao oAlSitAcc=null;
            try
            {
                CIServAlertas.ServAlerta oAl = new CIServAlertas.ServAlerta(this, m_oParameters);

                oAlSitAcc = oAl.AlertaSituacaoAccaoParaProcessar();
                if (oAlSitAcc == null)
                {
                    return false;
                }
                oAl.ProcessaAlertaSituacaoAccao(oAlSitAcc);
                return true;
            }
            catch (Exception ex)
            {
                string sMsg = "";
                if (oAlSitAcc == null)
                {
                    sMsg = "ALERT_ID e ACC_ID não identificados";
                }
                else
                {
                    sMsg = " ALERT_ID=" + oAlSitAcc.m_sALERT_ID;
                    sMsg += " ACC_ID=" + oAlSitAcc.m_oSituacaoAccao.m_oAccao.m_iACC_ID.ToString();
                }

                ErrorMessage("CheckForAlertas2Process: " + sMsg + " - " + ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "CIServicThread()", 500);
                m_oParameters.SetDefaultSleepTime();
                return true;
            }
        }

        protected bool CheckForRemessas2Process()
        {
            string sREMIN_ID = "";
            try
            {
                CIServRemessas.ServRemessa oRem = new CIServRemessas.ServRemessa(this, m_oParameters);

                sREMIN_ID = oRem.REMIN_IDParaProcessar();
                if (sREMIN_ID.Length == 0)
                {
                    return false;
                }
                oRem.ProcessaRemessa(sREMIN_ID);
                return true;
            }
            catch (Exception ex)
            {
                ErrorMessage("CheckForRemessas2Process: " + sREMIN_ID + " - " + ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "CIServicThread()", 500);
                m_oParameters.SetDefaultSleepTime();
                return true;
            }
        }

        protected bool CheckForTranchesRemessasBalcao2Process() // SDCIM 7
        {
            //string sREMIN_ID = "";
            try
            {
                CIServRemessas.ServRemessa oRem = new CIServRemessas.ServRemessa(this, m_oParameters);

                long? remessaId = oRem.RemessaBalcaoParaProcessar();

                if (!remessaId.HasValue)
                {
                    return false;
                }
                else
                {
                    oRem.TratarTranchesBalcao(remessaId.Value);
                }

                return true;
            }
            catch (Exception ex)
            {
                ErrorMessage("CheckForTranchesRemessasBalcao2Process: " + ex.Message);

                GenericLog.GenLogRegistarErro(ref ex, "CIServicThread()", 500);

                m_oParameters.SetDefaultSleepTime();

                return true;
            }
        }
    }
}
