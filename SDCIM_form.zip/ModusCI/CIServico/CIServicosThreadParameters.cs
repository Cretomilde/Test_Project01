﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

using CIConfigGP;
using NBiis;

namespace CIServico
{
    public class CIServicosThreadParameters : CIGlobalParameters
    {
        protected DateTime m_dtLastExecute;
        protected TimeSpan m_tsSleepTime;
        protected TimeSpan m_tsDefaultSleepTime;

        protected string[] m_asMaxThread;

        public string m_sServiceName;

        protected CIServicosThreadParameters()
            : base ()
        {
            m_dtLastExecute = DateTime.Now;
            m_tsDefaultSleepTime = new TimeSpan(0, 0, 0, 0, 0);
            SetDefaultSleepTime();

            m_sServiceName = "";
        }

        public CIServicosThreadParameters(string sPrefixo)
            : base (sPrefixo)
        {
            m_dtLastExecute = DateTime.Now;
            m_tsDefaultSleepTime = new TimeSpan(0, 0, 0, 0, 0);
            SetDefaultSleepTime();

            m_sServiceName = "";
        }

        public void ForceStepSleepTime(int iValue)
        {
            if (m_tsSleepTime.TotalMinutes > iValue)
            {
                return;
            }

            m_tsSleepTime = m_tsSleepTime += new TimeSpan(0, 0, iValue, 0, 0);
        }

        public void StepSleepTime()
        {
            m_tsSleepTime += new TimeSpan(0, 0, 0, 5, 0);

            if (m_tsSleepTime >= new TimeSpan(0, 0, 1, 0, 0))
            {
                m_tsSleepTime = new TimeSpan(0, 0, 1, 0, 0);
            }
        }

        public void SetDefaultSleepTime()
        {
            m_tsSleepTime = m_tsDefaultSleepTime;
        }

        public void SetConnectString()
        {
            SetCommandPromptParameters();
            DefineConnectString();
            CreateConnectionObject();
        }

        protected override void SetDatabaseParameters()
        {
        }

        public virtual void SetCIDatabaseParameters()
        {
            base.SetDatabaseParameters();       

            string sAux;
            int iSegundos = GetProfileInt("CIServicos", "Control", "WaitTimer", 0);

            if (m_tsDefaultSleepTime.TotalSeconds != iSegundos)
            {
                m_tsDefaultSleepTime = new TimeSpan(0, 0, 0, iSegundos, 0);
                SetDefaultSleepTime();
            }

            sAux = GetProfileString("CIServicos", "Control", "MaxThread", "1,1");
            if (sAux.Length == 0)
            {
                sAux = "0";
            }
            m_asMaxThread = sAux.Split(',');
        }

        public virtual void SetLastExecution()
        {
            m_dtLastExecute = DateTime.Now;
        }

        public virtual bool IsToWait()
        {
            if ((DateTime.Now - m_dtLastExecute) < m_tsSleepTime)
            {
                return true;
            }

            return false;
        }

        public virtual bool SleepAtLeast(int iSegundos)
        {
            return m_tsSleepTime.TotalSeconds >= iSegundos;
        }

        protected override string ParseCommand(string sParametro)
        {
            sParametro = sParametro.Replace("/", "");
            sParametro = sParametro.Replace(":", "");

            try
            {
                string sRes;
                sRes = ((string)global::CIServico.Properties.Settings.Default[sParametro]);
                return sRes;
            }
            catch (Exception)
            {
                return "";
            }
        }

        #region Inserir mensagems em Log de actividade

        public virtual void InsertServiceMsg(string sMsg, int iSeveridade, string sThreadName, string sFile)
        {
            try
            {
                if (!m_bUseBaseDados)
                {
                    return;
                }

                //InsertServiceMsgOnly(sMsg, iSeveridade, sThreadName, sFile);
                switch (iSeveridade)
                {
                    case 0:
                        GenericLog.GenLogRegistarInfo(sMsg, sThreadName, 36);
                        break;
                    case 1:
                        GenericLog.GenLogRegistarAlerta(sMsg, sThreadName, 37);
                        break;
                    case 2:
                        GenericLog.GenLogRegistarErro(sMsg, sThreadName, 38);
                        break;
                    default:
                        GenericLog.GenLogRegistarErro(sMsg, sThreadName, 39);
                        break;
                }
            }
            catch
            {
            }
        }

        //public virtual void InsertServiceMsgOnly(string sMsg, int iSeveridade, string sThreadName, string sFile)
        //{
        //    try
        //    {
        //        if (!m_bUseBaseDados)
        //        {
        //            return;
        //        }

        //        ArrayList oParam = new ArrayList();

        //        oParam.Add(CriarSPParameter("@ServlogName", System.Windows.Forms.Application.ProductName + "-" + m_sPrefixo));
        //        oParam.Add(CriarSPParameter("@ServlogSeveridade", iSeveridade));
        //        oParam.Add(CriarSPParameter("@ServlogThread", sThreadName));
        //        oParam.Add(CriarSPParameter("@ServlogFilename", sFile));
        //        oParam.Add(CriarSPParameter("@ServlogDescricao", sMsg));

        //        DirectStoredProcedureNonQuery("dbo.Insert_Servico_LogMsg", ref oParam);
        //    }
        //    catch
        //    {
        //    }
        //}

        public virtual void InsertServiceErrorMsg(string sMsg, string sThreadName, string sFile)
        {
            InsertServiceMsg(sMsg, 2, sThreadName, sFile);
        }

        public virtual void InsertServiceErrorMsg(Exception ex, string sThreadName, string sFile)
        {
            //GenericLog.GenLogRegistarErro(ref ex, sFile, 40);
            GenericLog.GenLogRegistarErro(ref ex, NBiis.GenericLog.GenLogGetExFile(ref ex), NBiis.GenericLog.GenLogGetExLine(ref ex));
            InsertServiceMsg(ex.Message, 2, sThreadName, sFile);
        }

        public virtual void InsertServiceInfoMsg(string sMsg, string sThreadName, string sFile)
        {
            InsertServiceMsg(sMsg, 0, sThreadName, sFile);
        }
        #endregion
    }
}
