﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Diagnostics;

using NBiis;
using NBiis.Generic;
using CIConfigGlobalParameters;

namespace CITestes
{
    public partial class ProcessarTrancheBalcao : CIComumInterface
    {
        public void ErrorMessage(string sMessage)
        {
            Debug.WriteLine("ProcessarRemessas Error: " + sMessage);
        }
        public void WarningMessage(string sMessage)
        {
            Debug.WriteLine("ProcessarRemessas Warning: " + sMessage);
        }
        public void InfoMessage(string sMessage, string sHeader)
        {
            Debug.WriteLine("ProcessarRemessas Info: " + sMessage);
        }
        public void InfoMessageCount(string sMessage)
        {
        }

        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public ProcessarTrancheBalcao(CIConfigGP.CIGlobalParameters oParameters, bool todas = false)
        {
            m_oParameters = oParameters;

            CIServRemessas.ServRemessa servRemessa = new CIServRemessas.ServRemessa(this, m_oParameters);

            long? remessaId = null;

            do
            {
                remessaId = servRemessa.RemessaBalcaoParaProcessar();

                if (remessaId.HasValue)
                {
                    servRemessa.TratarTranchesBalcao(remessaId.Value);
                }
                else
                {
                    Debug.WriteLine("Nada para processar");
                }

            } while (todas && remessaId.HasValue);
        }
    }
}
