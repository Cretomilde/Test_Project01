﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;

using CIConfigGlobalParameters;

namespace CIFicheiro
{
    public class DeleteOldFiles
    {
        CIComumInterface m_iInterface;

        public DeleteOldFiles(CIComumInterface iInterface)
        {
            m_iInterface = iInterface;
        }

        protected void DeleteIfOldFile(string sFullFileName, int iNDias)
        {
            if (File.GetLastWriteTime(sFullFileName).AddDays(iNDias) < DateTime.Now)
            {
                File.Delete(sFullFileName);
                m_iInterface.InfoMessage("Delete " + sFullFileName,"");
            }
        }

        public void DeleteFiles(string sPathOrigem, int iNDias, string sFileSintax, bool bRecursivo)
        {
            try
            {
                if (iNDias < 1)
                {
                    return;
                }
                string[] aFiles = Directory.GetFiles(sPathOrigem, sFileSintax);
                for (int i = 0; i < aFiles.Length; i++)
                {
                    DeleteIfOldFile(aFiles[i], iNDias);
                }

                if (!bRecursivo)
                {
                    return;
                }
                string[] aDirectorias = Directory.GetDirectories(sPathOrigem, "*");
                for (int i = 0; i < aDirectorias.Length; i++)
                {
                    DeleteFiles(aDirectorias[i], iNDias, sFileSintax, bRecursivo);
                }
            }
            catch(Exception ex)
            {
                m_iInterface.ErrorMessage(ex.Message);
            }
        }
    }
}
