﻿using System;
using System.Collections.Generic;
using System.Text;
using CIConfigGlobalParameters;
using System.Collections;

using NBiis;
using NBiis.Generic;
using NBIISNET;

namespace CIFicheiro
{
    public class FichEnvmAcom : Ficheiro
    {
        public string m_sExpectedName;
        protected ArrayList m_oParam;
        public int m_iTipoFicheiro;
        //Header Fich
        public string m_sHFREFCMP;
        public string m_sHFFICH;
        public string m_sHFBANCO;
        public string m_sHFNSEQFICH;
        public string m_sHFDTFICH;
        public DateTime m_dtHFDTFICH;
        public string m_sHFFICH_ID;
       
        //Header Lote
        public string m_sHLNLOTE;

        //Detalhes
        public string m_sDREFARQ;
        public decimal m_dDIMPORT;
        public string m_sDCODANA;
        public string m_sDCHAHOST;
        public string m_sDCHAHOSTEXT;
        public string m_sDCODBAL;

        //Trailer lote
        public int m_iTLTOTREG;
        public decimal m_dTLMONTTOTAL;

        //Trailer Fich
        public int m_iTFTOTREGFIS;
        public decimal m_dTFMONTTOTFIC;
        public string m_sTFULTFICH;

        public virtual void parseHeaderLote()
        {}
        public virtual void parseDetalhe()
        {}
        public virtual void parseTrailerLote()
        {}


        public FichEnvmAcom(CIComumInterface iInterface, CIConfigGP.CIGlobalParameters oParameters)
            : base(iInterface, oParameters)
        {
            m_oParam = new ArrayList();

            m_sHDT = "";
            m_sLinha = "";
            m_sHFFICH = "";
            m_sHFBANCO = "";
            m_sHFNSEQFICH = "";
            m_sHFDTFICH = "";
            m_dtHFDTFICH = DateTime.MinValue;
            m_sHFFICH_ID = "";

            m_sHLNLOTE = "";

            m_dDIMPORT = 0;
            m_sDREFARQ = "";
            m_sDCODANA = "";
            m_sDCHAHOST = "";
            m_sDCHAHOSTEXT = "";
            m_sDCODBAL = "";

            m_iTLTOTREG = 0;
            m_dTLMONTTOTAL = 0;

            m_sTFULTFICH = "";
            m_iTFTOTREGFIS = 0;
            m_dTFMONTTOTFIC = 0;
        }

        public void parseHeaderFich()
        {
            string sLinha = m_sLinha;
            int iPos = 0, iLen = 1;
            m_iCountTotRegLotes = 0;
            m_dAcumMontTotalLotes = 0;

       
            m_sHDT = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 4;
            m_sHFFICH = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 4;
            m_sHFBANCO = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 4;
            m_sHFNSEQFICH = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 12;
            m_sHFDTFICH = sLinha.Substring(iPos, iLen);

            try
            {
                m_dtHFDTFICH = new DateTime(Convert.ToInt32(m_sHFDTFICH.Substring(0, 4)), Convert.ToInt32(m_sHFDTFICH.Substring(4, 2)), Convert.ToInt32(m_sHFDTFICH.Substring(6, 2)), Convert.ToInt32(m_sHFDTFICH.Substring(8, 2)), Convert.ToInt32(m_sHFDTFICH.Substring(10, 2)), 0);
            }
            catch
            {
                m_dtHFDTFICH = DateTime.MinValue;
            }

            iPos = iPos + iLen; iLen = 8;
            m_sHFREFCMP = sLinha.Substring(iPos, iLen);
         
        }

        public override bool validaHeaderFich()
        {
            if (m_sLinha.Length < 33)
            {
                return false;
            }

            m_iCountTotRegLotes = 0;
            m_dAcumMontTotalLotes = (decimal)0;

            parseHeaderFich();

            int iEsperada = getLastNSeqFich() + 1;
            if (int.Parse(m_sHFNSEQFICH) != iEsperada)
            {
                string sSmg = "Sequencia de ficheiro " + m_sHFNSEQFICH + " != " + iEsperada.ToString() + " Esperada";
                GenericLog.GenLogRegistarAlerta(sSmg, "validaHeaderFich()", 600);
                m_oParameters.EnviarAlertaSituacao(600, sSmg);
            }

            if (m_sHFFICH != m_sExpectedName)
            {
                throw new Exception("Header de ficheiro:" + m_sHFFICH + " Invalido");
            }
            return true;
        }

        public int getLastNSeqFich()
        {   ArrayList oParam = new ArrayList();
            int iLastNSeqFich;

            try
            {

                oParam.Add(new GeneralDBParameters("@FichTipo", m_iTipoFicheiro));

                iLastNSeqFich = Convert.ToInt32(m_oParameters.DirectStoredProcedureScalar("dbo.Select_LastNSeqFichTipo", ref oParam));
                return iLastNSeqFich;
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "getLastNSeqFich()", 30);
                return iLastNSeqFich = 0;
            }
        }
   
        public override bool validaHeaderLote() 
        { 
            return false; 
        }

        public override void insertHeaderLote() 
        { }

        public override bool validaDetalhe() 
        {
            return false; 
        }
        public override void insertDetalhe()
        { }
        public override bool validaTrailerLote() 
        { 
            return false; 
        }
        public override void insertTrailerLote() 
        { }

        public void parseTrailerFich()
        {
            string sLinha = m_sLinha;
            int iPos = 0, iLen = 1;

            m_sHDT = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 6;
            string m_sTFTOTREGFIS = sLinha.Substring(iPos, iLen);
            m_iTFTOTREGFIS = int.Parse(m_sTFTOTREGFIS);

            iPos = iPos + iLen; iLen = 15;
            string m_sTFMONTTOTFIC = sLinha.Substring(iPos, iLen);
            m_dTFMONTTOTFIC = (decimal.Parse(m_sTFMONTTOTFIC) / (decimal)100.0);

            iPos = iPos + iLen; iLen = 2;
            m_sTFULTFICH = sLinha.Substring(iPos, iLen);

        }

        public override bool validaTrailerFich()
        {

            if (m_sLinha.Length < 24)
                return false;

            parseTrailerFich();

            if (m_iTFTOTREGFIS != m_iCountTotRegLotes)
            {
                alertaErroFich("Total de registos " + m_iTFTOTREGFIS.ToString() + " do trailer do Ficheiro " + m_sFichID + " na linha " + m_iCounter.ToString() + " != da quantidade de detalhes " + m_iCountTotRegLotes.ToString());
            }
            if (m_dTFMONTTOTFIC != m_dAcumMontTotalLotes)
            {
                alertaErroFich("Montante total " + m_dTFMONTTOTFIC.ToString() + " do trailer do Ficheiro " + m_sFichID + " na linha " + m_iCounter.ToString() + " != do montante dos detalhes " + m_dAcumMontTotalLotes.ToString());
            }
            return true;
        }

        public void alertaErroFich(string sErro)
        {
            m_iInterface.WarningMessage(sErro);

            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@FichID", m_sFichID));
            m_oParam.Add(new GeneralDBParameters("@Erro", sErro));

            m_oParameters.DirectStoredProcedureNonQuery("dbo.Update_Ficheiro", ref m_oParam);
        }

        public void ValidaTotaisLote()
        {
           // m_iCountTotRegLotes = m_iCountTotRegLotes + m_iTLTOTREG;

            if (m_iTLTOTREG != m_iCountDetalhesLote)
            {
                alertaErroFich("Total de registos " + m_iTLTOTREG.ToString() + " do Ficheiro " + m_sFichID + " do trailer do lote " + m_sHLNLOTE + " na linha " + m_iCounter.ToString() + " != da quantidade de detalhes " + m_iCountDetalhesLote.ToString()); 
            }
            if (m_dTLMONTTOTAL != m_dAcumDetalhesLote)
            {
                alertaErroFich("Montante total " + m_dTLMONTTOTAL.ToString() + " do Ficheiro " + m_sFichID + " do trailer do lote " + m_sHLNLOTE + " na linha " + m_iCounter.ToString() + " != do montante dos detalhes " + m_dAcumDetalhesLote.ToString()); 
            }
        }

        public override void insertHeaderFich()
        {
            try
            {
                m_oParam.Clear();
                m_oParam.Add(new GeneralDBParameters("@Fich", m_sHFFICH));
                m_oParam.Add(new GeneralDBParameters("@Banco", m_sHFBANCO));
                m_oParam.Add(new GeneralDBParameters("@NSeqFich", m_sHFNSEQFICH));
                m_oParam.Add(new GeneralDBParameters("@DtFich", m_dtHFDTFICH));
                m_oParam.Add(new GeneralDBParameters("@RefCmp", m_sHFREFCMP));
                m_oParam.Add(new GeneralDBParameters("@FullPathName", m_sFileName));

                m_sFichID = m_oParameters.DirectStoredProcedureScalar("dbo.Insert_Ficheiro", ref m_oParam).ToString();
            }
            catch (Exception ex)
            {
                if (ex.Message.IndexOf("UK_FICHEIRO") > 0)
                {
                    throw new Exception("Ficheiro já importado anteriormente");
                }
                throw;
            }
        }

        public override void insertTrailerFich()
        {
            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@FichID", m_sFichID));
            m_oParam.Add(new GeneralDBParameters("@TotReg", m_iTFTOTREGFIS));
            m_oParam.Add(new GeneralDBParameters("@MontTotal", m_dTFMONTTOTFIC));
            m_oParam.Add(new GeneralDBParameters("@UltFich", m_sTFULTFICH));

            m_oParameters.DirectStoredProcedureNonQuery("dbo.Update_Ficheiro", ref m_oParam);

        }
    }
}
