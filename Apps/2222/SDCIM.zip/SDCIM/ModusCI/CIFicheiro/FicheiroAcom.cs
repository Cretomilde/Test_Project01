﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Text;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;
using System.Collections;


namespace CIFicheiro
{
    public class FicheiroAcom : FichEnvmAcom
    {    
        public string m_sHLPRODUTO;
        public DateTime m_dtHLDATAPROC;
        public string m_sHLDATAPROC;     
        public string m_sDREFARQCAP; 
        public string m_sDLINHAOPT;
        public DateTime m_dtAcolhilmento { get; set; }

        public FicheiroAcom(CIComumInterface iInterface, CIConfigGP.CIGlobalParameters oParameters)
            : base(iInterface, oParameters)
        {
            m_sExpectedName = "ACOM";
            m_iTipoFicheiro = 2;
            m_sHDT = "";
            m_sLinha = "";
            m_oParam = new ArrayList();
            m_sHFFICH = "";
            m_sHFBANCO = "";
            m_sHFNSEQFICH = "";
            m_sHFDTFICH = "";
            m_dtHFDTFICH = DateTime.MinValue;
            m_sHFFICH_ID = "";

            m_sHLNLOTE = "";
            m_sHLPRODUTO = "";
            m_dtHLDATAPROC = DateTime.MinValue;


            m_dDIMPORT = 0;
            m_sDREFARQ = "";
            m_sDCODANA = "";
            m_sDCHAHOST = "";
            m_sDCHAHOSTEXT = "";
            m_sDREFARQCAP = "";
            m_sDCODBAL = "";
            m_sDLINHAOPT = "";

            m_iTLTOTREG = 0;
            m_dTLMONTTOTAL =0;

            m_sTFULTFICH = "";
            m_iTFTOTREGFIS = 0;
            m_dTFMONTTOTFIC = 0;

            this.m_dtAcolhilmento = DateTime.MinValue;
        }

        public override void parseHeaderLote()
        {
            string sLinha = m_sLinha;
            int iPos = 0, iLen = 1;

            m_sHDT = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 6;
            m_sHLNLOTE = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 3;
            m_sHLPRODUTO = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 8;
            m_sHLDATAPROC = sLinha.Substring(iPos, iLen);

            try
            {
                m_dtHLDATAPROC = new DateTime(Convert.ToInt32(m_sHLDATAPROC.Substring(0, 4)), Convert.ToInt32(m_sHLDATAPROC.Substring(4, 2)), Convert.ToInt32(m_sHLDATAPROC.Substring(6, 2)));
            }
            catch
            {
                m_dtHLDATAPROC = DateTime.MinValue;
            }
        }

        public override bool validaHeaderLote()
        {
            if (m_sLinha.Length < 18)
                return false;

            parseHeaderLote();

            m_iInterface.InfoMessage("Importação ACOM Lote:" + m_sHLNLOTE, "");

            m_iCountDetalhesLote = 0;
            m_dAcumDetalhesLote = (decimal)0;
            return true;
        }

        public override void parseDetalhe()
        {
            string sLinha = m_sLinha;
            int iPos = 0, iLen = 1;

            m_sHDT = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 14;
            m_sDREFARQCAP = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 14;
            m_sDREFARQ = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 4;
            m_sDCODBAL = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 2;
            m_sDCODANA = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 51;
            m_sDCHAHOST = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 77;
            m_sDCHAHOSTEXT = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 12;
            string sDIMPORT = sLinha.Substring(iPos, iLen);
            m_dDIMPORT = decimal.Parse(sDIMPORT)/ (decimal)100.0 ;
 
            iPos = iPos + iLen; iLen = 31;
            m_sDLINHAOPT = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen + 14 + 50; iLen = 8;
            DateTime dt;
            String dtAcolhimento = sLinha.Substring(iPos, iLen);
            if (DateTime.TryParse(String.Format("{0}-{1}-{2}", Convert.ToInt32(dtAcolhimento.Substring(0, 4)),
                Convert.ToInt32(dtAcolhimento.Substring(4, 2)), Convert.ToInt32(dtAcolhimento.Substring(6, 2))), out dt))
            {
                this.m_dtAcolhilmento = dt;
            }
            m_iCountDetalhesLote++;
            m_dAcumDetalhesLote += m_dDIMPORT;

            m_iCountTotRegLotes++;
            m_dAcumMontTotalLotes += m_dDIMPORT;                        
        }

        public override bool validaDetalhe()
        {
            if (m_sLinha.Length < 206)
                return false;
            parseDetalhe();
            return true;
        }

        public override void parseTrailerLote()
        {
            string sLinha = m_sLinha;
            int iPos = 0, iLen = 1;


            m_sHDT = sLinha.Substring(iPos, iLen);

            iPos = iPos + iLen; iLen = 6;
            string sTLTOTREG = sLinha.Substring(iPos, iLen);
            m_iTLTOTREG = int.Parse(sTLTOTREG);

            iPos = iPos + iLen; iLen = 15;
            string sTLMONTTOTAL = sLinha.Substring(iPos, iLen);
            m_dTLMONTTOTAL = decimal.Parse(sTLMONTTOTAL) / (decimal)100.0;
        }

        public override bool validaTrailerLote()
        {

            if (m_sLinha.Length < 22)
                return false;

            parseTrailerLote();
            ValidaTotaisLote();
            return true;

        }

        //public override bool validaTrailerFich()
        //{
        //    string sLinha = m_sLinha;
        //    int iPos = 0, iLen = 1;

        //    if (sLinha.Length < 24)
        //        return false;

        //    m_sHDT = sLinha.Substring(iPos, iLen);

        //    iPos = iPos + iLen; iLen = 6;
        //    m_sTFTOTREGFIS = sLinha.Substring(iPos, iLen);

        //    iPos = iPos + iLen; iLen = 15;
        //    m_sTFMONTTOTFIC = sLinha.Substring(iPos, iLen);

        //    iPos = iPos + iLen; iLen = 2;
        //    m_sTFULTFICH = sLinha.Substring(iPos, iLen);

        //    return true;
        //}

        //public override void insertHeaderFich()
        //{

        //    m_oParam.Clear();
        //    m_oParam.Add(new GeneralDBParameters("@Fich", m_sHFFICH));
        //    m_oParam.Add(new GeneralDBParameters("@Banco", m_sHFBANCO));
        //    m_oParam.Add(new GeneralDBParameters("@NSeqFich", m_sHFNSEQFICH));
        //    m_oParam.Add(new GeneralDBParameters("@DtFich", m_dtHFDTFICH));
        //    m_oParam.Add(new GeneralDBParameters("@RefCmp", "00000000"));
        //    m_oParam.Add(new GeneralDBParameters("@FullPathName", m_sFileName));

        //    m_sFichID = m_oParameters.DirectStoredProcedureScalar("dbo.Insert_Ficheiro", ref m_oParam).ToString();
        //}
        
        public override void insertHeaderLote()
        {
            
            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@FichID", m_sFichID));
            m_oParam.Add(new GeneralDBParameters("@Numero", m_sHLNLOTE));
            m_oParam.Add(new GeneralDBParameters("@Produto", m_sHLPRODUTO));
            m_oParam.Add(new GeneralDBParameters("@DataProc", m_dtHLDATAPROC));

            m_sLoteID = m_oParameters.DirectStoredProcedureScalar("dbo.Insert_LoteACOM", ref m_oParam).ToString();

        }
        public override void insertDetalhe()
        {
            
            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@LoteAcom_Id", m_sLoteID));
            m_oParam.Add(new GeneralDBParameters("@RefarqCap", m_sDREFARQCAP));
            m_oParam.Add(new GeneralDBParameters("@Refarq", m_sDREFARQ));
            m_oParam.Add(new GeneralDBParameters("@Balcao", m_sDCODBAL));
            m_oParam.Add(new GeneralDBParameters("@CodAna", m_sDCODANA));
            m_oParam.Add(new GeneralDBParameters("@ChaveH", m_sDCHAHOST));
            m_oParam.Add(new GeneralDBParameters("@ChaveHext", m_sDCHAHOSTEXT));
            m_oParam.Add(new GeneralDBParameters("@Import", m_dDIMPORT));
            m_oParam.Add(new GeneralDBParameters("@LinhaOpt", m_sDLINHAOPT));
            //supbkoff 30 - adição de campo DTACOLHIMENTO 
            m_oParam.Add(new GeneralDBParameters("@DtAcolhimento", this.m_dtAcolhilmento));
            m_sDocID = m_oParameters.DirectStoredProcedureScalar("dbo.Insert_DocumentoAcom", ref m_oParam).ToString();

        }
        public override void insertTrailerLote()
        {
            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@LoteAcomID", m_sLoteID));
            m_oParam.Add(new GeneralDBParameters("@FichID", m_sFichID));
            m_oParam.Add(new GeneralDBParameters("@TotReg", m_iTLTOTREG));
            m_oParam.Add(new GeneralDBParameters("@MontTotal", m_dTLMONTTOTAL));

            m_oParameters.DirectStoredProcedureNonQuery("dbo.Update_LoteAcom", ref m_oParam);

        }
        //public override void insertTrailerFich()
        //{
        //    m_oParam.Clear();
        //    m_oParam.Add(new GeneralDBParameters("@FichID", m_sFichID));
        //    m_oParam.Add(new GeneralDBParameters("@TotReg", m_sTFTOTREGFIS));
        //    m_oParam.Add(new GeneralDBParameters("@MontTotal", m_sTFMONTTOTFIC));
        //    m_oParam.Add(new GeneralDBParameters("@UltFich", m_sTFULTFICH));

        //    m_oParameters.DirectStoredProcedureNonQuery("dbo.Update_Ficheiro", ref m_oParam);

        //}
    }

  
}
