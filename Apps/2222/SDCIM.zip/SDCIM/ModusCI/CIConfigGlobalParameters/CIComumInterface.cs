﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIConfigGlobalParameters
{
    public interface CIComumInterface
    {
        void ErrorMessage(string sMessage);
        void WarningMessage(string sMessage);
        void InfoMessage(string sMessage, string sHeader);
        void InfoMessageCount(string sMessage);

    }
}
