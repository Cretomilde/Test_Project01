﻿
using System.Windows.Forms;

namespace CIConfigGlobalParameters
{
    public interface CIMenuInterface
    {
        Form GetMainForm();
        void alertasToolStripMenuItemEnable(bool bEnable);
        void processarEnvmEnable(bool bEnable);
        void processaAcomEnable(bool bEnable);
        void actividadesEnable(bool bEnable);
        void sacoEnable(bool bEnable);
        void actividadeBalcaoEnable(bool bEnable);
        void controloBalcaoAcoesEnable(bool bEnable);
        void consultasEnable(bool bEnable);
        void PesquisasEnable(bool bEnable);
        void balcoesEnable(bool bEnable);
        void utilizadoresEnable(bool bEnable);
        void configuracaoEnable(bool bEnable);
        void ControloMDIsFormMenuItemEnable(bool bEnable);
        void enablePesqFicheiroAcom(bool bEnable);
    }
}
