﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Data.SqlClient;

using NBiis.Generic;
using NBiis;

namespace CIConfigGP
{
    public class User
    {
        public string m_sUserName;
        public string m_sUserFullName;
        public string m_sGroupName;
        public int m_iUserGroup;

        private CIConfigGP.CIGlobalParameters m_oParameters;

        public User(SqlDataReader dr)
        {
            m_sUserName = Convert.ToString(dr["LOGIN_NAME"]);
            m_sUserFullName = Convert.ToString(dr["USER_FULLNAME"]);

            m_sGroupName = Convert.ToString(dr["GROUP_NAME"]);

            m_iUserGroup = Convert.ToInt16(dr["GROUP_ID"]);
        }

        public User(CIConfigGP.CIGlobalParameters oParameters, string sLoginName)
        {
            m_oParameters = oParameters;
            
            m_sUserName = sLoginName;
            m_sUserFullName = GetUserFullName(sLoginName);

           
            m_iUserGroup = GetUserGroup(sLoginName);
            m_sGroupName = GetGroupName(sLoginName);
        }

        public string GetUserFullName(string sLoginName)
        {
            try
            {
                string sUserFullName, sQuery;
                sQuery = "select USER_FULLNAME from VW_PASSWD_GROUP where LOGIN_NAME='" + sLoginName + "'";

                sUserFullName = (string)m_oParameters.DirectSqlScalar(sQuery);

                if (sUserFullName == null)
                {
                    return sLoginName;
                }

                return sUserFullName;
            }
            catch
            {
                return sLoginName;
            }
        }

      
        public int GetUserGroup(string sLoginName)
        {
            try
            {
                string sQuery;
                int iGroup;
                sQuery = "select GROUP_ID from VW_PASSWD_GROUP where LOGIN_NAME='" + sLoginName + "'";

                iGroup = (int)m_oParameters.DirectSqlScalar(sQuery);

                return iGroup;
            }
            catch
            {
                return 99;
            }
        }

       
        public string GetGroupName(string sLoginName)
        {
            try
            {
                string sGroupName, sQuery;
                sQuery = "select GROUP_NAME from VW_PASSWD_GROUP where LOGIN_NAME='" + sLoginName + "'";

                sGroupName = (string)m_oParameters.DirectSqlScalar(sQuery);

                if (sGroupName == null)
                {
                    return "guest";
                }

                return sGroupName;
            }
            catch
            {
                return "guest";
            }
        }
    }
}
