﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using NBiis.Generic;
using NBiis;

namespace CIConfigGP
{
    public class CIGlobalParameters : ConfigGlobalParameters
    {
        public CIConfigGP.User UserLogged;

        protected bool m_bServicoActivo;

        public int m_iTempoEntreIteracoesFicheiros;
        public int m_iTempoEntreIteracoes;
        public int m_iMaxDocsTranche;

        public string m_sSintaxFilesToImportENVM;
        public string m_sSintaxFilesToImportACOM;
        public string m_sFilePathENVM;
        public string m_sFilePathACOM;
        public string m_sFileBackupPath;
        public int m_iParagemHoraInicio;
        public int m_iParagemHoraFim;
        public int m_iParagemMinutoInicio;
        public int m_iParagemMinutoFim;
        public int m_iMaxDias;
        public int m_iMinDias;

        
        public int m_iHorasEsperaEnvm;
        public int m_iHorasEsperaRemessa;
        public int m_iParagemAlertaHoraInicio;
        public int m_iParagemAlertaMinutoInicio;
        public int m_iParagemAlertaHoraFim;
        public int m_iParagemAlertaMinutoFim;
        public int m_iPercentagemAlerta;
        public DateTime m_dtLastLoadParameters;

        public CIGlobalParameters()
            : base()
        {
            m_dtLastLoadParameters = DateTime.Now.AddMinutes(-6);
            LoadUser();
            LoadParameters();
        }

        public CIGlobalParameters(string sPrefixo)
            : base(sPrefixo)
        {
            m_dtLastLoadParameters = DateTime.Now.AddMinutes(-6);
            LoadUser();
            LoadParameters();
        }

        public virtual void LoadParameters()
        {
            if (m_dtLastLoadParameters.AddMinutes(5) > DateTime.Now)
            {
                return;
            }
            m_dtLastLoadParameters = DateTime.Now;

            m_sSintaxFilesToImportACOM = GetProfileString("Ficheiros", "Sintaxe", "ACOM", "acom.*");
            m_sSintaxFilesToImportENVM = GetProfileString("Ficheiros", "Sintaxe", "ENVM", "envm.*");
            m_sFilePathENVM = GetProfileString("Ficheiros", "PATHS", "ENVM", "c:\\tmp\\");
            m_sFilePathACOM = GetProfileString("Ficheiros", "PATHS", "ACOM", "c:\\tmp\\");
            m_sFileBackupPath = GetProfileString("Ficheiros", "PATHS", "Backup", "c:\\");

            LoadParametersVariaveis();
            
        }

        public virtual void LoadParametersVariaveis()
        {
            m_iTempoEntreIteracoesFicheiros = GetProfileInt("CI", "Tempos", "TempoEntreIteracoesFicheiros", 2);
            m_iTempoEntreIteracoes = GetProfileInt("CI", "Tempos", "TempoEntreIteracoes", 2);
            m_iMaxDocsTranche = GetProfileInt("CI", "Quantidades", "MaxDocsTranche", 10);
            m_iParagemHoraInicio = GetProfileInt("CI", "Paragem", "HoraInicio", 15);
            m_iParagemHoraFim = GetProfileInt("CI", "Paragem", "HoraFim", 16);
            m_iParagemMinutoInicio = GetProfileInt("CI", "Paragem", "MinutoInicio", 6);
            m_iParagemMinutoFim = GetProfileInt("CI", "Paragem", "MinutoFim", 7);
            m_iMaxDias = GetProfileInt("CI", "RemessaValida", "MaxDias", 7);
            m_iMinDias = GetProfileInt("CI", "RemessaValida", "MinDias", -30);
            m_iHorasEsperaEnvm = GetProfileInt("CI", "ALERTAS", "MaxHorasEsperaENVM", 2);
            m_iHorasEsperaRemessa = GetProfileInt("CI", "ALERTAS", "MaxHorasEsperaRemessaCI", 2);
            m_iParagemAlertaHoraInicio = GetProfileInt("CI", "ALERTAS", "HoraInicio", 15);
            m_iParagemAlertaHoraFim = GetProfileInt("CI", "ALERTAS", "HoraFim", 16);
            m_iParagemAlertaMinutoInicio = GetProfileInt("CI", "ALERTAS", "MinutoInicio", 6);
            m_iParagemAlertaMinutoFim = GetProfileInt("CI", "ALERTAS", "MinutoFim", 7);
            m_iPercentagemAlerta = GetProfileInt("CI", "ALERTAS", "ParamPercentagem", 1);
            //m_bServicoActivo = Convert.ToBoolean(GetProfileInt("CIServicos", "Control", "ServiçoON", 1);

            m_bServicoActivo = (GetProfileString("CIServicos", "Control", "ServiçoON", "1.0.0.0").CompareTo(System.Windows.Forms.Application.ProductVersion)<=0);
            //m_bServicoActivo = Convert.ToBoolean(GetProfileInt("CIServicos", System.Windows.Forms.Application.ProductVersion, "ServiçoON", 1));
            
        }


        //public void Para()//isto e para passar para o serviço
        //{
        //    if (HoradeParagem())
        //    {
        //        MessageBox.Show("PAROU", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
        //    }

        //}

        public bool HoradeParagem()
        {
            if (!m_bServicoActivo)
            {
                return true;
            }
           // LoadParametersVariaveis();
            DateTime dtInicioParagem = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, m_iParagemHoraInicio, m_iParagemMinutoInicio, 0);
            DateTime dtFimParagem = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, m_iParagemHoraFim, m_iParagemMinutoFim, 0);
            
            if (dtInicioParagem > dtFimParagem) //isto necessita de verificação 
            {
                if (dtInicioParagem < DateTime.Now)
                {
                    dtFimParagem = dtFimParagem.AddDays(+1);
                }

                if (dtFimParagem > DateTime.Now)
                {
                    dtInicioParagem = dtInicioParagem.AddDays(-1);
                }
            }


            return (DateTime.Now > dtInicioParagem && DateTime.Now < dtFimParagem);
        }

        protected virtual void LoadUser()
        {
            LoginName = System.Windows.Forms.SystemInformation.UserName;

            UserLogged = new User(this,LoginName);
        }

        public virtual void EnviarAlertaSituacao(int iSituacao, string sMensagem)
        {
            try
            {
                string sSPName = "dbo.Insert_Alerta";
                ArrayList oParam = new ArrayList();

                oParam.Add(new GeneralDBParameters("@SITUACAO_ID", iSituacao));
                oParam.Add(new GeneralDBParameters("@AL_TEXT", UserLogged.m_sUserName + ": " + sMensagem));

                DirectStoredProcedureNonQuery(sSPName, ref oParam);

            }
            catch
            { 
            }
        }

        public void InitGenericLog()
        {
            OpenConnection();
            IDbConnection oConn = DataBase;
            GenericLog.GenLogInicializacao(ref oConn, Sistema, Aplicativo, LoginName);
            GenericLog.RegistarApplicacaoLog();
            CloseConnection();
        }

        public string GetTempFileName(string sFixedPart)
        {
            string sTempFileName = Environment.GetEnvironmentVariable("temp");
            //sTempFileName += "\\" + Application.ProductName + "_" + sFixedPart + "_" + System.Threading.Thread.CurrentThread.ManagedThreadId.ToString() + "_" + DateTime.Now.Ticks.ToString() + "_";
            sTempFileName += "\\" + Application.ProductName + "_" + sFixedPart + "_" + System.Threading.Thread.CurrentThread.ManagedThreadId.ToString();
            return sTempFileName;
        }

    }
}
