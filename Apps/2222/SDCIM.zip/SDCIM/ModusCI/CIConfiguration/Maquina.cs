﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace CIConfiguration
{
    class Maquina
    {
        public long m_lMAQ_ID;          // Chave
        public string m_sBALCAO_PAIS;  // Ligação ao Balcão
        public int m_iBALCAO_BANCO;    // Ligação ao Balcão
        public int m_iBALCAO_CODIGO;   // Ligação ao Balcão
        public int m_iMAQ_SEQBALCAO;
        public int m_iMAQ_MODELO;
        public int m_iMAQ_IQA;
        public int m_iMAQ_OPERACAO;
        public string m_sOperacao;
        public int m_iMAQ_EFECTUADO;
        public DateTime m_dtMAQ_TIMER;
        public string m_sMAQ_ERRO;
        public string m_sChaveWS;

        public Maquina()
        {
            m_lMAQ_ID=-1;
            m_sBALCAO_PAIS="PT";
            m_iBALCAO_BANCO=35;
            m_iBALCAO_CODIGO=-1;
            m_iMAQ_SEQBALCAO=-1;
            m_iMAQ_MODELO=-1;
            m_iMAQ_IQA=0;
            m_iMAQ_OPERACAO=0;
            m_iMAQ_EFECTUADO=0;
            m_dtMAQ_TIMER = DateTime.Now;
            m_sMAQ_ERRO="";
            m_sOperacao = "";
            m_sChaveWS = "";
        }

        public Maquina(SqlDataReader dr)
        {
            m_lMAQ_ID = Convert.ToInt64(dr["MAQ_ID"]);
            m_sBALCAO_PAIS = Convert.ToString(dr["BALCAO_PAIS"]);
            m_iBALCAO_BANCO = Convert.ToInt16(dr["BALCAO_BANCO"]);
            m_iBALCAO_CODIGO = Convert.ToInt16(dr["BALCAO_CODIGO"]);
            m_iMAQ_SEQBALCAO = Convert.ToInt16(dr["MAQ_SEQBALCAO"]);
            m_iMAQ_MODELO = Convert.ToInt16(dr["MAQ_MODELO"]);
            m_iMAQ_IQA = Convert.ToInt16(dr["MAQ_IQA"]);
            m_iMAQ_OPERACAO = Convert.ToInt16(dr["MAQ_OPERACAO"]);
            m_sOperacao = Convert.ToString(dr["OPERACAO_ABR"]);
            m_iMAQ_EFECTUADO = Convert.ToInt16(dr["MAQ_EFECTUADO"]);
            m_dtMAQ_TIMER = Convert.ToDateTime(dr["MAQ_TIMER"]);
            m_sMAQ_ERRO = Convert.ToString(dr["MAQ_ERRO"]);
            m_sChaveWS = Convert.ToString(dr["CHAVE_WEBSERVICE"]);
        }

        public ListViewItem MakeListViewItemMaquina(string sDateTimeSysFmt)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_lMAQ_ID.ToString();
            olvItem.SubItems.Add(m_sBALCAO_PAIS + " " + m_iBALCAO_BANCO.ToString("0000") + "." + m_iBALCAO_CODIGO.ToString("0000"));
            olvItem.SubItems.Add(m_iMAQ_SEQBALCAO.ToString());
            olvItem.SubItems.Add(m_iMAQ_MODELO.ToString());
            olvItem.SubItems.Add(m_iMAQ_IQA.ToString());
            olvItem.SubItems.Add(m_sOperacao);
            olvItem.SubItems.Add(m_iMAQ_EFECTUADO.ToString());
            olvItem.SubItems.Add(m_dtMAQ_TIMER.ToString(sDateTimeSysFmt));
            olvItem.SubItems.Add(m_sMAQ_ERRO);
            olvItem.SubItems.Add(m_sChaveWS);

            return olvItem;
        }


    }
}
