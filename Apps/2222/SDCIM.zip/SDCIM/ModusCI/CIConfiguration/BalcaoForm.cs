﻿using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using NBiis;
using NBiis.Generic;

namespace CIConfiguration
{
    public partial class BalcaoForm : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        Balcao m_oCurrBalcao;
        Maquina m_oCurrMaquina;
        ArrayList m_oParam;
        string m_sPais, m_sBanco;
        protected CIConfigGlobalParameters.CIMenuInterface m_oMenuInterface;


        public BalcaoForm(CIConfigGP.CIGlobalParameters oParameters, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_oCurrBalcao = new Balcao();
            m_oCurrMaquina = new Maquina();
            m_oParam = new ArrayList();
            m_oMenuInterface = oMenuInterface;
        }

        private void AddBalcao2ListView(SqlDataReader dr)
        {
            Balcao oBalcao = new Balcao(dr);

            ListViewItem olvItem = oBalcao.MakeListViewItemBalcao(m_oParameters.DateTimeSysFmt);

            olvItem.Tag = oBalcao;

            listViewBalcoes.Items.Add(olvItem);
        }

        private void AddMaquina2ListView(SqlDataReader dr)
        {
            Maquina oMaquina = new Maquina(dr);

            ListViewItem olvItem = oMaquina.MakeListViewItemMaquina(m_oParameters.DateTimeSysFmt);

            olvItem.Tag = oMaquina;

            listViewMaquinas.Items.Add(olvItem);
        }

        private void RefreshBalcoes()
        {
            listViewBalcoes.MyClear();
            this.listViewMaquinas.MyClear();
            SqlDataReader drB = null;
            string sQuery = "select * from VW_BALCAO";
            if (txtBalcao.Text.Trim() != "")
            {
                sQuery = "select * from VW_BALCAO where BALCAO_CODIGO = " + txtBalcao.Text;
            }
            try
            {
                drB = m_oParameters.DirectSqlDataReader(sQuery);
                while (drB.Read())
                {
                    AddBalcao2ListView(drB);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (drB != null)
                {
                    drB.Close();
                }
            }
        }

        void LoadDatabaseValues()
        {
            string sQuery;
            DataSet dsPaisBanco = new DataSet();

            sQuery = "select pais + ' - ' + convert(varchar(4),banco) as display, pais + ',' + convert(varchar(4),banco) as valor from PAISBANCO ORDER BY ordem";
            dsPaisBanco = m_oParameters.DirectSqlDataSet(sQuery, "PaisBanco");

            comboBoxPaisBanco.DataSource = dsPaisBanco.Tables[0].DefaultView;
            comboBoxPaisBanco.DisplayMember = "display";
            comboBoxPaisBanco.ValueMember = "valor";
        }

        private void BalcaoForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = System.Windows.Forms.FormWindowState.Maximized;

                btInsertBalcao.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);
                btUpdateBalcao.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);
                btInsertMaq.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);
                btUpdateMaq.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);

                contextMenuStripBalcao.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);
                contextMenuMaquina.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);

                RefreshBalcoes();

                LoadDatabaseValues();
                m_oMenuInterface.balcoesEnable(false);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Dispose();
            }
        }

        private void btInsert_Click(object sender, EventArgs e)
        {
            string sSPName;
            try
            {
                if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                {
                    return;
                }

                validaCampos(true);

                sSPName = "dbo.Insert_Balcao";

                m_oParam.Clear();
                m_oParam.Add(new GeneralDBParameters("@Pais", m_sPais));
                m_oParam.Add(new GeneralDBParameters("@Banco", Convert.ToInt16(m_sBanco)));
                m_oParam.Add(new GeneralDBParameters("@Balcao", Convert.ToInt16(textBoxBalcao.Text)));
                m_oParam.Add(new GeneralDBParameters("@Fisicos", Convert.ToBoolean(comboBoxFisicos.Text)));
                m_oParam.Add(new GeneralDBParameters("@Devolvidos", Convert.ToBoolean(comboBoxDevolvidos.Text)));
                m_oParam.Add(new GeneralDBParameters("@Balcao_Abvr", textBoxAbrv.Text));
                m_oParam.Add(new GeneralDBParameters("@balcao_Desc", textBoxDescricao.Text));

                m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);

                string sSmg = "Balcão " + textBoxBalcao.Text + " inserido manualmente";
                GenericLog.GenLogRegistarAlerta(sSmg, "InsertBalcao()", 100);
                m_oParameters.EnviarAlertaSituacao(100, sSmg);
                RefreshBalcoes();
            }
            catch (Exception ex)
            {
                if (ex.Message.IndexOf("duplicate key") > 0)
                    MessageBox.Show("Balcão Já Existente!", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                    MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btUpdate_Click(object sender, EventArgs e)
        {
            string sSPName;
            try
            {
                if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                {
                    return;
                }

                validaCampos(true);

                sSPName = "dbo.Update_Balcao";

                m_oParam.Clear();
                m_oParam.Add(new GeneralDBParameters("@Pais", m_sPais));
                m_oParam.Add(new GeneralDBParameters("@Banco", Convert.ToInt16(m_sBanco)));
                m_oParam.Add(new GeneralDBParameters("@Balcao", Convert.ToInt16(textBoxBalcao.Text)));
                m_oParam.Add(new GeneralDBParameters("@Fisicos", Convert.ToBoolean(comboBoxFisicos.Text)));
                m_oParam.Add(new GeneralDBParameters("@Devolvidos", Convert.ToBoolean(comboBoxDevolvidos.Text)));
                m_oParam.Add(new GeneralDBParameters("@Balcao_Abvr", textBoxAbrv.Text));
                m_oParam.Add(new GeneralDBParameters("@balcao_Desc", textBoxDescricao.Text));

                m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);
                RefreshBalcoes();
            }
            catch (Exception ex)
            {
                if (ex.Message.IndexOf("duplicate key") > 0)
                    MessageBox.Show("Balcão Já Existente!", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                    MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void validaCampos(bool bOnlyBalcao)
        {
            string[] sValores = comboBoxPaisBanco.SelectedValue.ToString().Split(',');
            m_sPais = sValores[0];
            m_sBanco = sValores[1];

            if (textBoxBalcao.Text.Trim().Length == 0 || textBoxAbrv.Text.Trim().Length == 0 || textBoxDescricao.Text.Trim().Length == 0)
            {
                throw new Exception("Preencha os campos do balcão em branco");
            }

            if (bOnlyBalcao) return;

            if (this.m_oCurrBalcao.m_iCodigo.Equals(9601) || this.m_oCurrBalcao.m_iCodigo.Equals(9604) && (
                textBoxMaqSeqBalcao.Text.Trim().Length == 0 || textBoxMaqModelo.Text.Trim().Length == 0 || textBoxMaqIQA.Text.Trim().Length == 0))
            {
                throw new Exception("Preencha os campos da máquina em branco");
            }
        }

        private void btDelete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Não é permitido apagar balcões!!!", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void btRefresh_Click(object sender, EventArgs e)
        {
            this.txtBalcao.Text = String.Empty;
            RefreshBalcoes();
        }

        private void RefreshMaquinas()
        {
            listViewMaquinas.MyClear();
            SqlDataReader drM = null;
            string sQuery = "select * from VW_MAQUINA where ";
            sQuery += "BALCAO_PAIS='" + m_oCurrBalcao.m_sPais + "' and ";
            sQuery += "BALCAO_BANCO=" + m_oCurrBalcao.m_iBanco + " and ";
            sQuery += "BALCAO_CODIGO=" + m_oCurrBalcao.m_iCodigo + "";
            try
            {
                drM = m_oParameters.DirectSqlDataReader(sQuery);
                while (drM.Read())
                {
                    AddMaquina2ListView(drM);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (drM != null)
                {
                    drM.Close();
                }
            }
        }

        private void DisplaySelectedBalcao()
        {
            try
            {
                if (listViewBalcoes.SelectedItems.Count != 1)
                    return;
                m_oCurrBalcao = (Balcao)listViewBalcoes.GetTag();
                comboBoxPaisBanco.Text = m_oCurrBalcao.m_sPais + " - " + m_oCurrBalcao.m_iBanco.ToString();
                textBoxBalcao.Text = m_oCurrBalcao.m_iCodigo.ToString();
                textBoxAbrv.Text = m_oCurrBalcao.m_sAbrev;
                textBoxDescricao.Text = m_oCurrBalcao.m_sDescricao;
                comboBoxFisicos.Text = m_oCurrBalcao.m_bEnviaFisicos.ToString();
                comboBoxDevolvidos.Text = m_oCurrBalcao.m_bOperaDevolvidos.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void listViewBalcoes_SelectedIndexChanged(object sender, EventArgs e)
        {
            DisplaySelectedBalcao();
            RefreshMaquinas();
            textBoxMaqModelo.Text = "";
            textBoxMaqIQA.Text = "";
            textBoxMaqSeqBalcao.Text = "";
            if (this.m_oCurrBalcao.m_iCodigo.Equals(9601) || this.m_oCurrBalcao.m_iCodigo.Equals(9604))
            {
                EnableControlsToGCCA(true);
            }
            else
            {
                EnableControlsToGCCA(false);
            }
        }

        private void EnableControlsToGCCA(Boolean enabled)
        {
            this.textBoxMaqSeqBalcao.Enabled = enabled;
            this.textBoxMaqModelo.Enabled = enabled;
            this.textBoxMaqIQA.Enabled = enabled;
            this.btnLimparMaquina.Enabled = enabled;
            this.btUpdateMaq.Enabled = enabled;
            this.toolStripInserirMaquina.Enabled = enabled;
            this.toolStripActualizarMaquina.Enabled = enabled;
        }

        private void DisplaySelectedMaquina()
        {
            try
            {
                if (listViewMaquinas.SelectedItems.Count != 1)
                    return;

                m_oCurrMaquina = (Maquina)listViewMaquinas.GetTag();
                textBoxMaqSeqBalcao.Text = m_oCurrMaquina.m_iMAQ_SEQBALCAO.ToString();
                textBoxMaqModelo.Text = m_oCurrMaquina.m_iMAQ_MODELO.ToString();
                textBoxMaqIQA.Text = m_oCurrMaquina.m_iMAQ_IQA.ToString();

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "BalcaoForm.cs", 17);
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void listViewMaquinas_SelectedIndexChanged(object sender, EventArgs e)
        {
            DisplaySelectedMaquina();
        }

        private void btInsertMaq_Click(object sender, EventArgs e)
        {
            string sSPName;

            try
            {
                if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                {
                    return;
                }

                validaCampos(false);
                if (this.m_oCurrBalcao.m_iCodigo.Equals(9601) || this.m_oCurrBalcao.m_iCodigo.Equals(9604))
                {
                    if (Int32.Parse(textBoxMaqSeqBalcao.Text) < 1999)
                    {
                        sSPName = "dbo.Insert_Maquina";
                        m_oParam.Clear();
                        m_oParam.Add(new GeneralDBParameters("@Pais", m_sPais));
                        m_oParam.Add(new GeneralDBParameters("@Banco", Convert.ToInt16(m_sBanco)));
                        m_oParam.Add(new GeneralDBParameters("@Balcao", Convert.ToInt16(textBoxBalcao.Text)));
                        m_oParam.Add(new GeneralDBParameters("@SeqBalcao", Convert.ToInt16(textBoxMaqSeqBalcao.Text)));
                        m_oParam.Add(new GeneralDBParameters("@Modelo", Convert.ToInt16(textBoxMaqModelo.Text)));
                        m_oParam.Add(new GeneralDBParameters("@IQA", Convert.ToInt16(textBoxMaqIQA.Text)));
                        m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);
                        string sSmg = "Maquina " + textBoxMaqSeqBalcao.Text + " do balcão " + textBoxBalcao.Text + " inserida manualmente";
                        GenericLog.GenLogRegistarAlerta(sSmg, "InsertMaquina()", 100);
                        m_oParameters.EnviarAlertaSituacao(100, sSmg);
                    }
                    else
                    {
                        MessageBox.Show("O campo SeqBalcao tem de ser inferior a 2000");
                    }
                }
                else
                {
                    sSPName = "Insert_MaquinaBalcao";
                    m_oParam.Clear();
                    m_oParam.Add(new GeneralDBParameters("@REMBALCAO_DATA_IN", DateTime.Now.ToString("yyyy-MM-dd")));
                    m_oParam.Add(new GeneralDBParameters("@BALCAO_PAIS_IN", this.m_oCurrBalcao.m_sPais));
                    m_oParam.Add(new GeneralDBParameters("@BALCAO_EMPRESA_IN", "CGD"));
                    m_oParam.Add(new GeneralDBParameters("@BALCAO_BANCO_IN", this.m_oCurrBalcao.m_iBanco));
                    m_oParam.Add(new GeneralDBParameters("@BALCAO_CODIGO_IN", this.m_oCurrBalcao.m_iCodigo));
                    m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);
                    string sSmg = "Maquina " + textBoxMaqSeqBalcao.Text + " do balcão " + textBoxBalcao.Text + " inserida manualmente";
                    GenericLog.GenLogRegistarAlerta(sSmg, "InsertMaquina()", 100);
                    m_oParameters.EnviarAlertaSituacao(100, sSmg);
                }
                RefreshMaquinas();
            }
            catch (Exception ex)
            {
                if (ex.Message.IndexOf("duplicate key") > 0)
                    MessageBox.Show("Maquina Já Existente!", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                    MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btUpdateMaq_Click(object sender, EventArgs e)
        {
            string sSPName;
            try
            {
                if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                {
                    return;
                }

                validaCampos(false);
                sSPName = "dbo.Update_Maquina";
                if (textBoxAbrv.Text.Contains("GCAA"))
                {
                    if (Int32.Parse(textBoxMaqSeqBalcao.Text) < 1999)
                    {
                        m_oParam.Clear();
                        m_oParam.Add(new GeneralDBParameters("@Maq_ID", Convert.ToInt64(m_oCurrMaquina.m_lMAQ_ID)));
                        m_oParam.Add(new GeneralDBParameters("@SeqBalcao", Convert.ToInt16(textBoxMaqSeqBalcao.Text)));
                        m_oParam.Add(new GeneralDBParameters("@Modelo", Convert.ToInt16(textBoxMaqModelo.Text)));
                        m_oParam.Add(new GeneralDBParameters("@IQA", Convert.ToInt16(textBoxMaqIQA.Text)));
                    }
                }
                else
                {
                    m_oParam.Clear();
                    m_oParam.Add(new GeneralDBParameters("@Maq_ID", Convert.ToInt64(m_oCurrMaquina.m_lMAQ_ID)));
                    m_oParam.Add(new GeneralDBParameters("@SeqBalcao", Convert.ToInt16(-1)));
                    m_oParam.Add(new GeneralDBParameters("@Modelo", Convert.ToInt16(textBoxMaqModelo.Text)));
                    m_oParam.Add(new GeneralDBParameters("@IQA", Convert.ToInt16(textBoxMaqIQA.Text)));
                }
                m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);
                RefreshMaquinas();
            }
            catch (Exception ex)
            {
                if (ex.Message.IndexOf("duplicate key") > 0)
                    MessageBox.Show("Maquina Já Existente!", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                    MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void buttonExitJanela_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void ActualizarOperacaoEfectuadoBalcao(int iOperacao, int iEfectuado)
        {
            try
            {
                string sSPName;
                sSPName = "dbo.Update_BalcaoEfectuado";
                GenericLog.GenLogRegistarAlerta(sSPName, "BalcaoForm.cs", 14);

                m_oParam.Clear();
                m_oParam.Add(new GeneralDBParameters("@Pais", m_oCurrBalcao.m_sPais));
                m_oParam.Add(new GeneralDBParameters("@Banco", m_oCurrBalcao.m_iBanco));
                m_oParam.Add(new GeneralDBParameters("@Balcao", m_oCurrBalcao.m_iCodigo));
                m_oParam.Add(new GeneralDBParameters("@Operacao", iOperacao));
                m_oParam.Add(new GeneralDBParameters("@Efectuado", iEfectuado));

                m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);

                string sMsg = sSPName + " " + m_oCurrBalcao.m_sPais + "/" + m_oCurrBalcao.m_iBanco.ToString() + "/" + m_oCurrBalcao.m_iCodigo;
                sMsg += " Operacao:" + iOperacao.ToString() + " Efectuado:" + iEfectuado.ToString();

                GenericLog.GenLogRegistarAlerta(sMsg, "ActualizarOperacaoEfectuadoBalcao()", 100);

                RefreshBalcoes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void ActualizarOperacaoEfectuadoMaquina(int iOperacao, int iEfectuado)
        {
            try
            {
                string sSPName;
                sSPName = "dbo.Update_MaquinaEfectuado";
                GenericLog.GenLogRegistarAlerta(sSPName, "BalcaoForm.cs", 14);

                m_oParam.Clear();
                m_oParam.Add(new GeneralDBParameters("@Maq_ID", m_oCurrMaquina.m_lMAQ_ID));
                m_oParam.Add(new GeneralDBParameters("@Operacao", iOperacao));
                m_oParam.Add(new GeneralDBParameters("@Efectuado", iEfectuado));

                m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);

                string sMsg = sSPName + " " + m_oCurrMaquina.m_lMAQ_ID.ToString();
                sMsg += " Operacao:" + iOperacao.ToString() + " Efectuado:" + iEfectuado.ToString();

                GenericLog.GenLogRegistarAlerta(sMsg, "ActualizarOperacaoEfectuadoMaquina()", 100);

                RefreshMaquinas();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void toolStripInserir_Click(object sender, EventArgs e)
        {
            if (listViewBalcoes.SelectedItems.Count != 1)
                return;

            if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            m_oCurrBalcao = (Balcao)listViewBalcoes.GetTag();
            ActualizarOperacaoEfectuadoBalcao(1, m_oCurrBalcao.m_iEfectuado);
        }

        private void toolStripActualizar_Click(object sender, EventArgs e)
        {
            if (listViewBalcoes.SelectedItems.Count != 1)
                return;

            if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            m_oCurrBalcao = (Balcao)listViewBalcoes.GetTag();
            ActualizarOperacaoEfectuadoBalcao(3, m_oCurrBalcao.m_iEfectuado);
        }

        private void toolStripInserirMaquina_Click(object sender, EventArgs e)
        {
            if (listViewMaquinas.SelectedItems.Count != 1)
                return;

            if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            m_oCurrMaquina = (Maquina)listViewMaquinas.GetTag();
            ActualizarOperacaoEfectuadoMaquina(1, m_oCurrMaquina.m_iMAQ_EFECTUADO);
        }

        private void toolStripActualizarMaquina_Click(object sender, EventArgs e)
        {
            if (listViewMaquinas.SelectedItems.Count != 1)
                return;

            if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            m_oCurrMaquina = (Maquina)listViewMaquinas.GetTag();
            ActualizarOperacaoEfectuadoMaquina(3, m_oCurrMaquina.m_iMAQ_EFECTUADO);
        }

        private void pendenteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (listViewBalcoes.SelectedItems.Count != 1)
                return;

            if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            m_oCurrBalcao = (Balcao)listViewBalcoes.GetTag();
            ActualizarOperacaoEfectuadoBalcao(m_oCurrBalcao.m_iOperacao, 0);
        }

        private void efectuadoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (listViewBalcoes.SelectedItems.Count != 1)
                return;

            if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            m_oCurrBalcao = (Balcao)listViewBalcoes.GetTag();
            ActualizarOperacaoEfectuadoBalcao(m_oCurrBalcao.m_iOperacao, 2);
        }

        private void pendenteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewMaquinas.SelectedItems.Count != 1)
                return;

            if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            m_oCurrMaquina = (Maquina)listViewMaquinas.GetTag();
            ActualizarOperacaoEfectuadoMaquina(m_oCurrMaquina.m_iMAQ_OPERACAO, 0);
        }

        private void efectuadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewMaquinas.SelectedItems.Count != 1)
                return;

            if (MessageBox.Show("Tem a certeza?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            m_oCurrMaquina = (Maquina)listViewMaquinas.GetTag();
            ActualizarOperacaoEfectuadoMaquina(m_oCurrMaquina.m_iMAQ_OPERACAO, 2);
        }
        //SDCIM 7 
        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            this.RefreshBalcoes();
        }
        private void txtBalcao_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txtBalcao.Text, "[^0-9]"))
            {
                MessageBox.Show("Campo numérico");
                txtBalcao.Text.Remove(txtBalcao.Text.Length - 1);
                txtBalcao.Text = "";
            }
        }

        private void txtBalcao_Leave(object sender, EventArgs e)
        {
            if (this.txtBalcao.Text.Trim() != String.Empty)
                this.txtBalcao.Text = this.txtBalcao.Text.PadLeft(4, '0');
        }

        private void btnLimparBalcao_Click(object sender, EventArgs e)
        {
            this.comboBoxPaisBanco.SelectedIndex = 0;
            this.textBoxAbrv.Text = String.Empty;
            this.textBoxBalcao.Text = String.Empty;
            this.textBoxDescricao.Text = String.Empty;
            this.comboBoxDevolvidos.SelectedIndex = 1;
            this.comboBoxFisicos.SelectedIndex = 0;
            this.textBoxMaqIQA.Text = String.Empty;
            this.textBoxMaqModelo.Text = String.Empty;
            this.textBoxMaqSeqBalcao.Text = String.Empty;
            this.listViewMaquinas.MyClear();
            this.txtBalcao.Text = String.Empty;
            this.RefreshBalcoes();
            m_oCurrBalcao = new Balcao();
            m_oCurrMaquina = new Maquina();
        }

        private void btnLimparMaquina_Click(object sender, EventArgs e)
        {
            this.textBoxMaqIQA.Text = String.Empty;
            this.textBoxMaqModelo.Text = String.Empty;
            this.textBoxMaqSeqBalcao.Text = String.Empty;
            m_oCurrMaquina = new Maquina();
        }
        //SDCIM 7
    }
}