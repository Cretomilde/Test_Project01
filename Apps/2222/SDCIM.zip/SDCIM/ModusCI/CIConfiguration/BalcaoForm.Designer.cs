﻿using NBIISNET;

namespace CIConfiguration
{
    partial class BalcaoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);

            m_oMenuInterface.balcoesEnable(true);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BalcaoForm));
            this.listViewBalcoes = new NBIISNET.ListViewBase();
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStripBalcao = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripInserir = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripActualizar = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.pendenteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.efectuadoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.btInsertBalcao = new System.Windows.Forms.Button();
            this.btUpdateBalcao = new System.Windows.Forms.Button();
            this.btRefresh = new System.Windows.Forms.Button();
            this.listViewMaquinas = new NBIISNET.ListViewBase();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader22 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuMaquina = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripInserirMaquina = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripActualizarMaquina = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.pendenteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.efectuadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxBalcao = new System.Windows.Forms.TextBox();
            this.comboBoxPaisBanco = new System.Windows.Forms.ComboBox();
            this.textBoxAbrv = new System.Windows.Forms.TextBox();
            this.textBoxDescricao = new System.Windows.Forms.TextBox();
            this.textBoxMaqSeqBalcao = new System.Windows.Forms.TextBox();
            this.textBoxMaqModelo = new System.Windows.Forms.TextBox();
            this.textBoxMaqIQA = new System.Windows.Forms.TextBox();
            this.comboBoxFisicos = new System.Windows.Forms.ComboBox();
            this.comboBoxDevolvidos = new System.Windows.Forms.ComboBox();
            this.btInsertMaq = new System.Windows.Forms.Button();
            this.btUpdateMaq = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonExitJanela = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnLimparMaquina = new System.Windows.Forms.Button();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.txtBalcao = new System.Windows.Forms.TextBox();
            this.lblBalcão = new System.Windows.Forms.Label();
            this.btnLimparBalcao = new System.Windows.Forms.Button();
            this.contextMenuStripBalcao.SuspendLayout();
            this.contextMenuMaquina.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listViewBalcoes
            // 
            this.listViewBalcoes.AllowColumnReorder = true;
            this.listViewBalcoes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewBalcoes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader15,
            this.columnHeader21,
            this.columnHeader18,
            this.columnHeader20,
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader13});
            this.listViewBalcoes.ContextMenuStrip = this.contextMenuStripBalcao;
            this.listViewBalcoes.EnableExportar = true;
            this.listViewBalcoes.FullRowSelect = true;
            this.listViewBalcoes.GridLines = true;
            this.listViewBalcoes.HideSelection = false;
            this.listViewBalcoes.Location = new System.Drawing.Point(3, 16);
            this.listViewBalcoes.MultiSelect = false;
            this.listViewBalcoes.Name = "listViewBalcoes";
            this.listViewBalcoes.Size = new System.Drawing.Size(1019, 153);
            this.listViewBalcoes.TabIndex = 9;
            this.listViewBalcoes.TabStop = false;
            this.listViewBalcoes.UseCompatibleStateImageBehavior = false;
            this.listViewBalcoes.View = System.Windows.Forms.View.Details;
            this.listViewBalcoes.SelectedIndexChanged += new System.EventHandler(this.listViewBalcoes_SelectedIndexChanged);
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "País";
            this.columnHeader15.Width = 42;
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "Banco";
            this.columnHeader21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader21.Width = 52;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Balcão";
            this.columnHeader18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader18.Width = 51;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "Abrev";
            this.columnHeader20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader20.Width = 93;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Descrição";
            this.columnHeader1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader1.Width = 155;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Fisicos";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 69;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Devolvidos";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 70;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Operação";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 85;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Efectuado";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 66;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Timer";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader6.Width = 160;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Erro";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader7.Width = 120;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "ChaveWS";
            // 
            // contextMenuStripBalcao
            // 
            this.contextMenuStripBalcao.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripInserir,
            this.toolStripActualizar,
            this.toolStripMenuItem1,
            this.pendenteToolStripMenuItem1,
            this.efectuadoToolStripMenuItem1});
            this.contextMenuStripBalcao.Name = "contextMenuStripBalcao";
            this.contextMenuStripBalcao.Size = new System.Drawing.Size(128, 98);
            // 
            // toolStripInserir
            // 
            this.toolStripInserir.Name = "toolStripInserir";
            this.toolStripInserir.Size = new System.Drawing.Size(127, 22);
            this.toolStripInserir.Text = "Inserir";
            this.toolStripInserir.Click += new System.EventHandler(this.toolStripInserir_Click);
            // 
            // toolStripActualizar
            // 
            this.toolStripActualizar.Name = "toolStripActualizar";
            this.toolStripActualizar.Size = new System.Drawing.Size(127, 22);
            this.toolStripActualizar.Text = "Actualizar";
            this.toolStripActualizar.Click += new System.EventHandler(this.toolStripActualizar_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(124, 6);
            // 
            // pendenteToolStripMenuItem1
            // 
            this.pendenteToolStripMenuItem1.Name = "pendenteToolStripMenuItem1";
            this.pendenteToolStripMenuItem1.Size = new System.Drawing.Size(127, 22);
            this.pendenteToolStripMenuItem1.Text = "Pendente";
            this.pendenteToolStripMenuItem1.Click += new System.EventHandler(this.pendenteToolStripMenuItem1_Click);
            // 
            // efectuadoToolStripMenuItem1
            // 
            this.efectuadoToolStripMenuItem1.Name = "efectuadoToolStripMenuItem1";
            this.efectuadoToolStripMenuItem1.Size = new System.Drawing.Size(127, 22);
            this.efectuadoToolStripMenuItem1.Text = "Efectuado";
            this.efectuadoToolStripMenuItem1.Click += new System.EventHandler(this.efectuadoToolStripMenuItem1_Click);
            // 
            // btInsertBalcao
            // 
            this.btInsertBalcao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btInsertBalcao.Location = new System.Drawing.Point(745, 186);
            this.btInsertBalcao.Name = "btInsertBalcao";
            this.btInsertBalcao.Size = new System.Drawing.Size(75, 23);
            this.btInsertBalcao.TabIndex = 7;
            this.btInsertBalcao.Text = "Inserir";
            this.btInsertBalcao.UseVisualStyleBackColor = true;
            this.btInsertBalcao.Click += new System.EventHandler(this.btInsert_Click);
            // 
            // btUpdateBalcao
            // 
            this.btUpdateBalcao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btUpdateBalcao.Location = new System.Drawing.Point(826, 186);
            this.btUpdateBalcao.Name = "btUpdateBalcao";
            this.btUpdateBalcao.Size = new System.Drawing.Size(75, 23);
            this.btUpdateBalcao.TabIndex = 8;
            this.btUpdateBalcao.Text = "Actualizar";
            this.btUpdateBalcao.UseVisualStyleBackColor = true;
            this.btUpdateBalcao.Click += new System.EventHandler(this.btUpdate_Click);
            // 
            // btRefresh
            // 
            this.btRefresh.Image = ((System.Drawing.Image)(resources.GetObject("btRefresh.Image")));
            this.btRefresh.Location = new System.Drawing.Point(13, 12);
            this.btRefresh.Name = "btRefresh";
            this.btRefresh.Size = new System.Drawing.Size(49, 45);
            this.btRefresh.TabIndex = 14;
            this.toolTip1.SetToolTip(this.btRefresh, "Refresh");
            this.btRefresh.UseVisualStyleBackColor = true;
            this.btRefresh.Click += new System.EventHandler(this.btRefresh_Click);
            // 
            // listViewMaquinas
            // 
            this.listViewMaquinas.AllowColumnReorder = true;
            this.listViewMaquinas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewMaquinas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader19,
            this.columnHeader22,
            this.columnHeader14});
            this.listViewMaquinas.ContextMenuStrip = this.contextMenuMaquina;
            this.listViewMaquinas.EnableExportar = true;
            this.listViewMaquinas.FullRowSelect = true;
            this.listViewMaquinas.GridLines = true;
            this.listViewMaquinas.HideSelection = false;
            this.listViewMaquinas.Location = new System.Drawing.Point(3, 17);
            this.listViewMaquinas.MultiSelect = false;
            this.listViewMaquinas.Name = "listViewMaquinas";
            this.listViewMaquinas.Size = new System.Drawing.Size(1019, 193);
            this.listViewMaquinas.TabIndex = 14;
            this.listViewMaquinas.TabStop = false;
            this.listViewMaquinas.UseCompatibleStateImageBehavior = false;
            this.listViewMaquinas.View = System.Windows.Forms.View.Details;
            this.listViewMaquinas.SelectedIndexChanged += new System.EventHandler(this.listViewMaquinas_SelectedIndexChanged);
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "MaqID";
            this.columnHeader8.Width = 52;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "País/Banco/Balcão";
            this.columnHeader9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader9.Width = 115;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "SeqBalcão";
            this.columnHeader10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader10.Width = 70;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Modelo";
            this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader11.Width = 61;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "IQA";
            this.columnHeader12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader12.Width = 42;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Operação";
            this.columnHeader16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader16.Width = 66;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Efectuado";
            this.columnHeader17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader17.Width = 66;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "Timer";
            this.columnHeader19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader19.Width = 105;
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "Erro";
            this.columnHeader22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader22.Width = 312;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "ChaveWS";
            // 
            // contextMenuMaquina
            // 
            this.contextMenuMaquina.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripInserirMaquina,
            this.toolStripActualizarMaquina,
            this.toolStripMenuItem2,
            this.pendenteToolStripMenuItem,
            this.efectuadoToolStripMenuItem});
            this.contextMenuMaquina.Name = "contextMenuStripBalcao";
            this.contextMenuMaquina.Size = new System.Drawing.Size(128, 98);
            // 
            // toolStripInserirMaquina
            // 
            this.toolStripInserirMaquina.Name = "toolStripInserirMaquina";
            this.toolStripInserirMaquina.Size = new System.Drawing.Size(127, 22);
            this.toolStripInserirMaquina.Text = "Inserir";
            this.toolStripInserirMaquina.Click += new System.EventHandler(this.toolStripInserirMaquina_Click);
            // 
            // toolStripActualizarMaquina
            // 
            this.toolStripActualizarMaquina.Name = "toolStripActualizarMaquina";
            this.toolStripActualizarMaquina.Size = new System.Drawing.Size(127, 22);
            this.toolStripActualizarMaquina.Text = "Actualizar";
            this.toolStripActualizarMaquina.Click += new System.EventHandler(this.toolStripActualizarMaquina_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(124, 6);
            // 
            // pendenteToolStripMenuItem
            // 
            this.pendenteToolStripMenuItem.Name = "pendenteToolStripMenuItem";
            this.pendenteToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.pendenteToolStripMenuItem.Text = "Pendente";
            this.pendenteToolStripMenuItem.Click += new System.EventHandler(this.pendenteToolStripMenuItem_Click);
            // 
            // efectuadoToolStripMenuItem
            // 
            this.efectuadoToolStripMenuItem.Name = "efectuadoToolStripMenuItem";
            this.efectuadoToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.efectuadoToolStripMenuItem.Text = "Efectuado";
            this.efectuadoToolStripMenuItem.Click += new System.EventHandler(this.efectuadoToolStripMenuItem_Click);
            // 
            // textBoxBalcao
            // 
            this.textBoxBalcao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxBalcao.Location = new System.Drawing.Point(103, 188);
            this.textBoxBalcao.MaxLength = 4;
            this.textBoxBalcao.Name = "textBoxBalcao";
            this.textBoxBalcao.Size = new System.Drawing.Size(45, 20);
            this.textBoxBalcao.TabIndex = 2;
            this.toolTip1.SetToolTip(this.textBoxBalcao, "Balcão");
            // 
            // comboBoxPaisBanco
            // 
            this.comboBoxPaisBanco.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBoxPaisBanco.Enabled = false;
            this.comboBoxPaisBanco.FormattingEnabled = true;
            this.comboBoxPaisBanco.Location = new System.Drawing.Point(9, 187);
            this.comboBoxPaisBanco.Name = "comboBoxPaisBanco";
            this.comboBoxPaisBanco.Size = new System.Drawing.Size(88, 21);
            this.comboBoxPaisBanco.TabIndex = 1;
            this.toolTip1.SetToolTip(this.comboBoxPaisBanco, "Pais - Banco");
            // 
            // textBoxAbrv
            // 
            this.textBoxAbrv.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxAbrv.Location = new System.Drawing.Point(154, 188);
            this.textBoxAbrv.MaxLength = 50;
            this.textBoxAbrv.Name = "textBoxAbrv";
            this.textBoxAbrv.Size = new System.Drawing.Size(147, 20);
            this.textBoxAbrv.TabIndex = 3;
            this.toolTip1.SetToolTip(this.textBoxAbrv, "Balcão abreviatura");
            // 
            // textBoxDescricao
            // 
            this.textBoxDescricao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxDescricao.Location = new System.Drawing.Point(307, 188);
            this.textBoxDescricao.MaxLength = 128;
            this.textBoxDescricao.Name = "textBoxDescricao";
            this.textBoxDescricao.Size = new System.Drawing.Size(302, 20);
            this.textBoxDescricao.TabIndex = 4;
            this.toolTip1.SetToolTip(this.textBoxDescricao, "Descrição balcão");
            // 
            // textBoxMaqSeqBalcao
            // 
            this.textBoxMaqSeqBalcao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxMaqSeqBalcao.Location = new System.Drawing.Point(9, 229);
            this.textBoxMaqSeqBalcao.Name = "textBoxMaqSeqBalcao";
            this.textBoxMaqSeqBalcao.Size = new System.Drawing.Size(68, 20);
            this.textBoxMaqSeqBalcao.TabIndex = 9;
            this.toolTip1.SetToolTip(this.textBoxMaqSeqBalcao, "Sequencia Balcão");
            this.textBoxMaqSeqBalcao.ReadOnlyChanged += new System.EventHandler(this.listViewBalcoes_SelectedIndexChanged);
            // 
            // textBoxMaqModelo
            // 
            this.textBoxMaqModelo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxMaqModelo.Location = new System.Drawing.Point(83, 229);
            this.textBoxMaqModelo.Name = "textBoxMaqModelo";
            this.textBoxMaqModelo.Size = new System.Drawing.Size(56, 20);
            this.textBoxMaqModelo.TabIndex = 10;
            this.toolTip1.SetToolTip(this.textBoxMaqModelo, "Modelo");
            // 
            // textBoxMaqIQA
            // 
            this.textBoxMaqIQA.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBoxMaqIQA.Location = new System.Drawing.Point(145, 229);
            this.textBoxMaqIQA.Name = "textBoxMaqIQA";
            this.textBoxMaqIQA.Size = new System.Drawing.Size(39, 20);
            this.textBoxMaqIQA.TabIndex = 11;
            this.toolTip1.SetToolTip(this.textBoxMaqIQA, "IQA");
            // 
            // comboBoxFisicos
            // 
            this.comboBoxFisicos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBoxFisicos.Enabled = false;
            this.comboBoxFisicos.FormattingEnabled = true;
            this.comboBoxFisicos.Items.AddRange(new object[] {
            "TRUE",
            "FALSE"});
            this.comboBoxFisicos.Location = new System.Drawing.Point(615, 187);
            this.comboBoxFisicos.Name = "comboBoxFisicos";
            this.comboBoxFisicos.Size = new System.Drawing.Size(61, 21);
            this.comboBoxFisicos.TabIndex = 5;
            this.comboBoxFisicos.Text = "TRUE";
            this.toolTip1.SetToolTip(this.comboBoxFisicos, "Fisicos");
            // 
            // comboBoxDevolvidos
            // 
            this.comboBoxDevolvidos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBoxDevolvidos.Enabled = false;
            this.comboBoxDevolvidos.FormattingEnabled = true;
            this.comboBoxDevolvidos.Items.AddRange(new object[] {
            "TRUE",
            "FALSE"});
            this.comboBoxDevolvidos.Location = new System.Drawing.Point(682, 187);
            this.comboBoxDevolvidos.Name = "comboBoxDevolvidos";
            this.comboBoxDevolvidos.Size = new System.Drawing.Size(57, 21);
            this.comboBoxDevolvidos.TabIndex = 6;
            this.comboBoxDevolvidos.Text = "FALSE";
            this.toolTip1.SetToolTip(this.comboBoxDevolvidos, "Devolvidos");
            // 
            // btInsertMaq
            // 
            this.btInsertMaq.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btInsertMaq.Location = new System.Drawing.Point(190, 227);
            this.btInsertMaq.Name = "btInsertMaq";
            this.btInsertMaq.Size = new System.Drawing.Size(75, 23);
            this.btInsertMaq.TabIndex = 12;
            this.btInsertMaq.Text = "Inserir";
            this.btInsertMaq.UseVisualStyleBackColor = true;
            this.btInsertMaq.Click += new System.EventHandler(this.btInsertMaq_Click);
            // 
            // btUpdateMaq
            // 
            this.btUpdateMaq.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btUpdateMaq.Location = new System.Drawing.Point(271, 227);
            this.btUpdateMaq.Name = "btUpdateMaq";
            this.btUpdateMaq.Size = new System.Drawing.Size(75, 23);
            this.btUpdateMaq.TabIndex = 13;
            this.btUpdateMaq.Text = "Actualizar";
            this.btUpdateMaq.UseVisualStyleBackColor = true;
            this.btUpdateMaq.Click += new System.EventHandler(this.btUpdateMaq_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 41;
            this.label1.Text = "Balcões";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 42;
            this.label2.Text = "Máquinas";
            // 
            // buttonExitJanela
            // 
            this.buttonExitJanela.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonExitJanela.Image = ((System.Drawing.Image)(resources.GetObject("buttonExitJanela.Image")));
            this.buttonExitJanela.Location = new System.Drawing.Point(968, 12);
            this.buttonExitJanela.Name = "buttonExitJanela";
            this.buttonExitJanela.Size = new System.Drawing.Size(52, 45);
            this.buttonExitJanela.TabIndex = 15;
            this.buttonExitJanela.UseVisualStyleBackColor = true;
            this.buttonExitJanela.Click += new System.EventHandler(this.buttonExitJanela_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(4, 63);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label8);
            this.splitContainer1.Panel1.Controls.Add(this.label7);
            this.splitContainer1.Panel1.Controls.Add(this.label6);
            this.splitContainer1.Panel1.Controls.Add(this.label5);
            this.splitContainer1.Panel1.Controls.Add(this.label4);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.listViewBalcoes);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.textBoxDescricao);
            this.splitContainer1.Panel1.Controls.Add(this.btInsertBalcao);
            this.splitContainer1.Panel1.Controls.Add(this.btUpdateBalcao);
            this.splitContainer1.Panel1.Controls.Add(this.textBoxBalcao);
            this.splitContainer1.Panel1.Controls.Add(this.comboBoxPaisBanco);
            this.splitContainer1.Panel1.Controls.Add(this.comboBoxDevolvidos);
            this.splitContainer1.Panel1.Controls.Add(this.textBoxAbrv);
            this.splitContainer1.Panel1.Controls.Add(this.comboBoxFisicos);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.label11);
            this.splitContainer1.Panel2.Controls.Add(this.label10);
            this.splitContainer1.Panel2.Controls.Add(this.label9);
            this.splitContainer1.Panel2.Controls.Add(this.btnLimparMaquina);
            this.splitContainer1.Panel2.Controls.Add(this.listViewMaquinas);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.btUpdateMaq);
            this.splitContainer1.Panel2.Controls.Add(this.textBoxMaqSeqBalcao);
            this.splitContainer1.Panel2.Controls.Add(this.textBoxMaqModelo);
            this.splitContainer1.Panel2.Controls.Add(this.btInsertMaq);
            this.splitContainer1.Panel2.Controls.Add(this.textBoxMaqIQA);
            this.splitContainer1.Size = new System.Drawing.Size(1025, 471);
            this.splitContainer1.SplitterDistance = 215;
            this.splitContainer1.TabIndex = 43;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(679, 172);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 13);
            this.label8.TabIndex = 47;
            this.label8.Text = "Devolvidos";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(612, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 13);
            this.label7.TabIndex = 46;
            this.label7.Text = "Físicos";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(304, 172);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 45;
            this.label6.Text = "Descrição";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(154, 172);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 44;
            this.label5.Text = "Abrev.";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(103, 172);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 43;
            this.label4.Text = "Balcão";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 42;
            this.label3.Text = "País - Banco";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(142, 213);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(25, 13);
            this.label11.TabIndex = 52;
            this.label11.Text = "IQA";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(80, 213);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 13);
            this.label10.TabIndex = 51;
            this.label10.Text = "Modelo";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 213);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 13);
            this.label9.TabIndex = 50;
            this.label9.Text = "Seq. Balcão";
            // 
            // btnLimparMaquina
            // 
            this.btnLimparMaquina.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLimparMaquina.Location = new System.Drawing.Point(352, 227);
            this.btnLimparMaquina.Name = "btnLimparMaquina";
            this.btnLimparMaquina.Size = new System.Drawing.Size(75, 23);
            this.btnLimparMaquina.TabIndex = 49;
            this.btnLimparMaquina.Text = "Limpar";
            this.btnLimparMaquina.UseVisualStyleBackColor = true;
            this.btnLimparMaquina.Click += new System.EventHandler(this.btnLimparMaquina_Click);
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Location = new System.Drawing.Point(158, 27);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(75, 22);
            this.btnPesquisar.TabIndex = 44;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
            // 
            // txtBalcao
            // 
            this.txtBalcao.Location = new System.Drawing.Point(114, 27);
            this.txtBalcao.MaxLength = 4;
            this.txtBalcao.Name = "txtBalcao";
            this.txtBalcao.Size = new System.Drawing.Size(38, 20);
            this.txtBalcao.TabIndex = 45;
            this.txtBalcao.TextChanged += new System.EventHandler(this.txtBalcao_TextChanged);
            this.txtBalcao.Leave += new System.EventHandler(this.txtBalcao_Leave);
            // 
            // lblBalcão
            // 
            this.lblBalcão.AutoSize = true;
            this.lblBalcão.Location = new System.Drawing.Point(68, 32);
            this.lblBalcão.Name = "lblBalcão";
            this.lblBalcão.Size = new System.Drawing.Size(40, 13);
            this.lblBalcão.TabIndex = 46;
            this.lblBalcão.Text = "Balcão";
            // 
            // btnLimparBalcao
            // 
            this.btnLimparBalcao.Location = new System.Drawing.Point(239, 27);
            this.btnLimparBalcao.Name = "btnLimparBalcao";
            this.btnLimparBalcao.Size = new System.Drawing.Size(75, 22);
            this.btnLimparBalcao.TabIndex = 48;
            this.btnLimparBalcao.Text = "Limpar";
            this.btnLimparBalcao.UseVisualStyleBackColor = true;
            this.btnLimparBalcao.Click += new System.EventHandler(this.btnLimparBalcao_Click);
            // 
            // BalcaoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1032, 539);
            this.Controls.Add(this.btnLimparBalcao);
            this.Controls.Add(this.lblBalcão);
            this.Controls.Add(this.txtBalcao);
            this.Controls.Add(this.btnPesquisar);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.buttonExitJanela);
            this.Controls.Add(this.btRefresh);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BalcaoForm";
            this.ShowInTaskbar = false;
            this.Text = "Configuração de Balcões/ Máquinas";
            this.Load += new System.EventHandler(this.BalcaoForm_Load);
            this.contextMenuStripBalcao.ResumeLayout(false);
            this.contextMenuMaquina.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        
        //public System.Windows.Forms.ListView listViewBalcoes;
        public NBIISNET.ListViewBase listViewBalcoes;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.Button btInsertBalcao;
        private System.Windows.Forms.Button btUpdateBalcao;
        private System.Windows.Forms.Button btRefresh;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        //private System.Windows.Forms.ListView listViewMaquinas;
        NBIISNET.ListViewBase listViewMaquinas;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.TextBox textBoxBalcao;
        private System.Windows.Forms.ComboBox comboBoxPaisBanco;
        private System.Windows.Forms.TextBox textBoxAbrv;
        private System.Windows.Forms.TextBox textBoxDescricao;
        private System.Windows.Forms.TextBox textBoxMaqSeqBalcao;
        private System.Windows.Forms.TextBox textBoxMaqModelo;
        private System.Windows.Forms.TextBox textBoxMaqIQA;
        private System.Windows.Forms.ComboBox comboBoxFisicos;
        private System.Windows.Forms.ComboBox comboBoxDevolvidos;
        private System.Windows.Forms.Button btInsertMaq;
        private System.Windows.Forms.Button btUpdateMaq;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonExitJanela;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripBalcao;
        private System.Windows.Forms.ToolStripMenuItem toolStripInserir;
        private System.Windows.Forms.ToolStripMenuItem toolStripActualizar;
        private System.Windows.Forms.ContextMenuStrip contextMenuMaquina;
        private System.Windows.Forms.ToolStripMenuItem toolStripInserirMaquina;
        private System.Windows.Forms.ToolStripMenuItem toolStripActualizarMaquina;
        private System.Windows.Forms.ToolStripMenuItem pendenteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem efectuadoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem pendenteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem efectuadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnPesquisar;
        private System.Windows.Forms.TextBox txtBalcao;
        private System.Windows.Forms.Label lblBalcão;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnLimparBalcao;
        private System.Windows.Forms.Button btnLimparMaquina;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
    }
}