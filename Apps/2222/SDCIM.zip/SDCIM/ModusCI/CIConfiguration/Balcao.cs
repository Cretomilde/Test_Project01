﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace CIConfiguration
{
    public class Balcao
    {
        public string m_sPais;        // Default "PT"
        public int m_iBanco;          // Default 35
        public int m_iCodigo;
        public string m_sAbrev;
        public string m_sDescricao;
        public bool m_bEnviaFisicos;
        public bool m_bOperaDevolvidos;
        public int m_iOperacao;      // 0/1/2/3 - Nada a fazer/Insere/Apaga/Actualiza
        public string m_sOperacao;
        public int m_iEfectuado;      // 0/1 - Não Efectuado/Efectuado
        public DateTime m_dtTimer;
        public string m_sErro;
        public string m_sChaveWS;

        public Balcao()
        {
            m_sPais = "PT";
            m_iBanco = 35;
            m_iCodigo = -1;
            m_sAbrev = "";
            m_sDescricao = "";
            m_bEnviaFisicos = true;
            m_bOperaDevolvidos = false;
            m_iOperacao = 0;
            m_iEfectuado = 0;
            m_dtTimer = DateTime.Now;
            m_sErro = "";
            m_sOperacao = "";
            m_sChaveWS = "";
        }

        public Balcao(SqlDataReader dr)
        {
            m_sPais             = Convert.ToString(dr["BALCAO_PAIS"]);
            m_iBanco            = Convert.ToInt16(dr["BALCAO_BANCO"]);
            m_iCodigo           = Convert.ToInt16(dr["BALCAO_CODIGO"]);
            m_sAbrev            = Convert.ToString(dr["BALCAO_ABR"]);
            m_sDescricao        = Convert.ToString(dr["BALCAO_DESC"]);
            m_bEnviaFisicos     = Convert.ToBoolean(dr["BALCAO_ENVFISICOS"]);
            m_bOperaDevolvidos  = Convert.ToBoolean(dr["BALCAO_OPERDEVOLV"]);
            m_iOperacao         = Convert.ToInt16(dr["BALCAO_OPERACAO"]);
            m_sOperacao         = Convert.ToString(dr["OPERACAO_ABR"]);
            m_iEfectuado        = Convert.ToInt16(dr["BALCAO_EFECTUADO"]);
            m_dtTimer           = Convert.ToDateTime(dr["BALCAO_TIMER"]);
            m_sErro = Convert.ToString(dr["BALCAO_ERRO"]);
            m_sChaveWS = Convert.ToString(dr["CHAVE_WEBSERVICE"]);
        }

        //public Balcao(string sPais,
        //                int iBanco,
        //                int iCodigo,
        //                string sAbrev,
        //                string sDescricao,
        //                bool bEnviaFisicos,
        //                bool bOperaDevolvidos,
        //                int iOperacao,
        //                string sOperacao,
        //                int iEfectuado,
        //                DateTime dtTimer,
        //                string sErro)
        //{
        //    m_sPais = sPais;
        //    m_iBanco = iBanco;
        //    m_iCodigo = iCodigo;
        //    m_sAbrev = sAbrev;
        //    m_sDescricao = sDescricao;
        //    m_bEnviaFisicos = bEnviaFisicos;
        //    m_bOperaDevolvidos = bOperaDevolvidos;
        //    m_iOperacao = iOperacao;
        //    m_sOperacao = sOperacao;
        //    m_iEfectuado = iEfectuado;
        //    m_dtTimer = dtTimer;
        //    m_sErro = sErro;
        //}

        public ListViewItem MakeListViewItemBalcao(string sDateTimeSysFmt)
        {
            ListViewItem olvItem = new ListViewItem();
            olvItem.Text = m_sPais;
            olvItem.SubItems.Add(m_iBanco.ToString());
            olvItem.SubItems.Add(m_iCodigo.ToString("0000"));
            olvItem.SubItems.Add(m_sAbrev);
            olvItem.SubItems.Add(m_sDescricao);
            olvItem.SubItems.Add(m_bEnviaFisicos.ToString());
            olvItem.SubItems.Add(m_bOperaDevolvidos.ToString());
            olvItem.SubItems.Add(m_sOperacao);
            olvItem.SubItems.Add(m_iEfectuado.ToString());
            olvItem.SubItems.Add(m_dtTimer.ToString(sDateTimeSysFmt));
            olvItem.SubItems.Add(m_sErro);
            olvItem.SubItems.Add(m_sChaveWS);

            return olvItem;
        }
    }
}
