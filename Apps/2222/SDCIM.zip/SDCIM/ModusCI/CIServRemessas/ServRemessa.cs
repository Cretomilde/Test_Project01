﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;
using CIActividades;

namespace CIServRemessas
{
    public partial class ServRemessa
    {
        protected CIComumInterface m_iInterface;

        string m_sLastDOC_ID;
        int m_iNSeqDoc;

        long m_lTranoutID;
        long m_lTranoutBalcaoID; // SDCIM 7
        bool m_bMaquinaCriada, m_bDocsEmErro;
        bool m_bMaquinaCriadaBalcao, m_bDocsEmErroBalcao; // SDCIM 7
        string m_sLastError;
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        ArrayList m_oParam;

        public ServRemessa(CIComumInterface iInterface, CIConfigGP.CIGlobalParameters oParameters)
        {
            m_oParam = new ArrayList();
            m_oParameters = oParameters;
            m_iInterface = iInterface;

        }

        public string REMIN_IDParaProcessar()
        {
            try
            {
                string sQuery = "dbo.Select_Remessa2Process";

                Object obj = m_oParameters.DirectSqlScalar(sQuery);

                if (obj == null)
                {
                    return "";
                }
                if (obj.ToString().Length > 0)
                {
                    m_iInterface.InfoMessage("Tem a remessa " + obj.ToString() + " para processar", "");
                }
                return obj.ToString();
            }
            catch (Exception ex)
            {
                m_iInterface.ErrorMessage("REMIN_IDParaProcessar: " + ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "ServRemessa()", 500);
                return "";
            }
        }

        public void ProcessaRemessa(string sREMIN_ID)
        {
            DataSet ds = null;
            m_sLastDOC_ID = "";

            string sSPName;

            try
            {
                string sQuery;
                int iTeste;

                m_bMaquinaCriada = false;
                m_iNSeqDoc = 0;

                //Em processamento (30)
                try
                {
                    validaRemessa(sREMIN_ID);
                }
                catch (Exception ex)
                {
                    sQuery = "dbo.Update_ReminErro";
                    m_oParam.Clear();
                    m_oParam.Add(new GeneralDBParameters("@ReminID", sREMIN_ID));
                    m_oParam.Add(new GeneralDBParameters("@Estado", -40));
                    m_oParam.Add(new GeneralDBParameters("@Erro", ex.Message));
                    m_oParameters.DirectStoredProcedureNonQuery(sQuery, ref m_oParam);
                    m_iInterface.ErrorMessage("RemId:" + sREMIN_ID + " " + ex.Message);
                    GenericLog.GenLogRegistarErro(ref ex, "ServRemessa()", 500);

                    return;
                }
                // SqlTransaction oTrans = (SqlTransaction)m_oParameters.BeginTrans(IsolationLevel.ReadCommitted);
                sQuery = "UPDATE REMESSA_IN SET REMINSTAT_ID = 30 WHERE REMINSTAT_ID = 20 and REMIN_ID=" + sREMIN_ID;
                iTeste = m_oParameters.DirectSqlNonQuery(sQuery);
                if (iTeste != 1)
                {
                    m_iInterface.WarningMessage("Rows Updated != 1: " + iTeste.ToString() + " " + sQuery);
                    return;
                }

                //Processar
                sSPName = "dbo.Update_ProcessaRemessaProc";
                m_oParam.Clear();
                m_oParam.Add(new GeneralDBParameters("@RemID", sREMIN_ID));

                //Vai fazer a stored procedure para preencher a tabela "dbo.Update_ProcessaRemessaProc"
                m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);

                sQuery = "select * from VW_DETALHE_DOCUMENTOS where REMIN_ID=" + sREMIN_ID + " order by DOC_INDEX";

                m_lTranoutID = 0;
                int iCount = 0;
                int iTrancheNumero = 0;
                m_bDocsEmErro = false;
                m_sLastError = "";
                ds = m_oParameters.DirectSqlDataSet(sQuery, "DOC");
                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    if (iCount++ % m_oParameters.m_iMaxDocsTranche == 0)
                    {
                        if (m_lTranoutID != 0)
                        {
                            sQuery = "update TRANCHE_OUT set TRANOUTSTAT_ID=20 where TRANOUT_ID = " + m_lTranoutID.ToString();
                            m_oParameters.DirectSqlNonQuery(sQuery);
                        }

                        CriarTranche(sREMIN_ID, ++iTrancheNumero);
                    }
                    ProcessaDocumento(oRow);
                }
                //update da ultima tranche para ultima
                sQuery = " update TRANCHE_OUT set TRANOUT_ULTIMA =1, TRANOUTSTAT_ID=20, TRANOUT_INCOMPLETA =0 where TRANOUT_ID = " + m_lTranoutID.ToString();
                m_oParameters.DirectSqlNonQuery(sQuery);

                int iNewEstado = m_bMaquinaCriada ? 20 : 40;

                if (iNewEstado == 40 && m_bDocsEmErro)
                    iNewEstado = -40;

                //Processado (40)
                sSPName = "dbo.Update_EstadoRemessa";
                m_oParam.Clear();
                m_oParam.Add(new GeneralDBParameters("@RemID", sREMIN_ID));
                m_oParam.Add(new GeneralDBParameters("@OldEstado", 30));
                m_oParam.Add(new GeneralDBParameters("@NewEstado", iNewEstado));
                m_oParam.Add(new GeneralDBParameters("@Msg", m_sLastError));

                try
                {
                    m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);
                    m_iInterface.InfoMessage("Processou a remessa " + sREMIN_ID, "");
                }
                catch (Exception ex)
                {
                    try
                    {
                        m_iInterface.ErrorMessage("RemId:" + sREMIN_ID + " " + ex.Message);
                        GenericLog.GenLogRegistarErro(ref ex, "ServRemessa()", 500);

                        m_oParam.Clear();
                        m_oParam.Add(new GeneralDBParameters("@RemID", sREMIN_ID));
                        m_oParam.Add(new GeneralDBParameters("@Msg", ex.Message));
                        m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);

                    }
                    catch
                    {
                    }
                }

                // m_oParameters.Commit();

            }
            catch (Exception ex)
            {
                //   m_oParameters.RollBack();

                m_iInterface.ErrorMessage("RemId:" + sREMIN_ID + " " + ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "ServRemessa()", 500);

                updateRemssaErro(sREMIN_ID, ex.Message);

            }
            finally
            {
                if (ds != null)
                {
                    ds.Dispose();
                    ds = null;
                }
            }
        }

        private void updateRemssaErro(string sREMIN_ID, string sErro)
        {
            string sSPName = "dbo.Update_EstadoRemessa";

            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@RemID", sREMIN_ID));
            m_oParam.Add(new GeneralDBParameters("@NewEstado", -40));
            m_oParam.Add(new GeneralDBParameters("@Msg", sErro));

            try
            {
                m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);
                if (m_sLastDOC_ID != "")
                {
                    sSPName = "dbo.Update_EstadoDocumento";

                    m_oParam.Clear();
                    m_oParam.Add(new GeneralDBParameters("@DocID", m_sLastDOC_ID));
                    m_oParam.Add(new GeneralDBParameters("@Estado", -20));

                    m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);
                }
            }
            catch
            {
            }
        }

        private void validaRemessa(string sReminID)
        {
            string sQuery = "select REMIN_DATA from REMESSA_IN where remin_id = " + sReminID;
            object data = m_oParameters.DirectSqlScalar(sQuery);

            if (data == null)
            {
                updateERRO(sReminID, "Remessa não existente");
            }
            DateTime dtREMIN_DATA = Convert.ToDateTime(data);

            if (dtREMIN_DATA < DateTime.Now.AddDays(m_oParameters.m_iMinDias * (-1)) ||
                dtREMIN_DATA > DateTime.Now.AddDays(m_oParameters.m_iMaxDias))
            {
                updateERRO(sReminID, "Data Remessa " + dtREMIN_DATA.ToShortDateString() + " inválida");
            }
        }
        private void validaDocumento(CIActividades.DetalhesDocumento oDd)
        {

            if (oDd.m_sDOC_INDEX == "")
            {
                updateERRO(oDd.m_sDOC_ID, "Index Documento inválido");
            }
            if (oDd.m_sDOC_DOCNIB == null)
            {
                updateERRO(oDd.m_sDOC_ID, "NIB Documento null");
            }
            if (oDd.m_sDOC_DOCNIB.Length != 13 && oDd.m_sDOC_DOCNIB.Length != 21)
            {
                updateERRO(oDd.m_sDOC_ID, "NIB Documento inválido");
            }
        }

        private void ProcessaDocumento(DataRow oRow)
        {
            CIActividades.DetalhesDocumento oDd = new DetalhesDocumento(oRow);

            try
            {
                validaDocumento(oDd);
            }
            catch (Exception ex)
            {
                //update
                m_bDocsEmErro = true;
                m_sLastError = ex.Message;
                m_oParam.Clear();
                m_oParam.Add(new GeneralDBParameters("@DocID", oDd.m_sDOC_ID));
                m_oParam.Add(new GeneralDBParameters("@Erro", ex.Message));
                m_oParameters.DirectStoredProcedureNonQuery("dbo.InsertUpdate_DocumentoErro", ref m_oParam);
                m_iInterface.ErrorMessage("Doc:" + ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "ServRemessa()", 500);
                return;
            }

            ++m_iNSeqDoc;
            m_sLastDOC_ID = oDd.m_sDOC_ID;


            string sSPName = "dbo.Update_EstadoDocumento";

            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@DocID", oDd.m_sDOC_ID));
            m_oParam.Add(new GeneralDBParameters("@Estado", 20));
            if (m_lTranoutID <= 0)
            {
                throw new Exception("m_lTranoutID <= 0");
                //m_oParam.Add(new GeneralDBParameters("@Tranout_id", m_lTranoutID));
            }
            m_oParam.Add(new GeneralDBParameters("@Tranout_id", m_lTranoutID));
            //m_oParam.Add(new GeneralDBParameters("@Doc_Refarq", fnREFARQ(oDd)));
            //m_oParam.Add(new GeneralDBParameters("@Doc_Refarq", oDd.m_sDOC_REFARQ));
            m_oParam.Add(new GeneralDBParameters("@Doc_nSeq", m_iNSeqDoc));
            m_oParam.Add(new GeneralDBParameters("@Doc_ChaveH", fnCHAVEH(oDd)));

            m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);

            //processarImagemTeste(oDd);
            //processarImagem(oDd);

        }
        private void processarImagemTeste(DetalhesDocumento oDd)
        {
            string sImgPBFront;
            string sImgPBBack;

            try
            {
                //Escreve em disco, apenas para simular carga do TIBCO a enviar
                sImgPBFront = oDd.getImgFrente(m_oParameters);
                sImgPBBack = oDd.getImgBack(m_oParameters);

                //System.IO.FileInfo fInfoFrenteImagem = new System.IO.FileInfo(sImgPBFront);
                //System.IO.FileInfo fInfoVersoImagem = new System.IO.FileInfo(sImgPBBack);

                //if ((fInfoFrenteImagem.Length + fInfoVersoImagem.Length) > 69*1024)
                //{
                //    string sMsg;
                //    sMsg = sImgPBFront + " Superior a 69k: " + (fInfoVersoImagem.Length + fInfoFrenteImagem.Length).ToString() + " Bytes - " + sImgPBFront;
                //    sMsg += " No Doc_ID = " + oDd.m_sDOC_ID + " na Maquina_Id = " + oDd.m_sDOC_MAQUINA;
                //    m_iInterface.WarningMessage(sMsg);
                //}

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ServRemessa()", 500);
                m_iInterface.ErrorMessage(ex.Message);
                throw;
            }
        }



        #region Imagem - não está a ser utilizada

        private void processarImagem(DetalhesDocumento oDd)
        {
            string sImgPBFront;
            string sImgPBTempF;
            string sImgPBBack;
            string sImgPBTempB;

            int iQua = 70;
            int iDPI = 0;
            int iBri = 0;
            int iContr = 0;
            bool bChangeQualidade = true;

            try
            {
                //MostraImagem mostraImg = new MostraImagem(m_oParameters, oDd);

                sImgPBTempF = m_oParameters.GetTempFileName("IMGPBFront") + ".jpg";
                sImgPBFront = oDd.getImgFrente(m_oParameters);
                sImgPBTempB = m_oParameters.GetTempFileName("IMGPBBack") + ".jpg";
                sImgPBBack = oDd.getImgBack(m_oParameters);
                while (bChangeQualidade)
                {

                    CIConfigGlobalParameters.ConvertImage._ConvertJPEGToGrayScale(sImgPBFront, sImgPBTempF, iQua, iDPI, iContr, iBri);
                    CIConfigGlobalParameters.ConvertImage._ConvertJPEGToGrayScale(sImgPBBack, sImgPBTempB, iQua, iDPI, iContr, iBri);

                    System.IO.FileInfo fInfoFrenteImagem = new System.IO.FileInfo(sImgPBTempF);
                    if (!fInfoFrenteImagem.Exists)
                        throw new Exception(sImgPBFront + " Não existe");

                    System.IO.FileInfo fInfoVersoImagem = new System.IO.FileInfo(sImgPBTempB);
                    if (!fInfoVersoImagem.Exists)
                        throw new Exception(sImgPBTempB + " Não existe");

                    // 69 kbytes x 1024 bytes = 70656 bytes
                    if ((fInfoFrenteImagem.Length + fInfoVersoImagem.Length) < 70656)
                    {
                        bChangeQualidade = false;
                        break;
                    }

                    if (bChangeQualidade && iQua > 20)
                    {
                        iQua -= 5;
                    }
                    else if (iContr < 60)
                    {
                        iContr += 10;
                        iBri += 10;
                    }
                    else
                    {
                        string sMsg;
                        sMsg = sImgPBFront + " Superior a 69k: " + (fInfoVersoImagem.Length + fInfoFrenteImagem.Length).ToString() + " Bytes - " + sImgPBFront;
                        sMsg += " No Doc_ID = " + oDd.m_sDOC_ID + " na Maquina_Id = " + oDd.m_sDOC_MAQUINA;
                        m_iInterface.WarningMessage(sMsg);
                        bChangeQualidade = false;
                    }
                }
                byte[] iFrontImg = LoadImage(sImgPBTempF, 2);
                byte[] iRearImg = LoadImage(sImgPBTempB, 2);

                string sSPName = "dbo.Update_DocImagens";
                m_oParam.Clear();
                m_oParam.Add(new GeneralDBParameters("@DocId", oDd.m_sDOC_ID));
                m_oParam.Add(new GeneralDBParameters("@ImgType", "JPG"));
                m_oParam.Add(new GeneralDBParameters("@FrontImage", iFrontImg));
                m_oParam.Add(new GeneralDBParameters("@RearImage", iRearImg));

                m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ServRemessa()", 500);
                m_iInterface.ErrorMessage(ex.Message);
                throw;
            }
        }

        public byte[] LoadImage(string sFileName, int iTentativa)
        {
            StreamReader sr = null;
            BinaryReader br = null;

            try
            {
                sr = new StreamReader(sFileName);

                br = new BinaryReader(sr.BaseStream);

                byte[] aBytes = br.ReadBytes((int)sr.BaseStream.Length);
                return aBytes;
            }
            catch
            {
                if (iTentativa > 0)
                {
                    System.Threading.Thread.Sleep(500);
                    return LoadImage(sFileName, (iTentativa - 1));
                }

                throw;
            }
            finally
            {
                if (br != null)
                {
                    if (br.BaseStream != null)
                    {
                        br.Close();
                    }
                    br = null;
                }

                if (sr != null)
                {
                    if (sr.BaseStream != null)
                    {
                        sr.Close();
                        sr.Dispose();
                    }
                    sr = null;
                }
            }
        }
        #endregion

        private string fnCHAVEH(CIActividades.DetalhesDocumento oDd)
        {
            string sChaveH;

            sChaveH = oDd.m_iDOC_BALTOM.ToString("0000");
            sChaveH += oDd.m_iREMIN_BALCAO.ToString("0000");
            sChaveH += oDd.m_sREMIN_NUMERO.PadLeft(7, '0');
            sChaveH += fnNIB(oDd);
            sChaveH += oDd.m_dtREMIN_DATA.ToString("yyyyMMdd");
            //sChaveH += m_iNSeqDoc.ToString("000000");
            sChaveH += oDd.m_sDOCORI_ID.PadLeft(30, '0').Substring(24, 6);
            sChaveH += "0";

            return sChaveH;
        }

        private void updateERRO(string sID, string sMsg)
        {
            throw new Exception(sID + " " + sMsg);
        }

        private string fnNIB(CIActividades.DetalhesDocumento oDd)
        {
            if (oDd.m_sDOC_DOCNIB.Length == 21)
                return oDd.m_sDOC_DOCNIB;

            string sNIB;

            sNIB = "0035";
            sNIB += oDd.m_sDOC_DOCNIB.Substring(0, 4);
            sNIB += "00" + oDd.m_sDOC_DOCNIB.Substring(4, 9);

            //sNIB += CDigitoNIB(sNIB); //para o caso de ser necessario o check digito
            sNIB += "00";

            return sNIB;
        }

        private string CDigitoNIB(string sNIB)
        {
            int[] aiPesos = { 73, 17, 89, 38, 62, 45, 53, 15, 50, 5, 49, 34, 81, 76, 27, 90, 9, 30, 3 };
            string sWorkString = sNIB;
            long lSoma = 0;
            long lResult;

            for (int i = 0; i < sWorkString.Length; i++)
            {
                lSoma += (Convert.ToInt64(sWorkString.Substring(i, 1)) * aiPesos[i]);
            }
            lResult = (98 - (lSoma % 97));

            return lResult.ToString("00");
        }

        private void CriarTranche(string sREMIN_ID, int iTrancheNumero)
        {
            if (m_bMaquinaCriada)
            {
                m_lTranoutID = -1;
                return;
            }

            string sSPName = "dbo.Insert_TrancheOut";

            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@RemID", sREMIN_ID));
            m_oParam.Add(new GeneralDBParameters("@Numero", iTrancheNumero));
            m_oParam.Add(new GeneralDBParameters("@Depends", m_lTranoutID));
            //Vai fazer a stored procedure para preencher a tabela "dbo.Insert_TrancheOut"
            object oTranOutID;
            oTranOutID = m_oParameters.DirectStoredProcedureScalar(sSPName, ref m_oParam);

            m_lTranoutID = (long)(oTranOutID);

        }

        #region SDCIM 7

        public long? RemessaBalcaoParaProcessar()
        {
            try
            {
                string sQuery = "dbo.Select_RemessaBalcao2Process";

                Object obj = m_oParameters.DirectSqlScalar(sQuery);

                if (obj == null)
                {
                    return null;
                }

                if (obj.ToString().Length > 0)
                {
                    m_iInterface.InfoMessage("Tem a remessa " + obj.ToString() + " para processar", "");
                }

                return Int64.Parse(obj.ToString());
            }
            catch (Exception ex)
            {
                m_iInterface.ErrorMessage("RemessaBalcaoParaProcessar: " + ex.Message);

                GenericLog.GenLogRegistarErro(ref ex, "ServRemessa()", 500);

                return null;
            }
        }

        public void TratarTranchesBalcao(long remessaId)
        {
            DataSet ds = null;
            m_sLastDOC_ID = "";

            try
            {
                int iTeste;

                m_bMaquinaCriadaBalcao = false;
                m_iNSeqDoc = 0;

                // Em processamento (30)
                try
                {
                    ValidaRemessaBalcao(remessaId.ToString());
                }
                catch (Exception ex)
                {
                    m_oParam.Clear();
                    m_oParam.Add(new GeneralDBParameters("@ReminID", remessaId));
                    m_oParam.Add(new GeneralDBParameters("@Estado", -40));
                    m_oParam.Add(new GeneralDBParameters("@Erro", ex.Message));

                    m_oParameters.DirectStoredProcedureNonQuery("dbo.Update_RemessaBalcaoErro", ref m_oParam);

                    m_iInterface.ErrorMessage("RemId:" + remessaId + " " + ex.Message);

                    GenericLog.GenLogRegistarErro(ref ex, "ServRemessa()", 500);

                    return;
                }

                string sQuery2 = "UPDATE REMESSA_BALCAO SET REMBALCAO_STAT_ID = 30 WHERE REMBALCAO_STAT_ID = 20 and ID = " + remessaId;

                iTeste = m_oParameters.DirectSqlNonQuery(sQuery2);

                if (iTeste != 1)
                {
                    m_iInterface.WarningMessage("Rows Updated != 1: " + iTeste.ToString() + " " + sQuery2);

                    return;
                }

                // Processar
                m_oParam.Clear();
                m_oParam.Add(new GeneralDBParameters("@RemID", remessaId));

                string sQuery3 = "select * from VW_DETALHE_DOCUMENTOS_BALCAO where REMIN_ID = " + remessaId + " order by DOC_INDEX";
                m_lTranoutBalcaoID = 0;
                int iCount = 0;
                int iTrancheNumero = 0;
                m_bDocsEmErroBalcao = false;
                m_sLastError = "";
                ds = m_oParameters.DirectSqlDataSet(sQuery3, "DOC");

                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    if (iCount++ % m_oParameters.m_iMaxDocsTranche == 0)
                    {
                        if (m_lTranoutBalcaoID != 0)
                        {
                            string sQuery4 = "update TRANCHE_OUT set TRANOUTSTAT_ID = 20 where TRANOUT_ID = " + m_lTranoutBalcaoID.ToString();

                            m_oParameters.DirectSqlNonQuery(sQuery4);
                        }
                        CriarTrancheBalcao(remessaId, ++iTrancheNumero);
                    }

                    ProcessaDocumentoBalcao(oRow);
                }

                // Update da última tranche para última
                string sQuery5 = "update TRANCHE_OUT set TRANOUT_ULTIMA = 1, TRANOUTSTAT_ID = 20, TRANOUT_INCOMPLETA = 0 where TRANOUT_ID = " + m_lTranoutBalcaoID.ToString();

                m_oParameters.DirectSqlNonQuery(sQuery5);

                int iNewEstado = m_bMaquinaCriadaBalcao ? 20 : 40;

                if (iNewEstado == 40 && m_bDocsEmErroBalcao)
                    iNewEstado = -40;

                // Processado (40)
                m_oParam.Clear();
                m_oParam.Add(new GeneralDBParameters("@REMBALCAO_ID_IN", remessaId));
                m_oParam.Add(new GeneralDBParameters("@OldEstado_IN", 30));
                m_oParam.Add(new GeneralDBParameters("@NewEstado_IN", iNewEstado));
                m_oParam.Add(new GeneralDBParameters("@Msg_IN", m_sLastError));

                try
                {
                    m_oParameters.DirectStoredProcedureNonQuery("dbo.Update_EstadoRemessaBalcao", ref m_oParam);

                    m_iInterface.InfoMessage("Processou a remessa " + remessaId, "");
                }
                catch (Exception ex)
                {
                    try
                    {
                        m_iInterface.ErrorMessage("RemId:" + remessaId + " " + ex.Message);

                        GenericLog.GenLogRegistarErro(ref ex, "ServRemessa()", 500);

                        m_oParam.Clear();
                        m_oParam.Add(new GeneralDBParameters("@REMBALCAO_ID_IN", remessaId));
                        m_oParam.Add(new GeneralDBParameters("@Msg", ex.Message));

                        m_oParameters.DirectStoredProcedureNonQuery("dbo.Update_EstadoRemessaBalcao", ref m_oParam);
                    }
                    catch
                    {
                    }
                }
            }
            catch (Exception ex)
            {
                m_iInterface.ErrorMessage("RemId:" + remessaId + " " + ex.Message);

                GenericLog.GenLogRegistarErro(ref ex, "ServRemessa()", 500);

                UpdateRemessaBalcaoErro(remessaId, ex.Message);
            }
            finally
            {
                if (ds != null)
                {
                    ds.Dispose();

                    ds = null;
                }
            }
        }

        private void ValidaRemessaBalcao(string remessaId)
        {
            string sQuery = "select REMBALCAO_DATA from REMESSA_BALCAO where id = " + remessaId;

            object data = m_oParameters.DirectSqlScalar(sQuery);

            if (data == null)
            {
                updateERRO(remessaId, "Remessa Balcão não existente");
            }

            DateTime dtREMIN_DATA = Convert.ToDateTime(data);

            if (dtREMIN_DATA < DateTime.Now.AddDays(m_oParameters.m_iMinDias * (-1)) ||
                dtREMIN_DATA > DateTime.Now.AddDays(m_oParameters.m_iMaxDias))
            {
                updateERRO(remessaId, "Data Remessa Balcão" + dtREMIN_DATA.ToShortDateString() + " inválida");
            }
        }

        private void UpdateRemessaBalcaoErro(long remessaId, string sErro)
        {
            string sSPName = "dbo.Update_EstadoRemessaBalcao";

            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@REMBALCAO_ID_IN", remessaId));
            m_oParam.Add(new GeneralDBParameters("@NewEstado", -40));
            m_oParam.Add(new GeneralDBParameters("@Msg", sErro));

            try
            {
                m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);

                if (m_sLastDOC_ID != "")
                {
                    sSPName = "dbo.Update_EstadoDocumentoBalcao";

                    m_oParam.Clear();
                    m_oParam.Add(new GeneralDBParameters("@DocID", m_sLastDOC_ID));
                    m_oParam.Add(new GeneralDBParameters("@Estado", -20));

                    m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);
                }
            }
            catch
            {
            }
        }

        private void CriarTrancheBalcao(long remessaId, int iTrancheNumero)
        {
            if (m_bMaquinaCriadaBalcao)
            {
                m_lTranoutBalcaoID = -1;

                return;
            }

            string sSPName = "dbo.Insert_TrancheOut";

            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@RemID", remessaId));
            m_oParam.Add(new GeneralDBParameters("@Numero", iTrancheNumero));
            m_oParam.Add(new GeneralDBParameters("@Depends", m_lTranoutBalcaoID));
            m_oParam.Add(new GeneralDBParameters("@RemOrigemID_IN", Convert.ToInt32(CIActividades.RemessaOrigem.Balcao)));

            //Vai fazer a stored procedure para preencher a tabela "dbo.Insert_TrancheOutBalcao"
            object oTranOutID;
            oTranOutID = m_oParameters.DirectStoredProcedureScalar(sSPName, ref m_oParam);

            m_lTranoutBalcaoID = (long)(oTranOutID);
        }

        private void ProcessaDocumentoBalcao(DataRow oRow)
        {
            CIActividades.DetalhesDocumentoBalcao oDd = new DetalhesDocumentoBalcao(oRow);

            try
            {
                ValidaDocumentoBalcao(oDd);
            }
            catch (Exception ex)
            {
                //update
                m_bDocsEmErroBalcao = true;

                m_sLastError = ex.Message;

                m_oParam.Clear();
                m_oParam.Add(new GeneralDBParameters("@DocID", oDd.m_sDOC_ID));
                m_oParam.Add(new GeneralDBParameters("@Erro", ex.Message));
                m_oParam.Add(new GeneralDBParameters("@RemOrigemID_IN", Convert.ToInt32(CIActividades.RemessaOrigem.Balcao)));

                m_oParameters.DirectStoredProcedureNonQuery("dbo.InsertUpdate_DocumentoErro", ref m_oParam);

                m_iInterface.ErrorMessage("Doc:" + ex.Message);

                GenericLog.GenLogRegistarErro(ref ex, "ServRemessa()", 823);

                return;
            }

            ++m_iNSeqDoc;

            m_sLastDOC_ID = oDd.m_sDOC_ID;

            string sSPName = "dbo.Update_EstadoDocumentoBalcao";

            m_oParam.Clear();
            m_oParam.Add(new GeneralDBParameters("@DocID", oDd.m_sDOC_ID));
            m_oParam.Add(new GeneralDBParameters("@Estado", 20));

            if (m_lTranoutBalcaoID <= 0)
            {
                throw new Exception("m_lTranoutBalcaoID <= 0");
            }

            m_oParam.Add(new GeneralDBParameters("@Tranout_id", m_lTranoutBalcaoID));
            //m_oParam.Add(new GeneralDBParameters("@Doc_Refarq", fnREFARQ(oDd)));
            //m_oParam.Add(new GeneralDBParameters("@Doc_Refarq", oDd.m_sDOC_REFARQ));
            m_oParam.Add(new GeneralDBParameters("@Doc_nSeq", m_iNSeqDoc));
            m_oParam.Add(new GeneralDBParameters("@Doc_ChaveH", fnCHAVEH(oDd)));

            m_oParameters.DirectStoredProcedureNonQuery(sSPName, ref m_oParam);
        }

        private void ValidaDocumentoBalcao(CIActividades.DetalhesDocumentoBalcao oDd)
        {
            if (String.IsNullOrWhiteSpace(oDd.m_sDOC_INDEX))
            {
                updateERRO(oDd.m_sDOC_ID, "Index Documento inválido");
            }

            if (oDd.m_sDOC_DOCNIB == null)
            {
                updateERRO(oDd.m_sDOC_ID, "NIB Documento null");
            }

            if (oDd.m_sDOC_DOCNIB.Length != 13 && oDd.m_sDOC_DOCNIB.Length != 21)
            {
                updateERRO(oDd.m_sDOC_ID, "NIB Documento inválido");
            }
        }

        private string fnCHAVEH(CIActividades.DetalhesDocumentoBalcao oDd)
        {
            string sChaveH = "";

            sChaveH = oDd.m_iDOC_BALTOM.ToString("0000");
            sChaveH += oDd.m_iREMIN_BALCAO.ToString("0000");
            sChaveH += oDd.m_sREMIN_NUMERO.PadLeft(7, '0');
            sChaveH += fnNIB(oDd);
            sChaveH += oDd.m_dtREMIN_DATA.ToString("yyyyMMdd");
            //sChaveH += m_iNSeqDoc.ToString("000000");
            sChaveH += oDd.m_sDOC_INDEX.PadLeft(30, '0').Substring(24, 6);
            sChaveH += GetCaraterFinalizacao(oDd.DOC_TIPO);

            return sChaveH;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="docTipo"></param>
        /// <returns></returns>
        private string GetCaraterFinalizacao(int docTipo)
        {
            string toReturn = null;
            switch (docTipo)
            {
                case 3:
                    toReturn = "2";
                    break;
                case 8:
                    toReturn = "0";
                    break;
                case 9:
                    toReturn = "1";
                    break;
            }

            return toReturn;
        }

        private string fnNIB(CIActividades.DetalhesDocumentoBalcao oDd)
        {
            if (oDd.m_sDOC_DOCNIB.Length == 21)
                return oDd.m_sDOC_DOCNIB;

            string sNIB;

            sNIB = "0035";
            sNIB += oDd.m_sDOC_DOCNIB.Substring(0, 4);
            sNIB += "00" + oDd.m_sDOC_DOCNIB.Substring(4, 9);

            //sNIB += CDigitoNIB(sNIB); //para o caso de ser necessario o check digito
            sNIB += "00";

            return sNIB;
        }

        #endregion
    }
}