﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.IO;

//using CIServiceComum;
using NBiis;

namespace CIServico
{
    public class CIServiceComumThread : IComparable
    {
        #region IComparable Members

        public int CompareTo(object obj)
        {
            if (m_iThreadID > ((CIServiceComumThread)obj).m_iThreadID)
                return 1;

            if (m_iThreadID < ((CIServiceComumThread)obj).m_iThreadID)
                return -1;

            return 0;
        }

        #endregion

        protected int m_iThreadID;

        protected bool m_bStop;
        protected bool m_bProcessEnded;
        protected CIServiceInterface m_iInterface;
        protected string m_sConfig;
        protected Thread m_oThread;
        protected CIServicosThreadParameters m_oParameters;

        public int ThreadID
        {
            get
            {
                return m_iThreadID;
            }
        }

        public string ThreadName
        {
            get
            {
                return m_oThread.Name + ":" + m_iThreadID.ToString();
            }
        }

        protected virtual string GetThreadName()
        {
            throw new Exception("Tem de implementar o  método GetThreadName()");
        }

        protected virtual void InitProcessThread()
        {
        }

        protected virtual bool CheckForThingToDo()
        {
            throw new Exception("Tem de implementar o  método CheckForThingToDo()");
        }

        public CIServiceComumThread(CIServiceInterface iInterface, CIServicosThreadParameters oParameters)
        {
            m_iInterface = iInterface;
            m_oThread = new Thread(new ThreadStart(this.Process));
            m_oThread.Name = GetThreadName();

            m_oThread.IsBackground = true;

            m_oParameters = oParameters;

            m_bStop = false;

            m_iThreadID = -1;

            System.Data.IDbConnection oConn = m_oParameters.DataBase;
            GenericLog.GenLogInicializacao(ref oConn, m_oParameters.Sistema, m_oParameters.Aplicativo, System.Windows.Forms.SystemInformation.UserName);
        }

        public virtual void Start()
        {
            m_oThread.Start();
        }

        //public void ValidaFuncionamento()
        //{
        //    if (m_oThread.IsAlive)
        //    {
        //        return;
        //    }
        //}

        public bool ReallyStoped()
        {
            return m_bProcessEnded;
        }

        public void StopThread()
        {
            m_bStop = true;

            StopAllThreads();

            m_oParameters.InsertServiceInfoMsg("Thread Principal Terminou", ThreadName, "CISerciveComumThread.cs");
            m_iInterface.ServiceErrorMessage("Process Ended - " + "MainThread");
        }

        public virtual void StopAllThreads()
        {
        }

        protected virtual void Process()
        {
            DateTime dtLastWorking = DateTime.Now;
            string sMsg;

            m_bProcessEnded = false;

            try
            {
                //Thread.Sleep(10000);
                m_oParameters.InsertServiceInfoMsg("Thread Principal Iniciada", ThreadName, "CIServiceComumThread.cs");
                m_oParameters.InsertServiceInfoMsg("v:" + Application.ProductVersion + " - " + File.GetLastWriteTime(Application.ExecutablePath).ToString("yyyy/MM/dd HH:mm:ss"), ThreadName, "CIServiceComumThread.cs");
                m_iInterface.ServiceInfoMessage("Process Started - " + "MainThread", "Started");

                bool bRegistarInicioParagem = false;

                LoadDatabaseParameters();

                InitProcessThread();

                while (!m_bStop)
                {
                    try
                    {
                        LoadDatabaseParameters();

                        while (m_oParameters.HoradeParagem())
                        {
                            if (!bRegistarInicioParagem)
                            {
                                m_oParameters.ForceStepSleepTime(m_oParameters.m_iTempoEntreIteracoes);
                                GenericLog.GenLogRegistarAlerta("Inicio de hora de paragem.");
                                bRegistarInicioParagem = true;
                            }

                            ControloTempoEntreIteracoes(true);

                            if (m_bStop)
                            {
                                m_oParameters.InsertServiceInfoMsg("Pedido de paragem do CIServico!!!", ThreadName, "CIServiceComumThread.cs");
                                return;
                            }

                            LoadDatabaseParameters();

                            if (dtLastWorking.AddMinutes(5) < DateTime.Now)
                            {
                                sMsg = " Hora de Paragem\n";
                                sMsg += " Data " + File.GetLastWriteTime(System.Windows.Forms.Application.ExecutablePath).ToString() + "\n";
                                sMsg += " Versao " + System.Windows.Forms.Application.ProductVersion + "\n";
                                sMsg += " Machine " + System.Windows.Forms.SystemInformation.ComputerName + "\n";

                                GenericLog.RegistarApplicacaoLog();

                                dtLastWorking = DateTime.Now;
                                m_iInterface.ServiceInfoMessage(sMsg, "Working");
                            }

                        }

                        if (bRegistarInicioParagem)
                        {
                            GenericLog.GenLogRegistarAlerta("Fim de hora de paragem.");
                            bRegistarInicioParagem = false;
                        }

                        if (!CheckForThingToDo())
                        {
                            m_oParameters.StepSleepTime();
                        }
                        else
                        {
                            m_oParameters.SetDefaultSleepTime();
                        }
                    }
                    catch (Exception ex)
                    {
                        m_oParameters.InsertServiceErrorMsg(ex, ThreadName, "CIServiceComumThread.cs");
                        m_iInterface.ServiceErrorMessage(ex.Message);
                        GenericLog.GenLogRegistarErro(ref ex, "CIServiceComumThread()", 500);
                        m_oParameters.SetDefaultSleepTime();
                    }

                    ControloTempoEntreIteracoes(false);
                    if (m_bStop)
                    {
                        m_oParameters.InsertServiceInfoMsg("Pedido de paragem do CIServico!!!", ThreadName, "CIServiceComumThread.cs");
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                m_oParameters.InsertServiceErrorMsg(ex, ThreadName, "CIServiceComumThread.cs");
                GenericLog.GenLogRegistarErro(ref ex, "CIServiceComumThread()", 500);
            }
            finally
            {
                m_iInterface.ServiceInfoMessage("Thread Principal Finalizada", "finally");
                m_oParameters.InsertServiceInfoMsg("Thread Principal Finalizada", ThreadName, "CIServiceComumThread.cs");

                m_bProcessEnded = true;

                if (m_bStop)
                {
                    m_oParameters.InsertServiceInfoMsg("CIServico Parado Normalmente", ThreadName, "CIServiceComumThread.cs");
                    m_iInterface.StopService("CIServico Parado Normalmente");
                }
                else
                {
                    m_oParameters.InsertServiceInfoMsg("CIServico Parado Anormalmente", ThreadName, "CIServiceComumThread.cs");
                    m_iInterface.StopService("CIServico Parado Anormalmente");
                }
            }
        }

        protected virtual void ControloTempoEntreIteracoes(bool bTempoParagem)
        {
            m_oParameters.SetLastExecution();
            while (m_oParameters.IsToWait() && !m_bStop)
            {
                Thread.Sleep(1000);
            }

            if (!bTempoParagem && m_oParameters.SleepAtLeast(45))
            {
                m_oParameters.InsertServiceInfoMsg("Thread Principal a funcionar ...", ThreadName, "CIServiceComumThread.cs");
            }
        }

        protected virtual void LoadDatabaseParameters()
        {
            m_oParameters.SetConnectString();

            m_oParameters.LoadParameters();
            //m_oParameters.LoadParametersVariaveis();

            m_oParameters.SetCIDatabaseParameters();
        }
    }
}
