﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIServico
{
    public interface CIServicoThreadInterface
    {
        void ThreadStoped(int iThreadID);
    }
}
