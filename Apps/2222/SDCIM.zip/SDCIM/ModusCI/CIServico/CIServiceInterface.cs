﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIServico
{
    public interface CIServiceInterface
    {
        void ServiceErrorMessage(string sMessage);
        void ServiceWarningMessage(string sMessage);
        void ServiceInfoMessage(string sMessage, string sHeader);
        void StopService(string sMessage);
    }
}
