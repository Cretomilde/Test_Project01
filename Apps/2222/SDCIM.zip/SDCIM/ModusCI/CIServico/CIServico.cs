﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;

using NBiis;

namespace CIServico
{
    public partial class CIServico : ServiceBase, CIServiceInterface
    {
        protected CIServicoThread m_oThread;

        public CIServico()
        {
            InitializeComponent();

            m_oThread = null;
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                ServiceInfoMessage("OnStart - Starting", "");
                m_oThread = new CIServicoThread(this, new CIServicosThreadParameters(""));
                m_oThread.Start();
            }
            catch (Exception ex)
            {
                ServiceErrorMessage(ex.Message);
                try
                {
                    StopService("Paragem devido a erro no Start");
                }
                catch (Exception ex1)
                {
                    ServiceErrorMessage(ex1.Message);
                }
            }
        }

        protected override void OnStop()
        {
            try
            {
                if (m_oThread == null)
                {
                    return;
                }
                m_oThread.StopThread();
                int iCount = 0;
                while (!m_oThread.ReallyStoped() && iCount++<15)
                {
                    System.Threading.Thread.Sleep(1000);
                }
            }
            catch (Exception ex)
            {
                ServiceErrorMessage(ex.Message);
            }
        }

        protected override void OnShutdown()
        {
            OnStop();
        }

        public void ServiceErrorMessage(string sMessage)
        {
            EventLog.WriteEntry(sMessage, EventLogEntryType.Error,900,100);
        }

        public void ServiceWarningMessage(string sMessage)
        {
            EventLog.WriteEntry(sMessage, EventLogEntryType.Warning);
        }

        public void ServiceInfoMessage(string sMessage, string sHeader)
        {
            if (sHeader.Trim().Length == 0)
            {
                EventLog.WriteEntry(sMessage, EventLogEntryType.Information);
            }
            else
            {
                EventLog.WriteEntry("CIServico:" + sHeader, sMessage, EventLogEntryType.Information);
            }
        }
        public void StopService(string sMessage)
        {
            ServiceErrorMessage(sMessage);
            Stop();
        }

    }
}
