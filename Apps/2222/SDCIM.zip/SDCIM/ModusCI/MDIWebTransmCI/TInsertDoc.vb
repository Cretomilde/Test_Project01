﻿Imports GCCA.CCAWebTransmCI
Imports nbiis.CCAGeneric
Imports NBiis

Public Class TInsertDoc
    Inherits WebTransmCI

    Public m_sCA_PAIS As String
    Public m_iCA_BANCO As Integer
    Public m_iCA_BALCAO As Integer
    Public m_iCA_NUMERO As Integer
    Public m_sCA_IDDISPOSITIVO As String
    Public m_iCA_BALCAOGESTOR As Integer
    Public m_dtDEP_DATA As DateTime
    Public m_iDEP_NSESSAO As Integer
    Public m_iDEP_NRECOLHA As Integer
    Public m_iDEP_NSEQOPERACAO As Integer
    Public m_sDEP_ID As String
    Public m_iDEP_QTDOCS As Integer
    Public m_iDEP_ESTADO As Integer
    Public m_dDEP_MONTANTE As Decimal
    Public m_sDEP_NUMCONTA As String
    Public m_sDEP_APLICACAO As String
    Public m_iDEP_ESTADO_OPER As Integer
    Public m_sDOC_INDICADORREENVIO As String
    Public m_sDOC_LOZIB As String
    Public m_sDOC_LONCONTA As String
    Public m_sDOC_LONCHEQUE As String
    Public m_dDOC_LOMONTANTE As Decimal
    Public m_sDOC_LOTIPO As String
    Public m_iDOC_NSEQ As Integer
    Public m_sDOC_REFINDEX As String
    Public m_iDOC_ESTADO As Integer

    Public m_sImageTypeFrente As String
    Public m_sImageTypeVerso As String
    Public m_abImagemFrente As Byte()
    Public m_abImagemVerso As Byte()


    Public Sub New(ByVal oGlobalParameters As Parameters)
        MyBase.New(oGlobalParameters)

    End Sub


    Protected Overrides Sub BuildServiceObject()
        m_oService = New waiaccesstuInsertDoc.Insert_DocumentoMDIServiceService()
    End Sub

    Public Overrides Function Execute() As Boolean
        Dim oWebIn As New waiaccesstuInsertDoc.Insert_DocumentoMDIInput
        Dim oWebOut As New waiaccesstuInsertDoc.Insert_DocumentoMDIOutput

        oWebIn.pageIndex = 0
        oWebIn.pageSize = 0

        oWebIn.CA_Pais = m_sCA_PAIS
        oWebIn.CA_Banco = m_iCA_BANCO
        oWebIn.CA_Balcao = m_iCA_BALCAO
        oWebIn.CA_Numero = m_iCA_NUMERO
        oWebIn.CA_IDDispositivo = m_sCA_IDDISPOSITIVO
        oWebIn.CA_BalcaoGestor = m_iCA_BALCAOGESTOR
        oWebIn.DEP_Data = m_dtDEP_DATA
        oWebIn.DEP_NSessao = m_iDEP_NSESSAO
        oWebIn.DEP_NRecolha = m_iDEP_NRECOLHA
        oWebIn.DEP_NSeqOperacao = m_iDEP_NSEQOPERACAO
        oWebIn.DEP_ID = m_sDEP_ID
        oWebIn.DEP_QTDocs = m_iDEP_QTDOCS
        oWebIn.DEP_Estado = m_iDEP_ESTADO
        oWebIn.DEP_Montante = m_dDEP_MONTANTE
        oWebIn.DEP_NumConta = m_sDEP_NUMCONTA
        oWebIn.DEP_Aplicacao = m_sDEP_APLICACAO
        oWebIn.DEP_Estado_Oper = m_iDEP_ESTADO_OPER
        oWebIn.DOC_Indicador_Reenvio = m_sDOC_INDICADORREENVIO
        oWebIn.DOC_LOZIB = m_sDOC_LOZIB
        oWebIn.DOC_LONConta = m_sDOC_LONCONTA
        oWebIn.DOC_LONCheque = m_sDOC_LONCHEQUE
        oWebIn.DOC_LOMontante = m_dDOC_LOMONTANTE
        oWebIn.DOC_LOTipo = m_sDOC_LOTIPO
        oWebIn.DOC_NSeq = m_iDOC_NSEQ
        oWebIn.DOC_RefIndex = m_sDOC_REFINDEX
        oWebIn.DOC_Estado = m_iDOC_ESTADO

        oWebIn.DOC_TipoIMAGEmFrente = m_sImageTypeFrente
        oWebIn.DOC_TipoIMAGEmVerso = m_sImageTypeVerso
        oWebIn.DOC_IMAGEmFrente = m_abImagemFrente
        oWebIn.DOC_IMAGEmVerso = m_abImagemVerso

        oWebIn.clientId = 2
        'Comprimento máximo da token: 40
        oWebIn.reqToken = "InsDocMDI#" + m_sDEP_APLICACAO + "#" + m_iCA_BALCAO.ToString("0000") + m_iCA_NUMERO.ToString("0000") + "#" + m_sDEP_ID.PadLeft(20).Substring(15, 5) + "#" + m_iDOC_NSEQ.ToString("00000")

        Try
            Dim oServ As waiaccesstuInsertDoc.Insert_DocumentoMDIServiceService = m_oService

            'Dim oTrace As Tracer = m_oGlobalParameters.m_oMSLog.CreateTraceObject(CCAMSEntepriseLibLog.Category.Central, GetLoggingTitleIdentifier())
            oWebOut = oServ.invokeInsert_DocumentoMDI(oWebIn)
            'If Not IsNothing(oTrace) Then
            ' oTrace.Dispose()
            'End If

        Catch ex As Exception
            ProcessException(ex, "TInsertDoc")
            Return False
        End Try

        Dim oFixout = New MDIOutputFixo(oWebOut)

        If isErro(oFixout, "TInsertDoc.vb") Then
            Return False
        End If

        Return True

    End Function

    Protected Overrides Function GetLoggingTitleIdentifier() As String
        Return "MDInsDc"
    End Function

    Protected Overrides Sub GetWebParameters()
        m_oService.Url = m_oGlobalParameters.GetProfileString("MDIWebTransmCI", GetProfileSectionValue(), "URL", "")
        m_oService.Timeout = m_oGlobalParameters.GetProfileInt("MDIWebTransmCI", GetProfileSectionValue(), "TimeOut", 70000)
    End Sub


End Class
