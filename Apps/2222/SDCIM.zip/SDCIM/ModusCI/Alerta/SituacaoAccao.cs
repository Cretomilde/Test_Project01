﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Alerta
{
    public class SituacaoAccao
    {
        public int m_iSITUACAO_ID;
        public string m_sSITUACAO_DESC;
        public Accao m_oAccao;

        public SituacaoAccao()
        {
            m_oAccao = new Accao();
            m_iSITUACAO_ID = -1;
            m_sSITUACAO_DESC = "";
        }

        public SituacaoAccao(SqlDataReader dr)
        {
            m_iSITUACAO_ID = Convert.ToInt16(dr["SITUACAO_ID"]);
            m_sSITUACAO_DESC = Convert.ToString(dr["SITUACAO_DESC"]);
            m_oAccao = new Accao(dr);
        }
        public ListViewItem MakeListViewItemSituacaoAccao()
        {
            ListViewItem olvItem = new ListViewItem();
            olvItem.Text = m_iSITUACAO_ID.ToString();
            olvItem.SubItems.Add(m_sSITUACAO_DESC);
            olvItem.SubItems.Add(m_oAccao.m_iACC_ID.ToString());
            olvItem.SubItems.Add(m_oAccao.m_sACC_DESC);

            return olvItem;
        }

        public ListViewItem MakeListViewItemSituacao()
        {
            ListViewItem olvItem = new ListViewItem();
            olvItem.Text = m_iSITUACAO_ID.ToString();
            olvItem.SubItems.Add(m_sSITUACAO_DESC);

            return olvItem;
        }

    }
}
