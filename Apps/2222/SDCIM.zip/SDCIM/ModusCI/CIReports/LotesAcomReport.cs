﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using NBiis.GenericReport;
using NBiis;
using NBIISNET;

namespace CIReports
{
    public partial class LotesAcomReport : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        protected string m_sSQLCondition;
        protected CIConfigGlobalParameters.CIMenuInterface m_oMenuInterface;

        public LotesAcomReport(CIConfigGP.CIGlobalParameters oParameters, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_oMenuInterface = oMenuInterface;
        }

        private void BuildReport()
        {
            MakeSQLCondition();
            NBReportDocument oRepDoc = new NBReportDocument("ListaLotesAcom", m_oParameters);
            oRepDoc.m_sReportTitle = m_ctrdtInicio.Value.ToString(m_oParameters.DateSysFmt) + " a "+ m_ctrldtFim.Value.ToString(m_oParameters.DateSysFmt);
            oRepDoc.m_sCondition = m_sSQLCondition;
            oRepDoc.CreateReport();

            ReportFrm oRepPreview = new ReportFrm(ref oRepDoc, oRepDoc.m_sReportTitle);
            oRepPreview.MdiParent = m_oMenuInterface.GetMainForm();
            oRepPreview.Show();

            Dispose();
        }

        private void MakeSQLCondition()
        {
            m_sSQLCondition = " FICH_DATA between '" + m_ctrdtInicio.Value.ToString(m_oParameters.DateSysFmt) + "' and '" + m_ctrldtFim.Value.ToString(m_oParameters.DateSysFmt) + "' ";
            if (textBoxFiltroBalcao.Text.Length > 0)
            {
                m_sSQLCondition += "and DOCACOM_BALCAO= " + textBoxFiltroBalcao.Text;
            }
        }

        protected void DefinirDatas()
        {
            m_ctrldtFim.Value = DateTime.Now.Date;
            m_ctrdtInicio.Value = DateTime.Now.Date.AddDays(-1);
        }

        private void btGenLog_Click_1(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                NBIISNET.frmEspereUmMomento.ShowWaitForm();

                BuildReport();
                GenericLog.GenLogRegistarInfo(m_sSQLCondition, "LotesAcomReport.cs", 34);

                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                NBIISNET.frmEspereUmMomento.HideWaitForm();

                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LotesAcomReport_Load(object sender, EventArgs e)
        {
            try
            {
               

                DefinirDatas();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Dispose();
            }
        }

        private void textBoxFiltroBalcao_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBoxFiltroBalcao.Text, "[^0-9]"))
            {
                MessageBox.Show("Campo numérico");
                textBoxFiltroBalcao.Text.Remove(textBoxFiltroBalcao.Text.Length - 1);
                textBoxFiltroBalcao.Text = "";
            }
            if (textBoxFiltroBalcao.Text.Length >= 4)
            {
                textBoxFiltroBalcao.MaxLength = 4;
            }
        }

        private void textBoxFiltroBalcao_Leave(object sender, EventArgs e)
        {
            string padleft = "";
            if (textBoxFiltroBalcao.Text.Length > 0 && textBoxFiltroBalcao.Text.Length < 4)
            {
                padleft = textBoxFiltroBalcao.Text.PadLeft(4, '0');
                textBoxFiltroBalcao.Text = padleft;
            }
        }

    }
}