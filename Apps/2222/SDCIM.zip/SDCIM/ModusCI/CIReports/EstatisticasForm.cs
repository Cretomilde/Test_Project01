﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;
using NBiis.GenericReport; 

namespace CIReports
{
    public partial class EstatisticasForm : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        protected string m_sSQLCondition;

        public EstatisticasForm(CIConfigGP.CIGlobalParameters oParameters)
        {
            InitializeComponent();
            m_oParameters = oParameters;
        }

        private void EstatisticasForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = System.Windows.Forms.FormWindowState.Maximized;

                DefinirDatas();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Dispose();
            }
        }

        protected void DefinirDatas()
        {
            m_ctrldtFim.Value = DateTime.Now.Date;
            m_ctrdtInicio.Value = DateTime.Now.Date.AddMonths(-1);
        }

        private void MakeSQLCondition()
        {
            m_sSQLCondition = "GENLOG_USERID='NVB0047'";
        }

        private void BuildReport()
        {
            MakeSQLCondition();
            NBReportDocument oRepDoc = new NBReportDocument("GENERICLOG",m_oParameters);
            oRepDoc.m_sReportTitle = "Generic Log";
            oRepDoc.m_sCondition = m_sSQLCondition;
            oRepDoc.CreateReport();

            ReportFrm oRepPreview = new ReportFrm(ref oRepDoc,oRepDoc.m_sReportTitle);
            oRepPreview.MdiParent = this.MdiParent;
            oRepPreview.Show();
        }

        private void btGenLog_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                NBIISNET.frmEspereUmMomento.ShowWaitForm();

                BuildReport();
                GenericLog.GenLogRegistarInfo(m_sSQLCondition, "EstatisticasForm.cs", 32);

                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                NBIISNET.frmEspereUmMomento.HideWaitForm();

                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}