﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using NBiis;
using NBIISNET;
using NBiis.GenericReport;

namespace CIReports
{
    public partial class ResumoDeEnviosForm : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        protected string m_sSQLCondition;
        protected CIConfigGlobalParameters.CIMenuInterface m_oMenuInterface;

        public ResumoDeEnviosForm(CIConfigGP.CIGlobalParameters oParameters, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_oMenuInterface = oMenuInterface;
        }

       

        private void BuildReport()
        {
            MakeSQLCondition();
            NBReportDocument oRepDoc = new NBReportDocument("ResumoEnvios", m_oParameters);
            oRepDoc.m_sReportTitle = m_ctrdtInicio.Value.ToString(m_oParameters.DateSysFmt) + " a " + m_ctrldtFim.Value.ToString(m_oParameters.DateSysFmt);
            oRepDoc.m_sCondition = m_sSQLCondition;
            oRepDoc.CreateReport();

            ReportFrm oRepPreview = new ReportFrm(ref oRepDoc, oRepDoc.m_sReportTitle);
            oRepPreview.MdiParent = m_oMenuInterface.GetMainForm();
            oRepPreview.Show();

            Dispose();
        }

        private void MakeSQLCondition()
        {
            if (txBalcao.Text.Length > 0)
            {
                m_sSQLCondition = " Remin_data between '" + m_ctrdtInicio.Value.ToString(m_oParameters.DateSysFmt) + "' and '" + m_ctrldtFim.Value.ToString(m_oParameters.DateSysFmt) + "'" + " And REMIN_BALCAO = " + txBalcao.Text + "";
            }
            else
            {
                m_sSQLCondition = " Remin_data between '" + m_ctrdtInicio.Value.ToString(m_oParameters.DateSysFmt) + "' and '" + m_ctrldtFim.Value.ToString(m_oParameters.DateSysFmt) + "' ";
            }
        }

        protected void DefinirDatas()
        {
            m_ctrldtFim.Value = DateTime.Now.Date;
            m_ctrdtInicio.Value = DateTime.Now.Date.AddMonths(-1);
        }


        private void btGenLog_Click_1(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                NBIISNET.frmEspereUmMomento.ShowWaitForm();

                BuildReport();
                GenericLog.GenLogRegistarInfo(m_sSQLCondition, "ResumoDeEnviosForm.cs", 35);

                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                NBIISNET.frmEspereUmMomento.HideWaitForm();

                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ResumoDeEnviosForm_Load(object sender, EventArgs e)
        {
            try
            {
                
                DefinirDatas();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Dispose();
            }
        }

        private void txBalcao_TextChanged(object sender, EventArgs e)
        {
                 
            if (System.Text.RegularExpressions.Regex.IsMatch(txBalcao.Text, "[^0-9]"))
            {
                MessageBox.Show("Campo numérico");
                txBalcao.Text.Remove(txBalcao.Text.Length - 1);
                txBalcao.Text = "";
            }
            if (txBalcao.Text.Length >= 4)
            {
                txBalcao.MaxLength = 4;
            }
        }

        private void txBalcao_Leave(object sender, EventArgs e)
        {
            string padleft = "";
            if (txBalcao.Text.Length > 0 && txBalcao.Text.Length < 4)
            {
                padleft = txBalcao.Text.PadLeft(4, '0');
                txBalcao.Text = padleft;
            }
        }
       
    }
}