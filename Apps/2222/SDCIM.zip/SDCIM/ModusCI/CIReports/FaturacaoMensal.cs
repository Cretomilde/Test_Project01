﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using NBiis;
using NBIISNET;
using NBiis.GenericReport;

namespace CIReports
{
    public partial class FaturacaoMensal : Form
    {

        protected CIConfigGP.CIGlobalParameters m_oParameters;
        protected string m_sSQLCondition;
        protected CIConfigGlobalParameters.CIMenuInterface m_oMenuInterface;

        private class ComboboxItem
        {
            public string Text { get; set; }
            public object Value { get; set; }
        }

        public FaturacaoMensal(CIConfigGP.CIGlobalParameters oParameters, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_oMenuInterface = oMenuInterface;
        }

        private void btGenLog_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                NBIISNET.frmEspereUmMomento.ShowWaitForm();

                BuildReport();
                //GenericLog.GenLogRegistarInfo(m_sSQLCondition, "FaturacaoMensal.cs", 37);

                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                NBIISNET.frmEspereUmMomento.HideWaitForm();

                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BuildReport()
        {
            MakeSQLCondition();
            NBReportDocument oRepDoc = new NBReportDocument("FaturacaoMensal", m_oParameters);
           // oRepDoc.m_sReportTitle = "Faturação Mensal";
            oRepDoc.m_sCondition = m_sSQLCondition;
            
            oRepDoc.CreateReport();

            ReportFrm oRepPreview = new ReportFrm(ref oRepDoc, oRepDoc.m_sReportTitle);
            oRepPreview.MdiParent = m_oMenuInterface.GetMainForm();
            oRepPreview.Show();

            Dispose();
        }

        private void MakeSQLCondition()
        {
            m_sSQLCondition = "MES = '" + cbMes.SelectedItem  + "' AND ANO = " + cbAno.SelectedItem + "";

        }

        private void ListagemChequesPorMes_Load(object sender, EventArgs e)
        {
            BindCbAno();
           
            cbMes.SelectedIndex = DateTime.Now.AddMonths(-1).Month-1;
        }

        private void BindCbAno()
        {
            DataSet ds = new DataSet();

            string sComm = "SELECT DISTINCT YEAR(LOTEACOM_DATAPROC) as ANO from LOTE_ACOM";
            ds = m_oParameters.DirectSqlDataSet(sComm, "LOTE_ACOM");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                cbAno.Items.Add(ds.Tables[0].Rows[i].ItemArray[0]);
            }

            var ano = DateTime.Now.AddMonths(-1).Year;

            if (!cbAno.Items.Contains(ano))
                cbAno.Items.Add(ano);
            cbAno.SelectedItem = ano;



        }


       
    }
}
