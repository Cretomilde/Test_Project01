select * from VW_FATURACAO_MENSAL
Where 
%condition%