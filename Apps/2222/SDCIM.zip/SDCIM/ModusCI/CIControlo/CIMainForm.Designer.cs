﻿namespace CIControlo
{
    partial class CIMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CIMainForm));
            this.menuStripMainMenu = new System.Windows.Forms.MenuStrip();
            this.ficheiroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadENVMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadACOMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.controloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resumoActividadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alertasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.processamentoAutomaticoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jobMinutoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jobHoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jobDiarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.MDIsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pesquisasEReenviosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cBalcaoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sacoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.atividadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ficheiroACOMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.manutençãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.balcoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.utilisadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuracaoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relatóriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listagemRemessasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resumoDeEnviosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaLotesAcomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resumoAcomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.faturaçãoMensalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.janelasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cascadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileHorizontalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileVerticalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.créditosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.sQLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importarRemessaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonActividades = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSair = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonHelp = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonAlertas = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonEnvm = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonAcom = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonListRem = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonResEnvio = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonLtAcom = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonResAcom = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonMDI = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonPesquisas2 = new System.Windows.Forms.ToolStripButton();
            this.tsbtnPesReACOM = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonActividadesBalcao = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSacoBalcao = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonAccoesBalcao = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusData = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusGroup = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusUserFullName = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusConnect = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnDVPImportarRemessas = new System.Windows.Forms.Button();
            this.btnErroDeposito = new System.Windows.Forms.Button();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.menuStripMainMenu.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStripMainMenu
            // 
            this.menuStripMainMenu.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.menuStripMainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ficheiroToolStripMenuItem,
            this.controloToolStripMenuItem,
            this.manutençãoToolStripMenuItem,
            this.relatóriosToolStripMenuItem,
            this.janelasToolStripMenuItem,
            this.ajudaToolStripMenuItem});
            this.menuStripMainMenu.Location = new System.Drawing.Point(0, 0);
            this.menuStripMainMenu.MdiWindowListItem = this.janelasToolStripMenuItem;
            this.menuStripMainMenu.Name = "menuStripMainMenu";
            this.menuStripMainMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStripMainMenu.Size = new System.Drawing.Size(776, 24);
            this.menuStripMainMenu.TabIndex = 3;
            this.menuStripMainMenu.Text = "menuStripMainMenu";
            // 
            // ficheiroToolStripMenuItem
            // 
            this.ficheiroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadENVMToolStripMenuItem,
            this.loadACOMToolStripMenuItem,
            this.toolStripMenuItem1,
            this.sairToolStripMenuItem});
            this.ficheiroToolStripMenuItem.Name = "ficheiroToolStripMenuItem";
            this.ficheiroToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.ficheiroToolStripMenuItem.Text = "&Ficheiro";
            // 
            // loadENVMToolStripMenuItem
            // 
            this.loadENVMToolStripMenuItem.Name = "loadENVMToolStripMenuItem";
            this.loadENVMToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.loadENVMToolStripMenuItem.Text = "Importar &ENVM";
            this.loadENVMToolStripMenuItem.Click += new System.EventHandler(this.loadENVMToolStripMenuItem_Click);
            // 
            // loadACOMToolStripMenuItem
            // 
            this.loadACOMToolStripMenuItem.Name = "loadACOMToolStripMenuItem";
            this.loadACOMToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.loadACOMToolStripMenuItem.Text = "Importar &ACOM";
            this.loadACOMToolStripMenuItem.Click += new System.EventHandler(this.loadACOMToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(156, 6);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.sairToolStripMenuItem.Text = "&Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // controloToolStripMenuItem
            // 
            this.controloToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resumoActividadesToolStripMenuItem,
            this.alertasToolStripMenuItem,
            this.processamentoAutomaticoToolStripMenuItem,
            this.consultasToolStripMenuItem,
            this.toolStripMenuItem2,
            this.MDIsToolStripMenuItem,
            this.pesquisasEReenviosToolStripMenuItem,
            this.cBalcaoToolStripMenuItem,
            this.ficheiroACOMToolStripMenuItem});
            this.controloToolStripMenuItem.Name = "controloToolStripMenuItem";
            this.controloToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.controloToolStripMenuItem.Text = "&Controlo";
            // 
            // resumoActividadesToolStripMenuItem
            // 
            this.resumoActividadesToolStripMenuItem.Name = "resumoActividadesToolStripMenuItem";
            this.resumoActividadesToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.resumoActividadesToolStripMenuItem.Text = "&Actividades";
            this.resumoActividadesToolStripMenuItem.Click += new System.EventHandler(this.resumoActividadesToolStripMenuItem_Click);
            // 
            // alertasToolStripMenuItem
            // 
            this.alertasToolStripMenuItem.Name = "alertasToolStripMenuItem";
            this.alertasToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.alertasToolStripMenuItem.Text = "A&lertas";
            this.alertasToolStripMenuItem.Click += new System.EventHandler(this.alertasToolStripMenuItem_Click);
            // 
            // processamentoAutomaticoToolStripMenuItem
            // 
            this.processamentoAutomaticoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jobMinutoToolStripMenuItem,
            this.jobHoraToolStripMenuItem,
            this.jobDiarioToolStripMenuItem});
            this.processamentoAutomaticoToolStripMenuItem.Name = "processamentoAutomaticoToolStripMenuItem";
            this.processamentoAutomaticoToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.processamentoAutomaticoToolStripMenuItem.Text = "Processamento Automatico";
            // 
            // jobMinutoToolStripMenuItem
            // 
            this.jobMinutoToolStripMenuItem.Name = "jobMinutoToolStripMenuItem";
            this.jobMinutoToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.jobMinutoToolStripMenuItem.Text = "Job Minuto";
            this.jobMinutoToolStripMenuItem.Click += new System.EventHandler(this.jobMinutoToolStripMenuItem_Click);
            // 
            // jobHoraToolStripMenuItem
            // 
            this.jobHoraToolStripMenuItem.Name = "jobHoraToolStripMenuItem";
            this.jobHoraToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.jobHoraToolStripMenuItem.Text = "Job Hora";
            this.jobHoraToolStripMenuItem.Click += new System.EventHandler(this.jobHoraToolStripMenuItem_Click);
            // 
            // jobDiarioToolStripMenuItem
            // 
            this.jobDiarioToolStripMenuItem.Name = "jobDiarioToolStripMenuItem";
            this.jobDiarioToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.jobDiarioToolStripMenuItem.Text = "Job Diario";
            this.jobDiarioToolStripMenuItem.Click += new System.EventHandler(this.jobDiarioToolStripMenuItem_Click);
            // 
            // consultasToolStripMenuItem
            // 
            this.consultasToolStripMenuItem.Name = "consultasToolStripMenuItem";
            this.consultasToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.consultasToolStripMenuItem.Text = "Consultas SIBS";
            this.consultasToolStripMenuItem.Click += new System.EventHandler(this.consultasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(218, 6);
            // 
            // MDIsToolStripMenuItem
            // 
            this.MDIsToolStripMenuItem.Name = "MDIsToolStripMenuItem";
            this.MDIsToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.MDIsToolStripMenuItem.Text = "MDIs";
            this.MDIsToolStripMenuItem.Click += new System.EventHandler(this.MDIsToolStripMenuItem_Click);
            // 
            // pesquisasEReenviosToolStripMenuItem
            // 
            this.pesquisasEReenviosToolStripMenuItem.Name = "pesquisasEReenviosToolStripMenuItem";
            this.pesquisasEReenviosToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.pesquisasEReenviosToolStripMenuItem.Text = "Pesquisas e Reenvios";
            this.pesquisasEReenviosToolStripMenuItem.Click += new System.EventHandler(this.pesquisasEReenviosToolStripMenuItem_Click);
            // 
            // cBalcaoToolStripMenuItem
            // 
            this.cBalcaoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sacoToolStripMenuItem,
            this.atividadesToolStripMenuItem,
            this.acoesToolStripMenuItem});
            this.cBalcaoToolStripMenuItem.Name = "cBalcaoToolStripMenuItem";
            this.cBalcaoToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.cBalcaoToolStripMenuItem.Text = "Controlo Balcão";
            // 
            // sacoToolStripMenuItem
            // 
            this.sacoToolStripMenuItem.Name = "sacoToolStripMenuItem";
            this.sacoToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.sacoToolStripMenuItem.Text = "Depósitos / Estornos";
            this.sacoToolStripMenuItem.Click += new System.EventHandler(this.sacoToolStripMenuItem_Click);
            // 
            // atividadesToolStripMenuItem
            // 
            this.atividadesToolStripMenuItem.Name = "atividadesToolStripMenuItem";
            this.atividadesToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.atividadesToolStripMenuItem.Text = "Actividades";
            this.atividadesToolStripMenuItem.Click += new System.EventHandler(this.atividadesToolStripMenuItem_Click_1);
            // 
            // acoesToolStripMenuItem
            // 
            this.acoesToolStripMenuItem.Name = "acoesToolStripMenuItem";
            this.acoesToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.acoesToolStripMenuItem.Text = "Acções";
            this.acoesToolStripMenuItem.Click += new System.EventHandler(this.acoesToolStripMenuItem_Click);
            // 
            // ficheiroACOMToolStripMenuItem
            // 
            this.ficheiroACOMToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fToolStripMenuItem1});
            this.ficheiroACOMToolStripMenuItem.Name = "ficheiroACOMToolStripMenuItem";
            this.ficheiroACOMToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.ficheiroACOMToolStripMenuItem.Text = "Ficheiro ACOM";
            // 
            // fToolStripMenuItem1
            // 
            this.fToolStripMenuItem1.Name = "fToolStripMenuItem1";
            this.fToolStripMenuItem1.Size = new System.Drawing.Size(184, 22);
            this.fToolStripMenuItem1.Text = "Pesquisas e Reenvios";
            this.fToolStripMenuItem1.Click += new System.EventHandler(this.FichACOMPesToolStripMenuItem_Click);
            // 
            // manutençãoToolStripMenuItem
            // 
            this.manutençãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.balcoesToolStripMenuItem,
            this.utilisadoToolStripMenuItem,
            this.configuracaoToolStripMenuItem});
            this.manutençãoToolStripMenuItem.Name = "manutençãoToolStripMenuItem";
            this.manutençãoToolStripMenuItem.Size = new System.Drawing.Size(86, 20);
            this.manutençãoToolStripMenuItem.Text = "&Manutenção";
            // 
            // balcoesToolStripMenuItem
            // 
            this.balcoesToolStripMenuItem.Name = "balcoesToolStripMenuItem";
            this.balcoesToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.balcoesToolStripMenuItem.Text = "&Balcões/Leitores";
            this.balcoesToolStripMenuItem.Click += new System.EventHandler(this.balcoesToolStripMenuItem_Click);
            // 
            // utilisadoToolStripMenuItem
            // 
            this.utilisadoToolStripMenuItem.Name = "utilisadoToolStripMenuItem";
            this.utilisadoToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.utilisadoToolStripMenuItem.Text = "&Utilizadores";
            this.utilisadoToolStripMenuItem.Click += new System.EventHandler(this.utilisadoToolStripMenuItem_Click);
            // 
            // configuracaoToolStripMenuItem
            // 
            this.configuracaoToolStripMenuItem.Name = "configuracaoToolStripMenuItem";
            this.configuracaoToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.configuracaoToolStripMenuItem.Text = "&Configuração";
            this.configuracaoToolStripMenuItem.Click += new System.EventHandler(this.configuracaoToolStripMenuItem_Click);
            // 
            // relatóriosToolStripMenuItem
            // 
            this.relatóriosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listagemRemessasToolStripMenuItem,
            this.resumoDeEnviosToolStripMenuItem,
            this.listaLotesAcomToolStripMenuItem,
            this.resumoAcomToolStripMenuItem,
            this.faturaçãoMensalToolStripMenuItem});
            this.relatóriosToolStripMenuItem.Name = "relatóriosToolStripMenuItem";
            this.relatóriosToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.relatóriosToolStripMenuItem.Text = "&Relatórios";
            // 
            // listagemRemessasToolStripMenuItem
            // 
            this.listagemRemessasToolStripMenuItem.Name = "listagemRemessasToolStripMenuItem";
            this.listagemRemessasToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.listagemRemessasToolStripMenuItem.Text = "Listagem de Remessas";
            this.listagemRemessasToolStripMenuItem.Click += new System.EventHandler(this.ListagemRemessasToolStripMenuItem_Click);
            // 
            // resumoDeEnviosToolStripMenuItem
            // 
            this.resumoDeEnviosToolStripMenuItem.Name = "resumoDeEnviosToolStripMenuItem";
            this.resumoDeEnviosToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.resumoDeEnviosToolStripMenuItem.Text = "Resumo de Envios";
            this.resumoDeEnviosToolStripMenuItem.Click += new System.EventHandler(this.resumoDeEnviosToolStripMenuItem_Click_1);
            // 
            // listaLotesAcomToolStripMenuItem
            // 
            this.listaLotesAcomToolStripMenuItem.Name = "listaLotesAcomToolStripMenuItem";
            this.listaLotesAcomToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.listaLotesAcomToolStripMenuItem.Text = "Lista Lotes Acom ";
            this.listaLotesAcomToolStripMenuItem.Click += new System.EventHandler(this.listaLotesAcomToolStripMenuItem_Click);
            // 
            // resumoAcomToolStripMenuItem
            // 
            this.resumoAcomToolStripMenuItem.Name = "resumoAcomToolStripMenuItem";
            this.resumoAcomToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.resumoAcomToolStripMenuItem.Text = "Resumo Acom";
            this.resumoAcomToolStripMenuItem.Click += new System.EventHandler(this.resumoAcomToolStripMenuItem_Click);
            // 
            // faturaçãoMensalToolStripMenuItem
            // 
            this.faturaçãoMensalToolStripMenuItem.Name = "faturaçãoMensalToolStripMenuItem";
            this.faturaçãoMensalToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.faturaçãoMensalToolStripMenuItem.Text = "Faturação Mensal";
            this.faturaçãoMensalToolStripMenuItem.Click += new System.EventHandler(this.faturaçãoMensalToolStripMenuItem_Click);
            // 
            // janelasToolStripMenuItem
            // 
            this.janelasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cascadeToolStripMenuItem,
            this.tileHorizontalToolStripMenuItem,
            this.tileVerticalToolStripMenuItem});
            this.janelasToolStripMenuItem.Name = "janelasToolStripMenuItem";
            this.janelasToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.janelasToolStripMenuItem.Text = "&Janelas";
            // 
            // cascadeToolStripMenuItem
            // 
            this.cascadeToolStripMenuItem.Name = "cascadeToolStripMenuItem";
            this.cascadeToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.cascadeToolStripMenuItem.Text = "&Cascade";
            this.cascadeToolStripMenuItem.Click += new System.EventHandler(this.cascadeToolStripMenuItem_Click);
            // 
            // tileHorizontalToolStripMenuItem
            // 
            this.tileHorizontalToolStripMenuItem.Name = "tileHorizontalToolStripMenuItem";
            this.tileHorizontalToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.tileHorizontalToolStripMenuItem.Text = "Tile &Horizontal";
            this.tileHorizontalToolStripMenuItem.Click += new System.EventHandler(this.tileHorizontalToolStripMenuItem_Click);
            // 
            // tileVerticalToolStripMenuItem
            // 
            this.tileVerticalToolStripMenuItem.Name = "tileVerticalToolStripMenuItem";
            this.tileVerticalToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.tileVerticalToolStripMenuItem.Text = "Tile &Vertical";
            this.tileVerticalToolStripMenuItem.Click += new System.EventHandler(this.tileVerticalToolStripMenuItem_Click);
            // 
            // ajudaToolStripMenuItem
            // 
            this.ajudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.créditosToolStripMenuItem,
            this.toolStripMenuItem5,
            this.sQLToolStripMenuItem,
            this.importarRemessaToolStripMenuItem});
            this.ajudaToolStripMenuItem.Name = "ajudaToolStripMenuItem";
            this.ajudaToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.ajudaToolStripMenuItem.Text = "&Ajuda";
            // 
            // créditosToolStripMenuItem
            // 
            this.créditosToolStripMenuItem.Name = "créditosToolStripMenuItem";
            this.créditosToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.créditosToolStripMenuItem.Text = "&Créditos";
            this.créditosToolStripMenuItem.Click += new System.EventHandler(this.créditosToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(171, 6);
            // 
            // sQLToolStripMenuItem
            // 
            this.sQLToolStripMenuItem.Name = "sQLToolStripMenuItem";
            this.sQLToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.sQLToolStripMenuItem.Text = "Con&sultas Diversas";
            this.sQLToolStripMenuItem.Click += new System.EventHandler(this.sQLToolStripMenuItem_Click);
            // 
            // importarRemessaToolStripMenuItem
            // 
            this.importarRemessaToolStripMenuItem.Name = "importarRemessaToolStripMenuItem";
            this.importarRemessaToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.importarRemessaToolStripMenuItem.Text = "&Importar Remessas";
            this.importarRemessaToolStripMenuItem.Click += new System.EventHandler(this.importarRemessaToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonActividades,
            this.toolStripButtonSair,
            this.toolStripButtonHelp,
            this.toolStripButtonAlertas,
            this.toolStripButtonEnvm,
            this.toolStripButtonAcom,
            this.toolStripButtonListRem,
            this.toolStripButtonResEnvio,
            this.toolStripButtonLtAcom,
            this.toolStripButtonResAcom,
            this.toolStripButtonMDI,
            this.toolStripButtonPesquisas2,
            this.toolStripSeparator1,
            this.toolStripButtonActividadesBalcao,
            this.toolStripButtonSacoBalcao,
            this.toolStripButtonAccoesBalcao,
            this.toolStripSeparator2,
            this.tsbtnPesReACOM});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(776, 39);
            this.toolStrip1.TabIndex = 5;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButtonActividades
            // 
            this.toolStripButtonActividades.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonActividades.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonActividades.Image")));
            this.toolStripButtonActividades.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonActividades.Name = "toolStripButtonActividades";
            this.toolStripButtonActividades.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStripButtonActividades.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonActividades.Text = "toolStripButton2";
            this.toolStripButtonActividades.ToolTipText = "Actividades";
            this.toolStripButtonActividades.Click += new System.EventHandler(this.toolStripButtonActividades_Click);
            // 
            // toolStripButtonSair
            // 
            this.toolStripButtonSair.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButtonSair.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonSair.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSair.Image")));
            this.toolStripButtonSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSair.Name = "toolStripButtonSair";
            this.toolStripButtonSair.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonSair.Text = "Sair";
            this.toolStripButtonSair.Click += new System.EventHandler(this.toolStripButtonSair_Click);
            // 
            // toolStripButtonHelp
            // 
            this.toolStripButtonHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButtonHelp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonHelp.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonHelp.Image")));
            this.toolStripButtonHelp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonHelp.Name = "toolStripButtonHelp";
            this.toolStripButtonHelp.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonHelp.Text = "Help";
            this.toolStripButtonHelp.Click += new System.EventHandler(this.toolStripButtonHelp_Click);
            // 
            // toolStripButtonAlertas
            // 
            this.toolStripButtonAlertas.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonAlertas.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAlertas.Image")));
            this.toolStripButtonAlertas.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAlertas.Name = "toolStripButtonAlertas";
            this.toolStripButtonAlertas.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStripButtonAlertas.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonAlertas.Text = "toolStripButton1";
            this.toolStripButtonAlertas.ToolTipText = "Alertas";
            this.toolStripButtonAlertas.Click += new System.EventHandler(this.toolStripButtonAlertas_Click);
            // 
            // toolStripButtonEnvm
            // 
            this.toolStripButtonEnvm.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonEnvm.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonEnvm.Image")));
            this.toolStripButtonEnvm.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonEnvm.Name = "toolStripButtonEnvm";
            this.toolStripButtonEnvm.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStripButtonEnvm.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonEnvm.Text = "toolStripButton4";
            this.toolStripButtonEnvm.ToolTipText = "Importar Envm";
            this.toolStripButtonEnvm.Click += new System.EventHandler(this.toolStripButtonEnvm_Click);
            // 
            // toolStripButtonAcom
            // 
            this.toolStripButtonAcom.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonAcom.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAcom.Image")));
            this.toolStripButtonAcom.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAcom.Name = "toolStripButtonAcom";
            this.toolStripButtonAcom.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStripButtonAcom.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonAcom.Text = "toolStripButton3";
            this.toolStripButtonAcom.ToolTipText = "Importar Acom";
            this.toolStripButtonAcom.Click += new System.EventHandler(this.toolStripButtonAcom_Click);
            // 
            // toolStripButtonListRem
            // 
            this.toolStripButtonListRem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonListRem.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonListRem.Image")));
            this.toolStripButtonListRem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonListRem.Name = "toolStripButtonListRem";
            this.toolStripButtonListRem.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStripButtonListRem.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonListRem.Text = "Relatorio Listagem Remessas";
            this.toolStripButtonListRem.Click += new System.EventHandler(this.toolStripButtonListRem_Click);
            // 
            // toolStripButtonResEnvio
            // 
            this.toolStripButtonResEnvio.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonResEnvio.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonResEnvio.Image")));
            this.toolStripButtonResEnvio.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonResEnvio.Name = "toolStripButtonResEnvio";
            this.toolStripButtonResEnvio.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStripButtonResEnvio.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonResEnvio.Text = "Relatorio Resumo Envio";
            this.toolStripButtonResEnvio.Click += new System.EventHandler(this.toolStripButtonResEnvio_Click);
            // 
            // toolStripButtonLtAcom
            // 
            this.toolStripButtonLtAcom.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonLtAcom.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLtAcom.Image")));
            this.toolStripButtonLtAcom.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLtAcom.Name = "toolStripButtonLtAcom";
            this.toolStripButtonLtAcom.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStripButtonLtAcom.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonLtAcom.Text = "Relatorio Lotes Acom";
            this.toolStripButtonLtAcom.Click += new System.EventHandler(this.toolStripButtonLtAcom_Click);
            // 
            // toolStripButtonResAcom
            // 
            this.toolStripButtonResAcom.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonResAcom.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonResAcom.Image")));
            this.toolStripButtonResAcom.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonResAcom.Name = "toolStripButtonResAcom";
            this.toolStripButtonResAcom.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStripButtonResAcom.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonResAcom.Text = "Relatorio Resumo Acom";
            this.toolStripButtonResAcom.Click += new System.EventHandler(this.toolStripButtonResAcom_Click);
            // 
            // toolStripButtonMDI
            // 
            this.toolStripButtonMDI.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonMDI.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonMDI.Image")));
            this.toolStripButtonMDI.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonMDI.Name = "toolStripButtonMDI";
            this.toolStripButtonMDI.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStripButtonMDI.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonMDI.Text = "Controlo MDIs";
            this.toolStripButtonMDI.Click += new System.EventHandler(this.toolStripButtonMDI_Click);
            // 
            // toolStripButtonPesquisas2
            // 
            this.toolStripButtonPesquisas2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonPesquisas2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonPesquisas2.Image")));
            this.toolStripButtonPesquisas2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonPesquisas2.Name = "toolStripButtonPesquisas2";
            this.toolStripButtonPesquisas2.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStripButtonPesquisas2.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonPesquisas2.Text = "Pesquisas e reenvios";
            this.toolStripButtonPesquisas2.Click += new System.EventHandler(this.toolStripButtonPesquisas2_Click);
            // 
            // tsbtnPesReACOM
            // 
            this.tsbtnPesReACOM.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbtnPesReACOM.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnPesReACOM.Image")));
            this.tsbtnPesReACOM.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnPesReACOM.Margin = new System.Windows.Forms.Padding(2, 1, 0, 2);
            this.tsbtnPesReACOM.Name = "tsbtnPesReACOM";
            this.tsbtnPesReACOM.Size = new System.Drawing.Size(36, 36);
            this.tsbtnPesReACOM.Text = "Pesquisas e Reenvio ACOM Balcão";
            this.tsbtnPesReACOM.Click += new System.EventHandler(this.tsbtnPesReACOM_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Margin = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButtonActividadesBalcao
            // 
            this.toolStripButtonActividadesBalcao.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonActividadesBalcao.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonActividadesBalcao.Image")));
            this.toolStripButtonActividadesBalcao.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonActividadesBalcao.Name = "toolStripButtonActividadesBalcao";
            this.toolStripButtonActividadesBalcao.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStripButtonActividadesBalcao.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonActividadesBalcao.Text = "toolStripButton2";
            this.toolStripButtonActividadesBalcao.ToolTipText = "Actividades Balcão";
            this.toolStripButtonActividadesBalcao.Click += new System.EventHandler(this.toolStripButtonActividadesBalcao_Click);
            // 
            // toolStripButtonSacoBalcao
            // 
            this.toolStripButtonSacoBalcao.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonSacoBalcao.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSacoBalcao.Image")));
            this.toolStripButtonSacoBalcao.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSacoBalcao.Name = "toolStripButtonSacoBalcao";
            this.toolStripButtonSacoBalcao.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStripButtonSacoBalcao.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonSacoBalcao.Text = "Depósitos \\ Estornos";
            this.toolStripButtonSacoBalcao.Click += new System.EventHandler(this.toolStripButtonSacoBalcao_Click);
            // 
            // toolStripButtonAccoesBalcao
            // 
            this.toolStripButtonAccoesBalcao.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonAccoesBalcao.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAccoesBalcao.Image")));
            this.toolStripButtonAccoesBalcao.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAccoesBalcao.Name = "toolStripButtonAccoesBalcao";
            this.toolStripButtonAccoesBalcao.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.toolStripButtonAccoesBalcao.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonAccoesBalcao.Text = "toolStripButton1";
            this.toolStripButtonAccoesBalcao.ToolTipText = "Acções Balcão";
            this.toolStripButtonAccoesBalcao.Click += new System.EventHandler(this.toolStripButtonAccoesBalcao_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusData,
            this.toolStripStatusUser,
            this.toolStripStatusGroup,
            this.toolStripStatusUserFullName,
            this.toolStripStatusConnect});
            this.statusStrip1.Location = new System.Drawing.Point(0, 415);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(776, 22);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusData
            // 
            this.toolStripStatusData.Name = "toolStripStatusData";
            this.toolStripStatusData.Size = new System.Drawing.Size(144, 17);
            this.toolStripStatusData.Text = "YYYY/MM/DD HH:MM:SS";
            // 
            // toolStripStatusUser
            // 
            this.toolStripStatusUser.Name = "toolStripStatusUser";
            this.toolStripStatusUser.Size = new System.Drawing.Size(67, 17);
            this.toolStripStatusUser.Text = "Logon User";
            // 
            // toolStripStatusGroup
            // 
            this.toolStripStatusGroup.Name = "toolStripStatusGroup";
            this.toolStripStatusGroup.Size = new System.Drawing.Size(40, 17);
            this.toolStripStatusGroup.Text = "Group";
            // 
            // toolStripStatusUserFullName
            // 
            this.toolStripStatusUserFullName.Name = "toolStripStatusUserFullName";
            this.toolStripStatusUserFullName.Size = new System.Drawing.Size(87, 17);
            this.toolStripStatusUserFullName.Text = "User Full Name";
            // 
            // toolStripStatusConnect
            // 
            this.toolStripStatusConnect.Name = "toolStripStatusConnect";
            this.toolStripStatusConnect.Size = new System.Drawing.Size(86, 17);
            this.toolStripStatusConnect.Text = "Connect String";
            this.toolStripStatusConnect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnDVPImportarRemessas
            // 
            this.btnDVPImportarRemessas.Enabled = false;
            this.btnDVPImportarRemessas.Location = new System.Drawing.Point(558, 1);
            this.btnDVPImportarRemessas.Name = "btnDVPImportarRemessas";
            this.btnDVPImportarRemessas.Size = new System.Drawing.Size(75, 23);
            this.btnDVPImportarRemessas.TabIndex = 8;
            this.btnDVPImportarRemessas.Text = "ImportarRemessas";
            this.btnDVPImportarRemessas.UseVisualStyleBackColor = true;
            this.btnDVPImportarRemessas.Visible = false;
            this.btnDVPImportarRemessas.Click += new System.EventHandler(this.btnDVPImportarRemessas_Click);
            // 
            // btnErroDeposito
            // 
            this.btnErroDeposito.Location = new System.Drawing.Point(639, 1);
            this.btnErroDeposito.Name = "btnErroDeposito";
            this.btnErroDeposito.Size = new System.Drawing.Size(108, 23);
            this.btnErroDeposito.TabIndex = 10;
            this.btnErroDeposito.Text = "Erros de Depositos";
            this.btnErroDeposito.UseVisualStyleBackColor = true;
            this.btnErroDeposito.Visible = false;
            this.btnErroDeposito.Click += new System.EventHandler(this.btnErroDeposito_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Margin = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // CIMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(776, 437);
            this.Controls.Add(this.btnErroDeposito);
            this.Controls.Add(this.btnDVPImportarRemessas);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStripMainMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStripMainMenu;
            this.Name = "CIMainForm";
            this.Text = "Concentrador de Imagens - Controlo";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.CIMainForm_Load);
            this.menuStripMainMenu.ResumeLayout(false);
            this.menuStripMainMenu.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem ficheiroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem controloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manutençãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem janelasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem créditosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sQLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadENVMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadACOMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resumoActividadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem balcoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cascadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileHorizontalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileVerticalToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonSair;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonHelp;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusData;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusUser;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusConnect;
        private System.Windows.Forms.ToolStripMenuItem configuracaoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relatóriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusGroup;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusUserFullName;
        private System.Windows.Forms.ToolStripMenuItem utilisadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alertasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importarRemessaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem processamentoAutomaticoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listagemRemessasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resumoDeEnviosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listaLotesAcomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resumoAcomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultasToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStripMainMenu;
        private System.Windows.Forms.ToolStripButton toolStripButtonActividades;
        private System.Windows.Forms.ToolStripMenuItem jobMinutoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jobHoraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jobDiarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem MDIsToolStripMenuItem;
        //private System.Windows.Forms.ToolStripButton toolStripButtonPesquisas;
        private System.Windows.Forms.ToolStripMenuItem pesquisasEReenviosToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButtonPesquisas2;
        private System.Windows.Forms.ToolStripButton toolStripButtonAlertas;
        private System.Windows.Forms.ToolStripButton toolStripButtonEnvm;
        private System.Windows.Forms.ToolStripButton toolStripButtonAcom;
        private System.Windows.Forms.ToolStripButton toolStripButtonListRem;
        private System.Windows.Forms.ToolStripButton toolStripButtonResEnvio;
        private System.Windows.Forms.ToolStripButton toolStripButtonLtAcom;
        private System.Windows.Forms.ToolStripButton toolStripButtonResAcom;
        private System.Windows.Forms.ToolStripButton toolStripButtonMDI;
        private System.Windows.Forms.ToolStripMenuItem cBalcaoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem atividadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sacoToolStripMenuItem;
        private System.Windows.Forms.Button btnDVPImportarRemessas;
        private System.Windows.Forms.ToolStripMenuItem acoesToolStripMenuItem;
        private System.Windows.Forms.Button btnErroDeposito;
        private System.Windows.Forms.ToolStripButton toolStripButtonActividadesBalcao;
        private System.Windows.Forms.ToolStripButton toolStripButtonAccoesBalcao;
        private System.Windows.Forms.ToolStripButton toolStripButtonSacoBalcao;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem ficheiroACOMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem faturaçãoMensalToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton tsbtnPesReACOM;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    }
}