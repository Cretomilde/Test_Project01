﻿using System;
using System.Collections.Generic;
using System.Text;
using CIConfigGP;

namespace CIControlo
{
    public class CIControloParameters : CIGlobalParameters
    {
        public CIControloParameters()
            : base()
        {
            m_bUseBaseDados = true;
        }

        public CIControloParameters(string sPrefixo)
            : base(sPrefixo)
        {
            m_bUseBaseDados = true;
        }

        protected override string ParseCommand(string sParametro)
        {
            m_bUseBaseDados = true;
            sParametro = sParametro.Replace("/", "");
            sParametro = sParametro.Replace(":", "");

            try
            {
                string sRes;
                sRes = ((string)global::CIControlo.Properties.Settings.Default[sParametro]);
                return sRes;
            }
            catch (Exception)
            {
                return "";
            }
        }
    }
}
