﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Web;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;
using Alerta;

namespace CIServAlertas
{
    class ServAlertasSendWebmail : CGDSendWebmail.SendWebmail 
    {
        DataSet m_dsGen;
        DataSet m_dsEsp;
        CIConfigGP.CIGlobalParameters m_oParameters;

        Accao.enuTipoAccao m_eTipoMail;

        public ServAlertasSendWebmail(CIConfigGP.CIGlobalParameters oParameters, Accao.enuTipoAccao eTipoAccao)
            : base()
        {
            m_dsGen = null;
            m_dsEsp = null;
            m_oParameters = oParameters;

            m_eTipoMail = eTipoAccao;

            GetParametersComuns();
        }

        protected virtual void GetParametersComuns()
        {
            dataSetGenericos();
            
            string sNome = "TIPACCP_NAME";
            string sValue = "TIPACCP_VALUE";

            setValuesToVars(m_dsGen.Tables[0], sNome, sValue);          
        }

        public void GetParamEspecificos(int iACC_ID)
        {
            dataSetEspecifico(iACC_ID);
            string sNome = "ACCP_NAME";
            string sValue = "ACCP_VALUE";

            setValuesToVars(m_dsEsp.Tables[0], sNome, sValue);
        }

        protected void setValuesToVars(DataTable dt, string sNome, string sValue)
        {

            foreach (DataRow oRow in dt.Rows)
            {

                switch (oRow[sNome].ToString().ToUpper())
                {
                    case "PASSWD":
                        if (valida(oRow, sValue))
                           m_sPasswd = oRow[sValue].ToString();
                        break;
                    case "URL":
                        if (valida(oRow, sValue))
                          //m_oServiceEmail.Url = oRow[sValue].ToString();
                          m_sURL = oRow[sValue].ToString();
                        break;
                    case "DOMAIN":
                        if (valida(oRow, sValue))
                            m_sDomain = oRow[sValue].ToString();
                        break;
                    case "TIPOEMAIL":
                        if (valida(oRow, sValue))
                            m_sTipoEmail = oRow[sValue].ToString().ToUpper();
                        break;
                    case "USERNAME":
                        if (valida(oRow, sValue))
                            m_sUserName = oRow[sValue].ToString();
                        break;
                    case "CC":
                        if (valida(oRow, sValue))
                            AddEmailCC(oRow[sValue].ToString());
                        break;
                    case "TO":
                        if (valida(oRow, sValue))
                            AddEmailTO(oRow[sValue].ToString());
                        break;
                    case "BCC":
                        if (valida(oRow, sValue))
                            AddEmailBCC(oRow[sValue].ToString());
                        break;
                    case "SUBJECT":
                        if (valida(oRow, sValue))
                            m_sSubject = oRow[sValue].ToString();
                        break;
                    default:
                        break;
                }

            } 
            
        }

        private bool valida(DataRow oRow, string sValue)
        {
            if (oRow[sValue].ToString().Equals(null) || oRow[sValue].ToString().Equals(""))
                return false;
            else
                return true;
        }
        
        protected void dataSetGenericos()
        {
            string sQuery;
            //sQuery = "select * from ALERTA_TIPO_ACCAO_PARAM where TIPACC_ID = " + ((int)Accao.enuTipoAccao.MAIL).ToString();
            sQuery = "select * from ALERTA_TIPO_ACCAO_PARAM where TIPACC_ID = " + ((int)m_eTipoMail).ToString();
            m_dsGen = m_oParameters.DirectSqlDataSet(sQuery, "ALERTA_TIPO_ACCAO_PARAM");

        }
        protected void dataSetEspecifico(int iACC_ID)
        {
            string sQuery;
            sQuery = "select * from ALERTA_ACCAO_PARAM where ACC_ID = " + iACC_ID.ToString();
            m_dsEsp = m_oParameters.DirectSqlDataSet(sQuery, "ALERTA_ACCAO_PARAM");
        }
    }
}
