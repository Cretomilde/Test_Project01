﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceProcess;
using System.Data.SqlClient;

using Alerta;
using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;
using System.Net;


namespace CIServAlertas
{
    public class ServAlerta
    {
        protected CIComumInterface m_iInterface;
        //protected EventLog oEventLog;

        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public ServAlerta(CIComumInterface iInterface, CIConfigGP.CIGlobalParameters oParameters)
        {
            m_oParameters = oParameters;
            m_iInterface = iInterface;
            //oEventLog = new EventLog("CIServico - Alerta");
        }

        public AlertaSituacaoAccao AlertaSituacaoAccaoParaProcessar()
        {
            string sQuery = "select TOP 1 * from VW_AL_ALERTA_SITUACAO_ACCAO where ALACC_STATUS=0";

            SqlDataReader drA = null;
            AlertaSituacaoAccao oAl = null;

            try
            {
                drA = m_oParameters.DirectSqlDataReader(sQuery);
                if (drA.Read())
                {
                    oAl = new AlertaSituacaoAccao(drA);
                }
                return oAl;
            }
            catch (Exception ex)
            {
                try
                {
                    EventLog.WriteEntry("CIServico - Alerta", "Erros de execução do CIServico" + "\n" + ex.Message, EventLogEntryType.Warning, 800, 100);

                    m_iInterface.ErrorMessage("SituacaoAlertaParaProcessar: " + ex.Message);
                    GenericLog.GenLogRegistarErro(ref ex, "ServAlerta()", 500);
                }
                catch 
                { 
                }
                return null;
            }
            finally
            {
                if (drA != null)
                {
                    drA.Close();
                }
            }
        }

        public void ProcessaAlertaSituacaoAccao(AlertaSituacaoAccao oAlSitAcc)
        {
            try
            {
                m_oParameters.BeginTrans(IsolationLevel.ReadCommitted);

                switch (oAlSitAcc.m_oSituacaoAccao.m_oAccao.m_enuTIPACC_ID)
                {
                    case Accao.enuTipoAccao.MAILEWS:
                        ProcessaAlertaSituacaoAccaoMail(oAlSitAcc, Accao.enuTipoAccao.MAILEWS);
                        break;
                    case Accao.enuTipoAccao.MAILWEBDAV:
                        ProcessaAlertaSituacaoAccaoMail(oAlSitAcc, Accao.enuTipoAccao.MAILWEBDAV);
                        break;
                    case Accao.enuTipoAccao.LOGDB:
                        ProcessaAlertaSituacaoAccaoLogDB(oAlSitAcc);
                        break;
                    case Accao.enuTipoAccao.LOGFILE:
                        ProcessaAlertaSituacaoAccaoLogFile(oAlSitAcc, Convert.ToInt32(Accao.enuTipoAccao.LOGFILE));
                        break;
                    case Accao.enuTipoAccao.EVENTVIEWER:
                        ProcessaAlertaSituacaoAccaoEVENTVIEWER(oAlSitAcc);
                        break;
                }

                oAlSitAcc.SetProcessado(m_oParameters);

                m_oParameters.Commit();
                m_iInterface.InfoMessage("ProcessaAlertaSituacaoAccao: " + oAlSitAcc.m_sALERT_ID, "");
            }
            catch (Exception ex)
            {
                m_oParameters.RollBack();
                m_iInterface.ErrorMessage("ProcessaAlertaSituacaoAccao: " + ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "ServAlerta()", 500);
                throw;
            }
        }

        public void ProcessaAlertaSituacaoAccaoLogDB(AlertaSituacaoAccao oAlSitAcc)
        {
            try
            {
                GenericLog.GenLogRegistarAlerta(oAlSitAcc.m_sAL_VARCHAR + '\n' + oAlSitAcc.m_sAL_TEXT, "CIServico - Alerta", oAlSitAcc.m_oSituacaoAccao.m_iSITUACAO_ID);
            }
            catch
            {
                //nada a fazer, não dá nunca erro
            }
        }

        public void ProcessaAlertaSituacaoAccaoEVENTVIEWER(AlertaSituacaoAccao oAlSitAcc)
        {
            try
            {
                string sMsg = oAlSitAcc.m_sAL_VARCHAR + '\n' + oAlSitAcc.m_sAL_TEXT;
                EventLog.WriteEntry("CIServico - Alerta", oAlSitAcc.m_oSituacaoAccao.m_sSITUACAO_DESC + "\n" + sMsg, EventLogEntryType.Warning, oAlSitAcc.m_oSituacaoAccao.m_iSITUACAO_ID, 100);
            }
            catch (Exception ex)
            {
                oAlSitAcc.SetErroProcessamento(m_oParameters, ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "ServAlerta()", 500);
                m_oParameters.EnviarAlertaSituacao(910, "ProcessaAlertaSituacaoAccaoEVENTVIEWER: " + ex.Message);
            }
        }

        public void ProcessaAlertaSituacaoAccaoLogFile(AlertaSituacaoAccao oAlSitAcc, int iTipoAccao)
        {
            try
            {
                ServAlertasLogFile oLog = new ServAlertasLogFile(m_oParameters, iTipoAccao);
                oLog.AddLineToFile("Situação:" + oAlSitAcc.m_oSituacaoAccao.m_iSITUACAO_ID.ToString() + " - " + oAlSitAcc.m_oSituacaoAccao.m_sSITUACAO_DESC);
                oLog.AddLineToFile(oAlSitAcc.m_dtALACC_TIMER.ToString("yyyy-MM-dd HH:mm:ss") + " - " + oAlSitAcc.m_sAL_VARCHAR);
                oLog.AddLineToFile(oAlSitAcc.m_dtALACC_TIMER.ToString("yyyy-MM-dd HH:mm:ss") + " - " + oAlSitAcc.m_sAL_TEXT);
                oLog.CloseFile();
            }
            catch (Exception ex)
            {
                oAlSitAcc.SetErroProcessamento(m_oParameters, ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "ServAlerta()", 500);
                m_oParameters.EnviarAlertaSituacao(910, "ProcessaAlertaSituacaoAccaoLogFile: " + ex.Message);
            }
        }

        public void ProcessaAlertaSituacaoAccaoMail(AlertaSituacaoAccao oAlSitAcc, Accao.enuTipoAccao eTipoAccao)
        {
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | (SecurityProtocolType)768 | (SecurityProtocolType)3072;
                ServAlertasSendWebmail oEmail = new ServAlertasSendWebmail(m_oParameters, eTipoAccao);

                oEmail.GetParamEspecificos(oAlSitAcc.m_oSituacaoAccao.m_oAccao.m_iACC_ID);
                oEmail.Subject += " - " + oAlSitAcc.m_oSituacaoAccao.m_iSITUACAO_ID.ToString();

                oEmail.AddLineToBody("Mensagem de alerta");
                oEmail.AddLineToBody("Situação:" + oAlSitAcc.m_oSituacaoAccao.m_iSITUACAO_ID.ToString() + " - " + oAlSitAcc.m_oSituacaoAccao.m_sSITUACAO_DESC);
                oEmail.AddLineToBody("Ocorreu em : " + oAlSitAcc.m_dtALACC_TIMER.ToString("yyyy-MM-dd HH:mm:ss"));
                oEmail.AddLineToBody(oAlSitAcc.m_sAL_VARCHAR);
                oEmail.AddLineToBody(oAlSitAcc.m_sAL_TEXT);

                oEmail.Send();
            }
            catch (Exception ex)
            {
                oAlSitAcc.SetErroProcessamento(m_oParameters, ex.Message);
                GenericLog.GenLogRegistarErro(ref ex, "ServAlerta()", 500);
                m_oParameters.EnviarAlertaSituacao(910, "ProcessaAlertaSituacaoAccaoMail: " + ex.Message);
            }
        }
    }
}
