﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CIActividades
{
    public class ListViewSacoDetalhe
    {
        public String m_cREM_PAIS;
        public Int16 m_iREM_BANCO;
        public Int16 m_iREM_BALCAO;
        public Int32 m_iDeposito; // REM_SEQUENCIA
        public Int32 m_Estado_ID;
        public String  m_Estado;
        public DateTime m_dtREM_DATA;
        public String m_sREM_OPERADOR;
        public Int64 m_iRemessa; // [REM_NUMERO]
        public Int16 m_iREM_TIPO_ID;
        public String m_iREM_TIPO_Desc;
        public String m_cREM_APLICACAO;
        public Int32 m_iREM_QT_DOCS;
        public Double m_fREM_MT_DOCS;
        public String m_sREM_NIB;
        public String m_cZIB; // [DOC_ZONA5]
        public String m_cNUM_CONTA; // [DOC_ZONA4]
        public String m_cNUM_CHEQUE; //[DOC_ZONA3]
        public Double m_fCHEQUE_MONTANTE; //[DOC_ZONA2]
        public String m_cTIPO_CHEQU; // [DOC_ZONA1]
        public DateTime m_dtDOC_DATADIGIT;
        public Int32 m_iDOC_NSEQ;
        public Int32 m_iDOC_MAQUINA;
        public String TP_REGISTO;

        private void InitVars()
        {
            m_cREM_PAIS = "";
            m_dtREM_DATA = DateTime.MinValue;
            m_sREM_OPERADOR = "";
            m_cREM_APLICACAO = "";
            m_Estado = "";
            m_sREM_NIB = "";
            m_cZIB = "";
            m_cNUM_CONTA = "";
            m_cNUM_CHEQUE = "";
            m_cTIPO_CHEQU = "";
            m_dtDOC_DATADIGIT = DateTime.MinValue;
            TP_REGISTO = "";
            m_iREM_TIPO_Desc = "";
        }

        public ListViewSacoDetalhe(SqlDataReader dr)
        {
            InitVars();
            m_cREM_PAIS = Convert.ToString(dr["REM_PAIS"]);
            m_iREM_BANCO = Convert.ToInt16(dr["REM_BANCO"]);
            m_iREM_BALCAO = Convert.ToInt16(dr["REM_BALCAO"]);
            m_iDeposito = Convert.ToInt32(dr["REM_SEQUENCIA"]);
            this.m_Estado_ID = Convert.ToInt32(dr["STATUS_ID"]);
            m_Estado = Convert.ToString(dr["NM_SACO_STATUS"]);
            m_dtREM_DATA = Convert.ToDateTime(dr["REM_DATA"]);
            m_sREM_OPERADOR = Convert.ToString(dr["REM_OPERADOR"]);
            m_iRemessa = Convert.ToInt64(dr["REM_NUMERO"]);
            m_iREM_TIPO_ID = Convert.ToInt16(dr["REM_TIPO_ID"]);
            m_cREM_APLICACAO = Convert.ToString(dr["REM_APLICACAO"]);
            m_iREM_QT_DOCS = Convert.ToInt32(dr["REM_QT_DOCS"]);
            m_fREM_MT_DOCS = Convert.ToDouble(dr["REM_MT_DOCS"]);
            m_sREM_NIB = Convert.ToString(dr["REM_NIB"]);
            m_cZIB = Convert.ToString(dr["DOC_ZONA5"]);
            m_cNUM_CONTA = Convert.ToString(dr["DOC_ZONA4"]);
            m_cNUM_CHEQUE = Convert.ToString(dr["DOC_ZONA3"]);
            m_fCHEQUE_MONTANTE = Convert.ToDouble(dr["DOC_ZONA2"]);
            m_cTIPO_CHEQU = Convert.ToString(dr["DOC_ZONA1"]);
            m_dtDOC_DATADIGIT = Convert.ToDateTime(dr["DOC_DATADIGIT"]);
            m_iDOC_NSEQ = Convert.ToInt32(dr["DOC_NSEQ"]);
            m_iDOC_MAQUINA = Convert.ToInt32(dr["DOC_MAQUINA"]);
            TP_REGISTO = Convert.ToString(dr["TP_REGISTO"]);
            m_iREM_TIPO_Desc = Convert.ToString(dr["REMTIPOBALCAO_ABR"]);
        }

        public ListViewItem MakeListViewItem(string sDateFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_cREM_PAIS.ToString();
            olvItem.SubItems.Add(m_iREM_BANCO.ToString());
            olvItem.SubItems.Add(m_iREM_BALCAO.ToString("0000"));
            olvItem.SubItems.Add(m_iDeposito.ToString("0000000"));
            olvItem.SubItems.Add(m_Estado.ToString());            
            olvItem.SubItems.Add(m_dtREM_DATA.ToString(sDateFormat));
            olvItem.SubItems.Add(m_sREM_OPERADOR.ToString());
            olvItem.SubItems.Add(m_iRemessa.ToString("000000"));
            olvItem.SubItems.Add(m_iREM_TIPO_ID.ToString() + " - " + m_iREM_TIPO_Desc);
            olvItem.SubItems.Add(m_cREM_APLICACAO.ToString());
            olvItem.SubItems.Add(m_iREM_QT_DOCS.ToString());
            string montanteToInsert = this.m_fREM_MT_DOCS.ToString().Equals("0") ? this.m_fREM_MT_DOCS.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.m_fREM_MT_DOCS).PadLeft(16, ' ');            
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(m_sREM_NIB.PadLeft(13, '0'));
            olvItem.SubItems.Add(m_cZIB.ToString());
            olvItem.SubItems.Add(m_cNUM_CONTA.ToString());
            olvItem.SubItems.Add(m_cNUM_CHEQUE.ToString());
            montanteToInsert = this.m_fCHEQUE_MONTANTE.ToString().Equals("0") ? this.m_fCHEQUE_MONTANTE.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.m_fCHEQUE_MONTANTE).PadLeft(16, ' ');
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(m_cTIPO_CHEQU);
            olvItem.SubItems.Add(m_dtDOC_DATADIGIT.ToString(sDateFormat));
            olvItem.SubItems.Add(m_iDOC_NSEQ.ToString());
            olvItem.SubItems.Add(m_iDOC_MAQUINA.ToString());
           

            return olvItem;
        }
    }
}