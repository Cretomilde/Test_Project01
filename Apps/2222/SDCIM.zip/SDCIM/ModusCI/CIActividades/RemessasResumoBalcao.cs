﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CIActividades
{
    class RemessasResumoBalcao
    {
        public DateTime m_dtREMPROC_DATA;
        public DateTime m_dtREMIN_DATA;
        public int m_iREMINSTAT_ID;
        public string m_sREMINSTAT_ABR;
        public int m_iREMIN_QT;
        public int m_iREMIN_QT_DOCS;
        public decimal m_dREMIN_MT_DOCS;
        public int m_iLOTEENV_CGDERROR;
        public string descricaoTipoRemessa;
        public int tpRemessaID;

        private void InitVars()
        {
            m_dtREMPROC_DATA = DateTime.MinValue;
            m_dtREMIN_DATA = DateTime.MinValue;
            m_iREMINSTAT_ID = -1;
            m_sREMINSTAT_ABR = "";
            m_iREMIN_QT = 0;
            m_iREMIN_QT_DOCS = 0;
            m_dREMIN_MT_DOCS = 0;
            m_iLOTEENV_CGDERROR = 0;
            this.descricaoTipoRemessa = "";
            this.tpRemessaID = 0;

        }

        public RemessasResumoBalcao()
        {
            InitVars();
        }

        public RemessasResumoBalcao(SqlDataReader dr)
            : base()
        {
            InitVars();
            m_dtREMPROC_DATA = Convert.ToDateTime(dr["REMPROC_DATA"]);
            m_dtREMIN_DATA = Convert.ToDateTime(dr["REMIN_DATA"]);
            m_iREMINSTAT_ID = Convert.ToInt32(dr["REMINSTAT_ID"]);
            m_sREMINSTAT_ABR = Convert.ToString(dr["REMINSTAT_ABR"]);
            m_iREMIN_QT = Convert.ToInt32(dr["REMIN_QT"]);
            m_iREMIN_QT_DOCS = Convert.ToInt32(dr["REMIN_QT_DOCS"]);
            m_dREMIN_MT_DOCS = Convert.ToDecimal(dr["REMIN_MT_DOCS"]);
            m_iLOTEENV_CGDERROR = Convert.ToInt16(dr["LOTEENV_CGDERROR"]);
            descricaoTipoRemessa = Convert.ToString(dr["REMTIPOBALCAO_DESC"]);
            tpRemessaID = Convert.ToInt16(dr["REMBALCAO_TIPO_BALCAO_ID"]);
        }

        public ListViewItem MakeListViewItemResumoRemessasBalcao(string sDateFormat)
        {
            ListViewItem olvItem = new ListViewItem();
            olvItem.Text = m_dtREMPROC_DATA.ToString(sDateFormat);
            olvItem.SubItems.Add(m_dtREMIN_DATA.ToString(sDateFormat));
            olvItem.SubItems.Add(m_iREMINSTAT_ID.ToString() + " " + m_sREMINSTAT_ABR);
            olvItem.SubItems.Add(tpRemessaID.ToString() + " - " + descricaoTipoRemessa.ToString());
            olvItem.SubItems.Add(m_iREMIN_QT.ToString().PadLeft(4, ' '));
            olvItem.SubItems.Add(m_iREMIN_QT_DOCS.ToString().PadLeft(6, ' '));
            string montanteToInsert = m_dREMIN_MT_DOCS.ToString().Equals("0") ? m_dREMIN_MT_DOCS.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(m_dREMIN_MT_DOCS).PadLeft(16, ' ');
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(m_iLOTEENV_CGDERROR.ToString() == "0" ? "" : "Erro");            
            return olvItem;
        }
    }
}
