﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using CIConfigGlobalParameters;
using NBiis;

namespace CIActividades
{
    public enum TP_Registo_Saco
    {
        Deposito = 1,
        Estorno_Deposito = 2,
        Estorno_Documento = 3
    }

    public partial class SacoForm : Form
    {

        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public CIMenuInterface m_oMenuInterface;

        public SacoForm(CIConfigGP.CIGlobalParameters oParameters, CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_oMenuInterface = oMenuInterface;
        }
        private void SacoForm_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            m_oMenuInterface.sacoEnable(false);
            this.Search();
        }

        private void buttonPesquisa_Click(object sender, EventArgs e)
        {
            this.Search();
        }

        private void Search()
        {
            string padleft = "";
            if (this.textBoxBalcao.Text.Length > 0 && this.textBoxBalcao.Text.Length < 4)
            {
                padleft = textBoxBalcao.Text.PadLeft(4, '0');
                this.textBoxBalcao.Text = padleft;
            }
            this.listViewResultDeposito.MyClear();
            this.listViewResultEstornoDeposito.MyClear();
            this.listViewResultEstornoDocumento.MyClear();
            String sfiltros = this.filtros();
            this.RefreshListas(sfiltros);
        }

        private String filtros()
        {
            String whereClause = "";

            whereClause = " REM_DATA >='" + dtpBeginDate.Value.ToString(m_oParameters.DateSysFmt) + "'";
            whereClause += " AND REM_DATA <='" + dtpEndDate.Value.ToString(m_oParameters.DateSysFmt) + "'";
            if (textBoxBalcao.Text != "")
            {
                whereClause += " AND REM_BALCAO = " + textBoxBalcao.Text;
            }

            if (textBoxDeposito.Text != "")
            {
                if (whereClause != "")
                    whereClause += " AND ";
                whereClause += " REM_SEQUENCIA = " + textBoxDeposito.Text;
            }

            if (textBoxRemessa.Text != "")
            {
                if (whereClause != "")
                    whereClause += " AND ";
                whereClause += " REM_NUMERO = " + textBoxRemessa.Text;
            }

            if (whereClause.Length > 0)
                return " WHERE " + whereClause;
            else
                return whereClause;
        }

        private void RefreshListas(String whereClause)
        {
            SqlDataReader dr = null;
            String sQuery = "SELECT saco.[REM_PAIS], saco.[REM_BANCO], saco.[REM_BALCAO], saco.[REM_SEQUENCIA], sacoEstado.ID AS 'STATUS_ID', sacoEstado.[NM_SACO_STATUS], saco.[REM_DATA], saco.[REM_OPERADOR], saco.[REM_NUMERO], saco.[REM_APLICACAO], saco.[REM_TIPO_ID], saco.[REM_QT_DOCS], saco.[REM_MT_DOCS], saco.[REM_NIB], saco.[DOC_ZONA5], saco.[DOC_ZONA4], saco.[DOC_ZONA3], saco.[DOC_ZONA2], saco.[DOC_ZONA1], saco.[DOC_DATADIGIT], saco.[DOC_NSEQ], saco.[DOC_MAQUINA], saco.[TP_REGISTO], RemTipoBalc.REMTIPOBALCAO_ABR";
            String tableQuery = " FROM dbo.SACO_DEP_REM as saco ";
            sQuery += tableQuery;
            sQuery += "inner join [dbo].[SACO_STATUS] as sacoEstado on sacoEstado.ID  = saco.REM_STATUS_ID";
            sQuery += " LEFT JOIN [dbo].[REMESSA_TIPO_BALCAO] as RemTipoBalc ON  saco.[REM_TIPO_ID] = RemTipoBalc.REMTIPOBALCAO_ID";
            sQuery += whereClause;
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    switch (Convert.ToInt32(dr["TP_REGISTO"]))
                    {
                        case 1:
                            ListViewSacoDetalhe oSd = new ListViewSacoDetalhe(dr);
                            ListViewItem olvItem = oSd.MakeListViewItem(m_oParameters.DateFormat);
                            olvItem.Tag = oSd;
                            listViewResultDeposito.Items.Add(olvItem);
                            break;
                        case 2:
                            ListViewEstornoDeposito oEdp = new ListViewEstornoDeposito(dr);
                            ListViewItem olvItem2 = oEdp.MakeListViewItem(m_oParameters.DateFormat);
                            olvItem2.Tag = oEdp;
                            listViewResultEstornoDeposito.Items.Add(olvItem2);
                            break;
                        case 3:
                            ListViewEstornoDocumento oEdc = new ListViewEstornoDocumento(dr);
                            ListViewItem olvItem3 = oEdc.MakeListViewItem(m_oParameters.DateFormat);
                            olvItem3.Tag = oEdc;
                            listViewResultEstornoDocumento.Items.Add(olvItem3);
                            break;
                    }
                }
                this.lblCountListViewEstornoDocumento.Text = listViewResultEstornoDocumento.Items.Count == 0 ? "Estorno Documento" :
                                                    listViewResultEstornoDocumento.Items.Count.ToString() + " Estorno Documento";
                this.lblCountListViewDepositos.Text = listViewResultDeposito.Items.Count == 0 ? "Depósito" :
                                                    listViewResultDeposito.Items.Count.ToString() + " Depósito";
                this.lblListViewEstornoDeposito.Text = listViewResultEstornoDeposito.Items.Count == 0 ? "Estorno Depósito" :
                                                     listViewResultEstornoDeposito.Items.Count.ToString() + " Estorno Depósito";
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "RefreshListas()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
            }
        }
       
        private void textBoxBalcao_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBoxBalcao.Text, "[^0-9]"))
            {
                MessageBox.Show("Campo numérico");
                textBoxBalcao.Text.Remove(textBoxBalcao.Text.Length - 1);
                textBoxBalcao.Text = "";
            }
            if (textBoxBalcao.Text.Length >= 4)
            {
                textBoxBalcao.MaxLength = 4;
            }
        }

        private void textBoxDeposito_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBoxDeposito.Text, "[^0-9]"))
            {
                MessageBox.Show("Campo numérico");
                textBoxDeposito.Text.Remove(textBoxDeposito.Text.Length - 1);
                textBoxDeposito.Text = "";
            }
            if (textBoxDeposito.Text.Length >= 7)
            {
                textBoxDeposito.MaxLength = 7;
            }
        }

        private void textBoxRemessa_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBoxRemessa.Text, "[^0-9]"))
            {
                MessageBox.Show("Campo numérico");
                textBoxRemessa.Text.Remove(textBoxRemessa.Text.Length - 1);
                textBoxRemessa.Text = "";
            }
            if (textBoxRemessa.Text.Length >= 6)
            {
                textBoxRemessa.MaxLength = 6;
            }
        }   

        private void toolStripButtonExitJanela_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void SacoForm_Leave(object sender, EventArgs e)
        {
            this.m_oMenuInterface.sacoEnable(true);
        }  
    }
}