﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
using CIConfigGlobalParameters;
using NBiis;
using NBiis.Generic;

namespace CIActividades
{
    public enum Tipo_Agrupador
    {
        Balcao_E_TipoRemessa = 1,
        Balcao_E_Remessa = 2,
        Balcao_E_Deposito = 3,
        Balcao_E_Documento = 4
    }

    public partial class ControloBalcaoAcoes : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public CIMenuInterface m_oMenuInterface;

        #region Variables

        //FILTROS
        private Int32 _filtro_TipoAgrupador;
        private Int32 _filtro_Balcao;
        private Int32 _filtro_TipoRemessa;
        private Int32 _filtro_Remessa;
        private Int32 _filtro_Deposito;
        private Int32 _updateRowsInList = 0;

        #endregion Variables
        private Boolean _IsLoad = true;
        private const String _SP_CONFIRMA_CANCELAMENTO_AGR_ = "[dbo].[Update_ConfirmaTibcoCancelaEnvioDocumentoAGR]";
        private const String _SP_ANULA_CANCELAMENTO_AGR_ = "[dbo].[Delete_TibcoCancelaEnvioDocumentoAGR]";
        private const String _SP_CONFIRMA_NOTIFICACAO_AGR_ = "[dbo].[Update_ConfirmaTibcoNotificaEnvioDocumentoForaPrazoAGR]";
        private const String _SP_ANULA_NOTIFICACAO_AGR_ = "[dbo].[Delete_TibcoNotificaEnvioDocumentoForaPrazoAGR]";

        public ControloBalcaoAcoes(CIConfigGP.CIGlobalParameters oParameters, CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_oMenuInterface = oMenuInterface;
        }

        private void ControloBalcaoAcoes_Load(object sender, EventArgs e)
        {
            FillComboBoxTipoRemessa();
            RefreshListAnalise();
            this._filtro_TipoAgrupador = 0;
            this._filtro_Balcao = 0;
            this._filtro_TipoRemessa = 0;
            this._filtro_Remessa = 0;
            this._filtro_Deposito = 0;
            this.WindowState = FormWindowState.Maximized;
            this._IsLoad = false;
            this._updateRowsInList = 0;
            m_oMenuInterface.controloBalcaoAcoesEnable(false);
        }

        private void FillComboBoxTipoRemessa()
        {
            DataSet ds = null;

            if (comboBoxTipoRemessa.Items.Count == 0)
            {
                try
                {
                    String query = "SELECT [REMTIPOBALCAO_ID], CAST([REMTIPOBALCAO_ID] AS VARCHAR(2)) + ' - ' + [REMTIPOBALCAO_ABR] AS 'REMTIPOBALCAO_ABR' FROM [dbo].[REMESSA_TIPO_BALCAO]";
                    ds = m_oParameters.DirectSqlDataSet(query, "REMESSA_TIPO_BALCAO");
                    if (ds != null)
                    {
                        DataRow dr = ds.Tables["REMESSA_TIPO_BALCAO"].NewRow();
                        dr["REMTIPOBALCAO_ID"] = "0";
                        dr["REMTIPOBALCAO_ABR"] = "Todos";
                        ds.Tables["REMESSA_TIPO_BALCAO"].Rows.InsertAt(dr, 0);
                        comboBoxTipoRemessa.DataSource = ds.Tables["REMESSA_TIPO_BALCAO"];
                        comboBoxTipoRemessa.ValueMember = "REMTIPOBALCAO_ID";
                        comboBoxTipoRemessa.DisplayMember = "REMTIPOBALCAO_ABR";
                    }
                    else
                    {
                        MessageBox.Show("Não foi possível carregar os Tipos de Remessa.");
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Erro ao carregar os Tipos de Remessa. " + e.Message);
                }
                finally
                {
                    if (ds != null)
                    {
                        ds.Dispose();
                        ds = null;
                    }
                }
            }
        }

        #region ButtonsEvents

        private void buttonRefreshCompensacao_Click(object sender, EventArgs e)
        {
            this.RefreshListCompensacao();
            this.ShowCancelamentoENotificacaoButtons();
        }

        private void buttonRefreshAnalise_Click(object sender, EventArgs e)
        {
            this.RefreshListAnalise();
        }

        private void buttonNotificaAcolhimentoForaPrazo_Click(object sender, EventArgs e)
        {
            this.Insert_Notificacao();
        }

        private void buttonCancelamentoAcolhimento_Click(object sender, EventArgs e)
        {
            this.Insert_Cancelamento();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this._updateRowsInList = 0;
            this.labelRegistoEmAnalise.Text = "Registos em análise";
            this.lblRegEnviados.Text = "Registos enviados à compensação";
            this._filtro_TipoAgrupador = 0;
            this._filtro_Balcao = 0;
            this._filtro_TipoRemessa = 0;
            this._filtro_Remessa = 0;
            this._filtro_Deposito = 0;
            this.comboBoxTipoRemessa.SelectedIndex = 0;
            this.textBoxBalcao.Text = String.Empty;
            this.textBoxRemessa.Text = String.Empty;
            this.textBoxDeposito.Text = String.Empty;
            this.textBoxRemessa.Enabled = false;
            this.textBoxDeposito.Enabled = false;
            this.dateTimePickerAte.Value = DateTime.Now.Date;
            this.dateTimePickerDe.Value = DateTime.Now.Date;
            this.buttonCancelamentoAcolhimento.Enabled = false;
            this.buttonNotificaAcolhimentoForaPrazo.Enabled = false;
            this.listViewRegistosCompensacao.MyClear();
            this.RefreshListAnalise();
        }

        #endregion ButtonsEvents

        #region TextBoxEvents
        private void textBoxRemessa_Leave(object sender, EventArgs e)
        {
            this.ResetScreen();
            this.PaddTextbox(this.textBoxRemessa, 6, '0');
            this.EnableTxtFiltros();
        }

        private void textBoxDeposito_Leave(object sender, EventArgs e)
        {
            this.ResetScreen();
            this.PaddTextbox(this.textBoxDeposito, 7, '0');
        }

        private void textBoxBalcao_Leave(object sender, EventArgs e)
        {
            this.ResetScreen();
            this.PaddTextbox(this.textBoxBalcao, 4, '0');
            this.EnableTxtFiltros();
        }

        private void textBoxBalcao_TextChanged(object sender, EventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (!FieldIsNumeric(tb.Text))
            {
                textBoxBalcao.Text = textBoxBalcao.Text.Remove(textBoxBalcao.Text.Length - 1);
            }
        }

        private Boolean FieldIsNumeric(String text)
        {
            int result = 0;
            if (int.TryParse(text, out result) || text.Equals(""))
                return true;
            else
                return false;
        }

        /// <summary>
        /// Define se o filtro seguinte ficará disponível ou não para edição.
        /// Só se pode pesquisar por remessa se tivermos o balcão preenchido e por depósito se tivermos a remessa preenchida.
        /// </summary>
        private void EnableTxtFiltros()
        {
            if (!String.IsNullOrEmpty(this.textBoxBalcao.Text))
            {
                this.textBoxRemessa.Enabled = true;
            }
            else
            {
                this.textBoxRemessa.Enabled = false;
            }
            if (!String.IsNullOrEmpty(this.textBoxRemessa.Text))
            {
                this.textBoxDeposito.Enabled = true;
            }
            else
            {
                this.textBoxDeposito.Enabled = false;
            }
        }

        private void PaddTextbox(TextBox txtBox, Int32 padNumber, Char padChar)
        {
            if (!txtBox.Text.Trim().Equals(String.Empty))
                txtBox.Text = txtBox.Text.Trim().PadLeft(padNumber, padChar);
        }

        private void textBoxDeposito_TextChanged(object sender, EventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (!FieldIsNumeric(tb.Text))
            {
                textBoxDeposito.Text = textBoxDeposito.Text.Remove(textBoxDeposito.Text.Length - 1);
            }
        }

        private void textBoxRemessa_TextChanged(object sender, EventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (!FieldIsNumeric(tb.Text))
            {
                textBoxRemessa.Text = textBoxRemessa.Text.Remove(textBoxRemessa.Text.Length - 1);
            }
        }

        #endregion TextBoxEvents

        #region cbEvents

        private void comboBoxTipoRemessa_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!this._IsLoad)
                this.ResetScreen();
        }
        #endregion cbEvents

        #region ToolStripEvents

        private void ControloBalcaoAcoes_Click(object sender, EventArgs e)
        {
            if (!_IsLoad)
            {
                this.EnableTxtFiltros();
            }
        }

        private void contextMenuStripAnalise_Opening(object sender, CancelEventArgs e)
        {
            if (this.listViewRegistosAnalise.SelectedItems.Count < 1)
            {
                EnabledMenuStripAnalise(false, null);
            }
            else
            {
                EnabledMenuStripAnalise(true, ((ListViewAgregacaoBalcaoAcoes)listViewRegistosAnalise.SelectedItems[0].Tag));
            }
        }

        private void EnabledMenuStripAnalise(Boolean enabled, ListViewAgregacaoBalcaoAcoes balcaoAccao)
        {
            if (balcaoAccao == null)
            {
                this.confirmaCancelamentoDeAcolhimentoToolStripMenuItem.Enabled = enabled;
                this.confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Enabled = enabled;
                this.anulaCancelamentoDeAcolhimentoToolStripMenuItem.Enabled = enabled;
                this.anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Enabled = enabled;
            }
            else
            {
                if (balcaoAccao.sTipoAccao.Equals("Cancelamento"))
                {
                    this.confirmaCancelamentoDeAcolhimentoToolStripMenuItem.Enabled = enabled;
                    this.anulaCancelamentoDeAcolhimentoToolStripMenuItem.Enabled = enabled;
                    this.confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Enabled = !enabled;
                    this.anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Enabled = !enabled;
                }
                else
                {
                    this.confirmaCancelamentoDeAcolhimentoToolStripMenuItem.Enabled = !enabled;
                    this.anulaCancelamentoDeAcolhimentoToolStripMenuItem.Enabled = !enabled;
                    this.confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Enabled = enabled;
                    this.anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Enabled = enabled;
                }
            }
        }

        private void confirmaCancelamentoDeAcolhimentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewRegistosAnalise.SelectedItems.Count < 1)
                return;
            try
            {
                for (int i = 0; i < listViewRegistosAnalise.SelectedItems.Count; i++)
                {
                    Int32 iAgregacaoID = ((ListViewAgregacaoBalcaoAcoes)listViewRegistosAnalise.SelectedItems[i].Tag).iAgregacaoID;
                    this.Confirm_TibcoCancelaEnvioDocumento(iAgregacaoID);
                    GenericLog.GenLogRegistarInfo("Confirmado o Cancelamento DocACOM", "confirmaCancelamentoDeAcolhimentoToolStripMenuItem_Click()", iAgregacaoID);
                }
                MessageBox.Show(this, "Cancelamento de Acolhimento confirmado.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "confirmaCancelamentoDeAcolhimentoToolStripMenuItem_Click()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.RefreshLists();
            }
        }

        private void anulaCancelamentoDeAcolhimentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewRegistosAnalise.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewRegistosAnalise.SelectedItems.Count; i++)
                {
                    Int32 iAgregacaoID = ((ListViewAgregacaoBalcaoAcoes)listViewRegistosAnalise.SelectedItems[i].Tag).iAgregacaoID;
                    this.Delete_TibcoCancelaEnvioDocumento(iAgregacaoID);
                    GenericLog.GenLogRegistarInfo("Anulado o Cancelamento DocACOM", "anulaCancelamentoDeAcolhimentoToolStripMenuItem_Click()", iAgregacaoID);
                }
                MessageBox.Show(this, "Cancelamento de Acolhimento anulado.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "anulaCancelamentoDeAcolhimentoToolStripMenuItem_Click()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.RefreshLists();
            }
        }

        private void confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewRegistosAnalise.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewRegistosAnalise.SelectedItems.Count; i++)
                {
                    Int32 iAgregacaoID = ((ListViewAgregacaoBalcaoAcoes)listViewRegistosAnalise.SelectedItems[i].Tag).iAgregacaoID;
                    this.Confirm_TibcoNotificaEnvioDocumentoForaPrazo(iAgregacaoID);
                    GenericLog.GenLogRegistarInfo("DocACOM Notifica Confirma", "confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem_Click()", iAgregacaoID);
                }
                MessageBox.Show(this, "Notificação de envio de documentos fora de prazo confirmado.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem_Click()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.RefreshLists();
            }
        }

        private void anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewRegistosAnalise.SelectedItems.Count < 1)
                return;

            try
            {
                for (int i = 0; i < listViewRegistosAnalise.SelectedItems.Count; i++)
                {
                    Int32 iAgregacaoID = ((ListViewAgregacaoBalcaoAcoes)listViewRegistosAnalise.SelectedItems[i].Tag).iAgregacaoID;
                    this.Delete_TibcoNotificaEnvioDocumentoForaPrazo(iAgregacaoID);
                    GenericLog.GenLogRegistarInfo("DocACOM Notifica Anula", "anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem_Click()", iAgregacaoID);
                }
                MessageBox.Show(this, "Notificação de envio de documentos fora de prazo anulado.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem_Click()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.RefreshLists();
            }
        }

        #endregion ToolStripEvents

        #region DatePickersEvents
        private void dateTimePickerDe_ValueChanged(object sender, EventArgs e)
        {
            this.ResetScreen();
        }

        private void dateTimePickerAte_ValueChanged(object sender, EventArgs e)
        {
            this.ResetScreen();
        }
        #endregion DatePickersEvents

        private void ShowCancelamentoENotificacaoButtons()
        {
            this.buttonCancelamentoAcolhimento.Enabled = false;
            this.buttonNotificaAcolhimentoForaPrazo.Enabled = false;
            DateTime fromDate = dateTimePickerDe.Value;
            DateTime toDate = dateTimePickerAte.Value;
            Int16 differenceBetweenDates = Convert.ToInt16((toDate - fromDate).TotalDays);
            if (textBoxBalcao.Text != "" && comboBoxTipoRemessa.Text != "Todos"
                && differenceBetweenDates == 0 && this.listViewRegistosCompensacao.Items.Count > 0)
            {
                buttonCancelamentoAcolhimento.Enabled = true;
                buttonNotificaAcolhimentoForaPrazo.Enabled = true;
                this.lblRegEnviados.Text = this.listViewRegistosCompensacao.Items.Count + " Registos enviados à compensação";
            }
        }

        private void ResetScreen()
        {
            this.buttonCancelamentoAcolhimento.Enabled = false;
            this.buttonNotificaAcolhimentoForaPrazo.Enabled = false;
        }

        /// <summary>
        /// Método que executa o carregamento em simultâneo das duas listas
        /// </summary>
        private void RefreshLists()
        {
            this.RefreshListAnalise();
            this.RefreshListCompensacao();
            this.ShowCancelamentoENotificacaoButtons();
        }

        private String Filtros()
        {
            String whereClause = "";

            if (dateTimePickerDe.Value.Date != dateTimePickerAte.Value.Date)
                whereClause += " REMBALCAO_DATA >= '" + dateTimePickerDe.Value.Date.ToString("yyyy-MM-dd") + "' AND REMBALCAO_DATA <= '" + dateTimePickerAte.Value.Date.ToString("yyyy-MM-dd") + "'";
            else
                whereClause += " REMBALCAO_DATA = '" + dateTimePickerDe.Value.Date.ToString("yyyy-MM-dd") + "'";

            if (!String.IsNullOrEmpty(textBoxBalcao.Text))
            {
                whereClause += " AND BALCAO = " + textBoxBalcao.Text;
                this._filtro_Balcao = Convert.ToInt32(textBoxBalcao.Text.Trim());
            }

            if (comboBoxTipoRemessa.Text != "Todos")
            {
                whereClause += " AND REM_BALC.REMBALCAO_TIPO_BALCAO_ID = " + comboBoxTipoRemessa.SelectedValue;
                this._filtro_TipoAgrupador = (int)Tipo_Agrupador.Balcao_E_TipoRemessa;
                this._filtro_TipoRemessa = Convert.ToInt32(comboBoxTipoRemessa.SelectedValue);
            }

            if (!String.IsNullOrEmpty(textBoxRemessa.Text))
            {
                whereClause += " AND REMBALCAO_NUMERO = " + textBoxRemessa.Text;
                this._filtro_TipoAgrupador = (int)Tipo_Agrupador.Balcao_E_Remessa;
                this._filtro_Remessa = Convert.ToInt32(textBoxRemessa.Text);
            }

            if (!String.IsNullOrEmpty(textBoxDeposito.Text))
            {
                whereClause += " AND REMBALCAO_SEQUENCIA = " + textBoxDeposito.Text;
                this._filtro_TipoAgrupador = (int)Tipo_Agrupador.Balcao_E_Deposito;
                this._filtro_Deposito = Convert.ToInt32(textBoxDeposito.Text);
            }
            return whereClause;
        }

        private void RefreshListCompensacao()
        {
            this._updateRowsInList = 0;
            listViewRegistosCompensacao.MyClear();
            SqlDataReader dr = null;
            StringBuilder strBuilder = new StringBuilder();
            //strBuilder.Append("SELECT REM_BALC.REMBALCAO_DATA, REM_BALC.REMBALCAO_TIMER, VIEW_ACOM.BALCAO, REM_BALC.REMBALCAO_NUMERO, ");
            //strBuilder.Append("REM_BALC.REMBALCAO_SEQUENCIA, REM_STAT.REMINSTAT_DESC, VIEW_ACOM.DOC_ID, VIEW_ACOM.DOCACOM_ZONA5, VIEW_ACOM.DOCACOM_ZONA4, ");
            //strBuilder.Append("VIEW_ACOM.DOCACOM_ZONA3, VIEW_ACOM.DOCACOM_ZONA2, VIEW_ACOM.DOCACOM_ZONA1, REM_BALC.REMBALCAO_NIB, VIEW_ACOM.REFARQ, ");
            //strBuilder.Append("VIEW_ACOM.REFARQ_ORI, CAST(VIEW_ACOM.DOCACOM_CODANA AS VARCHAR(2)) + ' - ' + VIEW_ACOM.ESTADO_DESC AS 'DOCACOM_CODANA', ");
            //strBuilder.Append("VIEW_ACOM.DOCACOM_CANCELADO, VIEW_ACOM.CANCELA_EFECTUADO, VIEW_ACOM.CANCEL_ESTADO, ");
            //strBuilder.Append("VIEW_ACOM.CANCELA_DESCRICAO, VIEW_ACOM.CANCELA_ERRO, VIEW_ACOM.DOCACOM_NOTIFICADO, VIEW_ACOM.NOTIFICA_EFECTUADO, ");
            //strBuilder.Append("VIEW_ACOM.NOTIFICA_ESTADO, VIEW_ACOM.NOTIFICA_DESCRICAO, VIEW_ACOM.NOTIFICA_ERRO, VIEW_ACOM.DOCACOM_CHAVEH, ");
            //strBuilder.Append("REM_BALC.REMBALCAO_TIPO_ID, VIEW_ACOM.DOCACOM_ID");
            //strBuilder.Append(" FROM dbo.VW_PESQ_DOCUMENTO_ACOM VIEW_ACOM ");
            //strBuilder.Append(" INNER JOIN DOCUMENTO_BALCAO DOC_BALC ON VIEW_ACOM.DOC_ID = DOC_BALC.ID");
            //strBuilder.Append(" INNER JOIN dbo.DOCUMENTO_ACOM ACOM ON acom.DOCACOM_ID = VIEW_ACOM.DOCACOM_ID");
            //strBuilder.Append(" INNER JOIN REMESSA_BALCAO REM_BALC ON DOC_BALC.REMBALCAO_ID = REM_BALC.ID");
            //strBuilder.Append(" INNER JOIN REMESSAIN_STATUS REM_STAT ON REM_BALC.REMBALCAO_STAT_ID = REM_STAT.REMINSTAT_ID");
            //strBuilder.Append(" INNER JOIN [SIBSP_ESTADO_DOCUMENTO_ACOM] AS ACOM_EST ON ACOM.DOCACOM_CODANA = ACOM_EST.ESTADO");
            //strBuilder.Append(" WHERE ((ACOM_EST.[I_CANCELA] = 'TRUE' AND ACOM.DOCACOM_CANCELADO IS NULL OR VIEW_ACOM.CANCELA_EFECTUADO = 99) OR ");
            //strBuilder.Append(" (ACOM_EST.[I_NOTIFICA] = 'TRUE' AND ACOM.DOCACOM_NOTIFICADO IS NULL OR VIEW_ACOM.NOTIFICA_EFECTUADO = 99))");
            //strBuilder.Append(" AND ACOM.DOCACOMAGR_ID IS NULL AND VIEW_ACOM.DOC_ORIGEM_ID = 2 AND ");
            //remover 2 porque já foi recebido. só se tratam os que tiverem cancelado_id a null
            strBuilder.Append("SELECT REM_BALC.REMBALCAO_DATA, REM_BALC.REMBALCAO_TIMER, VIEW_ACOM.BALCAO, REM_BALC.REMBALCAO_NUMERO, ");
            strBuilder.Append("REM_BALC.REMBALCAO_SEQUENCIA, REM_STAT.REMINSTAT_DESC, VIEW_ACOM.DOC_ID, VIEW_ACOM.DOCACOM_ZONA5, ");
            strBuilder.Append("VIEW_ACOM.DOCACOM_ZONA4, VIEW_ACOM.DOCACOM_ZONA3, VIEW_ACOM.DOCACOM_ZONA2, VIEW_ACOM.DOCACOM_ZONA1, ");
            strBuilder.Append("REM_BALC.REMBALCAO_NIB, VIEW_ACOM.REFARQ, VIEW_ACOM.REFARQ_ORI, ");
            strBuilder.Append("CAST(VIEW_ACOM.DOCACOM_CODANA AS VARCHAR(2)) + ' - ' + VIEW_ACOM.ESTADO_DESC AS 'DOCACOM_CODANA', ");
            strBuilder.Append("VIEW_ACOM.DOCACOM_CANCELADO, VIEW_ACOM.CANCELA_EFECTUADO, VIEW_ACOM.CANCEL_ESTADO, VIEW_ACOM.CANCELA_DESCRICAO, ");
            strBuilder.Append("VIEW_ACOM.CANCELA_ERRO, VIEW_ACOM.DOCACOM_NOTIFICADO, VIEW_ACOM.NOTIFICA_EFECTUADO, VIEW_ACOM.NOTIFICA_ESTADO, ");
            strBuilder.Append("VIEW_ACOM.NOTIFICA_DESCRICAO, VIEW_ACOM.NOTIFICA_ERRO, VIEW_ACOM.DOCACOM_CHAVEH, REM_BALC.REMBALCAO_TIPO_ID, ");
            strBuilder.Append("VIEW_ACOM.DOCACOM_ID ");
            strBuilder.Append("FROM dbo.VW_PESQ_DOCUMENTO_ACOM VIEW_ACOM ");
            strBuilder.Append("INNER JOIN DOCUMENTO_BALCAO DOC_BALC ON VIEW_ACOM.DOC_ID = DOC_BALC.ID ");
            strBuilder.Append("INNER JOIN REMESSA_BALCAO REM_BALC ON DOC_BALC.REMBALCAO_ID = REM_BALC.ID ");
            strBuilder.Append("INNER JOIN REMESSAIN_STATUS REM_STAT ON REM_BALC.REMBALCAO_STAT_ID = REM_STAT.REMINSTAT_ID ");
            strBuilder.Append("INNER JOIN (SELECT MAX( VIEW_ACOM.DOCACOM_ID) AS 'DOCACOM_ID' ");
            strBuilder.Append("FROM dbo.VW_PESQ_DOCUMENTO_ACOM VIEW_ACOM ");
            strBuilder.Append("INNER JOIN DOCUMENTO_BALCAO DOC_BALC ON VIEW_ACOM.DOC_ID = DOC_BALC.ID ");
            strBuilder.Append("INNER JOIN dbo.DOCUMENTO_ACOM ACOM ON acom.DOCACOM_ID = VIEW_ACOM.DOCACOM_ID ");
            strBuilder.Append("INNER JOIN REMESSA_BALCAO REM_BALC ON DOC_BALC.REMBALCAO_ID = REM_BALC.ID ");
            strBuilder.Append("INNER JOIN [SIBSP_ESTADO_DOCUMENTO_ACOM] AS ACOM_EST ON ACOM.DOCACOM_CODANA = ACOM_EST.ESTADO ");
            strBuilder.Append("WHERE ((ACOM_EST.[I_CANCELA] = 'TRUE' AND ACOM.DOCACOM_CANCELADO IS NULL OR VIEW_ACOM.CANCELA_EFECTUADO = 99) OR ");
            strBuilder.Append("(ACOM_EST.[I_NOTIFICA] = 'TRUE' AND ACOM.DOCACOM_NOTIFICADO IS NULL OR VIEW_ACOM.NOTIFICA_EFECTUADO = 99)) AND ");
            strBuilder.Append("ACOM.DOCACOMAGR_ID IS NULL AND VIEW_ACOM.DOC_ORIGEM_ID = 2 AND ");
            strBuilder.Append(this.Filtros());
            strBuilder.Append(" group by VIEW_ACOM.DOC_ID) aux on aux.DOCACOM_ID = VIEW_ACOM.DOCACOM_ID ");            
            try
            {
                dr = m_oParameters.DirectSqlDataReader(strBuilder.ToString());
                while (dr.Read())
                {
                    AddCompensacaoListView(dr);
                }

                if (this.listViewRegistosCompensacao.Items.Count > 0)
                {
                    this.lblRegEnviados.Text = this.listViewRegistosCompensacao.Items.Count + " Registos enviados à compensação";
                    this._updateRowsInList = this.listViewRegistosCompensacao.Items.Count;
                }
                else
                {
                    this.lblRegEnviados.Text = "Registos enviados à compensação";
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "RefreshListCompensacao()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
            }
        }

        private void AddCompensacaoListView(SqlDataReader dr)
        {
            ListViewBalcaoAcoes oRr = new ListViewBalcaoAcoes(dr);
            ListViewItem olvItem = oRr.MakeListViewItemsAcoes(m_oParameters.DateFormat);
            olvItem.Tag = oRr;
            listViewRegistosCompensacao.Items.Add(olvItem);
        }

        private void RefreshListAnalise()
        {
            String filtros = Filtros();
            listViewRegistosAnalise.MyClear();
            SqlDataReader dr = null;
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.Append("SELECT DISTINCT REM_BALC.REMBALCAO_DATA, REM_BALC.REMBALCAO_TIMER, REM_BALC.REMBALCAO_BALCAO, ");
            strBuilder.Append("REM_BALC.REMBALCAO_NUMERO, REM_BALC.REMBALCAO_SEQUENCIA, REM_STAT.REMINSTAT_DESC, tp.REMTIPOBALCAO_DESC,  acom.DOCACOMAGR_ID, ");
            strBuilder.Append("(CASE WHEN acom.DOCACOM_NOTIFICADO IS NOT NULL THEN 'Notificação' ELSE 'Cancelamento' END) AS 'TIBCO' ");
            strBuilder.Append("FROM dbo.DOCUMENTO_ACOM AS acom ");
            strBuilder.Append("INNER JOIN DOCUMENTO_BALCAO AS DOC_BALC ON acom.DOC_ID = DOC_BALC.ID  ");
            strBuilder.Append("INNER JOIN REMESSA_BALCAO AS REM_BALC ON DOC_BALC.REMBALCAO_ID = REM_BALC.ID  ");
            strBuilder.Append("INNER JOIN REMESSAIN_STATUS REM_STAT ON REM_BALC.REMBALCAO_STAT_ID = REM_STAT.REMINSTAT_ID  ");
            strBuilder.Append("INNER JOIN [dbo].[DOCUMENTO_ACOM_AGR] agr ON agr.DOCACOMAGR_ID = acom.DOCACOMAGR_ID  ");
            strBuilder.Append("INNER JOIN [dbo].[REMESSA_TIPO_BALCAO] tp ON tp.REMTIPOBALCAO_ID = REM_BALC.REMBALCAO_TIPO_BALCAO_ID  ");
            strBuilder.Append("WHERE acom.DOCACOM_ORIGEM_ID = 2 ");
            strBuilder.Append("ORDER BY DOCACOMAGR_ID ASC");
            try
            {
                dr = m_oParameters.DirectSqlDataReader(strBuilder.ToString());
                while (dr.Read())
                {
                    AddAnaliseListView(dr);
                }
                if (this.listViewRegistosAnalise.Items.Count > 0)
                {
                    this.labelRegistoEmAnalise.Text = this.listViewRegistosAnalise.Items.Count + " Registos em análise";
                }
                else
                {
                    this.labelRegistoEmAnalise.Text = "Registos em análise";
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "RefreshListAnalise()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
            }
        }

        private void AddAnaliseListView(SqlDataReader dr)
        {
            ListViewAgregacaoBalcaoAcoes oRr = new ListViewAgregacaoBalcaoAcoes(dr);
            ListViewItem olvItem = oRr.MakeListViewItemsAcoes(m_oParameters.DateFormat);
            olvItem.Tag = oRr;
            listViewRegistosAnalise.Items.Add(olvItem);
        }

        private void Confirm_TibcoCancelaEnvioDocumento(Int32 idAgregacao)
        {
            this.ExecuteSPAgregacoes(idAgregacao, _SP_CONFIRMA_CANCELAMENTO_AGR_);
        }

        private void Delete_TibcoCancelaEnvioDocumento(Int32 idAgregacao)
        {
            this.ExecuteSPAgregacoes(idAgregacao, _SP_ANULA_CANCELAMENTO_AGR_);
        }

        private void Confirm_TibcoNotificaEnvioDocumentoForaPrazo(Int32 idAgregacao)
        {
            this.ExecuteSPAgregacoes(idAgregacao, _SP_CONFIRMA_NOTIFICACAO_AGR_);
        }

        private void Delete_TibcoNotificaEnvioDocumentoForaPrazo(Int32 idAgregacao)
        {
            this.ExecuteSPAgregacoes(idAgregacao, _SP_ANULA_NOTIFICACAO_AGR_);
        }

        /// <summary>
        /// Executa SP de anulação ou confirmação de agregação.
        /// </summary>
        /// <param name="idAgregacao">ID de agregação a executar acção</param>
        /// <param name="spName">Procedimento a executar</param>
        private void ExecuteSPAgregacoes(Int32 idAgregacao, String spName)
        {
            ArrayList oParamsAgreg = new ArrayList();
            oParamsAgreg.Add(new GeneralDBParameters("@AGREGAGACAO_ID_IN", idAgregacao));
            m_oParameters.DirectStoredProcedureNonQuery(spName, ref oParamsAgreg);
        }

        private void Insert_Notificacao()
        {
            this.Insert_DocumentosAcomAgregador(false);
        }

        private void Insert_Cancelamento()
        {
            this.Insert_DocumentosAcomAgregador(true);
        }

        /// <summary>
        /// Método que invoca SP para inserção de registos nas tabelas TIBCO
        /// Insere em TIBCO_CANCELA_ENVIO_DOCUMENTO ou TIBCO_NOTIFICA_ENVIO_DOCUMENTO_FORA_PRAZO      
        /// </summary>
        /// <param name="iCancelamento">TRUE para TIBCO_CANCELA_ENVIO_DOCUMENTO, FALSE para TIBCO_NOTIFICA_ENVIO_DOCUMENTO_FORA_PRAZO</param>
        private void Insert_DocumentosAcomAgregador(Boolean iCancelamento)
        {
            try
            {
                ArrayList oParams = new ArrayList();
                if (_filtro_Balcao != 0)
                    oParams.Add(new GeneralDBParameters("@Balcao_IN", this._filtro_Balcao));
                if (_filtro_Remessa != 0)
                    oParams.Add(new GeneralDBParameters("@Remessa_Numero_Balcao_IN", this._filtro_Remessa));
                if (_filtro_Deposito != 0)
                    oParams.Add(new GeneralDBParameters("@Remessa_Sequencia_Balcao_IN", this._filtro_Deposito));
                if (_filtro_TipoRemessa != 0)
                    oParams.Add(new GeneralDBParameters("@TipoRemessa_Balcao_IN", this._filtro_TipoRemessa));
                oParams.Add(new GeneralDBParameters("@TipoAgregador_IN", this._filtro_TipoAgrupador));
                oParams.Add(new GeneralDBParameters("@Operador_IN", m_oParameters.UserLogged.m_sUserName));
                oParams.Add(new GeneralDBParameters("@Remessa_Data_IN", this.dateTimePickerDe.Value.Date.ToString("yyyy-MM-dd")));
                if (iCancelamento)
                    oParams.Add(new GeneralDBParameters("@ICancelamento_IN", true));
                else
                    oParams.Add(new GeneralDBParameters("@ICancelamento_IN", false));
                object retRows = m_oParameters.DirectStoredProcedureScalar("[dbo].[Insert_All_Documentos_Acom_Agr]", ref oParams);
                Int32 updatedRows = Convert.ToInt32(retRows);
                this.ShowResultMessage(iCancelamento, updatedRows);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "RefreshLists()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.RefreshLists();
            }
        }

        private void ShowResultMessage(Boolean iCancelamento, Int32 updatedRows)
        {
            String tipo = "o seu cancelamento";
            if (updatedRows > 0)
            {
                tipo = "cancelamento";
                if (!iCancelamento)
                {
                    tipo = "notificação fora de prazo";
                }
                MessageBox.Show(this, String.Format("Foram inseridos {0} documentos para {1}.", this._updateRowsInList, tipo), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if (!iCancelamento)
                {
                    tipo = "a sua notificação fora de prazo";
                }
                MessageBox.Show(this, String.Format("O estado dos documentos não permite {0}.", tipo), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
