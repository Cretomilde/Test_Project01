﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CIActividades
{
    public class PesquisaDocumentoACOM
    {
        public string m_sFICH_ID;
        public string m_sFICH_NSEQ;
        public DateTime m_dtFICH_DATA;

        public string m_sLOTEACOM_ID;
        public string m_sLOTEACOM_NUMERO;
        public string m_sLOTEACOM_PRODUTO;
        public DateTime m_dtLOTEACOM_DATAPROC;
        public string m_sLOTESTATUS_ID;
        public string m_sLOTESTAT_ABR;

        public string m_sDOCACOM_ID;
        public string m_sDOCACOM_ZONA5;
        public string m_sDOCACOM_ZONA4;
        public string m_sDOCACOM_ZONA3;
        public string m_sDOCACOM_ZONA2;
        public decimal m_dDOCACOM_IMPORT;
        public string m_sDOCACOM_ZONA1;
        public string m_sREFARQ;
        public string m_sDOCACOM_REFARQ2;
        public string m_sDOCACOM_BALCAO;
        public string m_sDOCACOM_CODANA;
        public string m_sDOCACOM_CANCELADO;
        public string m_sCANCEL_ESTADO;
        public string m_sCANCELA_ERRO;
        public string m_sESTADO_DESC;
        public string m_sDOCACOM_CHAVEH;
        public string m_sDOCACOM_LINHAOPT;
        public string m_sCANCELA_EFECTUADO;
        public string m_sCANCELA_DESCRICAO;
        public string m_sCANCELA_ID;

        public string m_sNOTIFICA_ID;
        public string m_sDOCACOM_NOTIFICADO;
        public string m_sNOTIFICA_ESTADO;
        public string m_sNOTIFICA_ERRO;
        public string m_sNOTIFICA_EFECTUADO;
        public string m_sNOTIFICA_DESCRICAO;

        /*
         * SDCIM 7
         */
        public String m_sDocOrigemID { get; set; }
        public String m_sDocOrigemDesc { get; set; }

        private void InitVars()
        {
            m_sFICH_ID = "";
            m_sFICH_NSEQ = "";
            m_dtFICH_DATA = DateTime.MinValue;

            m_sLOTEACOM_ID = "";
            m_sLOTEACOM_NUMERO = "";
            m_sLOTEACOM_PRODUTO = "";
            m_dtLOTEACOM_DATAPROC = DateTime.MinValue;
            m_sLOTESTATUS_ID = "";
            m_sLOTESTAT_ABR = "";

            m_sDOCACOM_ID = "";
            m_sDOCACOM_ZONA5 = "";
            m_sDOCACOM_ZONA4 = "";
            m_sDOCACOM_ZONA3 = "";
            m_sDOCACOM_ZONA2 = "";
            m_dDOCACOM_IMPORT = -1;
            m_sDOCACOM_ZONA1 = "";
            m_sREFARQ = "";
            m_sDOCACOM_REFARQ2 = "";
            m_sDOCACOM_BALCAO = "";
            m_sDOCACOM_CODANA = "";
            m_sESTADO_DESC = "";
            m_sDOCACOM_CHAVEH = "";
            m_sDOCACOM_LINHAOPT = "";

            m_sDOCACOM_CANCELADO = "";
            m_sCANCEL_ESTADO = "";
            m_sCANCELA_ERRO = "";
            m_sCANCELA_EFECTUADO = "";
            m_sCANCELA_DESCRICAO = "";

            m_sDOCACOM_NOTIFICADO = "";
            m_sNOTIFICA_ESTADO = "";
            m_sNOTIFICA_ERRO = "";
            m_sNOTIFICA_EFECTUADO = "";
            m_sNOTIFICA_DESCRICAO = "";

            this.m_sDocOrigemDesc = String.Empty;
            this.m_sDocOrigemID = String.Empty;
        }

        public PesquisaDocumentoACOM()
        {
            InitVars();
        }

        public PesquisaDocumentoACOM(SqlDataReader dr)
        {
            InitVars();

            m_sFICH_ID = Convert.ToString(dr["FICH_ID"]);
            m_sFICH_NSEQ = Convert.ToString(dr["FICH_NSEQ"]);
            m_dtFICH_DATA = Convert.ToDateTime(dr["FICH_DATA"]);

            m_sLOTEACOM_ID = Convert.ToString(dr["LOTEACOM_ID"]);
            m_sLOTEACOM_NUMERO = Convert.ToString(dr["LOTEACOM_NUMERO"]);
            m_sLOTEACOM_PRODUTO = Convert.ToString(dr["LOTEACOM_PRODUTO"]);
            m_dtLOTEACOM_DATAPROC = Convert.ToDateTime(dr["LOTEACOM_DATAPROC"]);
            m_sLOTESTATUS_ID = Convert.ToString(dr["LOTESTATUS_ID"]);
            m_sLOTESTAT_ABR = Convert.ToString(dr["LOTESTAT_ABR"]);

            m_sDOCACOM_ID = Convert.ToString(dr["DOCACOM_ID"]);
            m_sDOCACOM_ZONA5 = Convert.ToString(dr["DOCACOM_ZONA5"]);
            m_sDOCACOM_ZONA4 = Convert.ToString(dr["DOCACOM_ZONA4"]);
            m_sDOCACOM_ZONA3 = Convert.ToString(dr["DOCACOM_ZONA3"]);
            m_sDOCACOM_ZONA2 = Convert.ToString(dr["DOCACOM_ZONA2"]);
            m_dDOCACOM_IMPORT = Convert.ToDecimal(dr["DOCACOM_IMPORT"]);
            m_sDOCACOM_ZONA1 = Convert.ToString(dr["DOCACOM_ZONA1"]);
            m_sREFARQ = Convert.ToString(dr["REFARQ"]);
            m_sDOCACOM_REFARQ2 = Convert.ToString(dr["DOCACOM_REFARQ2"]);
            m_sDOCACOM_BALCAO = Convert.ToString(dr["DOCACOM_BALCAO"]);
            m_sESTADO_DESC = Convert.ToString(dr["ESTADO_DESC"]);
            m_sDOCACOM_CODANA = Convert.ToString(dr["DOCACOM_CODANA"]);
            m_sDOCACOM_CHAVEH = Convert.ToString(dr["DOCACOM_CHAVEH"]);
            m_sDOCACOM_LINHAOPT = Convert.ToString(dr["DOCACOM_LINHAOPT"]);

            m_sDOCACOM_CANCELADO = Convert.ToString(dr["DOCACOM_CANCELADO"]);
            m_sCANCEL_ESTADO = Convert.ToString(dr["CANCEL_ESTADO"]);
            m_sCANCELA_ERRO = Convert.ToString(dr["CANCELA_ERRO"]);
            m_sCANCELA_EFECTUADO = Convert.ToString(dr["CANCELA_EFECTUADO"]);
            if (dr["CANCELA_DESCRICAO"] != DBNull.Value)
            {
                m_sCANCELA_DESCRICAO = Convert.ToString(dr["CANCELA_DESCRICAO"]);
            }
            else
            {

                m_sCANCELA_DESCRICAO = string.Empty;

            }
            m_sDOCACOM_NOTIFICADO = Convert.ToString(dr["DOCACOM_NOTIFICADO"]);
            m_sNOTIFICA_ESTADO = Convert.ToString(dr["NOTIFICA_ESTADO"]);
            m_sNOTIFICA_ERRO = Convert.ToString(dr["NOTIFICA_ERRO"]);
            m_sNOTIFICA_EFECTUADO = Convert.ToString(dr["NOTIFICA_EFECTUADO"]);
            if (dr["NOTIFICA_DESCRICAO"] != DBNull.Value)
            {
                m_sNOTIFICA_DESCRICAO = Convert.ToString(dr["NOTIFICA_DESCRICAO"]);
            }
            else
            {

                m_sNOTIFICA_DESCRICAO = string.Empty;
            }
            this.m_sDocOrigemID = Convert.ToString(dr["DOC_ORIGEM_ID"]);
            this.m_sDocOrigemDesc = Convert.ToString(dr["DOC_ORIGEM_D"]);
            if (dr["NotifID"] != DBNull.Value)
            {
                m_sNOTIFICA_ID = Convert.ToString(dr["NotifID"]);
            }
            if (dr["CancelID"] != DBNull.Value)
            {
                m_sCANCELA_ID = Convert.ToString(dr["CancelID"]);
            }
        }

        public ListViewItem MakeListViewItem(string sDateFormat)
        {
            ListViewItem olvItem = new ListViewItem();
            olvItem.Text = m_sFICH_ID;
            olvItem.SubItems.Add(m_sFICH_NSEQ);
            olvItem.SubItems.Add(m_dtFICH_DATA.ToString(sDateFormat));
            olvItem.SubItems.Add(m_sLOTEACOM_ID);
            olvItem.SubItems.Add(m_sLOTEACOM_NUMERO);
            olvItem.SubItems.Add(m_sLOTEACOM_PRODUTO);
            olvItem.SubItems.Add(m_dtLOTEACOM_DATAPROC.ToString(sDateFormat));
            olvItem.SubItems.Add(m_sLOTESTATUS_ID + " " + m_sLOTESTAT_ABR);
            olvItem.SubItems.Add(m_sDOCACOM_ID);
            olvItem.SubItems.Add(this.m_sDocOrigemDesc);
            olvItem.SubItems.Add(m_sDOCACOM_ZONA5);
            olvItem.SubItems.Add(m_sDOCACOM_ZONA4);
            olvItem.SubItems.Add(m_sDOCACOM_ZONA3);
            string montanteToInsert = m_dDOCACOM_IMPORT.ToString().Equals("0") ? m_dDOCACOM_IMPORT.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(m_dDOCACOM_IMPORT).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dDOCACOM_IMPORT).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(m_sDOCACOM_ZONA1);
            olvItem.SubItems.Add(m_sREFARQ);
            olvItem.SubItems.Add(m_sDOCACOM_REFARQ2);
            olvItem.SubItems.Add(m_sDOCACOM_BALCAO.PadLeft(4, '0'));
            olvItem.SubItems.Add(m_sDOCACOM_CODANA + " " + m_sESTADO_DESC);
            olvItem.SubItems.Add(m_sCANCELA_EFECTUADO + " " + m_sCANCEL_ESTADO + " " + m_sCANCELA_DESCRICAO + " " + m_sCANCELA_ERRO);
            olvItem.SubItems.Add(m_sDOCACOM_CANCELADO);
            olvItem.SubItems.Add(m_sNOTIFICA_EFECTUADO + " " + m_sNOTIFICA_ESTADO + " " + m_sNOTIFICA_DESCRICAO + " " + m_sNOTIFICA_ERRO);
            olvItem.SubItems.Add(m_sDOCACOM_NOTIFICADO);
            olvItem.SubItems.Add(m_sDOCACOM_CHAVEH);
            olvItem.SubItems.Add(m_sDOCACOM_LINHAOPT);
            olvItem.SubItems.Add(m_sCANCELA_ID);
            olvItem.SubItems.Add(m_sNOTIFICA_ID);
            return olvItem;
        }

    }
}