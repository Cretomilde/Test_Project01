﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using System.Data.SqlClient;
using CIConfigGlobalParameters;
using System.IO;

namespace CIActividades
{
    class ListViewDetalhesImagem
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public string m_sId;
        public int m_iNrPagina;
        public int m_iEstado;
        public string m_sErro;
        public DateTime m_dtTimer;
        public string m_sIdConsulta;

        public ListViewDetalhesImagem()
        {
            m_sId = "";
            m_iNrPagina = -1;
            m_iEstado = 0;
            m_sErro = "";
            m_dtTimer   = DateTime.Now;
            m_sIdConsulta = "";

            this.m_oParameters = null;
        }

        public ListViewDetalhesImagem(SqlDataReader oReader, CIConfigGP.CIGlobalParameters oParameters)
        {
            this.m_oParameters = oParameters;

            m_sId = Convert.ToString( oReader["CONSULTA_ID"] );
            m_iNrPagina = Convert.ToInt32(oReader["NUM_PAGINA"]);
            m_iEstado = Convert.ToInt32(oReader["ESTADO"]);
            m_sErro = Convert.ToString(oReader["LAST_ERRO_DESC"]);
            m_dtTimer = Convert.ToDateTime(oReader["TIMER_ACTUALIZACAO"]);
            m_sIdConsulta = Convert.ToString(oReader["ID_DADOS_DOCUMENTO_CONSULTA"]);
        }

        public virtual ListViewItem BuildListViewItem()
        {
            ListViewItem oItem = new ListViewItem();

            oItem.Text = m_sIdConsulta;
            oItem.SubItems.Add(m_dtTimer.ToString("yyyy-MM-dd HH:mm:ss"));
            oItem.SubItems.Add(m_iNrPagina.ToString());
            oItem.SubItems.Add(m_iEstado.ToString());
            oItem.SubItems.Add(m_sErro);

            oItem.Tag = this;

            return oItem;
        }

        public string GetImage()
        {
            string sFileName;

            byte[] aImgF = (byte[])m_oParameters.DirectSqlScalar("select IMAGEM from dbo.TIBCO_OBTEM_IMAGEM where CONSULTA_ID = " + m_sId);

            if (aImgF == null)
            {
                return "";
            }

            sFileName = m_oParameters.GetTempFileName(m_sId) + ".jpg";

            WriteImage(aImgF, sFileName);

            return sFileName;
        }

        protected void WriteImage(byte[] aBytes, string sFileName)
        {
            StreamWriter sw = new StreamWriter(sFileName, false);
            BinaryWriter bw = new BinaryWriter(sw.BaseStream);
            bw.Write(aBytes);
            sw.Close();
            bw.Close();
        }
    }
}
