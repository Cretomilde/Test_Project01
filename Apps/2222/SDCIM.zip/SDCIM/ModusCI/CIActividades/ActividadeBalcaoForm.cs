﻿using System;
using System.Data;
using System.Text;
using System.Windows.Forms;
using CIConfigGlobalParameters;
using System.Data.SqlClient;
using NBiis;

namespace CIActividades
{
    public partial class ActividadeBalcaoForm : Form
    {
        public CIMenuInterface m_oMenuInterface;
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        DetalheDocumento m_oCurrDoc;
        public int m_iNewEstado;
        public string m_sSPProcessa;
        public string m_sSPValida;

        public ActividadeBalcaoForm(CIConfigGP.CIGlobalParameters oParameters, CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            preenheComboBox();
            m_oMenuInterface = oMenuInterface;
        }
        private void ActvBalcaoForm_Load(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            m_oMenuInterface.actividadeBalcaoEnable(false);
            this.DefinirDatas();
            refresh();
        }
        
        protected void DefinirDatas()
        {
            //SUPFBKOFF 20 intervalo de dados por defeito passou a ser 1 dia.
            this.m_ctrldtFim.Value = DateTime.Now.Date;
            this.m_ctrldtInicio.Value = DateTime.Now.Date;
        }

        #region contextMenuStrip Right_Click EventsAndMethods

        private void contextMenuStripRemessasResumo_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (listViewResumoRemessas.Items.Count > 0)
            {
                EnabledMenuStripRemessasResumo(true);
            }
        }

        private void EnabledMenuStripRemessasResumo(Boolean enable)
        {
            verRemessasDetalheToolStripMenuItem.Enabled = enable;
        }

        private void contextMenuStripRemessaEstorno_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (listViewRemessaEstorno.Items.Count > 0)
            {
                EnabledMenuStripRemessaEstorno(true);
            }
        }

        private void EnabledMenuStripRemessaEstorno(Boolean enable)
        {
            toolStripMenuItemRemessaEstorno.Enabled = enable;
            mudarEstadoToolStripMenuItem.Enabled = enable;
        }

        private void contextMenuStripRemessa_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (listViewDetalhesRemessa.Items.Count > 0)
            {
                EnabledMenuStripRemessa(true);
            }
        }

        private void EnabledMenuStripRemessa(Boolean enable)
        {
            toolStripMenuRemessaMudarEstado.Enabled = enable;
            verTranchesToolStripMenuItem.Enabled = enable;
            verDocumentosToolStripMenuItem.Enabled = enable;
        }

        private void contextMenuStripTranche_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (listViewDetalhesTranche.Items.Count > 0)
            {
                EnabledMenuStripTranche(true);
            }
        }

        private void EnabledMenuStripTranche(Boolean enable)
        {
            contextMenuStripTrancheMudaEstado.Enabled = enable;
            contextMenuStripTrancheVerDocs.Enabled = enable;
        }

        private void contextMenuStripDocumento_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (listViewDetalhesDocumentos.Items.Count > 0)
            {
                EnabledMenuStripDocumento(true);
            }
        }

        private void EnabledMenuStripDocumento(Boolean enable)
        {
            toolStripMenuDocumentosVerImagem.Enabled = enable;
        }

        private void contextMenuStripResumoEstornos_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (listViewEstornoResumo.Items.Count > 0)
            {
                EnabledMenuStripResumoEstornos(true);
            }
        }

        private void EnabledMenuStripResumoEstornos(Boolean enable)
        {
            toolStripMenuItemResumoEstornos.Enabled = enable;
        }

        private void contextMenuStripDocumentoEstorno_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (listViewDocumentoEstorno.Items.Count > 0)
            {
                EnabledMenuStripDocumentoEstorno(true);
            }
        }

        private void EnabledMenuStripDocumentoEstorno(Boolean enable)
        {
            toolStripMenuDocumentosEstornosVerImagem.Enabled = enable;
        }

        private void contextMenuStripRemessa_Opened(object sender, EventArgs e)
        {
            if (listViewDetalhesRemessa.SelectedItems.Count == 0)
            {
                EnabledMenuStripRemessa(false);
            }
        }

        private void contextMenuStripDocumento_Opened(object sender, EventArgs e)
        {
            if (listViewDetalhesDocumentos.SelectedItems.Count == 0)
            {
                EnabledMenuStripDocumento(false);
            }
        }

        private void contextMenuStripDocumentoEstorno_Opened(object sender, EventArgs e)
        {
            if (listViewDocumentoEstorno.SelectedItems.Count == 0)
            {
                EnabledMenuStripDocumentoEstorno(false);
            }
        }

        private void contextMenuStripRemessaEstorno_Opened(object sender, EventArgs e)
        {
            if (listViewRemessaEstorno.SelectedItems.Count == 0)
            {
                EnabledMenuStripRemessaEstorno(false);
            }
        }

        private void contextMenuStripRemessasResumo_Opened(object sender, EventArgs e)
        {
            if (listViewResumoRemessas.SelectedItems.Count == 0)
            {
                EnabledMenuStripRemessasResumo(false);
            }
        }

        private void contextMenuStripResumoEstornos_Opened(object sender, EventArgs e)
        {
            if (listViewEstornoResumo.SelectedItems.Count == 0)
            {
                EnabledMenuStripResumoEstornos(false);
            }
        }

        private void contextMenuStripTranche_Opened(object sender, EventArgs e)
        {
            if (listViewDetalhesTranche.SelectedItems.Count == 0)
            {
                EnabledMenuStripTranche(false);
            }
        }

        #endregion contextMenuStrip Right_Click EventsAndMethods

        //Documento Estorno 
        private void AddDocumentoEstornoListView(SqlDataReader dr)
        {
            DetalheDocumento oRr = new DetalheDocumento(dr);
            ListViewItem olvItem = oRr.MakeListViewItemDocumento(m_oParameters.DateFormat);
            olvItem.Tag = oRr;
            listViewDocumentoEstorno.Items.Add(olvItem);
        }

        //Documento Estorno 
        private void refreshDocumentoEstorno(string sWhereClause)
        {
            listViewDocumentoEstorno.BeginUpdate();
            listViewDocumentoEstorno.MyClear();
            SqlDataReader dr = null;
            string sQuery = " Select * from VW_DETALHE_DOCUMENTOS_BALCAO";
            sQuery += sWhereClause; //vem sempre com WHERE e falta o AND
            sQuery += " AND ((LOTEENV_ANOMAL IS NULL) OR (LOTEENV_ANOMAL = 6) OR (LOTEENV_ANOMAL = 1 AND DOCENV_ANOMAL = 6)) ";
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                /*
                 * se não retornar dados na primeira query
                 * deverá ser pesquisado pelo documentos da remessa pois ainda não chegou no ENVM o estorno
                 */
                if (!dr.HasRows)
                {
                    dr.Close();
                    sQuery = " Select * from VW_DETALHE_DOCUMENTOS_BALCAO";
                    sQuery += sWhereClause;
                    dr = m_oParameters.DirectSqlDataReader(sQuery);
                }
                while (dr.Read())
                {
                    AddDocumentoEstornoListView(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ResumoForm.cs", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                lblCountDocumentosEstornos.Text = listViewDocumentoEstorno.Items.Count.ToString() + " Documentos-Estornos.";
                listViewDocumentoEstorno.EndUpdate();
            }
        }

        //Documento
        private void AddDocumentoListView(SqlDataReader dr)
        {
            DetalheDocumento oRr = new DetalheDocumento(dr);
            ListViewItem olvItem = oRr.MakeListViewItemDocumento(m_oParameters.DateFormat);
            olvItem.Tag = oRr;
            listViewDetalhesDocumentos.Items.Add(olvItem);
        }

        private void refreshDocumento(string sWhereClause)
        {

            listViewDetalhesDocumentos.BeginUpdate();
            listViewDetalhesDocumentos.MyClear();
            EnabledMenuStripDocumento(false);
            SqlDataReader dr = null;
            string sQuery = " Select * from VW_DETALHE_DOCUMENTOS_BALCAO";
            sQuery += sWhereClause;  // vem sempre com WHERE e falta o AND
            sQuery += " AND ((LOTEENV_ANOMAL IS NULL) OR (LOTEENV_ANOMAL != 6) OR (LOTEENV_ANOMAL = 1 AND DOCENV_ANOMAL != 6)) ";
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    AddDocumentoListView(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ResumoForm.cs", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                lblCountDocumentos.Text = listViewDetalhesDocumentos.Items.Count.ToString() + " Documentos.";
                listViewDetalhesDocumentos.EndUpdate();
            }
        }

        private void ClearListsEstorno()
        {
            this.listViewEstornoResumo.MyClear();
            this.listViewDocumentoEstorno.MyClear();
            this.listViewRemessaEstorno.MyClear();
            EnabledMenuStripRemessaEstorno(false);
        }

        //Remessa Estorno
        private void AddRemessaEstornoListView(SqlDataReader dr)
        {
            DetalheRemessasEstorno oRr = new DetalheRemessasEstorno(dr, m_oParameters);
            ListViewItem olvItem = oRr.MakeListViewItemRemessasEstorno(m_oParameters.DateFormat);
            olvItem.Tag = oRr;
            listViewRemessaEstorno.Items.Add(olvItem);
        }

        private void refreshRemessaEstorno(string sWhereClause)
        {
            listViewRemessaEstorno.BeginUpdate();
            SqlDataReader dr = null;
            string sQuery = String.Format("SELECT {0} FROM dbo.VW_ESTRN_REMESSA_BALCAO_DETALHE {1} ORDER BY [ID] ASC",
                "ID,REMBALCAO_DATA,REMBALCAOPROC_TIMER,REMBALCAO_TM_ENVIADA,REMBALCAO_TM_ENVIADA,I_ESTRN_REMESSA,I_ESTRN_DOC,REMBALCAO_BALCAO," +
                "BALCAO_DESC,REMBALCAO_NUMERO,REMTIPO,REMTIPOID,REMSEQ,D_ESTRN_STATUS,ESTRN_STATUS_ID,REMBALCAOPROC_CHAVEH,LOTEENV_CGDERROR," +
                "ESTRN_QT_DOCS,REMBALCAOPROC_MAQUINA,ESTRN_ERRO,ESTRN_MT_DOCS,DOC_ID, ESTRN_ENVIADO, ESTRN_TIMER, ESTRN_ID",
                sWhereClause);
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    AddRemessaEstornoListView(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ResumoForm.cs", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                lblCountRemessasEstornos.Text = listViewRemessaEstorno.Items.Count.ToString() + " Remessas-Estornos.";
                lblCountDocumentosEstornos.Text = "Documentos-Estornos";
                listViewRemessaEstorno.EndUpdate();
            }
        }
        //Tranche
        private void AddTrancheListView(SqlDataReader dr)
        {
            DetalheTranche oRr = new DetalheTranche(dr, m_oParameters);
            ListViewItem olvItem = oRr.MakeListViewItemTranche(m_oParameters.DateFormat);
            olvItem.Tag = oRr;
            listViewDetalhesTranche.Items.Add(olvItem);
        }

        private void refreshTranche(string sWhereClause)
        {
            listViewDetalhesTranche.BeginUpdate();
            listViewDetalhesTranche.MyClear();
            EnabledMenuStripTranche(false);
            SqlDataReader dr = null;
            string sQuery = " select * from VW_TRANCHE_BALCAO_DETALHE";
            sQuery += sWhereClause;
            sQuery += " ";
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    AddTrancheListView(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ResumoForm.cs", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                labelCountTranches.Text = listViewDetalhesTranche.Items.Count.ToString() + " Tranches.";
                listViewDetalhesTranche.EndUpdate();
            }
        }

        //Remessa
        private void AddRemessaListView(SqlDataReader dr)
        {
            DetalheRemessa oRr = new DetalheRemessa(dr, m_oParameters);
            ListViewItem olvItem = oRr.MakeListViewItemRemessas(m_oParameters.DateFormat);
            olvItem.Tag = oRr;
            listViewDetalhesRemessa.Items.Add(olvItem);
        }

        private void refreshRemessa(string sWhereClause)
        {
            listViewDetalhesRemessa.BeginUpdate();
            listViewDetalhesRemessa.MyClear();
            EnabledMenuStripRemessa(false);
            SqlDataReader dr = null;
            string sQuery = "select * from dbo.VW_REMESSA_BALCAO_DETALHE";
            sQuery += sWhereClause;
            sQuery += " order by LOTEENV_CGDERROR,REMBALCAO_DATA, REMBALCAO_STAT_ID, ID";
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    AddRemessaListView(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ResumoForm.cs", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                labelCountRemessas.Text = listViewDetalhesRemessa.Items.Count.ToString() + " Remessas.";
                labelCountTranches.Text = "Tranches";
                lblCountDocumentos.Text = "Documentos";
                listViewDetalhesRemessa.EndUpdate();
            }
        }

        // Estorno Resumo 
        private void AddEstornoResumoListView(SqlDataReader dr)
        {
            DetalhesEstornosResumo oRr = new DetalhesEstornosResumo(dr);
            ListViewItem olvItem = oRr.MakeListViewItemEstornoResumos(m_oParameters.DateFormat);
            olvItem.Tag = oRr;
            listViewEstornoResumo.Items.Add(olvItem);
        }

        private void refreshEstornoResumo(string sWhereClause)
        {
            listViewEstornoResumo.BeginUpdate();
            listViewEstornoResumo.MyClear();
            SqlDataReader dr = null;
            string sQuery = String.Format("SELECT {0} FROM dbo.GetResumoEstornosBalcaoEstado {1} order by Z_PROCESS ASC, Z_ESTRN ASC, ESTRN_STATUS_ID ASC",
                                             "Z_PROCESS, Z_ESTRN, ESTRN_STATUS_ID, D_ESTRN_STATUS, REMBALCAO_TIPO_BALCAO_ID, " +
                                             "REMTIPOBALCAO_DESC, QT_ESTRN, ESTRN_QT_DOCS, ESTRN_MT_DOCS, LOTEENV_CGDERROR ",
                                             sWhereClause);
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    AddEstornoResumoListView(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ResumoForm.cs", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                lblCountRemessasEstornos.Text = "Remessas-Estornos";
                lblCountDocumentosEstornos.Text = "Documentos-Estornos";
                listViewEstornoResumo.EndUpdate();
            }
        }

        // Deposito Resumo
        private void AddDepositoResumoListView(SqlDataReader dr)
        {
            //SDCIM 7 apesar dos campos serem REMIN, aí trata-se coisas de Remessas_Balcao 
            RemessasResumoBalcao oRr = new RemessasResumoBalcao(dr);
            ListViewItem olvItem = oRr.MakeListViewItemResumoRemessasBalcao(m_oParameters.DateFormat);
            olvItem.Tag = oRr;
            listViewResumoRemessas.Items.Add(olvItem);
        }

        private void refreshDepositoResumo(string sWhereClause)
        {
            listViewResumoRemessas.BeginUpdate();
            listViewResumoRemessas.MyClear();
            EnabledMenuStripRemessasResumo(false);
            SqlDataReader dr = null;
            string sQuery = "select * from dbo.GetResumoRemessasBalcaoEstado";
            sQuery += sWhereClause;
            // sQuery += " order by REMPROC_DATA desc, REMIN_DATA desc, REMINSTAT_ID desc";

            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    AddDepositoResumoListView(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "ResumoForm.cs", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                labelCountRemessas.Text = "Remessas";
                labelCountTranches.Text = "Tranches";
                lblCountDocumentos.Text = "Documentos";
                listViewResumoRemessas.EndUpdate();
            }
        }

        private void m_btRefreshRemessas_Click(object sender, EventArgs e)
        {
            this.SetPadLeftBalcao();
            this.ClearListsRemessas();
            this.FillListRemessas();
        }

        private void refresh()
        {
            this.SetPadLeftBalcao();
            this.ClearListsRemessas();
            this.FillListRemessas();
            this.ClearListsEstorno();
            this.FillListEstornoResumo();
        }

        private void SetPadLeftBalcao()
        {
            string padleft = "";
            if (txBalcao.Text.Length > 0 && txBalcao.Text.Length < 4)
            {
                padleft = txBalcao.Text.PadLeft(4, '0');
                txBalcao.Text = padleft;
            }
        }

        private void ClearListsRemessas()
        {
            listViewResumoRemessas.MyClear();
            listViewDetalhesRemessa.MyClear();
            listViewDetalhesTranche.MyClear();
            listViewDetalhesDocumentos.MyClear();
            EnabledMenuStripRemessasResumo(false);
            EnabledMenuStripRemessa(false);
            EnabledMenuStripTranche(false);
            EnabledMenuStripDocumento(false);
        }

        private void FillListRemessas()
        {
            this.ClearListsRemessas();
            this.refreshDepositoResumo(this.GetClauseWhereToResumos(true));
        }

        private String GetClauseWhereToResumos(Boolean iRemessa)
        {
            String filtroRem = this.filtrosRemessas(iRemessa);
            if (!String.IsNullOrWhiteSpace(filtroRem))
            {
                return String.Format("('{0}', '{1}', {2}) WHERE {3}",
                    m_ctrldtInicio.Value.ToString(m_oParameters.DateTimeSysFmt),
                    m_ctrldtFim.Value.ToString(m_oParameters.DateTimeSysFmt),
                    this.filtro(),
                    filtroRem
                    );
            }
            else
            {
                return String.Format("('{0}', '{1}', {2})",
                    m_ctrldtInicio.Value.ToString(m_oParameters.DateTimeSysFmt),
                    m_ctrldtFim.Value.ToString(m_oParameters.DateTimeSysFmt),
                    this.filtro()
                    );
            }
        }

        private void btEstorno_Click(object sender, EventArgs e)
        {
            this.SetPadLeftBalcao();
            this.ClearListsEstorno();
            this.FillListEstornoResumo();
        }

        private void FillListEstornoResumo()
        {
            this.ClearListsEstorno();
            this.refreshEstornoResumo(this.GetClauseWhereToResumos(false));
        }

        private String GetFiltroEstornoRemessasDetalhe()
        {
            StringBuilder sWhereClause = new StringBuilder();
            if (this.txBalcao.Text.Length > 0)
            {
                sWhereClause.Append(String.Format(" AND REMBALCAO_BALCAO = {0} ", this.txBalcao.Text));
            }
            if (txRemessaCI.Text.Length > 0)
            {
                sWhereClause.Append(String.Format(" AND ID = {0} ", txRemessaCI.Text));
            }
            if (txDeposito.Text.Length > 0)
            {
                sWhereClause.Append(String.Format(" AND REMSEQ = {0} ", txDeposito.Text));
            }
            return sWhereClause.ToString();
        }

        private string filtro()
        {
            StringBuilder sWhereClause = new StringBuilder();
            if (this.txBalcao.Text.Length > 0)
            {
                sWhereClause.Append(this.txBalcao.Text + " , ");
            }
            else
            {
                sWhereClause.Append("DEFAULT, ");
            }
            if (cbTRemessa.Text != "Todos")
            {
                sWhereClause.Append(cbTRemessa.SelectedValue + " , ");
            }
            else
            {
                sWhereClause.Append("DEFAULT, ");
            }
            if (txRemessaCI.Text.Length > 0)
            {
                sWhereClause.Append(txRemessaCI.Text + " , ");
            }
            else
            {
                sWhereClause.Append("DEFAULT, ");
            }
            if (txDeposito.Text.Length > 0)
            {
                sWhereClause.Append(txDeposito.Text);
            }
            else
            {
                sWhereClause.Append("DEFAULT");
            }
            return sWhereClause.ToString();
        }

        private void listViewResumoRemessas_DoubleClick(object sender, EventArgs e)
        {
            listViewDetalhesTranche.MyClear();
            listViewDetalhesDocumentos.MyClear();
            EnabledMenuStripTranche(false);
            EnabledMenuStripDocumento(false);

            string sWhereClause = "";
            RemessasResumoBalcao oRr = null;
            for (int i = 0; i < listViewResumoRemessas.SelectedItems.Count; i++)
            {
                oRr = (RemessasResumoBalcao)listViewResumoRemessas.SelectedItems[i].Tag;
                sWhereClause = " where REMBALCAO_DATA= '" + oRr.m_dtREMIN_DATA.ToString(m_oParameters.DateFormat) + "' and ";
                sWhereClause += " REMBALCAO_STAT_ID=" + oRr.m_iREMINSTAT_ID;
                sWhereClause += " and REMBALCAOPROC_TIMER between '" + oRr.m_dtREMPROC_DATA.ToString(m_oParameters.DateFormat) + "'";
                sWhereClause += " and '" + oRr.m_dtREMPROC_DATA.AddDays(+1).ToString(m_oParameters.DateFormat) + "'";
                sWhereClause += " and LOTEENV_CGDERROR =" + oRr.m_iLOTEENV_CGDERROR;
                sWhereClause += " and REMBALCAO_TIPO_BALCAO_ID =" + oRr.tpRemessaID;
                sWhereClause += this.GetFiltroEstornoRemessasDetalhe();
                this.refreshRemessa(sWhereClause);
            }
        }

        /// <summary>
        /// Get Filtro por estado de remessa.
        /// DEverá ser colocado WHERE ou AND de acordo com a query
        /// </summary>
        /// <returns></returns>
        private string filtrosRemessas(Boolean iRemessa)
        {
            StringBuilder filtro = new StringBuilder();
            if (toolStripButtonFechados.Checked)
                filtro.Append(" 20,"); //sFiltros += " 20,";
            if (toolStripButtonEspMaquinas.Checked)
                filtro.Append(" 25,"); //sFiltros += " 25,";
            if (toolStripButtonProcessamento.Checked)
                filtro.Append(" 30,"); //sFiltros += " 30,";
            if (toolStripButtonProcessado.Checked)
                filtro.Append(" 40,"); //sFiltros += " 40,";
            if (toolStripButtonEnviada.Checked)
                filtro.Append(" 50,"); //sFiltros += " 50,";
            if (toolStripButtonENVM.Checked)
                filtro.Append(" 60, 70, 80,"); //sFiltros += " 60, 70, 80,";
            if (toolStripButtonErro.Checked)
                filtro.Append(" -20, -40, -50, -60,"); //sFiltros += " -20, -40, -50, -60,";
            if (filtro.ToString().Length == 0)
            {
                return String.Empty;
            }
            if (iRemessa)
                return String.Format(" REMINSTAT_ID in ({0})", filtro.ToString().Substring(0, filtro.ToString().Length - 1));
            else
                return String.Format(" ESTRN_STATUS_ID in ({0})", filtro.ToString().Substring(0, filtro.ToString().Length - 1));
        }

        private void listViewDetalhesRemessa_DoubleClick(object sender, EventArgs e)
        {
            listViewDetalhesTranche.MyClear();
            listViewDetalhesDocumentos.MyClear();
            EnabledMenuStripTranche(false);
            EnabledMenuStripDocumento(false);

            string sWhereClause = "";
            DetalheRemessa oRr = null;
            for (int i = 0; i < listViewDetalhesRemessa.SelectedItems.Count; i++)
            {
                oRr = (DetalheRemessa)listViewDetalhesRemessa.SelectedItems[i].Tag;
                sWhereClause = " where ID = " + oRr.remId;
                sWhereClause += filtrosTranches();
                refreshTranche(sWhereClause);
            }

            ShowDocumentsAndTranchesOfRemessas();
        }

        private void ShowDocumentsAndTranchesOfRemessas()
        {
            listViewDetalhesDocumentos.MyClear();
            EnabledMenuStripDocumento(false);

            string sWhereClause = String.Empty;
            DetalheTranche oRr = null;

            for (int i = 0; i < listViewDetalhesTranche.Items.Count; i++)
            {
                oRr = (DetalheTranche)listViewDetalhesTranche.Items[i].Tag;              
                sWhereClause = " WHERE REMIN_ID = " + oRr.remId;
                refreshDocumento(sWhereClause);
            }
        }

        private void listViewDetalhesTranche_DoubleClick(object sender, EventArgs e)
        {
            listViewDetalhesDocumentos.MyClear();
            EnabledMenuStripDocumento(false);

            string sWhereClause = String.Empty;
            DetalheTranche oRr = null;

            for (int i = 0; i < listViewDetalhesTranche.SelectedItems.Count; i++)
            {
                oRr = (DetalheTranche)listViewDetalhesTranche.SelectedItems[i].Tag;
                if (oRr.transId.Equals(0))
                {
                    sWhereClause = " WHERE REMIN_ID = " + oRr.remId;
                }
                else
                {
                    sWhereClause = " WHERE TRANOUT_ID = " + oRr.transId;
                }
                refreshDocumento(sWhereClause);
            }
        }

        private void listViewEstornoResumo_DoubleClick(object sender, EventArgs e)
        {
            this.listViewDocumentoEstorno.MyClear();
            this.listViewRemessaEstorno.MyClear();
            EnabledMenuStripRemessaEstorno(false);
            for (int i = 0; i < listViewEstornoResumo.SelectedItems.Count; i++)
            {
                DetalhesEstornosResumo oRr = null;
                oRr = (DetalhesEstornosResumo)listViewEstornoResumo.SelectedItems[i].Tag;
                StringBuilder strBuilder = new StringBuilder();
                strBuilder.Append(String.Format(" WHERE Z_ESTRN = '{0}' AND ", oRr.ZEstorno.ToString(m_oParameters.DateFormat)));
                strBuilder.Append(String.Format(" ESTRN_STATUS_ID = {0} AND ", oRr.EstadoEstornoID));
                strBuilder.Append(String.Format(" Z_PROCESS_ESTRN BETWEEN '{0}' AND '{1}' AND ",
                                                oRr.ZProcessamento.ToString(m_oParameters.DateFormat),
                                                oRr.ZProcessamento.AddDays(1).ToString(m_oParameters.DateFormat)));
                strBuilder.Append(String.Format(" LOTEENV_CGDERROR = {0} AND ", oRr.ENVM));
                strBuilder.Append(String.Format(" REMTIPOID = {0} ", oRr.RemessaTipoID));
                strBuilder.Append(this.GetFiltroEstornoRemessasDetalhe());
                refreshRemessaEstorno(strBuilder.ToString());
            }
        }

        private void listViewRemessaEstorno_DoubleClick(object sender, EventArgs e)
        {
            listViewDocumentoEstorno.MyClear();
            string sWhereClause = "";
            for (int i = 0; i < listViewRemessaEstorno.SelectedItems.Count; i++)
            {
                DetalheRemessasEstorno oRr = null;
                oRr = (DetalheRemessasEstorno)listViewRemessaEstorno.SelectedItems[i].Tag;
                sWhereClause = " WHERE REMIN_ID = " + oRr.remId;
                if (oRr.Doc_ID.HasValue)
                {
                    sWhereClause += " AND DOC_ID = " + oRr.Doc_ID.Value;
                }
                refreshDocumentoEstorno(sWhereClause);
            }
        }

        private void listViewDetalhesDocumentos_DoubleClick(object sender, EventArgs e)
        {
            if (listViewDetalhesDocumentos.SelectedItems.Count > 0)
            {
                m_oCurrDoc = (DetalheDocumento)listViewDetalhesDocumentos.SelectedItems[0].Tag;
                int id = m_oCurrDoc.docID;
                ImagemBalcaoForm fMostraImg = new ImagemBalcaoForm(m_oParameters, id);
                fMostraImg.ShowDialog();
            }
        }

        private void listViewDocumentoEstorno_DoubleClick(object sender, EventArgs e)
        {
            if (listViewDocumentoEstorno.SelectedItems.Count > 0)
            {
                m_oCurrDoc = (DetalheDocumento)listViewDocumentoEstorno.SelectedItems[0].Tag;
                int id = m_oCurrDoc.docID;
                ImagemBalcaoForm fMostraImg = new ImagemBalcaoForm(m_oParameters, id);
                fMostraImg.ShowDialog();
            }
        }

        private string filtrosTranches()
        {
            string sFiltroStart = "And TRANOUTSTAT_ID in (";
            string sFiltros = "";

            if (toolStripButtonProcessamento.Checked)
                sFiltros += " 10,";
            if (toolStripButtonProcessado.Checked)
                sFiltros += " 20,";
            if (toolStripButtonEnviada.Checked)
                sFiltros += " 30,";
            if (toolStripButtonErro.Checked)
                sFiltros += " -30, 99,";
            if (sFiltros.Length == 0)
            {
                return "";
            }
            sFiltros = sFiltroStart + sFiltros.Substring(0, sFiltros.Length - 1) + ")";
            return sFiltros;
        }

        private void btnRemessasErro_Click(object sender, EventArgs e)
        {
            try
            {
                //ConfirmaPrivilegios();
                if (MessageBox.Show("Confirma o reenvio de todas as remessas em erro?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                string sSmg = "Reenvio manual de todas as remessas em erro";
                GenericLog.GenLogRegistarAlerta(sSmg, "Balcão - btnRemessasErro_Click()", 110);
                m_oParameters.EnviarAlertaSituacao(110, sSmg);

                string sQuery = "exec dbo.Update_ReenviarTodasRemessasBalcaoEmErro";
                m_oParameters.DirectSqlNonQuery(sQuery);

                this.FillListRemessas();
                MessageBox.Show(this, "Efectuado", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "btnRemessasErro_Click", -2);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEstonoErro_Click(object sender, EventArgs e)
        {
            try
            {
                //ConfirmaPrivilegios();
                if (MessageBox.Show("Confirma o reenvio de todas os estornos em erro?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                string sSmg = "Reenvio manual de todos os estornos em erro";
                GenericLog.GenLogRegistarAlerta(sSmg, "btnEstonoErro_Click()", 110);
                m_oParameters.EnviarAlertaSituacao(110, sSmg);

                string sQuery = "exec dbo.Update_ReenviarTodosEstornosBalcaoEmErro";
                m_oParameters.DirectSqlNonQuery(sQuery);

                this.FillListEstornoResumo();
                MessageBox.Show(this, "Efectuado", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "btnEstonoErro_Click", -2);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void preenheComboBox()
        {
            DataSet ds = null;
            if (cbTRemessa.Items.Count > 0)
            {
                return;
            }
            try
            {
                string sComm = "SELECT [REMTIPOBALCAO_ID], CAST([REMTIPOBALCAO_ID] AS VARCHAR(2)) + ' - ' + [REMTIPOBALCAO_ABR] AS 'REMTIPOBALCAO_ABR' FROM [dbo].[REMESSA_TIPO_BALCAO]";
                ds = m_oParameters.DirectSqlDataSet(sComm, "REMESSA_TIPO_BALCAO");
                DataTable dt = ds.Tables[0];
                DataRow dr = dt.NewRow();
                dr["REMTIPOBALCAO_ID"] = "0";
                dr["REMTIPOBALCAO_ABR"] = "Todos";
                dt.Rows.InsertAt(dr, 0);
                cbTRemessa.DataSource = dt;
                cbTRemessa.DisplayMember = "REMTIPOBALCAO_ABR";
                cbTRemessa.ValueMember = "REMTIPOBALCAO_ID";
            }
            finally
            {
                if (ds != null)
                {
                    ds.Dispose();
                    ds = null;
                }
            }
        }

        private void txBalcao_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txBalcao.Text, "[^0-9]"))
            {
                MessageBox.Show("Campo numérico");
                txBalcao.Text.Remove(txBalcao.Text.Length - 1);
                txBalcao.Text = "";
            }
            if (txBalcao.Text.Length >= 4)
            {
                txBalcao.MaxLength = 4;
            }
        }

        private void txRemessaCI_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txRemessaCI.Text, "[^0-9]"))
            {
                MessageBox.Show("Campo numérico");
                txRemessaCI.Text.Remove(txRemessaCI.Text.Length - 1);
                txRemessaCI.Text = "";
            }
            if (txRemessaCI.Text.Length >= 6)
            {
                txRemessaCI.MaxLength = 6;
            }
        }

        private void txDeposito_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txDeposito.Text, "[^0-9]"))
            {
                MessageBox.Show("Campo numérico");
                txDeposito.Text.Remove(txDeposito.Text.Length - 1);
                txDeposito.Text = "";
            }
            if (txDeposito.Text.Length >= 7)
            {
                txDeposito.MaxLength = 7;
            }
        }

        private void toolStripMenuRemessaMudarEstado_Click(object sender, EventArgs e)
        {
            int iDebug = -1;

            if (listViewDetalhesRemessa.SelectedItems.Count == 0)
                return;

            try
            {
                ConfirmaPrivilegios();
                DetalheRemessa oDetalheRemessa = null;
                oDetalheRemessa = (DetalheRemessa)listViewDetalhesRemessa.SelectedItems[0].Tag;

                //VerificaEstadosIguaisRemessa();

                MudarEstadoForm mudarEstado;
                mudarEstado = new MudarEstadoForm(m_oParameters, oDetalheRemessa.estadoId, oDetalheRemessa.GetTableName(), oDetalheRemessa.estadoRemessa);


                if (mudarEstado.ShowDialog() == DialogResult.Cancel)
                {
                    throw new Exception("Operação cancelada pelo utilizador");
                }

                try
                {
                    m_oParameters.BeginTrans(IsolationLevel.ReadCommitted);
                    while (listViewDetalhesRemessa.SelectedItems.Count > 0)
                    {
                        m_iNewEstado = mudarEstado.m_iNewEstado;
                        m_sSPProcessa = mudarEstado.m_sSPProcessa;
                        m_sSPValida = mudarEstado.m_sSPValida;
                        oDetalheRemessa = (DetalheRemessa)listViewDetalhesRemessa.SelectedItems[0].Tag;

                        oDetalheRemessa.ChangeEstado(m_iNewEstado, m_sSPProcessa, m_sSPValida);

                        listViewDetalhesRemessa.SelectedItems[0].Remove();
                    }

                    m_oParameters.Commit();
                }
                catch
                {
                    iDebug = Convert.ToInt32(oDetalheRemessa.remId);
                    m_oParameters.RollBack();
                    throw;
                }

                listViewResumoRemessas_DoubleClick(sender, e);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "toolStripMenuRemessaMudarEstado_Click", iDebug);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void verDocumentosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listViewDetalhesRemessa_DoubleClick(sender, e);
        }

        private void verTranchesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listViewDetalhesTranche.MyClear();
            listViewDetalhesDocumentos.MyClear();
            EnabledMenuStripTranche(false);
            EnabledMenuStripDocumento(false);

            string sWhereClause = "";
            DetalheRemessa oRr = null;
            for (int i = 0; i < listViewDetalhesRemessa.SelectedItems.Count; i++)
            {
                oRr = (DetalheRemessa)listViewDetalhesRemessa.SelectedItems[i].Tag;
                sWhereClause = " where ID = " + oRr.remId;
                sWhereClause += filtrosTranches();
                refreshTranche(sWhereClause);
            }
        }

        private void verRemessasDetalheToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listViewResumoRemessas_DoubleClick(sender, e);
        }

        private void contextMenuStripTrancheMudaEstado_Click(object sender, EventArgs e)
        {
            int iDebug = -1;

            try
            {
                ConfirmaPrivilegios();

                DetalheTranche oDetalheTranche = null;
                oDetalheTranche = (DetalheTranche)listViewDetalhesTranche.SelectedItems[0].Tag;
                MudarEstadoForm mudarEstado;
                mudarEstado = new MudarEstadoForm(m_oParameters, oDetalheTranche.estadoId, oDetalheTranche.GetTableName(), oDetalheTranche.estado);


                if (mudarEstado.ShowDialog() == DialogResult.Cancel)
                {
                    throw new Exception("Operação cancelada pelo utilizador");
                }

                try
                {
                    m_oParameters.BeginTrans(IsolationLevel.ReadCommitted);
                    while (listViewDetalhesTranche.SelectedItems.Count > 0)
                    {
                        m_iNewEstado = mudarEstado.m_iNewEstado;
                        m_sSPProcessa = mudarEstado.m_sSPProcessa;
                        m_sSPValida = mudarEstado.m_sSPValida;
                        oDetalheTranche = (DetalheTranche)listViewDetalhesTranche.SelectedItems[0].Tag;

                        oDetalheTranche.ChangeEstado(m_iNewEstado, m_sSPProcessa, m_sSPValida);

                        listViewDetalhesTranche.SelectedItems[0].Remove();
                    }

                    m_oParameters.Commit();
                }
                catch
                {
                    iDebug = Convert.ToInt32(oDetalheTranche.remId);
                    m_oParameters.RollBack();
                    throw;
                }

                verTranchesToolStripMenuItem_Click(sender, e);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "contextMenuStripTrancheMudaEstado_Click", iDebug);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void contextMenuStripTrancheVerDocs_Click(object sender, EventArgs e)
        {
            ShowDocumentsAndTranchesOfRemessas();
        }

        private void toolStripMenuItemResumoEstornos_Click(object sender, EventArgs e)
        {
            listViewEstornoResumo_DoubleClick(sender, e);

        }

        private void toolStripMenuItemRemessaEstorno_Click(object sender, EventArgs e)
        {
            listViewRemessaEstorno_DoubleClick(sender, e);
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            listViewDocumentoEstorno_DoubleClick(sender, e);
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            listViewDetalhesDocumentos_DoubleClick(sender, e);
        }

        private void mudarEstadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int iDebug = -1;

            try
            {
                ConfirmaPrivilegios();

                DetalheRemessasEstorno oDetalheRemessaEstorno = null;
                oDetalheRemessaEstorno = (DetalheRemessasEstorno)listViewRemessaEstorno.SelectedItems[0].Tag;

                MudarEstadoForm mudarEstado;
                mudarEstado = new MudarEstadoForm(m_oParameters, oDetalheRemessaEstorno.estadoId, oDetalheRemessaEstorno.GetTableName(), oDetalheRemessaEstorno.estadoEstorno);


                if (mudarEstado.ShowDialog() == DialogResult.Cancel)
                {
                    throw new Exception("Operação cancelada pelo utilizador");
                }

                try
                {
                    m_oParameters.BeginTrans(IsolationLevel.ReadCommitted);
                    while (listViewRemessaEstorno.SelectedItems.Count > 0)
                    {
                        m_iNewEstado = mudarEstado.m_iNewEstado;
                        m_sSPProcessa = mudarEstado.m_sSPProcessa;
                        m_sSPValida = mudarEstado.m_sSPValida;
                        oDetalheRemessaEstorno = (DetalheRemessasEstorno)listViewRemessaEstorno.SelectedItems[0].Tag;

                        oDetalheRemessaEstorno.ChangeEstado(m_iNewEstado, m_sSPProcessa, m_sSPValida);

                        listViewRemessaEstorno.SelectedItems[0].Remove();
                    }

                    m_oParameters.Commit();
                }
                catch
                {
                    iDebug = Convert.ToInt32(oDetalheRemessaEstorno.remId);
                    m_oParameters.RollBack();
                    throw;
                }

                listViewEstornoResumo_DoubleClick(sender, e);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "mudarEstadoToolStripMenuItem_Click", iDebug);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void toolStripButtonExitJanela_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void toolStripButtonRefresh_Click(object sender, EventArgs e)
        {
            refresh();
        }

        private void tsBtnRemessa_Click(object sender, EventArgs e)
        {
            this.BotoesJanelasEnabled();
        }

        private void tsBtnEstorno_Click(object sender, EventArgs e)
        {
            this.BotoesJanelasEnabled();
        }

        private void BotoesJanelasEnabled()
        {
            if (this.tsBtnEstorno.Checked && this.tsBtnRemessa.Checked)
            {
                spContainer.Panel1Collapsed = false;
                spContainer.Panel2Collapsed = false;
                return;
            }
            spContainer.Panel1Collapsed = this.tsBtnEstorno.Checked;
            spContainer.Panel2Collapsed = this.tsBtnRemessa.Checked;
        }

        private void ConfirmaPrivilegios()
        {
            if (m_oParameters.UserLogged.m_iUserGroup > 1)
            {
                throw new Exception("Utilizador sem privilegios para alterar estados");
            }
        }
    }
}
