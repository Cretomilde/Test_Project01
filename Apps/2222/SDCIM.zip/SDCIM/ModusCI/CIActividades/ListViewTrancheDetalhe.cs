﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIActividades
{
    class ListViewTrancheDetalhe: ListViewDetalhes
    {
        public string m_sTrancheID;
        public string m_sChaveWS;
        public string m_sTIBCOEstado;
      

        public override string GetTableName()
        {
            return "TRANCHE_OUT";
        }

        public ListViewTrancheDetalhe(SqlDataReader oReader, CIConfigGP.CIGlobalParameters oParameters)
            : base(oReader, oParameters)
        {
            m_sRemessaID = oReader["REMIN_ID"].ToString();
            //try 
            //{

                m_sTrancheID = Convert.ToString(oReader["TRANOUT_ID"]);
                m_dtTimer = Convert.ToDateTime(oReader["TRANOUT_TIMER"]);
                m_sNumero = (oReader["TRANOUT_NUMERO"]).ToString();
                m_iStatus = Convert.ToInt32(oReader["TRANOUTSTAT_ID"]);
                m_sStatusAbr = Convert.ToString(oReader["TRANOUTSTAT_ABR"]);
                m_iQt = Convert.ToInt32(oReader["TRANOUT_QT_DOCS"]);
                m_dMt = Convert.ToDecimal(oReader["TRANOUT_MT_DOCS"]);
                m_sErro = Convert.ToString(oReader["TRANOUT_ERRO"]);
                if (oReader["ENVIO_DESCRICAO"] == DBNull.Value) {

                    this.m_sErroDescricao = string.Empty;
                } 
                else {

                    m_sErroDescricao = Convert.ToString(oReader["ENVIO_DESCRICAO"]);
                }
                //try
                //{
                //    m_sErroDescricao = Convert.ToString(oReader["ENVIO_DESCRICAO"]);
                //}
                //catch
                //{
                //}
                m_sErro = m_sErroDescricao + " " + m_sErro;
                m_sChaveWS = Convert.ToString(oReader["CHAVE_WEBSERVICE"]);
                m_sTIBCOEstado = Convert.ToString(oReader["ESTADO"]);
            //}
            //catch
            //{}
            
        }

        public ListViewTrancheDetalhe(DataRow oRow, CIConfigGP.CIGlobalParameters oParameters)
            : base(oRow, oParameters)
        {
            m_sRemessaID = oRow["REMIN_ID"].ToString();
            m_sTrancheID = Convert.ToString(oRow["TRANOUT_ID"]);
            m_dtTimer = Convert.ToDateTime(oRow["TRANOUT_TIMER"]);
            m_sNumero = oRow["TRANOUT_NUMERO"].ToString();
            m_iStatus = Convert.ToInt32(oRow["TRANOUTSTAT_ID"]);
            m_sStatusAbr = Convert.ToString(oRow["TRANOUTSTAT_ABR"]);
            m_iQt = Convert.ToInt32(oRow["TRANOUT_QT_DOCS"]);
            m_dMt = Convert.ToDecimal(oRow["TRANOUT_MT_DOCS"]);
            m_sErro = Convert.ToString(oRow["TRANOUT_ERRO"]);
            if (oRow["ENVIO_DESCRICAO"] == DBNull.Value)
            {

                this.m_sErroDescricao = string.Empty;
            }
            else
            {

                m_sErroDescricao = Convert.ToString(oRow["ENVIO_DESCRICAO"]);
            }
            //try
            //{
            //    m_sErroDescricao = Convert.ToString(oRow["ENVIO_DESCRICAO"]);
            //}
            //catch
            //{
            //}
            m_sErro = m_sErroDescricao + " " + m_sErro;
            m_sChaveWS = Convert.ToString(oRow["CHAVE_WEBSERVICE"]);
            m_sTIBCOEstado = Convert.ToString(oRow["ESTADO"]);
            
        }


        public override void ChangeEstado(int iNewStatus, string m_sSPProcessa, string m_sSPValida)
        {
            // ValidaChangeEstadoTranche(iNewStatus);
             ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@OldEstado", m_iStatus));
            oParams.Add(new GeneralDBParameters("@NewEstado", iNewStatus));
            oParams.Add(new GeneralDBParameters("@TranoutID", m_sTrancheID));
            if (m_sSPValida.Length > 0)
            {
                m_oParameters.DirectStoredProcedureNonQuery(m_sSPValida , ref oParams);
            }
            m_oParameters.DirectStoredProcedureNonQuery(m_sSPProcessa, ref oParams);

            string sSmg = "Mudou estado da TRANCHE: " + m_sTrancheID + " de " + m_iStatus.ToString() + " para " + iNewStatus.ToString();
            GenericLog.GenLogRegistarAlerta(sSmg, "ChangeEstadoTranche()", 110);
            m_oParameters.EnviarAlertaSituacao(110, sSmg);

        }

        public override ListViewItem MakeListViewItem(string sDateFormat, string sDateTimeFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_sRemessaID;
            olvItem.SubItems.Add(m_sTrancheID);
            olvItem.SubItems.Add(m_dtTimer.ToString(sDateTimeFormat));
            olvItem.SubItems.Add(m_sNumero);
            olvItem.SubItems.Add(m_iStatus.ToString() + " " + m_sStatusAbr);
            olvItem.SubItems.Add(m_iQt.ToString().PadLeft(6,' '));
            string montanteToInsert = this.m_dMt.ToString().Equals("0") ? this.m_dMt.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(this.m_dMt).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dMt).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(m_sErro);
            olvItem.SubItems.Add(m_sChaveWS);
            olvItem.SubItems.Add(m_sTIBCOEstado);
            return olvItem;
        }

        public override string GetWhereClause2ViewDetails()
        {
            string sWhereClause;
            sWhereClause = " where TRANOUT_ID=" + m_sTrancheID;

            return sWhereClause;
        }
    }
}
