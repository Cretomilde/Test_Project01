﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NBiis.Generic;
using System.Collections;
using CIConfigGP;
using System.Windows.Forms;

namespace CIActividades
{
    /// <summary>
    /// SUPBACKOFF 30
    /// </summary>
    public class Tibco
    {
        public void Insert_TibcoCancelaChaveDocumento(PesquisaDocumentoENVM oDoc, CIGlobalParameters m_oParameters)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@Operativa", 8));
            oParams.Add(new GeneralDBParameters("@TipoProduto", 4));
            oParams.Add(new GeneralDBParameters("@Solucao", "SIDOC"));
            oParams.Add(new GeneralDBParameters("@Refarq", oDoc.m_sDOCENV_REFARQ));
            oParams.Add(new GeneralDBParameters("@DocEnv_id", oDoc.m_sDOCENV_ID));
            //SDCIM 7
            oParams.Add(new GeneralDBParameters("@DocOrigem_ID", oDoc.m_sDocOrigemID));
            //SDCIM 7
            m_oParameters.DirectStoredProcedureNonQuery("[dbo].[Insert_TibcoCancelaChaveDocumento]", ref oParams);
        }

        public void Insert_TibcoCancelaChaveDocumento(PesquisaDocumento oDoc, CIGlobalParameters m_oParameters)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@Operativa", 8));
            oParams.Add(new GeneralDBParameters("@TipoProduto", oDoc.m_sREMPROC_TIPOPROD));
            oParams.Add(new GeneralDBParameters("@Solucao", "SIDOC"));
            oParams.Add(new GeneralDBParameters("@Refarq", oDoc.m_sREFARQ));
            oParams.Add(new GeneralDBParameters("@Doc_id", oDoc.m_sDOC_ID));
            //SDCIM 7
            oParams.Add(new GeneralDBParameters("@DocOrigem_ID", oDoc.m_sDocOrigemID));
            //SDCIM 7
            m_oParameters.DirectStoredProcedureNonQuery("[dbo].[Insert_TibcoCancelaChaveDocumento]", ref oParams);
        }

        public void Insert_TibcoCancelaEnvioDocumento(PesquisaDocumentoACOM oDoc, CIGlobalParameters m_oParameters)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@Operativa", 8));
            oParams.Add(new GeneralDBParameters("@TipoProduto", oDoc.m_sLOTEACOM_PRODUTO));
            oParams.Add(new GeneralDBParameters("@Solucao", "SIDOC"));
            oParams.Add(new GeneralDBParameters("@Refarq", oDoc.m_sREFARQ));
            oParams.Add(new GeneralDBParameters("@Docacom_id", oDoc.m_sDOCACOM_ID));
            ////SDCIM 7
            //oParams.Add(new GeneralDBParameters("@DocOrigem_ID", oDoc.m_sDocOrigemID));
            ////SDCIM 7
            m_oParameters.DirectStoredProcedureNonQuery("[dbo].[Insert_TibcoCancelaEnvioDocumento]", ref oParams);
        }
                
        public void Confirma_TibcoCancelaChaveDocumento(string sCANCELADO, int iEstado, CIGlobalParameters m_oParameters)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@Cancelado", sCANCELADO));
            oParams.Add(new GeneralDBParameters("@Estado", iEstado));

            m_oParameters.DirectStoredProcedureNonQuery("[dbo].[Update_ConfirmaTibcoCancelaChaveDocumento]", ref oParams);
        }

        public void Confirma_TibcoCancelaEnvioDocumento(string sCANCELADO, int iEstado, CIGlobalParameters m_oParameters)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@Cancelado", sCANCELADO));
            oParams.Add(new GeneralDBParameters("@Estado", iEstado));

            m_oParameters.DirectStoredProcedureNonQuery("[dbo].[Update_ConfirmaTibcoCancelaEnvioDocumento]", ref oParams);
        }

        public void Confirma_TibcoNotificaEnvioDocumentoForaPrazo(string sNotificado, CIGlobalParameters m_oParameters)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@Doc_notificado", sNotificado));

            m_oParameters.DirectStoredProcedureNonQuery("[dbo].[Update_ConfirmaTibcoNotificaEnvioDocumentoForaPrazo]", ref oParams);
        }

        public void Anula_TibcoNotificaEnvioDocumentoForaPrazo(string sNotificado, CIGlobalParameters m_oParameters)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@Doc_notificado", sNotificado));

            m_oParameters.DirectStoredProcedureNonQuery("[dbo].[Delete_TibcoNotificaEnvioDocumentoForaPrazo]", ref oParams);
        }

        public void Insert_TibcoNotificaEnvioDocumentoForaPrazo(PesquisaDocumentoACOM oDoc, CIGlobalParameters m_oParameters)
        {
            string sQuery = "select count(*) from dbo.TIBCO_NOTIFICA_ENVIO_DOCUMENTO_FORA_PRAZO where notifica_refarq='" + oDoc.m_sREFARQ + "'";
            int iCount = (int)m_oParameters.DirectSqlScalar(sQuery);

            if (iCount > 0)
            {
                string sMsg = "Já existe " + iCount.ToString() + " documento(s) com a REFARQ:" + oDoc.m_sREFARQ;
                sMsg += "\nna tabela de notificação de envio fora de prazo";
                sMsg += "\n(dbo.TIBCO_NOTIFICA_ENVIO_DOCUMENTO_FORA_PRAZO)";
                sMsg += "\nPretende inserir de novo?";

                if (MessageBox.Show(sMsg, "Notifica Envio Fora de Prazo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    throw new Exception("Notificação de envio fora de prazo abortada!!!");
                }
            }

            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@DocACOM_id", oDoc.m_sDOCACOM_ID));
            oParams.Add(new GeneralDBParameters("@Operativa", "8"));
            oParams.Add(new GeneralDBParameters("@TipoProduto", "4"));
            oParams.Add(new GeneralDBParameters("@SubProduto", "001"));
            oParams.Add(new GeneralDBParameters("@Solucao", "SIDOC"));
            //oParams.Add(new GeneralDBParameters("@Operador", null));
            oParams.Add(new GeneralDBParameters("@Balcao", oDoc.m_sDOCACOM_BALCAO));
            //oParams.Add(new GeneralDBParameters("@Maquina", null));
            //oParams.Add(new GeneralDBParameters("@NumLote", null));
            //oParams.Add(new GeneralDBParameters("@Sequencia", null));
            oParams.Add(new GeneralDBParameters("@DataCompensacao", oDoc.m_dtFICH_DATA));
            //oParams.Add(new GeneralDBParameters("@DataRemessa", oDoc.m_dtFICH_DATA));
            //oParams.Add(new GeneralDBParameters("@NumRemessa", 0));
            oParams.Add(new GeneralDBParameters("@TipoRemessa", 1));
            oParams.Add(new GeneralDBParameters("@ChaveHost", oDoc.m_sDOCACOM_CHAVEH));
            oParams.Add(new GeneralDBParameters("@Refarq", oDoc.m_sREFARQ));
            oParams.Add(new GeneralDBParameters("@ZIB", oDoc.m_sDOCACOM_ZONA5));
            oParams.Add(new GeneralDBParameters("@NumConta", oDoc.m_sDOCACOM_ZONA4));
            oParams.Add(new GeneralDBParameters("@NumCheque", oDoc.m_sDOCACOM_ZONA3));
            oParams.Add(new GeneralDBParameters("@Montante", oDoc.m_dDOCACOM_IMPORT));
            oParams.Add(new GeneralDBParameters("@TipoCheque", oDoc.m_sDOCACOM_ZONA1));

            m_oParameters.DirectStoredProcedureNonQuery("[dbo].[Insert_TibcoNotificaEnvioDocumentoForaPrazo]", ref oParams);
        }

        public void Delete_TibcoCancelaEnvioDocumento(string sCANCELADO, CIGlobalParameters m_oParameters)
        {
            ArrayList oParams = new ArrayList();
            oParams.Add(new GeneralDBParameters("@Cancelado", sCANCELADO));

            m_oParameters.DirectStoredProcedureNonQuery("[dbo].[Delete_TibcoCancelaEnvioDocumento]", ref oParams);
        }


    }
}
