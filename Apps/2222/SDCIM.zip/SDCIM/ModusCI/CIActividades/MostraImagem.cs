﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;
using System.IO;


namespace CIActividades
{
    public partial class MostraImagem : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;

        InterfaceDocs m_oCurrDoc;
        Int32 e_origem;
        //DetalhesDocumento m_oCurrDoc;
        //ConsultaDocumentosDetalhe m_oCurrDetDoc;

        public MostraImagem(CIConfigGP.CIGlobalParameters oParameters, InterfaceDocs oCurrDoc, Int32 origem)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_oCurrDoc = oCurrDoc;
            this.e_origem = origem;
        }

        private void MostraImagem_Load(object sender, EventArgs e)
        {
            string sFileName;
            try
            {
                //parte da frente
                sFileName = m_oCurrDoc.getImgFrente(m_oParameters, e_origem);
                picImgFront.Image = System.Drawing.Image.FromFile(sFileName);
                picImgFront.SizeMode = PictureBoxSizeMode.StretchImage;

                //parte de tras
                sFileName = m_oCurrDoc.getImgBack(m_oParameters, e_origem);
                pictImgBack.Image = System.Drawing.Image.FromFile(sFileName);
                pictImgBack.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "MostraImagemForm", 11);
                labelErro.Visible = true;   
            }
        }

        private void MostraImagem_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                if (picImgFront.Image != null) picImgFront.Image.Dispose();
                if (pictImgBack.Image != null) pictImgBack.Image.Dispose();

                picImgFront.Image = null;
                pictImgBack.Image = null;
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "MostraImagemForm", 12);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}