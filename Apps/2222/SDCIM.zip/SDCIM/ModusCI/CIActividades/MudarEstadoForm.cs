﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;


using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;
namespace CIActividades
{
    public partial class MudarEstadoForm : Form
    {
        CIConfigGP.CIGlobalParameters m_oParameters;
        public bool m_bCancelPressed;
        int m_iOldActiv;
        string m_sTableName;
        string m_sCurrEstado;
        public int m_iNewEstado;
        public string m_sNewEstado;
        public string  m_sSPValida;
        public string  m_sSPProcessa;
 

        public MudarEstadoForm(CIConfigGP.CIGlobalParameters oParameters, int iOldActiv, string sTableName, string sCurrEstado)
        {
            m_sNewEstado = "";
            m_oParameters = oParameters;
            m_iOldActiv = iOldActiv;
            m_sTableName = sTableName;
            m_sCurrEstado = sCurrEstado;
            InitializeComponent();
        }

        private void MudarEstadoForm_Load(object sender, EventArgs e)
        {

            tbCurrentEstado.Text = m_iOldActiv.ToString() + " - " + m_sCurrEstado;

            m_iNewEstado = -999;
            m_bCancelPressed = false;

            int iSelected = 0;
            //int iIndex = 0;
            string sComm;
            DataSet ds;

            sComm = "Select ACTIVITY_OLD_DESC from view_activity_change_desc where ACTIVITY_OLD=" + m_iOldActiv + " AND ACTIVITY_TABLE='" + m_sTableName +"'";

            object obj = m_oParameters.DirectSqlScalar(sComm);
            if(obj != null)
            {
                tbCurrentEstado.Text = obj.ToString();
            }
            
            //sComm = "Select ACTIVITY_OLD, ACTIVITY_NEW, ACTIVITY_NEW_DESC from view_activity_change_desc where ACTIVITY_OLD=" + m_iOldActiv + " AND ACTIVITY_TABLE='" + m_sTableName + "'";
            sComm = "Select ACTCHANGE_ID, ACTIVITY_NEW, ACTIVITY_NEW_DESC, ACTIVITY_SPVALIDA, ACTIVITY_SPPROCESSA, TAG from view_activity_change_desc where ACTIVITY_OLD=" + m_iOldActiv + " AND ACTIVITY_TABLE='" + m_sTableName + "' order by ACTIVITY_NEW";
            ds = m_oParameters.DirectSqlDataSet(sComm, "ChangeEstado");
            cbEstadoNovo.Items.Clear();
           
            cbEstadoNovo.DataSource = ds.Tables[0];
            cbEstadoNovo.DisplayMember = "ACTIVITY_NEW_DESC";
            //cbEstadoNovo.ValueMember = "ACTCHANGE_ID";

            ds.Dispose();


            DataTable oTable = (DataTable)cbEstadoNovo.DataSource;

            //SqlDataReader dr;

            //dr = m_oParameters.DirectSqlDataReader(sComm);
            //while (dr.Read())
            //{
            //    object obj = dr["ACTIVITY_NEW_DESC"]
            //    iIndex = cbEstadoNovo.Items.Add(obj.Gettexto);
            //    if (dr["ACTIVITY_NEW"].ToString() == m_iOldActiv.ToString())
            //        iSelected = iIndex;
            //}
            //dr.Close();

            if (cbEstadoNovo.Items.Count > 0)
                cbEstadoNovo.SelectedIndex = iSelected;
            else
            {
                btOK.Enabled = false;
                cbEstadoNovo.Enabled = false;
            }
        }

        private void btOK_Click(object sender, EventArgs e)
        {
            DataRowView oRow;

            m_sNewEstado = cbEstadoNovo.Text;
           
            //string[] sValores;

            oRow = (DataRowView)cbEstadoNovo.SelectedValue;

            //sValores = cbEstadoNovo.SelectedValue.ToString().Split(',');

            //m_iNewEstado = int.Parse(sValores[0]);
            //m_sSPValida = sValores[1];
            //m_sSPProcessa = sValores[2];

            m_iNewEstado = Convert.ToInt16(oRow["ACTIVITY_NEW"]);
            m_sSPValida = oRow["ACTIVITY_SPVALIDA"].ToString();
            m_sSPProcessa = oRow["ACTIVITY_SPPROCESSA"].ToString();


            DialogResult = DialogResult.OK;
        }

       
    }
}