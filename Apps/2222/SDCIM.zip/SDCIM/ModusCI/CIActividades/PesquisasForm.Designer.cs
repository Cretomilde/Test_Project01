﻿namespace CIActividades
{
    partial class PesquisasForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);

            m_oMenuInterface.PesquisasEnable(true);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PesquisasForm));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonEmAnalise = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonOK = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonMaisMenos = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonErro = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonExitJanela = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonRem = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonENVM = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonACOM = new System.Windows.Forms.ToolStripButton();
            this.m_ctrldtFim = new System.Windows.Forms.DateTimePicker();
            this.m_ctrldtInicio = new System.Windows.Forms.DateTimePicker();
            this.listViewPesquisaDocumento = new NBIISNET.ListViewBase();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderPROC_TIMER = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnOrigemCompensacao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader31 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocZona1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocNIB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColDocRefarq = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderRefarqOri = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderISReapresentado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderReapr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderReaprID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderDocCancelado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeadercancelID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.detDocColChaveH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStripDOC = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItemReapresentarDOC = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemConfirmarDOC = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemAnularDOC = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.historicoDoDocumentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.cancelaDocumentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.confirmarCancelamentoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.anularCancelamentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marcarCancelamentoComEfectuadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listViewPesquisaDocumentoENVM = new NBIISNET.ListViewBase();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colunaOrigem = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LoteAnom = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader22 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader23 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderRefarqOriENVM = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmImgQual = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader24 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader26 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader25 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderReap = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader35 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderCancelado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader39 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderNotif = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader53 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader27 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStripENVM = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItemENVMNotificaAcolhimento = new System.Windows.Forms.ToolStripMenuItem();
            this.confirmarNotificacaoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemENVMAnulaNotificacao = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.reapresentarCompensacaoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ConfirmarReapresentacaoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.anularReapresentacaoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItemHistoricoENVM = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.cancelaDocumentoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.confirmarCancelamentoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.anularCancelamentoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.labelDOC = new System.Windows.Forms.Label();
            this.buttonDocumento = new System.Windows.Forms.Button();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.labelENVM = new System.Windows.Forms.Label();
            this.buttonENVM = new System.Windows.Forms.Button();
            this.labelACOM = new System.Windows.Forms.Label();
            this.listViewPesquisaDocumentoACOM = new NBIISNET.ListViewBase();
            this.columnHeader28 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader29 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader30 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader32 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader33 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader34 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader36 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader37 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader40 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnOrigem = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader41 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader42 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader43 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader44 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader45 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader46 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader47 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader48 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader49 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnACOMCancel = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader38 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderACOMNotif = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader52 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader50 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader51 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStripACOM = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CancelaACOMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.confirmarCancelamentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.anulaCancelaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItemHistoricoACOM = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.NotificaACOMStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ConfirmaNotificaACOMStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AnulaNotificaACOMStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonACOM = new System.Windows.Forms.Button();
            this.textBoxMontante = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxBalcao = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxNumRemessa = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxNumCheque = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxREFARQ = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBoxPorAnalisar = new System.Windows.Forms.CheckBox();
            this.lblOrigem = new System.Windows.Forms.Label();
            this.cbOrigem = new System.Windows.Forms.ComboBox();
            this.cbPendenteIntervencao = new System.Windows.Forms.CheckBox();
            this.lblDeposito = new System.Windows.Forms.Label();
            this.txtDeposito = new System.Windows.Forms.TextBox();
            this.toolStrip1.SuspendLayout();
            this.contextMenuStripDOC.SuspendLayout();
            this.contextMenuStripENVM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.contextMenuStripACOM.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonEmAnalise,
            this.toolStripSeparator3,
            this.toolStripButtonOK,
            this.toolStripButtonMaisMenos,
            this.toolStripButtonErro,
            this.toolStripSeparator2,
            this.toolStripButtonExitJanela,
            this.toolStripSeparator4,
            this.toolStripButtonRem,
            this.toolStripSeparator1,
            this.toolStripButtonENVM,
            this.toolStripSeparator5,
            this.toolStripButtonACOM});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0);
            this.toolStrip1.Size = new System.Drawing.Size(988, 39);
            this.toolStrip1.TabIndex = 24;
            this.toolStrip1.Text = "toolStripActividades";
            // 
            // toolStripButtonEmAnalise
            // 
            this.toolStripButtonEmAnalise.CheckOnClick = true;
            this.toolStripButtonEmAnalise.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonEmAnalise.Image = global::CIActividades.Properties.Resources.Par;
            this.toolStripButtonEmAnalise.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonEmAnalise.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonEmAnalise.Name = "toolStripButtonEmAnalise";
            this.toolStripButtonEmAnalise.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonEmAnalise.Text = "toolStripButton4";
            this.toolStripButtonEmAnalise.ToolTipText = "Em análise";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButtonOK
            // 
            this.toolStripButtonOK.CheckOnClick = true;
            this.toolStripButtonOK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonOK.Image = global::CIActividades.Properties.Resources.Bom;
            this.toolStripButtonOK.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonOK.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonOK.Name = "toolStripButtonOK";
            this.toolStripButtonOK.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonOK.Text = "Ver OK";
            this.toolStripButtonOK.ToolTipText = "Ver OK";
            // 
            // toolStripButtonMaisMenos
            // 
            this.toolStripButtonMaisMenos.CheckOnClick = true;
            this.toolStripButtonMaisMenos.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonMaisMenos.Image = global::CIActividades.Properties.Resources.comprobl;
            this.toolStripButtonMaisMenos.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonMaisMenos.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonMaisMenos.Name = "toolStripButtonMaisMenos";
            this.toolStripButtonMaisMenos.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonMaisMenos.Text = "Ver Mais ou Menos";
            this.toolStripButtonMaisMenos.ToolTipText = "Ver Mai ou Menos";
            // 
            // toolStripButtonErro
            // 
            this.toolStripButtonErro.CheckOnClick = true;
            this.toolStripButtonErro.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonErro.Image = global::CIActividades.Properties.Resources.Erro;
            this.toolStripButtonErro.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonErro.Margin = new System.Windows.Forms.Padding(0, 1, 10, 2);
            this.toolStripButtonErro.Name = "toolStripButtonErro";
            this.toolStripButtonErro.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonErro.Text = "Ver em Erro";
            this.toolStripButtonErro.ToolTipText = "Ver em Erro";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButtonExitJanela
            // 
            this.toolStripButtonExitJanela.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonExitJanela.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonExitJanela.Image")));
            this.toolStripButtonExitJanela.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonExitJanela.Name = "toolStripButtonExitJanela";
            this.toolStripButtonExitJanela.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonExitJanela.Click += new System.EventHandler(this.toolStripButtonExitJanela_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButtonRem
            // 
            this.toolStripButtonRem.BackColor = System.Drawing.SystemColors.Info;
            this.toolStripButtonRem.Checked = true;
            this.toolStripButtonRem.CheckOnClick = true;
            this.toolStripButtonRem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButtonRem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonRem.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripButtonRem.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonRem.Image")));
            this.toolStripButtonRem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRem.Name = "toolStripButtonRem";
            this.toolStripButtonRem.Size = new System.Drawing.Size(37, 36);
            this.toolStripButtonRem.Text = "Rem";
            this.toolStripButtonRem.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.toolStripButtonRem.Click += new System.EventHandler(this.toolStripButtonRem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButtonENVM
            // 
            this.toolStripButtonENVM.BackColor = System.Drawing.SystemColors.Info;
            this.toolStripButtonENVM.Checked = true;
            this.toolStripButtonENVM.CheckOnClick = true;
            this.toolStripButtonENVM.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButtonENVM.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonENVM.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripButtonENVM.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonENVM.Image")));
            this.toolStripButtonENVM.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonENVM.Name = "toolStripButtonENVM";
            this.toolStripButtonENVM.Size = new System.Drawing.Size(41, 36);
            this.toolStripButtonENVM.Text = "ENVM";
            this.toolStripButtonENVM.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.toolStripButtonENVM.Click += new System.EventHandler(this.toolStripButtonENVM_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButtonACOM
            // 
            this.toolStripButtonACOM.BackColor = System.Drawing.SystemColors.Info;
            this.toolStripButtonACOM.Checked = true;
            this.toolStripButtonACOM.CheckOnClick = true;
            this.toolStripButtonACOM.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButtonACOM.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonACOM.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripButtonACOM.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonACOM.Image")));
            this.toolStripButtonACOM.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonACOM.Name = "toolStripButtonACOM";
            this.toolStripButtonACOM.Size = new System.Drawing.Size(44, 36);
            this.toolStripButtonACOM.Text = "ACOM";
            this.toolStripButtonACOM.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.toolStripButtonACOM.Click += new System.EventHandler(this.toolStripButtonACOM_Click);
            // 
            // m_ctrldtFim
            // 
            this.m_ctrldtFim.CustomFormat = "yyyy-MM-dd";
            this.m_ctrldtFim.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrldtFim.Location = new System.Drawing.Point(103, 57);
            this.m_ctrldtFim.Name = "m_ctrldtFim";
            this.m_ctrldtFim.Size = new System.Drawing.Size(85, 20);
            this.m_ctrldtFim.TabIndex = 1;
            // 
            // m_ctrldtInicio
            // 
            this.m_ctrldtInicio.CustomFormat = "yyyy-MM-dd";
            this.m_ctrldtInicio.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.m_ctrldtInicio.Location = new System.Drawing.Point(12, 57);
            this.m_ctrldtInicio.Name = "m_ctrldtInicio";
            this.m_ctrldtInicio.Size = new System.Drawing.Size(85, 20);
            this.m_ctrldtInicio.TabIndex = 0;
            // 
            // listViewPesquisaDocumento
            // 
            this.listViewPesquisaDocumento.AllowColumnReorder = true;
            this.listViewPesquisaDocumento.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewPesquisaDocumento.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader3,
            this.columnHeaderPROC_TIMER,
            this.columnOrigemCompensacao,
            this.columnHeader2,
            this.columnHeader31,
            this.columnHeader1,
            this.detDocColDocId,
            this.detDocColDocZona5,
            this.detDocColDocZona4,
            this.detDocColDocZona3,
            this.detDocColDocZona2,
            this.detDocColDocZona1,
            this.detDocColDocNIB,
            this.detDocColDocRefarq,
            this.columnHeaderRefarqOri,
            this.columnHeaderISReapresentado,
            this.columnHeaderReapr,
            this.columnHeaderReaprID,
            this.columnHeaderDocCancelado,
            this.columnHeadercancelID,
            this.detDocColChaveH});
            this.listViewPesquisaDocumento.ContextMenuStrip = this.contextMenuStripDOC;
            this.listViewPesquisaDocumento.EnableExportar = true;
            this.listViewPesquisaDocumento.FullRowSelect = true;
            this.listViewPesquisaDocumento.GridLines = true;
            this.listViewPesquisaDocumento.HideSelection = false;
            this.listViewPesquisaDocumento.Location = new System.Drawing.Point(3, 27);
            this.listViewPesquisaDocumento.Name = "listViewPesquisaDocumento";
            this.listViewPesquisaDocumento.Size = new System.Drawing.Size(985, 149);
            this.listViewPesquisaDocumento.TabIndex = 42;
            this.listViewPesquisaDocumento.TabStop = false;
            this.listViewPesquisaDocumento.UseCompatibleStateImageBehavior = false;
            this.listViewPesquisaDocumento.View = System.Windows.Forms.View.Details;
            this.listViewPesquisaDocumento.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listViewPesquisaDocumento_MouseDoubleClick);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "ReminID";
            this.columnHeader4.Width = 0;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Rem.Data";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 70;
            // 
            // columnHeaderPROC_TIMER
            // 
            this.columnHeaderPROC_TIMER.Text = "ProcTimer";
            this.columnHeaderPROC_TIMER.Width = 120;
            // 
            // columnOrigemCompensacao
            // 
            this.columnOrigemCompensacao.Text = "Origem";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Rem.Balcao";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader2.Width = 50;
            // 
            // columnHeader31
            // 
            this.columnHeader31.Text = "RemNumero";
            this.columnHeader31.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader31.Width = 80;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Rem.Estado";
            this.columnHeader1.Width = 90;
            // 
            // detDocColDocId
            // 
            this.detDocColDocId.Text = "Doc ID";
            this.detDocColDocId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.detDocColDocId.Width = 49;
            // 
            // detDocColDocZona5
            // 
            this.detDocColDocZona5.Text = "ZIB";
            // 
            // detDocColDocZona4
            // 
            this.detDocColDocZona4.Text = "N. Conta";
            this.detDocColDocZona4.Width = 80;
            // 
            // detDocColDocZona3
            // 
            this.detDocColDocZona3.Text = "N.Cheque";
            this.detDocColDocZona3.Width = 75;
            // 
            // detDocColDocZona2
            // 
            this.detDocColDocZona2.Text = "Montante";
            this.detDocColDocZona2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.detDocColDocZona2.Width = 100;
            // 
            // detDocColDocZona1
            // 
            this.detDocColDocZona1.Text = "Tp";
            this.detDocColDocZona1.Width = 30;
            // 
            // detDocColDocNIB
            // 
            this.detDocColDocNIB.Text = "Conta/NIB";
            this.detDocColDocNIB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocNIB.Width = 120;
            // 
            // detDocColDocRefarq
            // 
            this.detDocColDocRefarq.Text = "Refarq";
            this.detDocColDocRefarq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColDocRefarq.Width = 100;
            // 
            // columnHeaderRefarqOri
            // 
            this.columnHeaderRefarqOri.Text = "RefarqOri";
            this.columnHeaderRefarqOri.Width = 30;
            // 
            // columnHeaderISReapresentado
            // 
            this.columnHeaderISReapresentado.Text = "IsReapresentado";
            this.columnHeaderISReapresentado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeaderISReapresentado.Width = 20;
            // 
            // columnHeaderReapr
            // 
            this.columnHeaderReapr.Text = "Reapresentado";
            // 
            // columnHeaderReaprID
            // 
            this.columnHeaderReaprID.Text = "Reapr.ID";
            this.columnHeaderReaprID.Width = 0;
            // 
            // columnHeaderDocCancelado
            // 
            this.columnHeaderDocCancelado.Text = "Cancelamento";
            // 
            // columnHeadercancelID
            // 
            this.columnHeadercancelID.Text = "Cancel ID";
            this.columnHeadercancelID.Width = 0;
            // 
            // detDocColChaveH
            // 
            this.detDocColChaveH.Text = "ChaveH";
            this.detDocColChaveH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detDocColChaveH.Width = 150;
            // 
            // contextMenuStripDOC
            // 
            this.contextMenuStripDOC.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemReapresentarDOC,
            this.toolStripMenuItemConfirmarDOC,
            this.toolStripMenuItemAnularDOC,
            this.toolStripMenuItem2,
            this.historicoDoDocumentoToolStripMenuItem,
            this.toolStripMenuItem5,
            this.cancelaDocumentoToolStripMenuItem,
            this.confirmarCancelamentoToolStripMenuItem1,
            this.anularCancelamentoToolStripMenuItem,
            this.marcarCancelamentoComEfectuadoToolStripMenuItem});
            this.contextMenuStripDOC.Name = "contextMenuStripRemTrans";
            this.contextMenuStripDOC.Size = new System.Drawing.Size(297, 192);
            this.contextMenuStripDOC.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripDOC_Opening);
            // 
            // toolStripMenuItemReapresentarDOC
            // 
            this.toolStripMenuItemReapresentarDOC.Name = "toolStripMenuItemReapresentarDOC";
            this.toolStripMenuItemReapresentarDOC.Size = new System.Drawing.Size(296, 22);
            this.toolStripMenuItemReapresentarDOC.Text = "Reapresentar à Compensação";
            this.toolStripMenuItemReapresentarDOC.Click += new System.EventHandler(this.toolStripMenuItemReapresentarDOC_Click);
            // 
            // toolStripMenuItemConfirmarDOC
            // 
            this.toolStripMenuItemConfirmarDOC.Name = "toolStripMenuItemConfirmarDOC";
            this.toolStripMenuItemConfirmarDOC.Size = new System.Drawing.Size(296, 22);
            this.toolStripMenuItemConfirmarDOC.Text = "Confirmar Reapresentação";
            this.toolStripMenuItemConfirmarDOC.Click += new System.EventHandler(this.toolStripMenuItemConfirmarDOC_Click);
            // 
            // toolStripMenuItemAnularDOC
            // 
            this.toolStripMenuItemAnularDOC.Name = "toolStripMenuItemAnularDOC";
            this.toolStripMenuItemAnularDOC.Size = new System.Drawing.Size(296, 22);
            this.toolStripMenuItemAnularDOC.Text = "Anular Reapresentação";
            this.toolStripMenuItemAnularDOC.Click += new System.EventHandler(this.toolStripMenuItemAnularDOC_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(293, 6);
            // 
            // historicoDoDocumentoToolStripMenuItem
            // 
            this.historicoDoDocumentoToolStripMenuItem.Name = "historicoDoDocumentoToolStripMenuItem";
            this.historicoDoDocumentoToolStripMenuItem.Size = new System.Drawing.Size(296, 22);
            this.historicoDoDocumentoToolStripMenuItem.Text = "Historico do documento";
            this.historicoDoDocumentoToolStripMenuItem.Click += new System.EventHandler(this.historicoDoDocumentoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(293, 6);
            // 
            // cancelaDocumentoToolStripMenuItem
            // 
            this.cancelaDocumentoToolStripMenuItem.Name = "cancelaDocumentoToolStripMenuItem";
            this.cancelaDocumentoToolStripMenuItem.Size = new System.Drawing.Size(296, 22);
            this.cancelaDocumentoToolStripMenuItem.Text = "Cancela Documento à Compensação";
            this.cancelaDocumentoToolStripMenuItem.Click += new System.EventHandler(this.cancelaDocumentoToolStripMenuItem_Click);
            // 
            // confirmarCancelamentoToolStripMenuItem1
            // 
            this.confirmarCancelamentoToolStripMenuItem1.Name = "confirmarCancelamentoToolStripMenuItem1";
            this.confirmarCancelamentoToolStripMenuItem1.Size = new System.Drawing.Size(296, 22);
            this.confirmarCancelamentoToolStripMenuItem1.Text = "Confirmar Cancelamento à Compensação";
            this.confirmarCancelamentoToolStripMenuItem1.Click += new System.EventHandler(this.confirmarCancelamentoToolStripMenuItem1_Click);
            // 
            // anularCancelamentoToolStripMenuItem
            // 
            this.anularCancelamentoToolStripMenuItem.Name = "anularCancelamentoToolStripMenuItem";
            this.anularCancelamentoToolStripMenuItem.Size = new System.Drawing.Size(296, 22);
            this.anularCancelamentoToolStripMenuItem.Text = "Anular Cancelamento à Compensação";
            this.anularCancelamentoToolStripMenuItem.Click += new System.EventHandler(this.anularCancelamentoToolStripMenuItem_Click);
            // 
            // marcarCancelamentoComEfectuadoToolStripMenuItem
            // 
            this.marcarCancelamentoComEfectuadoToolStripMenuItem.Name = "marcarCancelamentoComEfectuadoToolStripMenuItem";
            this.marcarCancelamentoComEfectuadoToolStripMenuItem.Size = new System.Drawing.Size(296, 22);
            this.marcarCancelamentoComEfectuadoToolStripMenuItem.Text = "Marcar Cancelamento como Efectuado";
            this.marcarCancelamentoComEfectuadoToolStripMenuItem.Click += new System.EventHandler(this.marcarCancelamentoComEfectuadoToolStripMenuItem_Click);
            // 
            // listViewPesquisaDocumentoENVM
            // 
            this.listViewPesquisaDocumentoENVM.AllowColumnReorder = true;
            this.listViewPesquisaDocumentoENVM.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewPesquisaDocumentoENVM.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.colunaOrigem,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader16,
            this.LoteAnom,
            this.columnHeader17,
            this.columnHeader18,
            this.columnHeader19,
            this.columnHeader20,
            this.columnHeader21,
            this.columnHeader22,
            this.columnHeader23,
            this.columnHeaderRefarqOriENVM,
            this.clmImgQual,
            this.columnHeader24,
            this.columnHeader26,
            this.columnHeader25,
            this.columnHeaderReap,
            this.columnHeader35,
            this.columnHeaderCancelado,
            this.columnHeader39,
            this.columnHeaderNotif,
            this.columnHeader53,
            this.columnHeader27});
            this.listViewPesquisaDocumentoENVM.ContextMenuStrip = this.contextMenuStripENVM;
            this.listViewPesquisaDocumentoENVM.EnableExportar = true;
            this.listViewPesquisaDocumentoENVM.FullRowSelect = true;
            this.listViewPesquisaDocumentoENVM.GridLines = true;
            this.listViewPesquisaDocumentoENVM.HideSelection = false;
            this.listViewPesquisaDocumentoENVM.Location = new System.Drawing.Point(3, 30);
            this.listViewPesquisaDocumentoENVM.Name = "listViewPesquisaDocumentoENVM";
            this.listViewPesquisaDocumentoENVM.Size = new System.Drawing.Size(476, 234);
            this.listViewPesquisaDocumentoENVM.TabIndex = 43;
            this.listViewPesquisaDocumentoENVM.UseCompatibleStateImageBehavior = false;
            this.listViewPesquisaDocumentoENVM.View = System.Windows.Forms.View.Details;
            this.listViewPesquisaDocumentoENVM.DoubleClick += new System.EventHandler(this.listViewPesquisaDocumentoENVM_DoubleClick);
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "FichID";
            this.columnHeader5.Width = 0;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "FichNSeq";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader6.Width = 50;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "FichData";
            this.columnHeader7.Width = 70;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "REFCMP";
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "LOTEENVID";
            this.columnHeader9.Width = 0;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "LotNum";
            this.columnHeader10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader10.Width = 50;
            // 
            // colunaOrigem
            // 
            this.colunaOrigem.Text = "Origem";
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "CodBal";
            this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader11.Width = 50;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "NumRem";
            this.columnHeader12.Width = 80;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "RemData";
            this.columnHeader13.Width = 70;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "TCAP";
            this.columnHeader14.Width = 30;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "TREM";
            this.columnHeader15.Width = 30;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "LoteStatus";
            this.columnHeader16.Width = 80;
            // 
            // LoteAnom
            // 
            this.LoteAnom.Text = "Lote Anomal";
            this.LoteAnom.Width = 80;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "DocenvID";
            this.columnHeader17.Width = 0;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "ZIB";
            this.columnHeader18.Width = 70;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "NConta";
            this.columnHeader19.Width = 80;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "NCheque";
            this.columnHeader20.Width = 75;
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "Import";
            this.columnHeader21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader21.Width = 100;
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "Tipo";
            this.columnHeader22.Width = 30;
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "REFARQ";
            this.columnHeader23.Width = 100;
            // 
            // columnHeaderRefarqOriENVM
            // 
            this.columnHeaderRefarqOriENVM.Text = "RefarqOri";
            // 
            // clmImgQual
            // 
            this.clmImgQual.Text = "Img. Qual.";
            this.clmImgQual.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clmImgQual.Width = 50;
            // 
            // columnHeader24
            // 
            this.columnHeader24.Text = "Anomal";
            // 
            // columnHeader26
            // 
            this.columnHeader26.Text = "CodAna";
            this.columnHeader26.Width = 30;
            // 
            // columnHeader25
            // 
            this.columnHeader25.Text = "Duplicado";
            this.columnHeader25.Width = 30;
            // 
            // columnHeaderReap
            // 
            this.columnHeaderReap.Text = "Reapr.";
            // 
            // columnHeader35
            // 
            this.columnHeader35.Text = "Reapr.ID";
            this.columnHeader35.Width = 0;
            // 
            // columnHeaderCancelado
            // 
            this.columnHeaderCancelado.Text = "Cancelamento";
            // 
            // columnHeader39
            // 
            this.columnHeader39.Text = "Cancel ID";
            this.columnHeader39.Width = 0;
            // 
            // columnHeaderNotif
            // 
            this.columnHeaderNotif.Text = "Notificação";
            this.columnHeaderNotif.Width = 100;
            // 
            // columnHeader53
            // 
            this.columnHeader53.Text = "Notif ID";
            this.columnHeader53.Width = 0;
            // 
            // columnHeader27
            // 
            this.columnHeader27.Text = "ChaveH";
            this.columnHeader27.Width = 100;
            // 
            // contextMenuStripENVM
            // 
            this.contextMenuStripENVM.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemENVMNotificaAcolhimento,
            this.confirmarNotificacaoToolStripMenuItem,
            this.toolStripMenuItemENVMAnulaNotificacao,
            this.toolStripMenuItem1,
            this.reapresentarCompensacaoToolStripMenuItem,
            this.ConfirmarReapresentacaoToolStripMenuItem,
            this.anularReapresentacaoToolStripMenuItem,
            this.toolStripMenuItem3,
            this.toolStripMenuItemHistoricoENVM,
            this.toolStripMenuItem6,
            this.cancelaDocumentoToolStripMenuItem1,
            this.confirmarCancelamentoToolStripMenuItem2,
            this.anularCancelamentoToolStripMenuItem1});
            this.contextMenuStripENVM.Name = "contextMenuStripRemTrans";
            this.contextMenuStripENVM.Size = new System.Drawing.Size(365, 242);
            this.contextMenuStripENVM.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripENVM_Opening);
            // 
            // toolStripMenuItemENVMNotificaAcolhimento
            // 
            this.toolStripMenuItemENVMNotificaAcolhimento.Name = "toolStripMenuItemENVMNotificaAcolhimento";
            this.toolStripMenuItemENVMNotificaAcolhimento.Size = new System.Drawing.Size(364, 22);
            this.toolStripMenuItemENVMNotificaAcolhimento.Text = "Notifica Acolhimento de Envio Documento Fora Prazo";
            this.toolStripMenuItemENVMNotificaAcolhimento.Click += new System.EventHandler(this.toolStripMenuItemENVMNotificaAcolhimento_Click);
            // 
            // confirmarNotificacaoToolStripMenuItem
            // 
            this.confirmarNotificacaoToolStripMenuItem.Name = "confirmarNotificacaoToolStripMenuItem";
            this.confirmarNotificacaoToolStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.confirmarNotificacaoToolStripMenuItem.Text = "Confirmar Notificação de Envio Documento Fora Prazo";
            this.confirmarNotificacaoToolStripMenuItem.Click += new System.EventHandler(this.confirmarNotificacaoToolStripMenuItem_Click);
            // 
            // toolStripMenuItemENVMAnulaNotificacao
            // 
            this.toolStripMenuItemENVMAnulaNotificacao.Name = "toolStripMenuItemENVMAnulaNotificacao";
            this.toolStripMenuItemENVMAnulaNotificacao.Size = new System.Drawing.Size(364, 22);
            this.toolStripMenuItemENVMAnulaNotificacao.Text = "Anula Notificação de Envio Documento Fora Prazo";
            this.toolStripMenuItemENVMAnulaNotificacao.Click += new System.EventHandler(this.toolStripMenuItemENVMAnulaNotificacao_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(361, 6);
            // 
            // reapresentarCompensacaoToolStripMenuItem
            // 
            this.reapresentarCompensacaoToolStripMenuItem.Name = "reapresentarCompensacaoToolStripMenuItem";
            this.reapresentarCompensacaoToolStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.reapresentarCompensacaoToolStripMenuItem.Text = "Reapresentar à Compensação";
            this.reapresentarCompensacaoToolStripMenuItem.Click += new System.EventHandler(this.reapresentarCompensacaoToolStripMenuItem_Click);
            // 
            // ConfirmarReapresentacaoToolStripMenuItem
            // 
            this.ConfirmarReapresentacaoToolStripMenuItem.Name = "ConfirmarReapresentacaoToolStripMenuItem";
            this.ConfirmarReapresentacaoToolStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.ConfirmarReapresentacaoToolStripMenuItem.Text = "Confirmar Reapresentação";
            this.ConfirmarReapresentacaoToolStripMenuItem.Click += new System.EventHandler(this.ConfirmarReapresentacaoToolStripMenuItem_Click);
            // 
            // anularReapresentacaoToolStripMenuItem
            // 
            this.anularReapresentacaoToolStripMenuItem.Name = "anularReapresentacaoToolStripMenuItem";
            this.anularReapresentacaoToolStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.anularReapresentacaoToolStripMenuItem.Text = "Anular Reapresentação";
            this.anularReapresentacaoToolStripMenuItem.Click += new System.EventHandler(this.anularReapresentacaoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(361, 6);
            // 
            // toolStripMenuItemHistoricoENVM
            // 
            this.toolStripMenuItemHistoricoENVM.Name = "toolStripMenuItemHistoricoENVM";
            this.toolStripMenuItemHistoricoENVM.Size = new System.Drawing.Size(364, 22);
            this.toolStripMenuItemHistoricoENVM.Text = "Historico do documento";
            this.toolStripMenuItemHistoricoENVM.Click += new System.EventHandler(this.toolStripMenuItemHistoricoENVM_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(361, 6);
            // 
            // cancelaDocumentoToolStripMenuItem1
            // 
            this.cancelaDocumentoToolStripMenuItem1.Name = "cancelaDocumentoToolStripMenuItem1";
            this.cancelaDocumentoToolStripMenuItem1.Size = new System.Drawing.Size(364, 22);
            this.cancelaDocumentoToolStripMenuItem1.Text = "Cancela Documento à Compensação";
            this.cancelaDocumentoToolStripMenuItem1.Click += new System.EventHandler(this.cancelaDocumentoToolStripMenuItem1_Click);
            // 
            // confirmarCancelamentoToolStripMenuItem2
            // 
            this.confirmarCancelamentoToolStripMenuItem2.Name = "confirmarCancelamentoToolStripMenuItem2";
            this.confirmarCancelamentoToolStripMenuItem2.Size = new System.Drawing.Size(364, 22);
            this.confirmarCancelamentoToolStripMenuItem2.Text = "Confirmar Cancelamento à Compensação";
            this.confirmarCancelamentoToolStripMenuItem2.Click += new System.EventHandler(this.confirmarCancelamentoToolStripMenuItem2_Click);
            // 
            // anularCancelamentoToolStripMenuItem1
            // 
            this.anularCancelamentoToolStripMenuItem1.Name = "anularCancelamentoToolStripMenuItem1";
            this.anularCancelamentoToolStripMenuItem1.Size = new System.Drawing.Size(364, 22);
            this.anularCancelamentoToolStripMenuItem1.Text = "Anular Cancelamento à Compensação";
            this.anularCancelamentoToolStripMenuItem1.Click += new System.EventHandler(this.anularCancelamentoToolStripMenuItem1_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(0, 83);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.labelDOC);
            this.splitContainer1.Panel1.Controls.Add(this.listViewPesquisaDocumento);
            this.splitContainer1.Panel1.Controls.Add(this.buttonDocumento);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(988, 456);
            this.splitContainer1.SplitterDistance = 179;
            this.splitContainer1.TabIndex = 44;
            // 
            // labelDOC
            // 
            this.labelDOC.AutoSize = true;
            this.labelDOC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDOC.Location = new System.Drawing.Point(111, 8);
            this.labelDOC.Name = "labelDOC";
            this.labelDOC.Size = new System.Drawing.Size(286, 13);
            this.labelDOC.TabIndex = 43;
            this.labelDOC.Text = "Registos em Remessas enviadas à Compensação";
            // 
            // buttonDocumento
            // 
            this.buttonDocumento.Location = new System.Drawing.Point(12, 3);
            this.buttonDocumento.Name = "buttonDocumento";
            this.buttonDocumento.Size = new System.Drawing.Size(75, 23);
            this.buttonDocumento.TabIndex = 0;
            this.buttonDocumento.Text = "Refresh";
            this.buttonDocumento.UseVisualStyleBackColor = true;
            this.buttonDocumento.Click += new System.EventHandler(this.buttonDocumento_Click);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer2.Location = new System.Drawing.Point(3, 3);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.labelENVM);
            this.splitContainer2.Panel1.Controls.Add(this.listViewPesquisaDocumentoENVM);
            this.splitContainer2.Panel1.Controls.Add(this.buttonENVM);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.labelACOM);
            this.splitContainer2.Panel2.Controls.Add(this.listViewPesquisaDocumentoACOM);
            this.splitContainer2.Panel2.Controls.Add(this.buttonACOM);
            this.splitContainer2.Size = new System.Drawing.Size(982, 267);
            this.splitContainer2.SplitterDistance = 482;
            this.splitContainer2.TabIndex = 44;
            // 
            // labelENVM
            // 
            this.labelENVM.AutoSize = true;
            this.labelENVM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelENVM.Location = new System.Drawing.Point(107, 9);
            this.labelENVM.Name = "labelENVM";
            this.labelENVM.Size = new System.Drawing.Size(115, 13);
            this.labelENVM.TabIndex = 44;
            this.labelENVM.Text = "Registos em ENVM";
            // 
            // buttonENVM
            // 
            this.buttonENVM.Location = new System.Drawing.Point(9, 3);
            this.buttonENVM.Name = "buttonENVM";
            this.buttonENVM.Size = new System.Drawing.Size(75, 23);
            this.buttonENVM.TabIndex = 0;
            this.buttonENVM.Text = "Refresh";
            this.buttonENVM.UseVisualStyleBackColor = true;
            this.buttonENVM.Click += new System.EventHandler(this.buttonENVM_Click);
            // 
            // labelACOM
            // 
            this.labelACOM.AutoSize = true;
            this.labelACOM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelACOM.Location = new System.Drawing.Point(98, 8);
            this.labelACOM.Name = "labelACOM";
            this.labelACOM.Size = new System.Drawing.Size(115, 13);
            this.labelACOM.TabIndex = 45;
            this.labelACOM.Text = "Registos em ACOM";
            // 
            // listViewPesquisaDocumentoACOM
            // 
            this.listViewPesquisaDocumentoACOM.AllowColumnReorder = true;
            this.listViewPesquisaDocumentoACOM.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewPesquisaDocumentoACOM.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader28,
            this.columnHeader29,
            this.columnHeader30,
            this.columnHeader32,
            this.columnHeader33,
            this.columnHeader34,
            this.columnHeader36,
            this.columnHeader37,
            this.columnHeader40,
            this.columnOrigem,
            this.columnHeader41,
            this.columnHeader42,
            this.columnHeader43,
            this.columnHeader44,
            this.columnHeader45,
            this.columnHeader46,
            this.columnHeader47,
            this.columnHeader48,
            this.columnHeader49,
            this.columnACOMCancel,
            this.columnHeader38,
            this.columnHeaderACOMNotif,
            this.columnHeader52,
            this.columnHeader50,
            this.columnHeader51});
            this.listViewPesquisaDocumentoACOM.ContextMenuStrip = this.contextMenuStripACOM;
            this.listViewPesquisaDocumentoACOM.EnableExportar = true;
            this.listViewPesquisaDocumentoACOM.FullRowSelect = true;
            this.listViewPesquisaDocumentoACOM.GridLines = true;
            this.listViewPesquisaDocumentoACOM.HideSelection = false;
            this.listViewPesquisaDocumentoACOM.Location = new System.Drawing.Point(3, 30);
            this.listViewPesquisaDocumentoACOM.Name = "listViewPesquisaDocumentoACOM";
            this.listViewPesquisaDocumentoACOM.Size = new System.Drawing.Size(490, 234);
            this.listViewPesquisaDocumentoACOM.TabIndex = 44;
            this.listViewPesquisaDocumentoACOM.UseCompatibleStateImageBehavior = false;
            this.listViewPesquisaDocumentoACOM.View = System.Windows.Forms.View.Details;
            this.listViewPesquisaDocumentoACOM.DoubleClick += new System.EventHandler(this.listViewPesquisaDocumentoACOM_DoubleClick);
            // 
            // columnHeader28
            // 
            this.columnHeader28.Text = "FichID";
            this.columnHeader28.Width = 0;
            // 
            // columnHeader29
            // 
            this.columnHeader29.Text = "FichNSeq";
            this.columnHeader29.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader29.Width = 50;
            // 
            // columnHeader30
            // 
            this.columnHeader30.Text = "FichData";
            this.columnHeader30.Width = 70;
            // 
            // columnHeader32
            // 
            this.columnHeader32.Text = "LotAcomID";
            this.columnHeader32.Width = 0;
            // 
            // columnHeader33
            // 
            this.columnHeader33.Text = "LotNum";
            this.columnHeader33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader33.Width = 0;
            // 
            // columnHeader34
            // 
            this.columnHeader34.Text = "Produto";
            this.columnHeader34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader34.Width = 30;
            // 
            // columnHeader36
            // 
            this.columnHeader36.Text = "DataProc";
            this.columnHeader36.Width = 80;
            // 
            // columnHeader37
            // 
            this.columnHeader37.Text = "LoteStatus";
            // 
            // columnHeader40
            // 
            this.columnHeader40.Text = "DocAcomID";
            this.columnHeader40.Width = 0;
            // 
            // columnOrigem
            // 
            this.columnOrigem.Text = "Origem";
            // 
            // columnHeader41
            // 
            this.columnHeader41.Text = "ZIB";
            this.columnHeader41.Width = 70;
            // 
            // columnHeader42
            // 
            this.columnHeader42.Text = "NConta";
            this.columnHeader42.Width = 80;
            // 
            // columnHeader43
            // 
            this.columnHeader43.Text = "NCheque";
            this.columnHeader43.Width = 75;
            // 
            // columnHeader44
            // 
            this.columnHeader44.Text = "Import";
            this.columnHeader44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader44.Width = 100;
            // 
            // columnHeader45
            // 
            this.columnHeader45.Text = "Tipo";
            this.columnHeader45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader45.Width = 30;
            // 
            // columnHeader46
            // 
            this.columnHeader46.Text = "REFARQ";
            this.columnHeader46.Width = 100;
            // 
            // columnHeader47
            // 
            this.columnHeader47.Text = "REFARQ2";
            this.columnHeader47.Width = 100;
            // 
            // columnHeader48
            // 
            this.columnHeader48.Text = "Balcão";
            this.columnHeader48.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader48.Width = 50;
            // 
            // columnHeader49
            // 
            this.columnHeader49.Text = "CodAna";
            // 
            // columnACOMCancel
            // 
            this.columnACOMCancel.Text = "Cancelamento";
            // 
            // columnHeader38
            // 
            this.columnHeader38.Text = "Cancel ID";
            this.columnHeader38.Width = 0;
            // 
            // columnHeaderACOMNotif
            // 
            this.columnHeaderACOMNotif.Text = "Notificação";
            // 
            // columnHeader52
            // 
            this.columnHeader52.Text = "Notif ID";
            this.columnHeader52.Width = 0;
            // 
            // columnHeader50
            // 
            this.columnHeader50.Text = "ChaveH";
            this.columnHeader50.Width = 100;
            // 
            // columnHeader51
            // 
            this.columnHeader51.Text = "Linha Óptica";
            this.columnHeader51.Width = 100;
            // 
            // contextMenuStripACOM
            // 
            this.contextMenuStripACOM.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CancelaACOMToolStripMenuItem,
            this.confirmarCancelamentoToolStripMenuItem,
            this.anulaCancelaToolStripMenuItem,
            this.toolStripMenuItem4,
            this.ToolStripMenuItemHistoricoACOM,
            this.toolStripMenuItem7,
            this.NotificaACOMStripMenuItem,
            this.ConfirmaNotificaACOMStripMenuItem,
            this.AnulaNotificaACOMStripMenuItem});
            this.contextMenuStripACOM.Name = "contextMenuStripRemTrans";
            this.contextMenuStripACOM.Size = new System.Drawing.Size(365, 192);
            this.contextMenuStripACOM.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripACOM_Opening);
            // 
            // CancelaACOMToolStripMenuItem
            // 
            this.CancelaACOMToolStripMenuItem.Name = "CancelaACOMToolStripMenuItem";
            this.CancelaACOMToolStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.CancelaACOMToolStripMenuItem.Text = "Cancela Acolhimento";
            this.CancelaACOMToolStripMenuItem.Click += new System.EventHandler(this.CancelaACOMToolStripMenuItem_Click);
            // 
            // confirmarCancelamentoToolStripMenuItem
            // 
            this.confirmarCancelamentoToolStripMenuItem.Name = "confirmarCancelamentoToolStripMenuItem";
            this.confirmarCancelamentoToolStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.confirmarCancelamentoToolStripMenuItem.Text = "Confirmar Cancelamento";
            this.confirmarCancelamentoToolStripMenuItem.Click += new System.EventHandler(this.confirmarCancelamentoToolStripMenuItem_Click);
            // 
            // anulaCancelaToolStripMenuItem
            // 
            this.anulaCancelaToolStripMenuItem.Name = "anulaCancelaToolStripMenuItem";
            this.anulaCancelaToolStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.anulaCancelaToolStripMenuItem.Text = "Anula Cancelamento";
            this.anulaCancelaToolStripMenuItem.Click += new System.EventHandler(this.anulaCancelaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(361, 6);
            // 
            // ToolStripMenuItemHistoricoACOM
            // 
            this.ToolStripMenuItemHistoricoACOM.Name = "ToolStripMenuItemHistoricoACOM";
            this.ToolStripMenuItemHistoricoACOM.Size = new System.Drawing.Size(364, 22);
            this.ToolStripMenuItemHistoricoACOM.Text = "Historico do documento";
            this.ToolStripMenuItemHistoricoACOM.Click += new System.EventHandler(this.ToolStripMenuItemHistoricoACOM_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(361, 6);
            // 
            // NotificaACOMStripMenuItem
            // 
            this.NotificaACOMStripMenuItem.Name = "NotificaACOMStripMenuItem";
            this.NotificaACOMStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.NotificaACOMStripMenuItem.Text = "Notifica Acolhimento de Envio Documento Fora Prazo";
            this.NotificaACOMStripMenuItem.Click += new System.EventHandler(this.NotificaACOMStripMenuItem_Click);
            // 
            // ConfirmaNotificaACOMStripMenuItem
            // 
            this.ConfirmaNotificaACOMStripMenuItem.Name = "ConfirmaNotificaACOMStripMenuItem";
            this.ConfirmaNotificaACOMStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.ConfirmaNotificaACOMStripMenuItem.Text = "Confirmar Notificação de Envio Documento Fora Prazo";
            this.ConfirmaNotificaACOMStripMenuItem.Click += new System.EventHandler(this.ConfirmaNotificaACOMStripMenuItem_Click);
            // 
            // AnulaNotificaACOMStripMenuItem
            // 
            this.AnulaNotificaACOMStripMenuItem.Name = "AnulaNotificaACOMStripMenuItem";
            this.AnulaNotificaACOMStripMenuItem.Size = new System.Drawing.Size(364, 22);
            this.AnulaNotificaACOMStripMenuItem.Text = "Anula Notificação de Envio Documento Fora Prazo";
            this.AnulaNotificaACOMStripMenuItem.Click += new System.EventHandler(this.AnulaNotificaACOMStripMenuItem_Click);
            // 
            // buttonACOM
            // 
            this.buttonACOM.Location = new System.Drawing.Point(3, 4);
            this.buttonACOM.Name = "buttonACOM";
            this.buttonACOM.Size = new System.Drawing.Size(75, 23);
            this.buttonACOM.TabIndex = 0;
            this.buttonACOM.Text = "Refresh";
            this.buttonACOM.UseVisualStyleBackColor = true;
            this.buttonACOM.Click += new System.EventHandler(this.buttonACOM_Click);
            // 
            // textBoxMontante
            // 
            this.textBoxMontante.Location = new System.Drawing.Point(419, 57);
            this.textBoxMontante.MaxLength = 13;
            this.textBoxMontante.Name = "textBoxMontante";
            this.textBoxMontante.Size = new System.Drawing.Size(83, 20);
            this.textBoxMontante.TabIndex = 5;
            this.textBoxMontante.TextChanged += new System.EventHandler(this.textBoxMontante_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(416, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 31;
            this.label6.Text = "Montante";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(194, 43);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 13);
            this.label7.TabIndex = 51;
            this.label7.Text = "Balcão";
            // 
            // textBoxBalcao
            // 
            this.textBoxBalcao.Location = new System.Drawing.Point(194, 57);
            this.textBoxBalcao.MaxLength = 4;
            this.textBoxBalcao.Name = "textBoxBalcao";
            this.textBoxBalcao.Size = new System.Drawing.Size(38, 20);
            this.textBoxBalcao.TabIndex = 2;
            this.textBoxBalcao.TextChanged += new System.EventHandler(this.textBoxBalcao_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(505, 43);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 13);
            this.label8.TabIndex = 53;
            this.label8.Text = "NumRemessa";
            // 
            // textBoxNumRemessa
            // 
            this.textBoxNumRemessa.Location = new System.Drawing.Point(508, 57);
            this.textBoxNumRemessa.MaxLength = 11;
            this.textBoxNumRemessa.Name = "textBoxNumRemessa";
            this.textBoxNumRemessa.Size = new System.Drawing.Size(76, 20);
            this.textBoxNumRemessa.TabIndex = 6;
            this.textBoxNumRemessa.TextChanged += new System.EventHandler(this.textBoxNumRemessa_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(341, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 55;
            this.label1.Text = "NumCheque";
            // 
            // textBoxNumCheque
            // 
            this.textBoxNumCheque.Location = new System.Drawing.Point(344, 57);
            this.textBoxNumCheque.MaxLength = 10;
            this.textBoxNumCheque.Name = "textBoxNumCheque";
            this.textBoxNumCheque.Size = new System.Drawing.Size(69, 20);
            this.textBoxNumCheque.TabIndex = 4;
            this.textBoxNumCheque.TextChanged += new System.EventHandler(this.textBoxNumCheque_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label2.Location = new System.Drawing.Point(235, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 57;
            this.label2.Text = "REFARQ";
            // 
            // textBoxREFARQ
            // 
            this.textBoxREFARQ.Location = new System.Drawing.Point(238, 57);
            this.textBoxREFARQ.MaxLength = 14;
            this.textBoxREFARQ.Name = "textBoxREFARQ";
            this.textBoxREFARQ.Size = new System.Drawing.Size(100, 20);
            this.textBoxREFARQ.TabIndex = 3;
            this.textBoxREFARQ.TextChanged += new System.EventHandler(this.textBoxREFARQ_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 59;
            this.label3.Text = "Data Inicial";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(100, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 60;
            this.label4.Text = "Data Final";
            // 
            // checkBoxPorAnalisar
            // 
            this.checkBoxPorAnalisar.AutoSize = true;
            this.checkBoxPorAnalisar.Location = new System.Drawing.Point(889, 59);
            this.checkBoxPorAnalisar.Name = "checkBoxPorAnalisar";
            this.checkBoxPorAnalisar.Size = new System.Drawing.Size(81, 17);
            this.checkBoxPorAnalisar.TabIndex = 61;
            this.checkBoxPorAnalisar.Text = "Por analisar";
            this.checkBoxPorAnalisar.UseVisualStyleBackColor = true;
            // 
            // lblOrigem
            // 
            this.lblOrigem.AutoSize = true;
            this.lblOrigem.Location = new System.Drawing.Point(669, 43);
            this.lblOrigem.Name = "lblOrigem";
            this.lblOrigem.Size = new System.Drawing.Size(40, 13);
            this.lblOrigem.TabIndex = 62;
            this.lblOrigem.Text = "Origem";
            // 
            // cbOrigem
            // 
            this.cbOrigem.DisplayMember = "Text";
            this.cbOrigem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbOrigem.FormattingEnabled = true;
            this.cbOrigem.Location = new System.Drawing.Point(672, 57);
            this.cbOrigem.Name = "cbOrigem";
            this.cbOrigem.Size = new System.Drawing.Size(73, 21);
            this.cbOrigem.TabIndex = 63;
            this.cbOrigem.ValueMember = "Value";
            this.cbOrigem.SelectedIndexChanged += new System.EventHandler(this.cbOrigem_SelectedIndexChanged);
            // 
            // cbPendenteIntervencao
            // 
            this.cbPendenteIntervencao.AutoSize = true;
            this.cbPendenteIntervencao.Location = new System.Drawing.Point(751, 59);
            this.cbPendenteIntervencao.Name = "cbPendenteIntervencao";
            this.cbPendenteIntervencao.Size = new System.Drawing.Size(132, 17);
            this.cbPendenteIntervencao.TabIndex = 64;
            this.cbPendenteIntervencao.Text = "Pendente Intervenção";
            this.cbPendenteIntervencao.UseVisualStyleBackColor = true;
            // 
            // lblDeposito
            // 
            this.lblDeposito.AutoSize = true;
            this.lblDeposito.Location = new System.Drawing.Point(588, 43);
            this.lblDeposito.Name = "lblDeposito";
            this.lblDeposito.Size = new System.Drawing.Size(49, 13);
            this.lblDeposito.TabIndex = 66;
            this.lblDeposito.Text = "Depósito";
            // 
            // txtDeposito
            // 
            this.txtDeposito.Enabled = false;
            this.txtDeposito.Location = new System.Drawing.Point(590, 57);
            this.txtDeposito.MaxLength = 7;
            this.txtDeposito.Name = "txtDeposito";
            this.txtDeposito.Size = new System.Drawing.Size(76, 20);
            this.txtDeposito.TabIndex = 65;
            this.txtDeposito.TextChanged += new System.EventHandler(this.txtDeposito_TextChanged);
            // 
            // PesquisasForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(988, 551);
            this.Controls.Add(this.lblDeposito);
            this.Controls.Add(this.txtDeposito);
            this.Controls.Add(this.cbPendenteIntervencao);
            this.Controls.Add(this.cbOrigem);
            this.Controls.Add(this.lblOrigem);
            this.Controls.Add(this.checkBoxPorAnalisar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxNumCheque);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBoxREFARQ);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxNumRemessa);
            this.Controls.Add(this.textBoxBalcao);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxMontante);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.m_ctrldtFim);
            this.Controls.Add(this.m_ctrldtInicio);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PesquisasForm";
            this.ShowInTaskbar = false;
            this.Text = "Pesquisas e Reenvios";
            this.Load += new System.EventHandler(this.PesquisasForm_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.contextMenuStripDOC.ResumeLayout(false);
            this.contextMenuStripENVM.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.contextMenuStripACOM.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonEmAnalise;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButtonErro;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButtonExitJanela;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.DateTimePicker m_ctrldtFim;
        private System.Windows.Forms.DateTimePicker m_ctrldtInicio;
        private NBIISNET.ListViewBase listViewPesquisaDocumento;
        private System.Windows.Forms.ColumnHeader detDocColDocId;
        private System.Windows.Forms.ColumnHeader detDocColDocZona5;
        private System.Windows.Forms.ColumnHeader detDocColDocZona4;
        private System.Windows.Forms.ColumnHeader detDocColDocZona3;
        private System.Windows.Forms.ColumnHeader detDocColDocZona2;
        private System.Windows.Forms.ColumnHeader detDocColDocZona1;
        private System.Windows.Forms.ColumnHeader detDocColDocNIB;
        private System.Windows.Forms.ColumnHeader detDocColDocRefarq;
        private System.Windows.Forms.ColumnHeader detDocColChaveH;
        public NBIISNET.ListViewBase listViewPesquisaDocumentoENVM;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.ColumnHeader columnHeader23;
        private System.Windows.Forms.ColumnHeader columnHeader24;
        private System.Windows.Forms.ColumnHeader columnHeader25;
        private System.Windows.Forms.ColumnHeader columnHeader26;
        private System.Windows.Forms.ColumnHeader columnHeader27;
        private System.Windows.Forms.SplitContainer splitContainer2;
        public NBIISNET.ListViewBase listViewPesquisaDocumentoACOM;
        private System.Windows.Forms.ColumnHeader columnHeader28;
        private System.Windows.Forms.ColumnHeader columnHeader29;
        private System.Windows.Forms.ColumnHeader columnHeader30;
        private System.Windows.Forms.ColumnHeader columnHeader32;
        private System.Windows.Forms.ColumnHeader columnHeader33;
        private System.Windows.Forms.ColumnHeader columnHeader34;
        private System.Windows.Forms.ColumnHeader columnHeader36;
        private System.Windows.Forms.ColumnHeader columnHeader37;
        private System.Windows.Forms.ColumnHeader columnHeader40;
        private System.Windows.Forms.ColumnHeader columnHeader41;
        private System.Windows.Forms.ColumnHeader columnHeader42;
        private System.Windows.Forms.ColumnHeader columnHeader43;
        private System.Windows.Forms.ColumnHeader columnHeader44;
        private System.Windows.Forms.ColumnHeader columnHeader45;
        private System.Windows.Forms.ColumnHeader columnHeader46;
        private System.Windows.Forms.ColumnHeader columnHeader47;
        private System.Windows.Forms.ColumnHeader columnHeader48;
        private System.Windows.Forms.ColumnHeader columnHeader49;
        private System.Windows.Forms.ColumnHeader columnHeader50;
        private System.Windows.Forms.ColumnHeader columnHeader51;
        private System.Windows.Forms.Button buttonDocumento;
        private System.Windows.Forms.Button buttonENVM;
        private System.Windows.Forms.Button buttonACOM;
        private System.Windows.Forms.TextBox textBoxMontante;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxBalcao;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxNumRemessa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxNumCheque;
        private System.Windows.Forms.ColumnHeader columnHeader31;
        private System.Windows.Forms.ColumnHeader columnHeaderReap;
        private System.Windows.Forms.ColumnHeader columnACOMCancel;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripACOM;
        private System.Windows.Forms.ToolStripMenuItem CancelaACOMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem anulaCancelaToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripENVM;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemENVMNotificaAcolhimento;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemENVMAnulaNotificacao;
        private System.Windows.Forms.ToolStripMenuItem reapresentarCompensacaoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ConfirmarReapresentacaoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem anularReapresentacaoToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader columnHeaderNotif;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxREFARQ;
        private System.Windows.Forms.ToolStripMenuItem confirmarNotificacaoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem confirmarCancelamentoToolStripMenuItem;
        public System.Windows.Forms.Label labelDOC;
        public System.Windows.Forms.Label labelENVM;
        public System.Windows.Forms.Label labelACOM;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ColumnHeader columnHeaderReapr;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripDOC;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemReapresentarDOC;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemConfirmarDOC;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemAnularDOC;
        private System.Windows.Forms.ToolStripButton toolStripButtonRem;
        private System.Windows.Forms.ToolStripButton toolStripButtonENVM;
        private System.Windows.Forms.ToolStripButton toolStripButtonACOM;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem historicoDoDocumentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemHistoricoENVM;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemHistoricoACOM;
        private System.Windows.Forms.ColumnHeader columnHeaderDocCancelado;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem cancelaDocumentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem confirmarCancelamentoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem anularCancelamentoToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader columnHeaderISReapresentado;
        private System.Windows.Forms.ToolStripButton toolStripButtonOK;
        private System.Windows.Forms.ToolStripButton toolStripButtonMaisMenos;
        private System.Windows.Forms.ColumnHeader columnHeaderCancelado;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem cancelaDocumentoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem confirmarCancelamentoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem anularCancelamentoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem NotificaACOMStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ConfirmaNotificaACOMStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AnulaNotificaACOMStripMenuItem;
        private System.Windows.Forms.ColumnHeader columnHeaderACOMNotif;
        private System.Windows.Forms.ColumnHeader columnHeaderReaprID;
        private System.Windows.Forms.ColumnHeader columnHeadercancelID;
        private System.Windows.Forms.ColumnHeader columnHeader35;
        private System.Windows.Forms.ColumnHeader columnHeader39;
        private System.Windows.Forms.ColumnHeader columnHeader53;
        private System.Windows.Forms.ColumnHeader columnHeader38;
        private System.Windows.Forms.ColumnHeader columnHeader52;
        private System.Windows.Forms.ColumnHeader columnHeaderRefarqOri;
        private System.Windows.Forms.ColumnHeader columnHeaderRefarqOriENVM;
        private System.Windows.Forms.CheckBox checkBoxPorAnalisar;
        private System.Windows.Forms.ColumnHeader columnHeaderPROC_TIMER;
        private System.Windows.Forms.ToolStripMenuItem marcarCancelamentoComEfectuadoToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader colunaOrigem;
        private System.Windows.Forms.ColumnHeader columnOrigem;
        private System.Windows.Forms.ColumnHeader columnOrigemCompensacao;
        private System.Windows.Forms.Label lblOrigem;
        protected System.Windows.Forms.ComboBox cbOrigem;
        private System.Windows.Forms.CheckBox cbPendenteIntervencao;
        private System.Windows.Forms.Label lblDeposito;
        private System.Windows.Forms.TextBox txtDeposito;
        private System.Windows.Forms.ColumnHeader clmImgQual;
        private System.Windows.Forms.ColumnHeader LoteAnom;
    }
}