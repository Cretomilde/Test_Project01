﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace CIActividades
{
    public static class CriaXML
    {

        static string m_sXml;
        static ArrayList m_oNome;
        static ArrayList m_oValor;
    

        public static string Filtro(ArrayList nome, ArrayList valor)
        {
            m_oNome = nome;
            m_oValor = valor;
    
            
            m_sXml = "<filtro>";

            criaBody();

            m_sXml += "</filtro>";
           
            return m_sXml;
        }

        public static void criaBody()
        {
            for (int i = 0; i<m_oNome.Count; i++)
            {
                m_sXml += "<" + m_oNome[i].ToString() + ">" + m_oValor[i].ToString() + "</" + m_oNome[i].ToString() + ">";

            }

        }
    }
}
