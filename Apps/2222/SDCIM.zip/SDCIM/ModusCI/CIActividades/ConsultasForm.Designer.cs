﻿namespace CIActividades
{
    partial class ConsultasForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);

            m_oMenuInterface.consultasEnable(true);
        }


        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConsultasForm));
            this.contextMenuStripConsultaDocs = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.consultarImagensToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataInicio = new System.Windows.Forms.DateTimePicker();
            this.dataFim = new System.Windows.Forms.DateTimePicker();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.m_splitContainerMain = new System.Windows.Forms.SplitContainer();
            this.listViewConsultaRemessas = new NBIISNET.ListViewBase();
            this.colunaRemessaConsultaID = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaReminID = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaTimerCriacao = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaTimerActualizacao = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaEstado = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaFiltro = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaAguardaRedig = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaBalcao = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaChaveHost = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaMontante = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaNumContaDep = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaNIB = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaDataRem = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaEstadoLote = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaHoraChegada = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaIdRemessa = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaNomeImgCabLote = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaNumCabLote = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaNumDocs = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaNumPaginaCabLote = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaNumPropostaLogica = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaOrigem = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaSubProduto = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaTipoRemessa = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaMaisResultados = new System.Windows.Forms.ColumnHeader();
            this.colunaRemessaErro = new System.Windows.Forms.ColumnHeader();
            this.m_splitContainerDocs = new System.Windows.Forms.SplitContainer();
            this.listViewConsultaDocs = new NBIISNET.ListViewBase();
            this.colunaDocConsultaId = new System.Windows.Forms.ColumnHeader();
            this.colunaOperativa = new System.Windows.Forms.ColumnHeader();
            this.coluaDocDOCID = new System.Windows.Forms.ColumnHeader();
            this.colunaDocTimerCriacao = new System.Windows.Forms.ColumnHeader();
            this.colunaDocTimerActualizacao = new System.Windows.Forms.ColumnHeader();
            this.colunaDocEstadoTibco = new System.Windows.Forms.ColumnHeader();
            this.colunaDocFiltro = new System.Windows.Forms.ColumnHeader();
            this.colunaDocAguardaRedig = new System.Windows.Forms.ColumnHeader();
            this.colunaDocAnomaliaDadosIlegais = new System.Windows.Forms.ColumnHeader();
            this.colunaDocBalcao = new System.Windows.Forms.ColumnHeader();
            this.colunaDocChaveHost = new System.Windows.Forms.ColumnHeader();
            this.colunaDocZib = new System.Windows.Forms.ColumnHeader();
            this.colunaDocNumConta = new System.Windows.Forms.ColumnHeader();
            this.colunaDocNumCheque = new System.Windows.Forms.ColumnHeader();
            this.colunaDocMontante = new System.Windows.Forms.ColumnHeader();
            this.colunaDocTipoCheque = new System.Windows.Forms.ColumnHeader();
            this.colunaDocValidaRequisitosDoc = new System.Windows.Forms.ColumnHeader();
            this.colunaDocEstado = new System.Windows.Forms.ColumnHeader();
            this.colunaDocFsl = new System.Windows.Forms.ColumnHeader();
            this.colunaDocIdDocumento = new System.Windows.Forms.ColumnHeader();
            this.colunaDocIdRemessa = new System.Windows.Forms.ColumnHeader();
            this.colunaDocLote = new System.Windows.Forms.ColumnHeader();
            this.colunaDocMaquina = new System.Windows.Forms.ColumnHeader();
            this.colunaDocNomeImagem = new System.Windows.Forms.ColumnHeader();
            this.colunaDocNumPaginas = new System.Windows.Forms.ColumnHeader();
            this.colunaDocOrigem = new System.Windows.Forms.ColumnHeader();
            this.colunaDocRefarqCaptura = new System.Windows.Forms.ColumnHeader();
            this.colunaDocSequencia = new System.Windows.Forms.ColumnHeader();
            this.colunaDocSubProduto = new System.Windows.Forms.ColumnHeader();
            this.colunaDocMaisResultados = new System.Windows.Forms.ColumnHeader();
            this.colunaDocErro = new System.Windows.Forms.ColumnHeader();
            this.m_pictureBox = new System.Windows.Forms.PictureBox();
            this.lbImagem = new System.Windows.Forms.Label();
            this.listViewImagens = new NBIISNET.ListViewBase();
            this.colImgConsultaID = new System.Windows.Forms.ColumnHeader();
            this.colImgTimer = new System.Windows.Forms.ColumnHeader();
            this.colImgSide = new System.Windows.Forms.ColumnHeader();
            this.colImgEstado = new System.Windows.Forms.ColumnHeader();
            this.colImgErro = new System.Windows.Forms.ColumnHeader();
            this.contextMenuStripConsultaDocs.SuspendLayout();
            this.m_splitContainerMain.Panel1.SuspendLayout();
            this.m_splitContainerMain.Panel2.SuspendLayout();
            this.m_splitContainerMain.SuspendLayout();
            this.m_splitContainerDocs.Panel1.SuspendLayout();
            this.m_splitContainerDocs.Panel2.SuspendLayout();
            this.m_splitContainerDocs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.m_pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // contextMenuStripConsultaDocs
            // 
            this.contextMenuStripConsultaDocs.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.consultarImagensToolStripMenuItem});
            this.contextMenuStripConsultaDocs.Name = "contextMenuStripConsultaDocs";
            this.contextMenuStripConsultaDocs.Size = new System.Drawing.Size(201, 26);
            this.contextMenuStripConsultaDocs.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripConsultaDocs_Opening);
            // 
            // consultarImagensToolStripMenuItem
            // 
            this.consultarImagensToolStripMenuItem.Name = "consultarImagensToolStripMenuItem";
            this.consultarImagensToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.consultarImagensToolStripMenuItem.Text = "Consultar Imagens SIBS";
            this.consultarImagensToolStripMenuItem.Click += new System.EventHandler(this.consultarImagensToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "REMESSAS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "DOCUMENTOS";
            // 
            // dataInicio
            // 
            this.dataInicio.CustomFormat = "yyyy-MM-dd";
            this.dataInicio.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dataInicio.Location = new System.Drawing.Point(66, 12);
            this.dataInicio.Name = "dataInicio";
            this.dataInicio.Size = new System.Drawing.Size(88, 20);
            this.dataInicio.TabIndex = 4;
            // 
            // dataFim
            // 
            this.dataFim.CustomFormat = "yyyy-MM-dd";
            this.dataFim.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dataFim.Location = new System.Drawing.Point(160, 12);
            this.dataFim.Name = "dataFim";
            this.dataFim.Size = new System.Drawing.Size(88, 20);
            this.dataFim.TabIndex = 5;
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.Location = new System.Drawing.Point(268, 9);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(103, 23);
            this.buttonRefresh.TabIndex = 6;
            this.buttonRefresh.Text = "Refresh";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // m_splitContainerMain
            // 
            this.m_splitContainerMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.m_splitContainerMain.Location = new System.Drawing.Point(12, 54);
            this.m_splitContainerMain.Name = "m_splitContainerMain";
            this.m_splitContainerMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // m_splitContainerMain.Panel1
            // 
            this.m_splitContainerMain.Panel1.Controls.Add(this.label1);
            this.m_splitContainerMain.Panel1.Controls.Add(this.listViewConsultaRemessas);
            // 
            // m_splitContainerMain.Panel2
            // 
            this.m_splitContainerMain.Panel2.Controls.Add(this.m_splitContainerDocs);
            this.m_splitContainerMain.Size = new System.Drawing.Size(917, 460);
            this.m_splitContainerMain.SplitterDistance = 145;
            this.m_splitContainerMain.TabIndex = 7;
            // 
            // listViewConsultaRemessas
            // 
            this.listViewConsultaRemessas.AllowColumnReorder = true;
            this.listViewConsultaRemessas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewConsultaRemessas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colunaRemessaConsultaID,
            this.colunaRemessaReminID,
            this.colunaRemessaTimerCriacao,
            this.colunaRemessaTimerActualizacao,
            this.colunaRemessaEstado,
            this.colunaRemessaFiltro,
            this.colunaRemessaAguardaRedig,
            this.colunaRemessaBalcao,
            this.colunaRemessaChaveHost,
            this.colunaRemessaMontante,
            this.colunaRemessaNumContaDep,
            this.colunaRemessaNIB,
            this.colunaRemessaDataRem,
            this.colunaRemessaEstadoLote,
            this.colunaRemessaHoraChegada,
            this.colunaRemessaIdRemessa,
            this.colunaRemessaNomeImgCabLote,
            this.colunaRemessaNumCabLote,
            this.colunaRemessaNumDocs,
            this.colunaRemessaNumPaginaCabLote,
            this.colunaRemessaNumPropostaLogica,
            this.colunaRemessaOrigem,
            this.colunaRemessaSubProduto,
            this.colunaRemessaTipoRemessa,
            this.colunaRemessaMaisResultados,
            this.colunaRemessaErro});
            this.listViewConsultaRemessas.EnableExportar = true;
            this.listViewConsultaRemessas.FullRowSelect = true;
            this.listViewConsultaRemessas.GridLines = true;
            this.listViewConsultaRemessas.HideSelection = false;
            this.listViewConsultaRemessas.Location = new System.Drawing.Point(6, 16);
            this.listViewConsultaRemessas.Name = "listViewConsultaRemessas";
            this.listViewConsultaRemessas.Size = new System.Drawing.Size(911, 126);
            this.listViewConsultaRemessas.TabIndex = 0;
            this.listViewConsultaRemessas.UseCompatibleStateImageBehavior = false;
            this.listViewConsultaRemessas.View = System.Windows.Forms.View.Details;
            // 
            // colunaRemessaConsultaID
            // 
            this.colunaRemessaConsultaID.Text = "Consulta ID";
            this.colunaRemessaConsultaID.Width = 72;
            // 
            // colunaRemessaReminID
            // 
            this.colunaRemessaReminID.Text = "Remin Id";
            // 
            // colunaRemessaTimerCriacao
            // 
            this.colunaRemessaTimerCriacao.Text = "Timer Criacao";
            this.colunaRemessaTimerCriacao.Width = 100;
            // 
            // colunaRemessaTimerActualizacao
            // 
            this.colunaRemessaTimerActualizacao.Text = "Timer Actualizacao";
            this.colunaRemessaTimerActualizacao.Width = 114;
            // 
            // colunaRemessaEstado
            // 
            this.colunaRemessaEstado.Text = "Estado tibco";
            this.colunaRemessaEstado.Width = 77;
            // 
            // colunaRemessaFiltro
            // 
            this.colunaRemessaFiltro.Text = "Filtro";
            this.colunaRemessaFiltro.Width = 372;
            // 
            // colunaRemessaAguardaRedig
            // 
            this.colunaRemessaAguardaRedig.Text = "Aguarda Redig";
            this.colunaRemessaAguardaRedig.Width = 90;
            // 
            // colunaRemessaBalcao
            // 
            this.colunaRemessaBalcao.Text = "Balcao";
            this.colunaRemessaBalcao.Width = 48;
            // 
            // colunaRemessaChaveHost
            // 
            this.colunaRemessaChaveHost.Text = "Chave host";
            this.colunaRemessaChaveHost.Width = 100;
            // 
            // colunaRemessaMontante
            // 
            this.colunaRemessaMontante.Text = "Montante";
            this.colunaRemessaMontante.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colunaRemessaMontante.Width = 63;
            // 
            // colunaRemessaNumContaDep
            // 
            this.colunaRemessaNumContaDep.Text = "Num Conta Dep";
            this.colunaRemessaNumContaDep.Width = 98;
            // 
            // colunaRemessaNIB
            // 
            this.colunaRemessaNIB.Text = "NIB";
            // 
            // colunaRemessaDataRem
            // 
            this.colunaRemessaDataRem.Text = "Data Rem";
            this.colunaRemessaDataRem.Width = 80;
            // 
            // colunaRemessaEstadoLote
            // 
            this.colunaRemessaEstadoLote.Text = "Estado Lote";
            this.colunaRemessaEstadoLote.Width = 80;
            // 
            // colunaRemessaHoraChegada
            // 
            this.colunaRemessaHoraChegada.Text = "Hora chegada";
            this.colunaRemessaHoraChegada.Width = 88;
            // 
            // colunaRemessaIdRemessa
            // 
            this.colunaRemessaIdRemessa.Text = "Id Remessa";
            this.colunaRemessaIdRemessa.Width = 80;
            // 
            // colunaRemessaNomeImgCabLote
            // 
            this.colunaRemessaNomeImgCabLote.Text = "Nome Img Cab Lote";
            this.colunaRemessaNomeImgCabLote.Width = 80;
            // 
            // colunaRemessaNumCabLote
            // 
            this.colunaRemessaNumCabLote.Text = "Num Cabeca Lote";
            this.colunaRemessaNumCabLote.Width = 80;
            // 
            // colunaRemessaNumDocs
            // 
            this.colunaRemessaNumDocs.Text = "Num Docs";
            this.colunaRemessaNumDocs.Width = 80;
            // 
            // colunaRemessaNumPaginaCabLote
            // 
            this.colunaRemessaNumPaginaCabLote.Text = "Num Paginas Cab Lote";
            this.colunaRemessaNumPaginaCabLote.Width = 80;
            // 
            // colunaRemessaNumPropostaLogica
            // 
            this.colunaRemessaNumPropostaLogica.Text = "Num Proposta Logica";
            this.colunaRemessaNumPropostaLogica.Width = 80;
            // 
            // colunaRemessaOrigem
            // 
            this.colunaRemessaOrigem.Text = "Origem";
            this.colunaRemessaOrigem.Width = 80;
            // 
            // colunaRemessaSubProduto
            // 
            this.colunaRemessaSubProduto.Text = "Sub Produto";
            this.colunaRemessaSubProduto.Width = 80;
            // 
            // colunaRemessaTipoRemessa
            // 
            this.colunaRemessaTipoRemessa.Text = "Tipo Remessa";
            this.colunaRemessaTipoRemessa.Width = 80;
            // 
            // colunaRemessaMaisResultados
            // 
            this.colunaRemessaMaisResultados.Text = "Mais Resultados";
            this.colunaRemessaMaisResultados.Width = 90;
            // 
            // colunaRemessaErro
            // 
            this.colunaRemessaErro.Text = "Erro";
            this.colunaRemessaErro.Width = 100;
            // 
            // m_splitContainerDocs
            // 
            this.m_splitContainerDocs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.m_splitContainerDocs.Location = new System.Drawing.Point(0, 3);
            this.m_splitContainerDocs.Name = "m_splitContainerDocs";
            this.m_splitContainerDocs.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // m_splitContainerDocs.Panel1
            // 
            this.m_splitContainerDocs.Panel1.Controls.Add(this.label2);
            this.m_splitContainerDocs.Panel1.Controls.Add(this.listViewConsultaDocs);
            // 
            // m_splitContainerDocs.Panel2
            // 
            this.m_splitContainerDocs.Panel2.Controls.Add(this.m_pictureBox);
            this.m_splitContainerDocs.Panel2.Controls.Add(this.lbImagem);
            this.m_splitContainerDocs.Panel2.Controls.Add(this.listViewImagens);
            this.m_splitContainerDocs.Size = new System.Drawing.Size(914, 305);
            this.m_splitContainerDocs.SplitterDistance = 152;
            this.m_splitContainerDocs.TabIndex = 4;
            // 
            // listViewConsultaDocs
            // 
            this.listViewConsultaDocs.AllowColumnReorder = true;
            this.listViewConsultaDocs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewConsultaDocs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colunaDocConsultaId,
            this.colunaOperativa,
            this.coluaDocDOCID,
            this.colunaDocTimerCriacao,
            this.colunaDocTimerActualizacao,
            this.colunaDocEstadoTibco,
            this.colunaDocFiltro,
            this.colunaDocAguardaRedig,
            this.colunaDocAnomaliaDadosIlegais,
            this.colunaDocBalcao,
            this.colunaDocChaveHost,
            this.colunaDocZib,
            this.colunaDocNumConta,
            this.colunaDocNumCheque,
            this.colunaDocMontante,
            this.colunaDocTipoCheque,
            this.colunaDocValidaRequisitosDoc,
            this.colunaDocEstado,
            this.colunaDocFsl,
            this.colunaDocIdDocumento,
            this.colunaDocIdRemessa,
            this.colunaDocLote,
            this.colunaDocMaquina,
            this.colunaDocNomeImagem,
            this.colunaDocNumPaginas,
            this.colunaDocOrigem,
            this.colunaDocRefarqCaptura,
            this.colunaDocSequencia,
            this.colunaDocSubProduto,
            this.colunaDocMaisResultados,
            this.colunaDocErro});
            this.listViewConsultaDocs.ContextMenuStrip = this.contextMenuStripConsultaDocs;
            this.listViewConsultaDocs.EnableExportar = true;
            this.listViewConsultaDocs.FullRowSelect = true;
            this.listViewConsultaDocs.GridLines = true;
            this.listViewConsultaDocs.HideSelection = false;
            this.listViewConsultaDocs.Location = new System.Drawing.Point(0, 16);
            this.listViewConsultaDocs.Name = "listViewConsultaDocs";
            this.listViewConsultaDocs.Size = new System.Drawing.Size(911, 133);
            this.listViewConsultaDocs.TabIndex = 1;
            this.listViewConsultaDocs.UseCompatibleStateImageBehavior = false;
            this.listViewConsultaDocs.View = System.Windows.Forms.View.Details;
            this.listViewConsultaDocs.DoubleClick += new System.EventHandler(this.listViewConsultaDocs_DoubleClick);
            // 
            // colunaDocConsultaId
            // 
            this.colunaDocConsultaId.Text = "Consulta ID";
            this.colunaDocConsultaId.Width = 73;
            // 
            // colunaOperativa
            // 
            this.colunaOperativa.Text = "Operativa";
            this.colunaOperativa.Width = 62;
            // 
            // coluaDocDOCID
            // 
            this.coluaDocDOCID.Text = "Doc Id";
            // 
            // colunaDocTimerCriacao
            // 
            this.colunaDocTimerCriacao.Text = "Timer Criacao";
            this.colunaDocTimerCriacao.Width = 101;
            // 
            // colunaDocTimerActualizacao
            // 
            this.colunaDocTimerActualizacao.Text = "Timer Actualizacao";
            this.colunaDocTimerActualizacao.Width = 116;
            // 
            // colunaDocEstadoTibco
            // 
            this.colunaDocEstadoTibco.Text = "Estado Tibco";
            this.colunaDocEstadoTibco.Width = 80;
            // 
            // colunaDocFiltro
            // 
            this.colunaDocFiltro.Text = "Filtro";
            this.colunaDocFiltro.Width = 368;
            // 
            // colunaDocAguardaRedig
            // 
            this.colunaDocAguardaRedig.Text = "Aguarda Redig";
            this.colunaDocAguardaRedig.Width = 90;
            // 
            // colunaDocAnomaliaDadosIlegais
            // 
            this.colunaDocAnomaliaDadosIlegais.Text = "Anomalia Dados Ileg";
            this.colunaDocAnomaliaDadosIlegais.Width = 117;
            // 
            // colunaDocBalcao
            // 
            this.colunaDocBalcao.Text = "Balcao";
            this.colunaDocBalcao.Width = 50;
            // 
            // colunaDocChaveHost
            // 
            this.colunaDocChaveHost.Text = "ChaveHost";
            this.colunaDocChaveHost.Width = 90;
            // 
            // colunaDocZib
            // 
            this.colunaDocZib.Text = "Zib";
            this.colunaDocZib.Width = 70;
            // 
            // colunaDocNumConta
            // 
            this.colunaDocNumConta.Text = "Num Conta";
            this.colunaDocNumConta.Width = 70;
            // 
            // colunaDocNumCheque
            // 
            this.colunaDocNumCheque.Text = "Num Cheque";
            this.colunaDocNumCheque.Width = 70;
            // 
            // colunaDocMontante
            // 
            this.colunaDocMontante.Text = "Montante";
            this.colunaDocMontante.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colunaDocMontante.Width = 70;
            // 
            // colunaDocTipoCheque
            // 
            this.colunaDocTipoCheque.Text = "Tipo Cheque";
            this.colunaDocTipoCheque.Width = 70;
            // 
            // colunaDocValidaRequisitosDoc
            // 
            this.colunaDocValidaRequisitosDoc.Text = "Valida Requisitos Doc";
            this.colunaDocValidaRequisitosDoc.Width = 100;
            // 
            // colunaDocEstado
            // 
            this.colunaDocEstado.Text = "Estado";
            this.colunaDocEstado.Width = 48;
            // 
            // colunaDocFsl
            // 
            this.colunaDocFsl.Text = "Fsl";
            this.colunaDocFsl.Width = 35;
            // 
            // colunaDocIdDocumento
            // 
            this.colunaDocIdDocumento.Text = "Id Documento";
            this.colunaDocIdDocumento.Width = 70;
            // 
            // colunaDocIdRemessa
            // 
            this.colunaDocIdRemessa.Text = "Id Remessa";
            this.colunaDocIdRemessa.Width = 70;
            // 
            // colunaDocLote
            // 
            this.colunaDocLote.Text = "Lote";
            this.colunaDocLote.Width = 70;
            // 
            // colunaDocMaquina
            // 
            this.colunaDocMaquina.Text = "Maquina";
            this.colunaDocMaquina.Width = 70;
            // 
            // colunaDocNomeImagem
            // 
            this.colunaDocNomeImagem.Text = "Nome Imagem";
            this.colunaDocNomeImagem.Width = 100;
            // 
            // colunaDocNumPaginas
            // 
            this.colunaDocNumPaginas.Text = "Num Paginas";
            this.colunaDocNumPaginas.Width = 70;
            // 
            // colunaDocOrigem
            // 
            this.colunaDocOrigem.Text = "Origem";
            this.colunaDocOrigem.Width = 70;
            // 
            // colunaDocRefarqCaptura
            // 
            this.colunaDocRefarqCaptura.Text = "Refarq Captura";
            this.colunaDocRefarqCaptura.Width = 70;
            // 
            // colunaDocSequencia
            // 
            this.colunaDocSequencia.Text = "Sequencia";
            this.colunaDocSequencia.Width = 70;
            // 
            // colunaDocSubProduto
            // 
            this.colunaDocSubProduto.Text = "SubProduto";
            this.colunaDocSubProduto.Width = 70;
            // 
            // colunaDocMaisResultados
            // 
            this.colunaDocMaisResultados.Text = "Mais Resultados";
            this.colunaDocMaisResultados.Width = 100;
            // 
            // colunaDocErro
            // 
            this.colunaDocErro.Text = "Erro";
            this.colunaDocErro.Width = 100;
            // 
            // m_pictureBox
            // 
            this.m_pictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.m_pictureBox.Location = new System.Drawing.Point(464, 16);
            this.m_pictureBox.Name = "m_pictureBox";
            this.m_pictureBox.Size = new System.Drawing.Size(447, 130);
            this.m_pictureBox.TabIndex = 5;
            this.m_pictureBox.TabStop = false;
            // 
            // lbImagem
            // 
            this.lbImagem.AutoSize = true;
            this.lbImagem.Location = new System.Drawing.Point(3, 0);
            this.lbImagem.Name = "lbImagem";
            this.lbImagem.Size = new System.Drawing.Size(56, 13);
            this.lbImagem.TabIndex = 4;
            this.lbImagem.Text = "IMAGENS";
            // 
            // listViewImagens
            // 
            this.listViewImagens.AllowColumnReorder = true;
            this.listViewImagens.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.listViewImagens.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colImgConsultaID,
            this.colImgTimer,
            this.colImgSide,
            this.colImgEstado,
            this.colImgErro});
            this.listViewImagens.FullRowSelect = true;
            this.listViewImagens.GridLines = true;
            this.listViewImagens.HideSelection = false;
            this.listViewImagens.Location = new System.Drawing.Point(0, 16);
            this.listViewImagens.MultiSelect = false;
            this.listViewImagens.Name = "listViewImagens";
            this.listViewImagens.Size = new System.Drawing.Size(458, 130);
            this.listViewImagens.TabIndex = 0;
            this.listViewImagens.UseCompatibleStateImageBehavior = false;
            this.listViewImagens.View = System.Windows.Forms.View.Details;
            this.listViewImagens.DoubleClick += new System.EventHandler(this.listViewImagens_DoubleClick);
            // 
            // colImgConsultaID
            // 
            this.colImgConsultaID.Text = "ConsultaID";
            this.colImgConsultaID.Width = 73;
            // 
            // colImgTimer
            // 
            this.colImgTimer.Text = "Timer";
            this.colImgTimer.Width = 116;
            // 
            // colImgSide
            // 
            this.colImgSide.Text = "Lado";
            // 
            // colImgEstado
            // 
            this.colImgEstado.Text = "Estado";
            this.colImgEstado.Width = 80;
            // 
            // colImgErro
            // 
            this.colImgErro.Text = "Erro";
            this.colImgErro.Width = 100;
            // 
            // ConsultasForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(941, 536);
            this.Controls.Add(this.m_splitContainerMain);
            this.Controls.Add(this.dataInicio);
            this.Controls.Add(this.dataFim);
            this.Controls.Add(this.buttonRefresh);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ConsultasForm";
            this.ShowInTaskbar = false;
            this.Text = "Consultas SIBS";
            this.Load += new System.EventHandler(this.Consultas_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ConsultasForm_FormClosed);
            this.contextMenuStripConsultaDocs.ResumeLayout(false);
            this.m_splitContainerMain.Panel1.ResumeLayout(false);
            this.m_splitContainerMain.Panel1.PerformLayout();
            this.m_splitContainerMain.Panel2.ResumeLayout(false);
            this.m_splitContainerMain.ResumeLayout(false);
            this.m_splitContainerDocs.Panel1.ResumeLayout(false);
            this.m_splitContainerDocs.Panel1.PerformLayout();
            this.m_splitContainerDocs.Panel2.ResumeLayout(false);
            this.m_splitContainerDocs.Panel2.PerformLayout();
            this.m_splitContainerDocs.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.m_pictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion


        private NBIISNET.ListViewBase listViewConsultaRemessas;
        private NBIISNET.ListViewBase listViewConsultaDocs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ColumnHeader colunaRemessaConsultaID;
        private System.Windows.Forms.ColumnHeader colunaRemessaAguardaRedig;
        private System.Windows.Forms.ColumnHeader colunaRemessaBalcao;
        private System.Windows.Forms.ColumnHeader colunaRemessaChaveHost;
        private System.Windows.Forms.ColumnHeader colunaRemessaMontante;
        private System.Windows.Forms.ColumnHeader colunaRemessaNumContaDep;
        private System.Windows.Forms.ColumnHeader colunaRemessaNIB;
        private System.Windows.Forms.ColumnHeader colunaRemessaDataRem;
        private System.Windows.Forms.ColumnHeader colunaRemessaEstadoLote;
        private System.Windows.Forms.ColumnHeader colunaRemessaHoraChegada;
        private System.Windows.Forms.ColumnHeader colunaRemessaIdRemessa;
        private System.Windows.Forms.ColumnHeader colunaRemessaNomeImgCabLote;
        private System.Windows.Forms.ColumnHeader colunaRemessaNumCabLote;
        private System.Windows.Forms.ColumnHeader colunaRemessaNumDocs;
        private System.Windows.Forms.ColumnHeader colunaRemessaNumPaginaCabLote;
        private System.Windows.Forms.ColumnHeader colunaRemessaNumPropostaLogica;
        private System.Windows.Forms.ColumnHeader colunaRemessaOrigem;
        private System.Windows.Forms.ColumnHeader colunaRemessaSubProduto;
        private System.Windows.Forms.ColumnHeader colunaRemessaTipoRemessa;
        private System.Windows.Forms.ColumnHeader colunaDocConsultaId;
        private System.Windows.Forms.ColumnHeader colunaDocAguardaRedig;
        private System.Windows.Forms.ColumnHeader colunaDocAnomaliaDadosIlegais;
        private System.Windows.Forms.ColumnHeader colunaDocBalcao;
        private System.Windows.Forms.ColumnHeader colunaDocChaveHost;
        private System.Windows.Forms.ColumnHeader colunaDocZib;
        private System.Windows.Forms.ColumnHeader colunaDocNumConta;
        private System.Windows.Forms.ColumnHeader colunaDocNumCheque;
        private System.Windows.Forms.ColumnHeader colunaDocMontante;
        private System.Windows.Forms.ColumnHeader colunaDocTipoCheque;
        private System.Windows.Forms.ColumnHeader colunaDocValidaRequisitosDoc;
        private System.Windows.Forms.ColumnHeader colunaDocEstado;
        private System.Windows.Forms.ColumnHeader colunaDocFsl;
        private System.Windows.Forms.ColumnHeader colunaDocIdDocumento;
        private System.Windows.Forms.ColumnHeader colunaDocIdRemessa;
        private System.Windows.Forms.ColumnHeader colunaDocLote;
        private System.Windows.Forms.ColumnHeader colunaDocMaquina;
        private System.Windows.Forms.ColumnHeader colunaDocNomeImagem;
        private System.Windows.Forms.ColumnHeader colunaDocNumPaginas;
        private System.Windows.Forms.ColumnHeader colunaDocOrigem;
        private System.Windows.Forms.ColumnHeader colunaDocRefarqCaptura;
        private System.Windows.Forms.ColumnHeader colunaDocSequencia;
        private System.Windows.Forms.ColumnHeader colunaDocSubProduto;
        private System.Windows.Forms.DateTimePicker dataInicio;
        private System.Windows.Forms.DateTimePicker dataFim;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripConsultaDocs;
        private System.Windows.Forms.ToolStripMenuItem consultarImagensToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader colunaRemessaMaisResultados;
        private System.Windows.Forms.ColumnHeader colunaRemessaTimerCriacao;
        private System.Windows.Forms.ColumnHeader colunaRemessaErro;
        private System.Windows.Forms.ColumnHeader colunaRemessaEstado;
        private System.Windows.Forms.ColumnHeader colunaRemessaFiltro;
        private System.Windows.Forms.ColumnHeader colunaRemessaTimerActualizacao;
        private System.Windows.Forms.ColumnHeader colunaDocTimerCriacao;
        private System.Windows.Forms.ColumnHeader colunaDocTimerActualizacao;
        private System.Windows.Forms.ColumnHeader colunaDocMaisResultados;
        private System.Windows.Forms.ColumnHeader colunaDocErro;
        private System.Windows.Forms.ColumnHeader colunaDocEstadoTibco;
        private System.Windows.Forms.ColumnHeader colunaDocFiltro;
        private System.Windows.Forms.ColumnHeader coluaDocDOCID;
        private System.Windows.Forms.ColumnHeader colunaRemessaReminID;
        private System.Windows.Forms.ColumnHeader colunaOperativa;
        private System.Windows.Forms.SplitContainer m_splitContainerMain;
        private System.Windows.Forms.SplitContainer m_splitContainerDocs;
        private System.Windows.Forms.Label lbImagem;
        private NBIISNET.ListViewBase listViewImagens;
        private System.Windows.Forms.ColumnHeader colImgConsultaID;
        private System.Windows.Forms.ColumnHeader colImgTimer;
        private System.Windows.Forms.ColumnHeader colImgEstado;
        private System.Windows.Forms.ColumnHeader colImgErro;
        private System.Windows.Forms.PictureBox m_pictureBox;
        private System.Windows.Forms.ColumnHeader colImgSide; 
    }
}