﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using Alerta;
using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIActividades
{
    public partial class AlertasForm : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        string m_sAlertaFiltro;
        protected CIConfigGlobalParameters.CIMenuInterface m_oMenuInterface;

        public AlertasForm(CIConfigGP.CIGlobalParameters oParameters, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_sAlertaFiltro = "";
            m_oMenuInterface = oMenuInterface;
        }

        private void AlertasForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.WindowState = System.Windows.Forms.FormWindowState.Maximized;

                DefinirDatas();

                RefreshAlertas();
                //RefreshParametros();

                m_oMenuInterface.alertasToolStripMenuItemEnable(false);


                string sComm;
                DataSet ds;

                sComm = "select cast(situacao_id as varchar(40)) +' - '+ situacao_desc  as combobox, situacao_id from vw_alerta_situacao";
                ds = m_oParameters.DirectSqlDataSet(sComm, "Alerta Situacao");
                cbAlertasFiltro.Items.Clear();

                cbAlertasFiltro.DataSource = ds.Tables[0];
                cbAlertasFiltro.DisplayMember = "combobox";
          
                ds.Dispose();

                DataTable oTable = (DataTable)cbAlertasFiltro.DataSource;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Dispose();
            }
        }

        protected void DefinirDatas()
        {
            m_ctrldtFim.Value = DateTime.Now.Date;
            m_ctrldtInicio.Value = DateTime.Now.Date;
        }

        private void m_btRefresh_Click(object sender, EventArgs e)
        {
            RefreshAlertas();
        }

        //private void AddParam2ListView1(SqlDataReader dr)
        //{
        //    AccaoParam oAccP = new AccaoParam(dr);

        //    ListViewItem olvItem = oAccP.MakeListViewItemParam1();

        //    olvItem.Tag = oAccP;

        //    listViewAccaoParam1.Items.Add(olvItem);
          
        //}

        //private void AddParam2ListView2(SqlDataReader dr)
        //{
        //    AccaoParam oAccP = new AccaoParam(dr);

        //    ListViewItem olvItem = oAccP.MakeListViewItemParam2();

        //    olvItem.Tag = oAccP;

        //    listViewAccaoParam2.Items.Add(olvItem);
        //}

        private void AddAlerta2ListView(SqlDataReader dr)
        {
            AlertaSituacaoAccao oAl = new AlertaSituacaoAccao(dr);

            ListViewItem olvItem = oAl.MakeListViewItemAlerta(m_oParameters.DateTimeSysFmt);

            olvItem.Tag = oAl;

            listViewAlertas.Items.Add(olvItem);

            DisplayCount();

        }

        private void RefreshAlertas()
        {

            string sQuery = "select top 10000 * from VW_AL_ALERTA_SITUACAO_ACCAO where Al_TIMER between ";
            sQuery += "'" + m_ctrldtInicio.Value.ToString(m_oParameters.DateTimeSysFmt) + "' and ";
            sQuery += "'" + m_ctrldtFim.Value.AddDays(1).ToString(m_oParameters.DateTimeSysFmt) + "' ";
            if (m_sAlertaFiltro != "")
            {
                sQuery += "and SITUACAO_ID = " + m_sAlertaFiltro;
            }
            sQuery += " order by AL_TIMER desc, ACC_ID";

            SqlDataReader drA = null;

            

            try
            {
                Cursor = Cursors.WaitCursor;
                frmEspereUmMomento.ShowWaitForm();

                listViewAlertas.MyClear();

                drA = m_oParameters.DirectSqlDataReader(sQuery);
                while (drA.Read())
                {
                    AddAlerta2ListView(drA);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "AlertasForm.cs", 7);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (drA != null)
                {
                    drA.Close();
                }
               
                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();

                DisplayCount();
            }
        }

        private void DisplayCount()
        {
            labelCount.Text = listViewAlertas.Items.Count.ToString() + " Registos";
        }

        private void cbAlertasFiltro_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataRowView oRow;

            oRow = (DataRowView)cbAlertasFiltro.SelectedValue;

            int iAlertaFiltro = int.Parse(oRow["situacao_id"].ToString());
            if (iAlertaFiltro == 0)
            {
                m_sAlertaFiltro = "";
            }
            else
            {
                m_sAlertaFiltro = iAlertaFiltro.ToString();
            }
        }

        private void buttonSairJanela_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}