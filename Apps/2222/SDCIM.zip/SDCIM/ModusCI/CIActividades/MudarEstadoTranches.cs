﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CIActividades
{
    public partial class MudarEstadoTranches : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        public int idTranche;
        public string estadoTranche;
        public int idEstado;
        public MudarEstadoTranches(CIConfigGP.CIGlobalParameters oParameters, int id, string estado, int idEstado)
        {
            this.idEstado = idEstado;
            this.idTranche = id;
            this.estadoTranche = estado;
            m_oParameters = oParameters;
            InitializeComponent();
            preenheComboBox();
            preencherTexbox();
        }
        private void preencherTexbox()
        {

            this.tbCurrentEstado.Text = estadoTranche;
        }
        private void preenheComboBox()
        {
            DataSet ds = null;

            if (cbEstadoNovo.Items.Count > 0)
            {
                return;
            }

            try
            {
                string sComm = "select * from dbo.TRANCHEOUT_STATUS";
                ds = m_oParameters.DirectSqlDataSet(sComm, "TRANCHEOUT_STATUS");
                cbEstadoNovo.DataSource = ds.Tables[0];
                cbEstadoNovo.DisplayMember = "TRANOUTSTAT_DESC";
                cbEstadoNovo.ValueMember = "TRANOUTSTAT_ID";

            }
            finally
            {
                if (ds != null)
                {
                    ds.Dispose();
                    ds = null;
                }
            }
        }

        private void cbEstadoNovo_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            this.tbCurrentEstado.Text = cbEstadoNovo.Text;

        }

        private void btOK_Click(object sender, EventArgs e)
        {

            estadoTranche = cbEstadoNovo.Text;
            idEstado = Convert.ToInt32(cbEstadoNovo.SelectedValue);
            SqlDataReader dr = null;
            string sQuery = "Update  TRANCHE_OUT Set TRANOUTSTAT_ID = " + idEstado + " where TRANOUT_ID =" + idTranche;
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
            }
            catch
            {
                MessageBox.Show("Não foi possivel mudar o estado");
            }

            DialogResult = DialogResult.OK;
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
