﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace CIActividades
{
    class TranchesDetalhe
    {
        public string m_sREMIN_ID;
        public string m_sTRANOUT_ID;
        // m_ID

        public DateTime m_dtREMPROC_TIMER;

        public DateTime m_dtTRANOUT_TIMER;
        public DateTime m_dtREMIN_DATA;
        public int m_iREMINSTAT_ID;
        public string m_sREMINSTAT_ABR;
        public int m_iTRANOUTSTAT_ID;
        public string m_sTRANOUTSTAT_ABR;
        public long m_lREMIN_NUMERO;
        public int m_iTRANOUT_NUMERO;

        public int m_iREMIN_QT_DOCS;
        public decimal m_dREMIN_MT_DOCS;
        public int m_iTRANOUT_QT_DOCS;
        public decimal m_dTRANOUT_MT_DOCS;
        public string m_sREMPROC_ERRO;
        public string m_sTRANOUT_ERRO;
        //-----------------------------------------


        public string m_sREMIN_PAIS;
        public int m_iREMIN_BANCO;
        public int m_iREMIN_BALCAO;
        public string m_sBALCAO_ABR;



        public string m_sREMPROC_CHAVEH;
        public string m_sREMPROC_CHAVEHEXT;


        private void InitVars()
        {
            m_dtREMIN_DATA=DateTime.MinValue;
            m_sREMIN_ID="-1";
            m_sTRANOUT_ID="";
            m_sREMIN_PAIS="PT  ";
            m_iREMIN_BANCO=35;
            m_iREMIN_BALCAO=-1;
            m_sBALCAO_ABR="";
            m_lREMIN_NUMERO=-1;
            m_iTRANOUTSTAT_ID=0;
            m_iREMINSTAT_ID = 0;
            m_sREMINSTAT_ABR = "";
            m_sTRANOUTSTAT_ABR="";
            m_iTRANOUT_NUMERO=-1;
            m_iTRANOUT_QT_DOCS=0;
            m_dTRANOUT_MT_DOCS=0;
            m_iREMIN_QT_DOCS = 0;
            m_dREMIN_MT_DOCS = 0;
            m_sREMPROC_CHAVEH = "";
            m_sREMPROC_CHAVEHEXT = "";
            m_sREMPROC_ERRO= "";
            m_dtREMPROC_TIMER = DateTime.MinValue;
            m_sTRANOUT_ERRO ="";
            m_dtTRANOUT_TIMER = DateTime.MinValue;
        }

        public TranchesDetalhe()
        {
            InitVars();
        }

        public TranchesDetalhe(SqlDataReader dr)
        {
            InitVars();

            try
            {
                m_dtREMIN_DATA = Convert.ToDateTime(dr["REMIN_DATA"]);
                m_sREMIN_ID = Convert.ToString(dr["REMIN_ID"]);
                m_iREMINSTAT_ID = Convert.ToInt32(dr["REMINSTAT_ID"]);
                m_sREMINSTAT_ABR = Convert.ToString(dr["REMINSTAT_ABR"]);
                m_sREMIN_PAIS = Convert.ToString(dr["REMIN_PAIS"]);
                m_iREMIN_BANCO = Convert.ToInt32(dr["REMIN_BANCO"]);
                m_iREMIN_BALCAO = Convert.ToInt32(dr["REMIN_BALCAO"]);
                m_iREMIN_QT_DOCS = Convert.ToInt32(dr["REMIN_QT_DOCS"]);
                m_dREMIN_MT_DOCS = Convert.ToDecimal(dr["REMIN_MT_DOCS"]);
                m_sREMPROC_CHAVEH = Convert.ToString(dr["REMPROC_CHAVEH"]);
                m_sREMPROC_CHAVEHEXT = Convert.ToString(dr["REMPROC_CHAVEHEXT"]);
                m_sREMPROC_ERRO = Convert.ToString(dr["REMPROC_ERRO"]);
                m_dtREMPROC_TIMER = Convert.ToDateTime(dr["REMPROC_TIMER"]);
                
    
                try
                {
                    m_sBALCAO_ABR = Convert.ToString(dr["BALCAO_ABR"]);
                }
                catch 
                {
                    m_sBALCAO_ABR = m_iREMIN_BALCAO.ToString();
                }

                m_lREMIN_NUMERO = Convert.ToInt64(dr["REMIN_NUMERO"]);

                try
                {
                    m_sTRANOUT_ID = Convert.ToString(dr["TRANOUT_ID"]);
                    m_iTRANOUTSTAT_ID = Convert.ToInt32(dr["TRANOUTSTAT_ID"]);
                    m_sTRANOUTSTAT_ABR = Convert.ToString(dr["TRANOUTSTAT_ABR"]);
                    m_iTRANOUT_QT_DOCS = Convert.ToInt32(dr["TRANOUT_QT_DOCS"]);
                    m_dTRANOUT_MT_DOCS = Convert.ToDecimal(dr["TRANOUT_MT_DOCS"]);
                    m_iTRANOUT_NUMERO = Convert.ToInt32(dr["TRANOUT_NUMERO"]);
                    m_sTRANOUT_ERRO = Convert.ToString(dr["TRANOUT_ERRO"]);
                    m_dtTRANOUT_TIMER = Convert.ToDateTime(dr["TRANOUT_TIMER"]);
                }
                catch 
                {
                
                }

            }
            catch
            { 
            }
        }
        public ListViewItem MakeListViewItemDetalheTranches(string sDateFormat,string sDateTimeFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_sREMIN_ID;
            olvItem.SubItems.Add(m_sTRANOUT_ID);
            olvItem.SubItems.Add(m_dtREMIN_DATA.ToString(sDateFormat));
            olvItem.SubItems.Add(m_sREMIN_PAIS);//esconder
            olvItem.SubItems.Add(m_iREMIN_BANCO.ToString());//esconder
            olvItem.SubItems.Add(m_iREMIN_BALCAO.ToString()+ " " + m_sBALCAO_ABR);
            olvItem.SubItems.Add(m_lREMIN_NUMERO.ToString());
            olvItem.SubItems.Add(m_iREMINSTAT_ID.ToString()+ " " + m_sREMINSTAT_ABR);
            olvItem.SubItems.Add(m_sREMPROC_CHAVEH);
            olvItem.SubItems.Add(m_sREMPROC_CHAVEHEXT);
            olvItem.SubItems.Add(m_sREMPROC_ERRO);
            olvItem.SubItems.Add(m_dtREMPROC_TIMER.ToString(sDateTimeFormat));


            if (m_iTRANOUT_NUMERO > 0)
            {
                olvItem.SubItems.Add(m_iTRANOUT_NUMERO.ToString());
                olvItem.SubItems.Add(m_iTRANOUTSTAT_ID + " " + m_sTRANOUTSTAT_ABR);
                olvItem.SubItems.Add(m_sTRANOUT_ERRO);
                olvItem.SubItems.Add(m_dtTRANOUT_TIMER.ToString(sDateTimeFormat));
            }
            else
            {
                olvItem.SubItems.Add("");
                olvItem.SubItems.Add("");
                olvItem.SubItems.Add("");
                olvItem.SubItems.Add("");
            }
            olvItem.SubItems.Add(m_iTRANOUT_QT_DOCS.ToString());
            olvItem.SubItems.Add(m_dTRANOUT_MT_DOCS.ToString("0.00"));
            olvItem.SubItems.Add(m_iREMIN_QT_DOCS.ToString());
            olvItem.SubItems.Add(m_dREMIN_MT_DOCS.ToString("0.00"));

            return olvItem;
        }

    }
}
