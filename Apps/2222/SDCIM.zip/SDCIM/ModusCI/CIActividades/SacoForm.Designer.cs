﻿namespace CIActividades
{
    partial class SacoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            m_oMenuInterface.sacoEnable(true);
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SacoForm));
            this.labelBalcao = new System.Windows.Forms.Label();
            this.labelDeposito = new System.Windows.Forms.Label();
            this.labelRemessa = new System.Windows.Forms.Label();
            this.textBoxBalcao = new System.Windows.Forms.TextBox();
            this.textBoxDeposito = new System.Windows.Forms.TextBox();
            this.textBoxRemessa = new System.Windows.Forms.TextBox();
            this.buttonPesquisa = new System.Windows.Forms.Button();
            this.toolStripButtonExitJanela = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.dtpBeginDate = new System.Windows.Forms.DateTimePicker();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.lblBeginDate = new System.Windows.Forms.Label();
            this.listViewResultEstornoDocumento = new NBIISNET.ListViewBase();
            this.columnHeader29 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader30 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader31 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader32 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Estado1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader33 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader34 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader42 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader35 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader36 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lblCountListViewEstornoDocumento = new System.Windows.Forms.Label();
            this.lblCountListViewDepositos = new System.Windows.Forms.Label();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Estado3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewResultDeposito = new NBIISNET.ListViewBase();
            this.lblListViewEstornoDeposito = new System.Windows.Forms.Label();
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader22 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader23 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader24 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Estado2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader25 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader26 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader27 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader28 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewResultEstornoDeposito = new NBIISNET.ListViewBase();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelBalcao
            // 
            this.labelBalcao.AutoSize = true;
            this.labelBalcao.Location = new System.Drawing.Point(412, 8);
            this.labelBalcao.Name = "labelBalcao";
            this.labelBalcao.Size = new System.Drawing.Size(40, 13);
            this.labelBalcao.TabIndex = 0;
            this.labelBalcao.Text = "Balcão";
            // 
            // labelDeposito
            // 
            this.labelDeposito.AutoSize = true;
            this.labelDeposito.Location = new System.Drawing.Point(452, 8);
            this.labelDeposito.Name = "labelDeposito";
            this.labelDeposito.Size = new System.Drawing.Size(49, 13);
            this.labelDeposito.TabIndex = 1;
            this.labelDeposito.Text = "Depósito";
            // 
            // labelRemessa
            // 
            this.labelRemessa.AutoSize = true;
            this.labelRemessa.Location = new System.Drawing.Point(504, 8);
            this.labelRemessa.Name = "labelRemessa";
            this.labelRemessa.Size = new System.Drawing.Size(51, 13);
            this.labelRemessa.TabIndex = 2;
            this.labelRemessa.Text = "Remessa";
            // 
            // textBoxBalcao
            // 
            this.textBoxBalcao.Location = new System.Drawing.Point(412, 24);
            this.textBoxBalcao.MaxLength = 4;
            this.textBoxBalcao.Name = "textBoxBalcao";
            this.textBoxBalcao.Size = new System.Drawing.Size(37, 20);
            this.textBoxBalcao.TabIndex = 3;
            this.textBoxBalcao.TextChanged += new System.EventHandler(this.textBoxBalcao_TextChanged);
            // 
            // textBoxDeposito
            // 
            this.textBoxDeposito.Location = new System.Drawing.Point(455, 24);
            this.textBoxDeposito.MaxLength = 7;
            this.textBoxDeposito.Name = "textBoxDeposito";
            this.textBoxDeposito.Size = new System.Drawing.Size(46, 20);
            this.textBoxDeposito.TabIndex = 4;
            this.textBoxDeposito.TextChanged += new System.EventHandler(this.textBoxDeposito_TextChanged);
            // 
            // textBoxRemessa
            // 
            this.textBoxRemessa.Location = new System.Drawing.Point(507, 24);
            this.textBoxRemessa.MaxLength = 6;
            this.textBoxRemessa.Name = "textBoxRemessa";
            this.textBoxRemessa.Size = new System.Drawing.Size(48, 20);
            this.textBoxRemessa.TabIndex = 5;
            this.textBoxRemessa.TextChanged += new System.EventHandler(this.textBoxRemessa_TextChanged);
            // 
            // buttonPesquisa
            // 
            this.buttonPesquisa.Image = global::CIActividades.Properties.Resources.Refresh;
            this.buttonPesquisa.Location = new System.Drawing.Point(561, 8);
            this.buttonPesquisa.Name = "buttonPesquisa";
            this.buttonPesquisa.Size = new System.Drawing.Size(40, 43);
            this.buttonPesquisa.TabIndex = 6;
            this.buttonPesquisa.UseVisualStyleBackColor = true;
            this.buttonPesquisa.Click += new System.EventHandler(this.buttonPesquisa_Click);
            // 
            // toolStripButtonExitJanela
            // 
            this.toolStripButtonExitJanela.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonExitJanela.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonExitJanela.Image")));
            this.toolStripButtonExitJanela.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonExitJanela.Name = "toolStripButtonExitJanela";
            this.toolStripButtonExitJanela.Size = new System.Drawing.Size(36, 36);
            this.toolStripButtonExitJanela.Click += new System.EventHandler(this.toolStripButtonExitJanela_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonExitJanela});
            this.toolStrip1.Location = new System.Drawing.Point(604, 9);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0);
            this.toolStrip1.Size = new System.Drawing.Size(47, 39);
            this.toolStrip1.TabIndex = 24;
            this.toolStrip1.Text = "toolStripActividades";
            // 
            // dtpBeginDate
            // 
            this.dtpBeginDate.CustomFormat = " dddd - yyyy-MM-dd";
            this.dtpBeginDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpBeginDate.Location = new System.Drawing.Point(41, 24);
            this.dtpBeginDate.Name = "dtpBeginDate";
            this.dtpBeginDate.Size = new System.Drawing.Size(168, 20);
            this.dtpBeginDate.TabIndex = 26;
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEndDate.Location = new System.Drawing.Point(215, 28);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(18, 13);
            this.lblEndDate.TabIndex = 27;
            this.lblEndDate.Text = "a:";
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.CustomFormat = " dddd - yyyy-MM-dd";
            this.dtpEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEndDate.Location = new System.Drawing.Point(239, 24);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(167, 20);
            this.dtpEndDate.TabIndex = 28;
            // 
            // lblBeginDate
            // 
            this.lblBeginDate.AutoSize = true;
            this.lblBeginDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBeginDate.Location = new System.Drawing.Point(12, 27);
            this.lblBeginDate.Name = "lblBeginDate";
            this.lblBeginDate.Size = new System.Drawing.Size(27, 13);
            this.lblBeginDate.TabIndex = 25;
            this.lblBeginDate.Text = "De:";
            // 
            // listViewResultEstornoDocumento
            // 
            this.listViewResultEstornoDocumento.AllowColumnReorder = true;
            this.listViewResultEstornoDocumento.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewResultEstornoDocumento.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader29,
            this.columnHeader30,
            this.columnHeader31,
            this.columnHeader32,
            this.Estado1,
            this.columnHeader33,
            this.columnHeader34,
            this.columnHeader42,
            this.columnHeader35,
            this.columnHeader36});
            this.listViewResultEstornoDocumento.EnableExportar = true;
            this.listViewResultEstornoDocumento.FullRowSelect = true;
            this.listViewResultEstornoDocumento.GridLines = true;
            this.listViewResultEstornoDocumento.HideSelection = false;
            this.listViewResultEstornoDocumento.Location = new System.Drawing.Point(3, 16);
            this.listViewResultEstornoDocumento.Name = "listViewResultEstornoDocumento";
            this.listViewResultEstornoDocumento.Size = new System.Drawing.Size(909, 122);
            this.listViewResultEstornoDocumento.TabIndex = 34;
            this.listViewResultEstornoDocumento.TabStop = false;
            this.listViewResultEstornoDocumento.UseCompatibleStateImageBehavior = false;
            this.listViewResultEstornoDocumento.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader29
            // 
            this.columnHeader29.Text = "País";
            // 
            // columnHeader30
            // 
            this.columnHeader30.Text = "Banco";
            // 
            // columnHeader31
            // 
            this.columnHeader31.Text = "Balcão";
            this.columnHeader31.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // columnHeader32
            // 
            this.columnHeader32.Text = "Depósito";
            this.columnHeader32.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader32.Width = 59;
            // 
            // Estado1
            // 
            this.Estado1.Text = "Estado";
            this.Estado1.Width = 110;
            // 
            // columnHeader33
            // 
            this.columnHeader33.Text = "Data Remessa";
            this.columnHeader33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader33.Width = 90;
            // 
            // columnHeader34
            // 
            this.columnHeader34.Text = "Operador";
            this.columnHeader34.Width = 79;
            // 
            // columnHeader42
            // 
            this.columnHeader42.Text = "N. Seq";
            this.columnHeader42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader42.Width = 62;
            // 
            // columnHeader35
            // 
            this.columnHeader35.Text = "Remessa Balcão";
            this.columnHeader35.Width = 0;
            // 
            // columnHeader36
            // 
            this.columnHeader36.Text = "Tipo Remessa";
            this.columnHeader36.Width = 0;
            // 
            // lblCountListViewEstornoDocumento
            // 
            this.lblCountListViewEstornoDocumento.AutoSize = true;
            this.lblCountListViewEstornoDocumento.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountListViewEstornoDocumento.Location = new System.Drawing.Point(-1, 0);
            this.lblCountListViewEstornoDocumento.Name = "lblCountListViewEstornoDocumento";
            this.lblCountListViewEstornoDocumento.Size = new System.Drawing.Size(118, 13);
            this.lblCountListViewEstornoDocumento.TabIndex = 33;
            this.lblCountListViewEstornoDocumento.Text = "Estorno Documento";
            // 
            // lblCountListViewDepositos
            // 
            this.lblCountListViewDepositos.AutoSize = true;
            this.lblCountListViewDepositos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountListViewDepositos.Location = new System.Drawing.Point(0, 0);
            this.lblCountListViewDepositos.Name = "lblCountListViewDepositos";
            this.lblCountListViewDepositos.Size = new System.Drawing.Size(57, 13);
            this.lblCountListViewDepositos.TabIndex = 29;
            this.lblCountListViewDepositos.Text = "Depósito";
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "País";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Banco";
            this.columnHeader2.Width = 50;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Balcão";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Depósito";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Estado3
            // 
            this.Estado3.Text = "Estado";
            this.Estado3.Width = 110;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Data Remessa";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 85;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Operador";
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Remessa Balcão";
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Tipo Remessa";
            this.columnHeader8.Width = 185;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Aplic.";
            this.columnHeader9.Width = 40;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Tot. Doc. Rem";
            this.columnHeader10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader10.Width = 80;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Montante Remessa";
            this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader11.Width = 90;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Nib/Conta";
            this.columnHeader12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader12.Width = 80;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Zib";
            this.columnHeader13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader13.Width = 70;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Num. Conta";
            this.columnHeader14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader14.Width = 80;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Num. Cheque";
            this.columnHeader15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader15.Width = 80;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Montante";
            this.columnHeader16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader16.Width = 85;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Tp";
            this.columnHeader17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Data Digitalização";
            this.columnHeader18.Width = 85;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "N. Seq";
            this.columnHeader19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "Máquina";
            this.columnHeader20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // listViewResultDeposito
            // 
            this.listViewResultDeposito.AllowColumnReorder = true;
            this.listViewResultDeposito.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewResultDeposito.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.Estado3,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader18,
            this.columnHeader19,
            this.columnHeader20});
            this.listViewResultDeposito.EnableExportar = true;
            this.listViewResultDeposito.FullRowSelect = true;
            this.listViewResultDeposito.GridLines = true;
            this.listViewResultDeposito.HideSelection = false;
            this.listViewResultDeposito.Location = new System.Drawing.Point(4, 16);
            this.listViewResultDeposito.Name = "listViewResultDeposito";
            this.listViewResultDeposito.Size = new System.Drawing.Size(909, 227);
            this.listViewResultDeposito.TabIndex = 30;
            this.listViewResultDeposito.TabStop = false;
            this.listViewResultDeposito.UseCompatibleStateImageBehavior = false;
            this.listViewResultDeposito.View = System.Windows.Forms.View.Details;
            // 
            // lblListViewEstornoDeposito
            // 
            this.lblListViewEstornoDeposito.AutoSize = true;
            this.lblListViewEstornoDeposito.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblListViewEstornoDeposito.Location = new System.Drawing.Point(-1, 0);
            this.lblListViewEstornoDeposito.Name = "lblListViewEstornoDeposito";
            this.lblListViewEstornoDeposito.Size = new System.Drawing.Size(104, 13);
            this.lblListViewEstornoDeposito.TabIndex = 31;
            this.lblListViewEstornoDeposito.Text = "Estorno Depósito";
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "País";
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "Banco";
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "Balcão";
            this.columnHeader23.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // columnHeader24
            // 
            this.columnHeader24.Text = "Depósito";
            this.columnHeader24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Estado2
            // 
            this.Estado2.Text = "Estado";
            this.Estado2.Width = 110;
            // 
            // columnHeader25
            // 
            this.columnHeader25.Text = "Data Remessa";
            this.columnHeader25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader25.Width = 90;
            // 
            // columnHeader26
            // 
            this.columnHeader26.Text = "Operador";
            this.columnHeader26.Width = 73;
            // 
            // columnHeader27
            // 
            this.columnHeader27.Text = "Remessa Balcão";
            this.columnHeader27.Width = 0;
            // 
            // columnHeader28
            // 
            this.columnHeader28.Text = "Tipo Remessa";
            this.columnHeader28.Width = 0;
            // 
            // listViewResultEstornoDeposito
            // 
            this.listViewResultEstornoDeposito.AllowColumnReorder = true;
            this.listViewResultEstornoDeposito.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewResultEstornoDeposito.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader21,
            this.columnHeader22,
            this.columnHeader23,
            this.columnHeader24,
            this.Estado2,
            this.columnHeader25,
            this.columnHeader26,
            this.columnHeader27,
            this.columnHeader28});
            this.listViewResultEstornoDeposito.EnableExportar = true;
            this.listViewResultEstornoDeposito.FullRowSelect = true;
            this.listViewResultEstornoDeposito.GridLines = true;
            this.listViewResultEstornoDeposito.HideSelection = false;
            this.listViewResultEstornoDeposito.Location = new System.Drawing.Point(3, 16);
            this.listViewResultEstornoDeposito.Name = "listViewResultEstornoDeposito";
            this.listViewResultEstornoDeposito.Size = new System.Drawing.Size(909, 121);
            this.listViewResultEstornoDeposito.TabIndex = 32;
            this.listViewResultEstornoDeposito.TabStop = false;
            this.listViewResultEstornoDeposito.UseCompatibleStateImageBehavior = false;
            this.listViewResultEstornoDeposito.View = System.Windows.Forms.View.Details;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(12, 50);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lblCountListViewDepositos);
            this.splitContainer1.Panel1.Controls.Add(this.listViewResultDeposito);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(916, 551);
            this.splitContainer1.SplitterDistance = 249;
            this.splitContainer1.TabIndex = 35;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer2.Location = new System.Drawing.Point(1, 4);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.lblListViewEstornoDeposito);
            this.splitContainer2.Panel1.Controls.Add(this.listViewResultEstornoDeposito);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.lblCountListViewEstornoDocumento);
            this.splitContainer2.Panel2.Controls.Add(this.listViewResultEstornoDocumento);
            this.splitContainer2.Size = new System.Drawing.Size(915, 291);
            this.splitContainer2.SplitterDistance = 146;
            this.splitContainer2.TabIndex = 0;
            // 
            // SacoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 602);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.dtpEndDate);
            this.Controls.Add(this.lblEndDate);
            this.Controls.Add(this.dtpBeginDate);
            this.Controls.Add(this.lblBeginDate);
            this.Controls.Add(this.buttonPesquisa);
            this.Controls.Add(this.textBoxRemessa);
            this.Controls.Add(this.textBoxDeposito);
            this.Controls.Add(this.textBoxBalcao);
            this.Controls.Add(this.labelRemessa);
            this.Controls.Add(this.labelDeposito);
            this.Controls.Add(this.labelBalcao);
            this.Controls.Add(this.toolStrip1);
            this.Name = "SacoForm";
            this.ShowInTaskbar = false;
            this.Text = "Depósitos / Estornos";
            this.Load += new System.EventHandler(this.SacoForm_Load);
            this.Leave += new System.EventHandler(this.SacoForm_Leave);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelBalcao;
        private System.Windows.Forms.Label labelDeposito;
        private System.Windows.Forms.Label labelRemessa;
        private System.Windows.Forms.TextBox textBoxBalcao;
        private System.Windows.Forms.TextBox textBoxDeposito;
        private System.Windows.Forms.TextBox textBoxRemessa;
        private System.Windows.Forms.Button buttonPesquisa;
        private System.Windows.Forms.ToolStripButton toolStripButtonExitJanela;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.DateTimePicker dtpBeginDate;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.Label lblBeginDate;
        private NBIISNET.ListViewBase listViewResultEstornoDocumento;
        private System.Windows.Forms.ColumnHeader columnHeader29;
        private System.Windows.Forms.ColumnHeader columnHeader30;
        private System.Windows.Forms.ColumnHeader columnHeader31;
        private System.Windows.Forms.ColumnHeader columnHeader32;
        private System.Windows.Forms.ColumnHeader Estado1;
        private System.Windows.Forms.ColumnHeader columnHeader33;
        private System.Windows.Forms.ColumnHeader columnHeader34;
        private System.Windows.Forms.ColumnHeader columnHeader42;
        private System.Windows.Forms.ColumnHeader columnHeader35;
        private System.Windows.Forms.ColumnHeader columnHeader36;
        private System.Windows.Forms.Label lblCountListViewEstornoDocumento;
        private System.Windows.Forms.Label lblCountListViewDepositos;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader Estado3;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private NBIISNET.ListViewBase listViewResultDeposito;
        private System.Windows.Forms.Label lblListViewEstornoDeposito;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.ColumnHeader columnHeader23;
        private System.Windows.Forms.ColumnHeader columnHeader24;
        private System.Windows.Forms.ColumnHeader Estado2;
        private System.Windows.Forms.ColumnHeader columnHeader25;
        private System.Windows.Forms.ColumnHeader columnHeader26;
        private System.Windows.Forms.ColumnHeader columnHeader27;
        private System.Windows.Forms.ColumnHeader columnHeader28;
        private NBIISNET.ListViewBase listViewResultEstornoDeposito;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
    }
}