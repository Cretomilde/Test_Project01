﻿namespace CIActividades
{
    partial class ControloBalcaoAcoes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);

            m_oMenuInterface.controloBalcaoAcoesEnable(true);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listViewRegistosCompensacao = new NBIISNET.ListViewBase();
            this.colCompRemData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompProcTimer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompRemBalcao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompRemNumero = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompDepNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompRemEstado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompDocId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompZib = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompNumeroConta = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompNumeroCheque = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompMontante = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompTipoCheque = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompContaNib = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompRefArq = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompRefarqOri = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompCodAna = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompCancelamento = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompCancelamentoID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompNotificacao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompNotifID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCompChaveH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.labelDataDe = new System.Windows.Forms.Label();
            this.labelDataAte = new System.Windows.Forms.Label();
            this.labelBalcao = new System.Windows.Forms.Label();
            this.labelTipoRemessa = new System.Windows.Forms.Label();
            this.labelRemessa = new System.Windows.Forms.Label();
            this.labelDeposito = new System.Windows.Forms.Label();
            this.textBoxBalcao = new System.Windows.Forms.TextBox();
            this.textBoxRemessa = new System.Windows.Forms.TextBox();
            this.textBoxDeposito = new System.Windows.Forms.TextBox();
            this.comboBoxTipoRemessa = new System.Windows.Forms.ComboBox();
            this.dateTimePickerDe = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerAte = new System.Windows.Forms.DateTimePicker();
            this.buttonRefreshCompensacao = new System.Windows.Forms.Button();
            this.buttonCancelamentoAcolhimento = new System.Windows.Forms.Button();
            this.buttonNotificaAcolhimentoForaPrazo = new System.Windows.Forms.Button();
            this.lblRegEnviados = new System.Windows.Forms.Label();
            this.labelRegistoEmAnalise = new System.Windows.Forms.Label();
            this.listViewRegistosAnalise = new NBIISNET.ListViewBase();
            this.colAnaRemData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAnaProcTimer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAnaRemBalcao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAnaRemNumero = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAnaDepNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAnaRemEstado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmTpRemessa = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmTipo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStripAnalise = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.confirmaCancelamentoDeAcolhimentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.anulaCancelamentoDeAcolhimentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonRefreshAnalise = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.spContAccoes = new System.Windows.Forms.SplitContainer();
            this.contextMenuStripAnalise.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spContAccoes)).BeginInit();
            this.spContAccoes.Panel1.SuspendLayout();
            this.spContAccoes.Panel2.SuspendLayout();
            this.spContAccoes.SuspendLayout();
            this.SuspendLayout();
            // 
            // listViewRegistosCompensacao
            // 
            this.listViewRegistosCompensacao.AllowColumnReorder = true;
            this.listViewRegistosCompensacao.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewRegistosCompensacao.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colCompRemData,
            this.colCompProcTimer,
            this.colCompRemBalcao,
            this.colCompRemNumero,
            this.colCompDepNum,
            this.colCompRemEstado,
            this.colCompDocId,
            this.colCompZib,
            this.colCompNumeroConta,
            this.colCompNumeroCheque,
            this.colCompMontante,
            this.colCompTipoCheque,
            this.colCompContaNib,
            this.colCompRefArq,
            this.colCompRefarqOri,
            this.colCompCodAna,
            this.colCompCancelamento,
            this.colCompCancelamentoID,
            this.colCompNotificacao,
            this.colCompNotifID,
            this.colCompChaveH});
            this.listViewRegistosCompensacao.EnableExportar = true;
            this.listViewRegistosCompensacao.FullRowSelect = true;
            this.listViewRegistosCompensacao.GridLines = true;
            this.listViewRegistosCompensacao.HideSelection = false;
            this.listViewRegistosCompensacao.Location = new System.Drawing.Point(0, 16);
            this.listViewRegistosCompensacao.Name = "listViewRegistosCompensacao";
            this.listViewRegistosCompensacao.Size = new System.Drawing.Size(922, 273);
            this.listViewRegistosCompensacao.TabIndex = 6;
            this.listViewRegistosCompensacao.TabStop = false;
            this.listViewRegistosCompensacao.UseCompatibleStateImageBehavior = false;
            this.listViewRegistosCompensacao.View = System.Windows.Forms.View.Details;
            // 
            // colCompRemData
            // 
            this.colCompRemData.Text = "Rem. Data";
            this.colCompRemData.Width = 66;
            // 
            // colCompProcTimer
            // 
            this.colCompProcTimer.Text = "Proc. Timer";
            this.colCompProcTimer.Width = 66;
            // 
            // colCompRemBalcao
            // 
            this.colCompRemBalcao.Text = "Rem. Balcão";
            this.colCompRemBalcao.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colCompRemBalcao.Width = 73;
            // 
            // colCompRemNumero
            // 
            this.colCompRemNumero.Text = "Rem. Número";
            this.colCompRemNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colCompRemNumero.Width = 80;
            // 
            // colCompDepNum
            // 
            this.colCompDepNum.Text = "Dep. Número";
            this.colCompDepNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colCompDepNum.Width = 77;
            // 
            // colCompRemEstado
            // 
            this.colCompRemEstado.Text = "Rem. Estado";
            this.colCompRemEstado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colCompRemEstado.Width = 74;
            // 
            // colCompDocId
            // 
            this.colCompDocId.Text = "Doc Id";
            this.colCompDocId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colCompDocId.Width = 50;
            // 
            // colCompZib
            // 
            this.colCompZib.Text = "ZIB";
            this.colCompZib.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colCompZib.Width = 50;
            // 
            // colCompNumeroConta
            // 
            this.colCompNumeroConta.Text = "N. Conta";
            this.colCompNumeroConta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colCompNumeroCheque
            // 
            this.colCompNumeroCheque.Text = "N. Cheque";
            this.colCompNumeroCheque.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colCompNumeroCheque.Width = 100;
            // 
            // colCompMontante
            // 
            this.colCompMontante.Text = "Montante";
            this.colCompMontante.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.colCompMontante.Width = 100;
            // 
            // colCompTipoCheque
            // 
            this.colCompTipoCheque.Text = "Tp";
            this.colCompTipoCheque.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colCompTipoCheque.Width = 40;
            // 
            // colCompContaNib
            // 
            this.colCompContaNib.Text = "Conta/NIB";
            this.colCompContaNib.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colCompRefArq
            // 
            this.colCompRefArq.Text = "RefArq";
            this.colCompRefArq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colCompRefarqOri
            // 
            this.colCompRefarqOri.Text = "RefarqOri";
            this.colCompRefarqOri.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colCompCodAna
            // 
            this.colCompCodAna.Text = "CodAna";
            this.colCompCodAna.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colCompCancelamento
            // 
            this.colCompCancelamento.Text = "Cancelamento";
            this.colCompCancelamento.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colCompCancelamento.Width = 70;
            // 
            // colCompCancelamentoID
            // 
            this.colCompCancelamentoID.Text = "Cancelamento ID";
            this.colCompCancelamentoID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colCompCancelamentoID.Width = 70;
            // 
            // colCompNotificacao
            // 
            this.colCompNotificacao.Text = "Notificação";
            this.colCompNotificacao.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colCompNotifID
            // 
            this.colCompNotifID.Text = "Notif ID";
            this.colCompNotifID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // colCompChaveH
            // 
            this.colCompChaveH.Text = "ChaveH";
            this.colCompChaveH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelDataDe
            // 
            this.labelDataDe.AutoSize = true;
            this.labelDataDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDataDe.Location = new System.Drawing.Point(12, 29);
            this.labelDataDe.Name = "labelDataDe";
            this.labelDataDe.Size = new System.Drawing.Size(27, 13);
            this.labelDataDe.TabIndex = 7;
            this.labelDataDe.Text = "De:";
            // 
            // labelDataAte
            // 
            this.labelDataAte.AutoSize = true;
            this.labelDataAte.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDataAte.Location = new System.Drawing.Point(222, 30);
            this.labelDataAte.Name = "labelDataAte";
            this.labelDataAte.Size = new System.Drawing.Size(18, 13);
            this.labelDataAte.TabIndex = 8;
            this.labelDataAte.Text = "a:";
            // 
            // labelBalcao
            // 
            this.labelBalcao.AutoSize = true;
            this.labelBalcao.Location = new System.Drawing.Point(626, 11);
            this.labelBalcao.Name = "labelBalcao";
            this.labelBalcao.Size = new System.Drawing.Size(40, 13);
            this.labelBalcao.TabIndex = 9;
            this.labelBalcao.Text = "Balcão";
            // 
            // labelTipoRemessa
            // 
            this.labelTipoRemessa.AutoSize = true;
            this.labelTipoRemessa.Location = new System.Drawing.Point(423, 10);
            this.labelTipoRemessa.Name = "labelTipoRemessa";
            this.labelTipoRemessa.Size = new System.Drawing.Size(75, 13);
            this.labelTipoRemessa.TabIndex = 10;
            this.labelTipoRemessa.Text = "Tipo Remessa";
            // 
            // labelRemessa
            // 
            this.labelRemessa.AutoSize = true;
            this.labelRemessa.Location = new System.Drawing.Point(672, 11);
            this.labelRemessa.Name = "labelRemessa";
            this.labelRemessa.Size = new System.Drawing.Size(51, 13);
            this.labelRemessa.TabIndex = 11;
            this.labelRemessa.Text = "Remessa";
            // 
            // labelDeposito
            // 
            this.labelDeposito.AutoSize = true;
            this.labelDeposito.Location = new System.Drawing.Point(740, 11);
            this.labelDeposito.Name = "labelDeposito";
            this.labelDeposito.Size = new System.Drawing.Size(49, 13);
            this.labelDeposito.TabIndex = 12;
            this.labelDeposito.Text = "Depósito";
            // 
            // textBoxBalcao
            // 
            this.textBoxBalcao.Location = new System.Drawing.Point(629, 27);
            this.textBoxBalcao.MaxLength = 4;
            this.textBoxBalcao.Name = "textBoxBalcao";
            this.textBoxBalcao.Size = new System.Drawing.Size(37, 20);
            this.textBoxBalcao.TabIndex = 4;
            this.textBoxBalcao.TextChanged += new System.EventHandler(this.textBoxBalcao_TextChanged);
            this.textBoxBalcao.Leave += new System.EventHandler(this.textBoxBalcao_Leave);
            // 
            // textBoxRemessa
            // 
            this.textBoxRemessa.Enabled = false;
            this.textBoxRemessa.Location = new System.Drawing.Point(672, 27);
            this.textBoxRemessa.MaxLength = 7;
            this.textBoxRemessa.Name = "textBoxRemessa";
            this.textBoxRemessa.Size = new System.Drawing.Size(65, 20);
            this.textBoxRemessa.TabIndex = 5;
            this.textBoxRemessa.TextChanged += new System.EventHandler(this.textBoxRemessa_TextChanged);
            this.textBoxRemessa.Leave += new System.EventHandler(this.textBoxRemessa_Leave);
            // 
            // textBoxDeposito
            // 
            this.textBoxDeposito.Enabled = false;
            this.textBoxDeposito.Location = new System.Drawing.Point(743, 27);
            this.textBoxDeposito.MaxLength = 7;
            this.textBoxDeposito.Name = "textBoxDeposito";
            this.textBoxDeposito.Size = new System.Drawing.Size(65, 20);
            this.textBoxDeposito.TabIndex = 6;
            this.textBoxDeposito.TextChanged += new System.EventHandler(this.textBoxDeposito_TextChanged);
            this.textBoxDeposito.Leave += new System.EventHandler(this.textBoxDeposito_Leave);
            // 
            // comboBoxTipoRemessa
            // 
            this.comboBoxTipoRemessa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTipoRemessa.Location = new System.Drawing.Point(426, 26);
            this.comboBoxTipoRemessa.Name = "comboBoxTipoRemessa";
            this.comboBoxTipoRemessa.Size = new System.Drawing.Size(197, 21);
            this.comboBoxTipoRemessa.TabIndex = 3;
            this.comboBoxTipoRemessa.SelectedIndexChanged += new System.EventHandler(this.comboBoxTipoRemessa_SelectedIndexChanged);
            // 
            // dateTimePickerDe
            // 
            this.dateTimePickerDe.CustomFormat = " dddd - yyyy-MM-dd";
            this.dateTimePickerDe.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerDe.Location = new System.Drawing.Point(40, 27);
            this.dateTimePickerDe.Name = "dateTimePickerDe";
            this.dateTimePickerDe.Size = new System.Drawing.Size(176, 20);
            this.dateTimePickerDe.TabIndex = 1;
            this.dateTimePickerDe.ValueChanged += new System.EventHandler(this.dateTimePickerDe_ValueChanged);
            // 
            // dateTimePickerAte
            // 
            this.dateTimePickerAte.CustomFormat = " dddd - yyyy-MM-dd";
            this.dateTimePickerAte.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerAte.Location = new System.Drawing.Point(246, 26);
            this.dateTimePickerAte.Name = "dateTimePickerAte";
            this.dateTimePickerAte.Size = new System.Drawing.Size(174, 20);
            this.dateTimePickerAte.TabIndex = 2;
            this.dateTimePickerAte.ValueChanged += new System.EventHandler(this.dateTimePickerAte_ValueChanged);
            // 
            // buttonRefreshCompensacao
            // 
            this.buttonRefreshCompensacao.Location = new System.Drawing.Point(426, 52);
            this.buttonRefreshCompensacao.Name = "buttonRefreshCompensacao";
            this.buttonRefreshCompensacao.Size = new System.Drawing.Size(75, 23);
            this.buttonRefreshCompensacao.TabIndex = 7;
            this.buttonRefreshCompensacao.Text = "Refresh";
            this.buttonRefreshCompensacao.UseVisualStyleBackColor = true;
            this.buttonRefreshCompensacao.Click += new System.EventHandler(this.buttonRefreshCompensacao_Click);
            // 
            // buttonCancelamentoAcolhimento
            // 
            this.buttonCancelamentoAcolhimento.Enabled = false;
            this.buttonCancelamentoAcolhimento.Location = new System.Drawing.Point(40, 52);
            this.buttonCancelamentoAcolhimento.Name = "buttonCancelamentoAcolhimento";
            this.buttonCancelamentoAcolhimento.Size = new System.Drawing.Size(176, 23);
            this.buttonCancelamentoAcolhimento.TabIndex = 9;
            this.buttonCancelamentoAcolhimento.Text = "Cancelamento Acolhimento";
            this.buttonCancelamentoAcolhimento.UseVisualStyleBackColor = true;
            this.buttonCancelamentoAcolhimento.Click += new System.EventHandler(this.buttonCancelamentoAcolhimento_Click);
            // 
            // buttonNotificaAcolhimentoForaPrazo
            // 
            this.buttonNotificaAcolhimentoForaPrazo.Enabled = false;
            this.buttonNotificaAcolhimentoForaPrazo.Location = new System.Drawing.Point(246, 52);
            this.buttonNotificaAcolhimentoForaPrazo.Name = "buttonNotificaAcolhimentoForaPrazo";
            this.buttonNotificaAcolhimentoForaPrazo.Size = new System.Drawing.Size(174, 23);
            this.buttonNotificaAcolhimentoForaPrazo.TabIndex = 10;
            this.buttonNotificaAcolhimentoForaPrazo.Text = "Notifica Acolh. Fora Prazo";
            this.buttonNotificaAcolhimentoForaPrazo.UseVisualStyleBackColor = true;
            this.buttonNotificaAcolhimentoForaPrazo.Click += new System.EventHandler(this.buttonNotificaAcolhimentoForaPrazo_Click);
            // 
            // lblRegEnviados
            // 
            this.lblRegEnviados.AutoSize = true;
            this.lblRegEnviados.Location = new System.Drawing.Point(0, 0);
            this.lblRegEnviados.Name = "lblRegEnviados";
            this.lblRegEnviados.Size = new System.Drawing.Size(176, 13);
            this.lblRegEnviados.TabIndex = 24;
            this.lblRegEnviados.Text = "Registos enviados à compensação ";
            // 
            // labelRegistoEmAnalise
            // 
            this.labelRegistoEmAnalise.AutoSize = true;
            this.labelRegistoEmAnalise.Location = new System.Drawing.Point(3, 8);
            this.labelRegistoEmAnalise.Name = "labelRegistoEmAnalise";
            this.labelRegistoEmAnalise.Size = new System.Drawing.Size(101, 13);
            this.labelRegistoEmAnalise.TabIndex = 25;
            this.labelRegistoEmAnalise.Text = "Registos em análise";
            // 
            // listViewRegistosAnalise
            // 
            this.listViewRegistosAnalise.AllowColumnReorder = true;
            this.listViewRegistosAnalise.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewRegistosAnalise.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colAnaRemData,
            this.colAnaProcTimer,
            this.colAnaRemBalcao,
            this.colAnaRemNumero,
            this.colAnaDepNum,
            this.colAnaRemEstado,
            this.clmTpRemessa,
            this.clmTipo});
            this.listViewRegistosAnalise.ContextMenuStrip = this.contextMenuStripAnalise;
            this.listViewRegistosAnalise.EnableExportar = true;
            this.listViewRegistosAnalise.FullRowSelect = true;
            this.listViewRegistosAnalise.GridLines = true;
            this.listViewRegistosAnalise.HideSelection = false;
            this.listViewRegistosAnalise.Location = new System.Drawing.Point(0, 32);
            this.listViewRegistosAnalise.Name = "listViewRegistosAnalise";
            this.listViewRegistosAnalise.Size = new System.Drawing.Size(922, 182);
            this.listViewRegistosAnalise.TabIndex = 26;
            this.listViewRegistosAnalise.TabStop = false;
            this.listViewRegistosAnalise.UseCompatibleStateImageBehavior = false;
            this.listViewRegistosAnalise.View = System.Windows.Forms.View.Details;
            // 
            // colAnaRemData
            // 
            this.colAnaRemData.Text = "Rem. Data";
            this.colAnaRemData.Width = 72;
            // 
            // colAnaProcTimer
            // 
            this.colAnaProcTimer.Text = "Proc. Timer";
            this.colAnaProcTimer.Width = 72;
            // 
            // colAnaRemBalcao
            // 
            this.colAnaRemBalcao.Text = "Rem. Balcão";
            this.colAnaRemBalcao.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colAnaRemBalcao.Width = 74;
            // 
            // colAnaRemNumero
            // 
            this.colAnaRemNumero.Text = "Rem. Número";
            this.colAnaRemNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colAnaRemNumero.Width = 88;
            // 
            // colAnaDepNum
            // 
            this.colAnaDepNum.Text = "Dep. Número";
            this.colAnaDepNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colAnaDepNum.Width = 79;
            // 
            // colAnaRemEstado
            // 
            this.colAnaRemEstado.Text = "Rem. Estado";
            this.colAnaRemEstado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.colAnaRemEstado.Width = 150;
            // 
            // clmTpRemessa
            // 
            this.clmTpRemessa.Text = "Tipo Remessa";
            this.clmTpRemessa.Width = 150;
            // 
            // clmTipo
            // 
            this.clmTipo.Text = "Ação";
            this.clmTipo.Width = 135;
            // 
            // contextMenuStripAnalise
            // 
            this.contextMenuStripAnalise.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.confirmaCancelamentoDeAcolhimentoToolStripMenuItem,
            this.anulaCancelamentoDeAcolhimentoToolStripMenuItem,
            this.toolStripSeparator1,
            this.confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem,
            this.anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem});
            this.contextMenuStripAnalise.Name = "contextMenuStripAnalise";
            this.contextMenuStripAnalise.Size = new System.Drawing.Size(335, 98);
            this.contextMenuStripAnalise.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripAnalise_Opening);
            // 
            // confirmaCancelamentoDeAcolhimentoToolStripMenuItem
            // 
            this.confirmaCancelamentoDeAcolhimentoToolStripMenuItem.Name = "confirmaCancelamentoDeAcolhimentoToolStripMenuItem";
            this.confirmaCancelamentoDeAcolhimentoToolStripMenuItem.Size = new System.Drawing.Size(334, 22);
            this.confirmaCancelamentoDeAcolhimentoToolStripMenuItem.Text = "Confirma Cancelamento de Acolhimento";
            this.confirmaCancelamentoDeAcolhimentoToolStripMenuItem.Click += new System.EventHandler(this.confirmaCancelamentoDeAcolhimentoToolStripMenuItem_Click);
            // 
            // anulaCancelamentoDeAcolhimentoToolStripMenuItem
            // 
            this.anulaCancelamentoDeAcolhimentoToolStripMenuItem.Name = "anulaCancelamentoDeAcolhimentoToolStripMenuItem";
            this.anulaCancelamentoDeAcolhimentoToolStripMenuItem.Size = new System.Drawing.Size(334, 22);
            this.anulaCancelamentoDeAcolhimentoToolStripMenuItem.Text = "Anula Cancelamento de Acolhimento";
            this.anulaCancelamentoDeAcolhimentoToolStripMenuItem.Click += new System.EventHandler(this.anulaCancelamentoDeAcolhimentoToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(331, 6);
            // 
            // confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem
            // 
            this.confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Name = "confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem";
            this.confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Size = new System.Drawing.Size(334, 22);
            this.confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Text = "Confirma Notificação de Acolhimento Fora Prazo";
            this.confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Click += new System.EventHandler(this.confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem_Click);
            // 
            // anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem
            // 
            this.anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Name = "anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem";
            this.anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Size = new System.Drawing.Size(334, 22);
            this.anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Text = "Anula Notificação de Acolhimento Fora Prazo";
            this.anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem.Click += new System.EventHandler(this.anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem_Click);
            // 
            // buttonRefreshAnalise
            // 
            this.buttonRefreshAnalise.Location = new System.Drawing.Point(120, 3);
            this.buttonRefreshAnalise.Name = "buttonRefreshAnalise";
            this.buttonRefreshAnalise.Size = new System.Drawing.Size(75, 23);
            this.buttonRefreshAnalise.TabIndex = 8;
            this.buttonRefreshAnalise.Text = "Refresh";
            this.buttonRefreshAnalise.UseVisualStyleBackColor = true;
            this.buttonRefreshAnalise.Click += new System.EventHandler(this.buttonRefreshAnalise_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(507, 52);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(78, 23);
            this.btnClear.TabIndex = 27;
            this.btnClear.Text = "Limpar Filtros";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // spContAccoes
            // 
            this.spContAccoes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.spContAccoes.Location = new System.Drawing.Point(12, 81);
            this.spContAccoes.Name = "spContAccoes";
            this.spContAccoes.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spContAccoes.Panel1
            // 
            this.spContAccoes.Panel1.Controls.Add(this.lblRegEnviados);
            this.spContAccoes.Panel1.Controls.Add(this.listViewRegistosCompensacao);
            // 
            // spContAccoes.Panel2
            // 
            this.spContAccoes.Panel2.Controls.Add(this.labelRegistoEmAnalise);
            this.spContAccoes.Panel2.Controls.Add(this.buttonRefreshAnalise);
            this.spContAccoes.Panel2.Controls.Add(this.listViewRegistosAnalise);
            this.spContAccoes.Size = new System.Drawing.Size(922, 509);
            this.spContAccoes.SplitterDistance = 288;
            this.spContAccoes.TabIndex = 28;
            // 
            // ControloBalcaoAcoes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 602);
            this.Controls.Add(this.spContAccoes);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.buttonNotificaAcolhimentoForaPrazo);
            this.Controls.Add(this.buttonCancelamentoAcolhimento);
            this.Controls.Add(this.buttonRefreshCompensacao);
            this.Controls.Add(this.dateTimePickerAte);
            this.Controls.Add(this.dateTimePickerDe);
            this.Controls.Add(this.comboBoxTipoRemessa);
            this.Controls.Add(this.textBoxDeposito);
            this.Controls.Add(this.textBoxRemessa);
            this.Controls.Add(this.textBoxBalcao);
            this.Controls.Add(this.labelDeposito);
            this.Controls.Add(this.labelRemessa);
            this.Controls.Add(this.labelTipoRemessa);
            this.Controls.Add(this.labelBalcao);
            this.Controls.Add(this.labelDataAte);
            this.Controls.Add(this.labelDataDe);
            this.Name = "ControloBalcaoAcoes";
            this.Text = "Controlo Balcão - Ações";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ControloBalcaoAcoes_Load);
            this.Click += new System.EventHandler(this.ControloBalcaoAcoes_Click);
            this.contextMenuStripAnalise.ResumeLayout(false);
            this.spContAccoes.Panel1.ResumeLayout(false);
            this.spContAccoes.Panel1.PerformLayout();
            this.spContAccoes.Panel2.ResumeLayout(false);
            this.spContAccoes.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spContAccoes)).EndInit();
            this.spContAccoes.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private NBIISNET.ListViewBase listViewRegistosCompensacao;
        private System.Windows.Forms.ColumnHeader colCompRemData;
        private System.Windows.Forms.ColumnHeader colCompProcTimer;
        private System.Windows.Forms.ColumnHeader colCompRemBalcao;
        private System.Windows.Forms.ColumnHeader colCompRemNumero;
        private System.Windows.Forms.ColumnHeader colCompDepNum;
        private System.Windows.Forms.ColumnHeader colCompRemEstado;
        private System.Windows.Forms.ColumnHeader colCompDocId;
        private System.Windows.Forms.Label labelDataDe;
        private System.Windows.Forms.Label labelDataAte;
        private System.Windows.Forms.Label labelBalcao;
        private System.Windows.Forms.Label labelTipoRemessa;
        private System.Windows.Forms.Label labelRemessa;
        private System.Windows.Forms.Label labelDeposito;
        private System.Windows.Forms.TextBox textBoxBalcao;
        private System.Windows.Forms.TextBox textBoxRemessa;
        private System.Windows.Forms.TextBox textBoxDeposito;
        private System.Windows.Forms.ComboBox comboBoxTipoRemessa;
        private System.Windows.Forms.DateTimePicker dateTimePickerDe;
        private System.Windows.Forms.DateTimePicker dateTimePickerAte;
        private System.Windows.Forms.Button buttonRefreshCompensacao;
        private System.Windows.Forms.Button buttonCancelamentoAcolhimento;
        private System.Windows.Forms.Button buttonNotificaAcolhimentoForaPrazo;
        private System.Windows.Forms.Label lblRegEnviados;
        private System.Windows.Forms.ColumnHeader colCompZib;
        private System.Windows.Forms.ColumnHeader colCompNumeroConta;
        private System.Windows.Forms.ColumnHeader colCompNumeroCheque;
        private System.Windows.Forms.ColumnHeader colCompMontante;
        private System.Windows.Forms.ColumnHeader colCompTipoCheque;
        private System.Windows.Forms.ColumnHeader colCompContaNib;
        private System.Windows.Forms.ColumnHeader colCompRefArq;
        private System.Windows.Forms.ColumnHeader colCompRefarqOri;
        private System.Windows.Forms.ColumnHeader colCompCodAna;
        private System.Windows.Forms.ColumnHeader colCompCancelamento;
        private System.Windows.Forms.ColumnHeader colCompCancelamentoID;
        private System.Windows.Forms.ColumnHeader colCompNotificacao;
        private System.Windows.Forms.ColumnHeader colCompNotifID;
        private System.Windows.Forms.ColumnHeader colCompChaveH;
        private System.Windows.Forms.Label labelRegistoEmAnalise;
        private NBIISNET.ListViewBase listViewRegistosAnalise;
        private System.Windows.Forms.ColumnHeader colAnaRemData;
        private System.Windows.Forms.ColumnHeader colAnaProcTimer;
        private System.Windows.Forms.ColumnHeader colAnaRemBalcao;
        private System.Windows.Forms.ColumnHeader colAnaRemNumero;
        private System.Windows.Forms.ColumnHeader colAnaDepNum;
        private System.Windows.Forms.ColumnHeader colAnaRemEstado;
        private System.Windows.Forms.Button buttonRefreshAnalise;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripAnalise;
        private System.Windows.Forms.ToolStripMenuItem confirmaCancelamentoDeAcolhimentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem confirmaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem anulaCancelamentoDeAcolhimentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem anulaNotificaçãoDeAcolhimentoForaPrazoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ColumnHeader clmTpRemessa;
        private System.Windows.Forms.ColumnHeader clmTipo;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.SplitContainer spContAccoes;
    }
}