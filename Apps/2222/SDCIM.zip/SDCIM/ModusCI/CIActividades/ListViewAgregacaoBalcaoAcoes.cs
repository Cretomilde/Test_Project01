﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CIActividades
{
    public class ListViewAgregacaoBalcaoAcoes
    {
        public DateTime dtREM_BALCAO_DATA;
        public DateTime dtREM_BALCAO_PROC;
        public Int16 iREM_BALCAO;
        public Int32 iREM_NUMERO;
        public Int32 iNUM_DEPOSITO; // REM_SEQUENCIA
        public String sREMBALCAO_STAT_DESC; //Estado da Remessa
        public Int32 iAgregacaoID;
        public String sRemessaTipo;
        public String sTipoAccao;

        private void initVars()
        {
            dtREM_BALCAO_DATA = DateTime.MinValue;
            dtREM_BALCAO_PROC = DateTime.MinValue;
            sREMBALCAO_STAT_DESC = String.Empty;
            iAgregacaoID = 0;
            sRemessaTipo = String.Empty;
        }

        public ListViewAgregacaoBalcaoAcoes(SqlDataReader dr)
        {
            initVars();

            dtREM_BALCAO_DATA = Convert.ToDateTime(dr["REMBALCAO_DATA"]);
            dtREM_BALCAO_PROC = Convert.ToDateTime(dr["REMBALCAO_TIMER"]);
            iREM_BALCAO = Convert.ToInt16(dr["REMBALCAO_BALCAO"]);
            iREM_NUMERO = Convert.ToInt32(dr["REMBALCAO_NUMERO"]);
            iNUM_DEPOSITO = Convert.ToInt32(dr["REMBALCAO_SEQUENCIA"]);
            sREMBALCAO_STAT_DESC = Convert.ToString(dr["REMINSTAT_DESC"]);
            iAgregacaoID = Convert.ToInt32(dr["DOCACOMAGR_ID"]);
            sRemessaTipo = Convert.ToString(dr["REMTIPOBALCAO_DESC"]);
            sTipoAccao = Convert.ToString(dr["TIBCO"]);
            //dtFICH_DATA = Convert.ToDateTime(dr["FICH_DATA"]);
        }

        public ListViewAgregacaoBalcaoAcoes(DataRow dtr)
        {
            initVars();

            dtREM_BALCAO_DATA = Convert.ToDateTime(dtr["REMBALCAO_DATA"]);
            dtREM_BALCAO_PROC = Convert.ToDateTime(dtr["REMBALCAO_TIMER"]);
            iREM_BALCAO = Convert.ToInt16(dtr["REMBALCAO_BALCAO"]);
            iREM_NUMERO = Convert.ToInt32(dtr["REMBALCAO_NUMERO"]);
            iNUM_DEPOSITO = Convert.ToInt32(dtr["REMBALCAO_SEQUENCIA"]);
            sREMBALCAO_STAT_DESC = Convert.ToString(dtr["REMINSTAT_DESC"]);
            iAgregacaoID = Convert.ToInt32(dtr["DOCACOMAGR_ID"]);
            sRemessaTipo = Convert.ToString(dtr["REMTIPOBALCAO_DESC"]);
            sTipoAccao = Convert.ToString(dtr["TIBCO"]);
        }

        public ListViewItem MakeListViewItemsAcoes(string sDateFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = dtREM_BALCAO_DATA.ToString(sDateFormat);
            olvItem.SubItems.Add(dtREM_BALCAO_PROC.ToString(sDateFormat));
            olvItem.SubItems.Add(iREM_BALCAO.ToString("0000"));
            olvItem.SubItems.Add(iREM_NUMERO.ToString("0000000"));
            olvItem.SubItems.Add(iNUM_DEPOSITO.ToString("000000"));
            olvItem.SubItems.Add(sREMBALCAO_STAT_DESC);
            olvItem.SubItems.Add(sRemessaTipo);
            olvItem.SubItems.Add(sTipoAccao);
            return olvItem;
        }
    }
}