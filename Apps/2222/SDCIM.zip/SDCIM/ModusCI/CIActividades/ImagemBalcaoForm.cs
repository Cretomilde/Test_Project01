﻿using System;
using System.IO;
using System.Windows.Forms;
using NBiis;

namespace CIActividades
{
    public partial class ImagemBalcaoForm : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;

        int m_sDOCMDI_ID;
        public ImagemBalcaoForm()
        {
            InitializeComponent();

        }
        public ImagemBalcaoForm(CIConfigGP.CIGlobalParameters oParameters, int sDOCMDI_ID)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_sDOCMDI_ID = sDOCMDI_ID;
        }
        protected void WriteImage(byte[] aBytes, string sFileName)
        {
            StreamWriter sw = new StreamWriter(sFileName, false);
            BinaryWriter bw = new BinaryWriter(sw.BaseStream);
            bw.Write(aBytes);
            sw.Close();
            bw.Close();
        }

        public string getImgFrente(CIConfigGP.CIGlobalParameters oParameters)
        {
            string sFileName = m_oParameters.GetTempFileName("IMGMDIFront") + ".jpg";
            String query = "select top 1 IMGBALCAO_IMAGE from dbo.Imagem_Balcao where DOCBALCAO_ID= " + m_sDOCMDI_ID + " and IMGBALCAO_SIDE = 0 ";
            this.SetImage(oParameters, query, sFileName);
            return sFileName;
        }

        public string getImgBack(CIConfigGP.CIGlobalParameters oParameters)
        {
            string sFileName = m_oParameters.GetTempFileName("IMGMDIBack") + ".jpg";
            String query = "select top 1 IMGBALCAO_IMAGE from dbo.Imagem_Balcao where DOCBALCAO_ID= " + m_sDOCMDI_ID + " and IMGBALCAO_SIDE = 1 ";
            this.SetImage(oParameters, query, sFileName);
            return sFileName;
        }

        private void SetImage(CIConfigGP.CIGlobalParameters oParameters, string query, string imageName)
        {
            byte[] aImgF = (byte[])oParameters.DirectSqlScalar(query);
            WriteImage(aImgF, imageName);
        }
        private void MostraImagem_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                if (imgFrente.Image != null) imgFrente.Image.Dispose();
                if (imgVerso.Image != null) imgVerso.Image.Dispose();
                imgFrente.Image = null;
                imgVerso.Image = null;
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "MDIMostraImagemForm", 12);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ImagemBalcaoForm_Load_1(object sender, EventArgs e)
        {

            try
            {
                //parte da frente
                string sFileNameFront;
                sFileNameFront = getImgFrente(m_oParameters);
                imgFrente.Image = System.Drawing.Image.FromFile(sFileNameFront);
                imgFrente.SizeMode = PictureBoxSizeMode.StretchImage;

                //parte de tras
                string sFileNameBack;
                sFileNameBack = getImgBack(m_oParameters);
                imgVerso.Image = System.Drawing.Image.FromFile(sFileNameBack);
                imgVerso.SizeMode = PictureBoxSizeMode.StretchImage;
                lblErro.Visible = false;
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "MDIMostraImagemForm", 11);
                lblErro.Visible = true;
            }
        }
    }
}
