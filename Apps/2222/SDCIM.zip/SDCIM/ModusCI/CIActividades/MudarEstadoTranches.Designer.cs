﻿namespace CIActividades
{
    partial class MudarEstadoTranches
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.btCancel = new System.Windows.Forms.Button();
            this.btOK = new System.Windows.Forms.Button();
            this.cbEstadoNovo = new System.Windows.Forms.ComboBox();
            this.tbCurrentEstado = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Label2
            // 
            this.Label2.Location = new System.Drawing.Point(12, 71);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(96, 23);
            this.Label2.TabIndex = 17;
            this.Label2.Text = "Novo Estado:";
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(12, 31);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(96, 23);
            this.Label1.TabIndex = 16;
            this.Label1.Text = "Estado Actual:";
            // 
            // btCancel
            // 
            this.btCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btCancel.Location = new System.Drawing.Point(298, 129);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(75, 23);
            this.btCancel.TabIndex = 14;
            this.btCancel.Text = "Cancel";
            this.btCancel.Click += new System.EventHandler(this.btCancel_Click);
            // 
            // btOK
            // 
            this.btOK.Location = new System.Drawing.Point(67, 129);
            this.btOK.Name = "btOK";
            this.btOK.Size = new System.Drawing.Size(75, 23);
            this.btOK.TabIndex = 13;
            this.btOK.Text = "OK";
            this.btOK.Click += new System.EventHandler(this.btOK_Click);
            // 
            // cbEstadoNovo
            // 
            this.cbEstadoNovo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEstadoNovo.Location = new System.Drawing.Point(132, 71);
            this.cbEstadoNovo.Name = "cbEstadoNovo";
            this.cbEstadoNovo.Size = new System.Drawing.Size(304, 21);
            this.cbEstadoNovo.TabIndex = 12;
            this.cbEstadoNovo.SelectedIndexChanged += new System.EventHandler(this.cbEstadoNovo_SelectedIndexChanged_1);
            // 
            // tbCurrentEstado
            // 
            this.tbCurrentEstado.Location = new System.Drawing.Point(132, 31);
            this.tbCurrentEstado.Name = "tbCurrentEstado";
            this.tbCurrentEstado.ReadOnly = true;
            this.tbCurrentEstado.Size = new System.Drawing.Size(304, 20);
            this.tbCurrentEstado.TabIndex = 18;
            this.tbCurrentEstado.TabStop = false;
            this.tbCurrentEstado.Text = "Estado Actual";
            // 
            // MudarEstadoTranches
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 170);
            this.Controls.Add(this.tbCurrentEstado);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.btCancel);
            this.Controls.Add(this.btOK);
            this.Controls.Add(this.cbEstadoNovo);
            this.Name = "MudarEstadoTranches";
            this.Text = "MudarEstadoTranches";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button btCancel;
        internal System.Windows.Forms.Button btOK;
        internal System.Windows.Forms.ComboBox cbEstadoNovo;
        internal System.Windows.Forms.TextBox tbCurrentEstado;
    }
}