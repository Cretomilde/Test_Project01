﻿using System;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Windows.Forms;
using CIConfigGlobalParameters;
using CIConfigGP;
using NBiis;

namespace CIActividades
{
    public partial class PesqFicheiroACOM : Form
    {
        #region Properties

        public CIGlobalParameters m_oParameters;

        public CIMenuInterface m_oMenuInterface;

        public Tibco Tibco = new Tibco();

        #endregion

        #region Page Events
        private CIMenuInterface _m_oMenuInterface = null;

        public PesqFicheiroACOM(CIGlobalParameters oParameters, CIMenuInterface m_oMenuInterface)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            this._m_oMenuInterface = m_oMenuInterface;
        }

        private void PesqFicheiroACOM_Load(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;            
            m_ctrldtInicio.Value = DateTime.Now.AddDays(-1);
            m_ctrldtFim.Value = DateTime.Now.AddDays(-1);
            RefreshListaACOM();
            this._m_oMenuInterface.enablePesqFicheiroAcom(false);
        }

        #endregion

        #region Private Functions

        private void RefreshListaACOM()
        {
            listViewPesquisaDocumentoACOM.MyClear();

            string sWhereClause = FiltrosComuns();

            String innerJoin = String.Empty;

            innerJoin = @" INNER JOIN dbo.DOCUMENTO_BALCAO as docBalcao ON docBalcao.ID = DOC_ID 
                                         INNER JOIN dbo.REMESSA_BALCAO as rem ON rem.ID = docBalcao.REMBALCAO_ID ";
            if (txtDeposito.Text != "")
                sWhereClause += " AND rem.REMBALCAO_SEQUENCIA = " + this.txtDeposito.Text;

            this.RefreshDocumentoACOM(String.Format(" {0} {1} {2} ", innerJoin, sWhereClause, FiltrosBotoesACOM()));

        }

        private void RefreshDocumentoACOM(string sWhereClause)
        {
            string sQuery = "select * from VW_PESQ_DOCUMENTO_ACOM " + sWhereClause + " order by FICH_DATA";

            SqlDataReader dr = null;
            try
            {
                dr = m_oParameters.DirectSqlDataReader(sQuery);
                while (dr.Read())
                {
                    AddDocumento2ListViewACOM(dr);
                }
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "RefreshDocumentoACOM()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (dr != null)
                {
                    dr.Close();
                }
                listViewPesquisaDocumentoACOM.EndUpdate();
                labelACOM.Text = listViewPesquisaDocumentoACOM.Items.Count.ToString() + " Registos em ACOM";
            }
        }

        private void AddDocumento2ListViewACOM(SqlDataReader dr)
        {
            PesquisaDocumentoACOM oPd = new PesquisaDocumentoACOM(dr);

            ListViewItem olvItem = oPd.MakeListViewItem(m_oParameters.DateFormat);

            olvItem.Tag = oPd;

            listViewPesquisaDocumentoACOM.Items.Add(olvItem);
        }


        private decimal GetDecimal(string str)
        {
            if (str.Trim().Length == 0) return 0;
            string s = Convert.ToString(1.2);
            if (s.IndexOf('.') > 0) { str = str.Replace(',', '.'); } else { str = str.Replace('.', ','); }
            decimal dValor = -1;
            if (!Decimal.TryParse(str, out dValor))
            {
                dValor = -1;
            }
            return dValor;
        }

        private string FiltrosBotoesACOM()
        {
            string sWhereClause = "";
            string sWhereStatus = "";


            if (sWhereStatus.Length > 0)
            {
                sWhereStatus = " and (" + sWhereStatus.Substring(3) + ")";
            }

            return sWhereClause + sWhereStatus;
        }

        private string FiltrosComuns()
        {
            string sWhereClause = "";
            sWhereClause = " Where (DATA between '" + m_ctrldtInicio.Value.ToString(m_oParameters.DateFormat) + "' and ";
            sWhereClause += "'" + m_ctrldtFim.Value.ToString(m_oParameters.DateFormat) + "' ";
            sWhereClause += "  or DATA2 between '" + m_ctrldtInicio.Value.ToString(m_oParameters.DateFormat) + "' and ";
            sWhereClause += "'" + m_ctrldtFim.Value.ToString(m_oParameters.DateFormat) + "') ";

            if (GetDecimal(textBoxBalcao.Text) > 0)
            {
                sWhereClause += " and BALCAO=" + textBoxBalcao.Text;
            }
            if (GetDecimal(textBoxNumCheque.Text) > 0)
            {
                sWhereClause += " and DOC_NCHEQUE='" + textBoxNumCheque.Text + "'";
            }

            if (GetDecimal(textBoxREFARQ.Text) > 0)
            {
                sWhereClause += "and (REFARQ='" + textBoxREFARQ.Text + "' or DOCACOM_REFARQ2='" + textBoxREFARQ.Text + "') ";
            }

            //validar
            sWhereClause += " and DOC_ORIGEM_ID=2 AND DOCACOM_CODANA = 3";

            return sWhereClause;
        }

        private void listViewPesquisaDocumentoACOM_DoubleClick(object sender, EventArgs e)
        {

        }

        private void CancelaACOMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
                return;
            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_ID;

                    Tibco.Insert_TibcoCancelaEnvioDocumento((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag, m_oParameters);

                    GenericLog.GenLogRegistarInfo("DocACOM Cancelado", "Insert_TibcoCancelaEnvioDocumento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Acolhimento dos documentos cancelado", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Insert_TibcoCancelaEnvioDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaACOM();
            }
        }

        private void confirmarCancelamentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
                return;
            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_ID;
                    Tibco.Confirma_TibcoCancelaEnvioDocumento(((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_CANCELADO, 0, m_oParameters);
                    GenericLog.GenLogRegistarInfo("Confirmado o Cancelamento DocACOM", "Update_ConfirmaTibcoCancelaEnvioDocumento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Confirmado o Cancelamento do Acolhimento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Confirma_TibcoCancelaEnvioDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaACOM();
            }
        }

        private void anulaCancelaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
                return;
            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_ID;
                    Tibco.Delete_TibcoCancelaEnvioDocumento(((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_CANCELADO, m_oParameters);
                    GenericLog.GenLogRegistarInfo("Anulado o Cancelamento DocACOM", "Delete_TibcoCancelaEnvioDocumento()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Anulado o Cancelamento do Acolhimento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Delete_TibcoCancelaChaveDocumento()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaACOM();
            }
        }

        private void NotificaACOMStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
                return;
            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_ID;
                    Tibco.Insert_TibcoNotificaEnvioDocumentoForaPrazo((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag, m_oParameters);
                    GenericLog.GenLogRegistarInfo("DocACOM Notificado", "Insert_TibcoNotificaEnvioDocumentoForaPrazo()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Notificação de envio de documentos fora de prazo para acolhimento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Insert_TibcoNotificaEnvioDocumentoForaPrazo()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaACOM();
            }
        }

        private void ConfirmaNotificaACOMStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
                return;
            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_ID;
                    Tibco.Confirma_TibcoNotificaEnvioDocumentoForaPrazo(((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_NOTIFICADO, m_oParameters);
                    GenericLog.GenLogRegistarInfo("DocACOM Notifica Confirma", "Confirma_TibcoNotificaEnvioDocumentoForaPrazo()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Confirma Notificação de envio de documentos fora de prazo para acolhimento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Confirma_TibcoNotificaEnvioDocumentoForaPrazo()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaACOM();
            }
        }

        private void AnulaNotificaACOMStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
                return;
            try
            {
                for (int i = 0; i < listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
                {
                    string sID = ((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_ID;
                    Tibco.Anula_TibcoNotificaEnvioDocumentoForaPrazo(((PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag).m_sDOCACOM_NOTIFICADO, m_oParameters);
                    GenericLog.GenLogRegistarInfo("DocACOM Notifica Anula", "Anula_TibcoNotificaEnvioDocumentoForaPrazo()", Convert.ToInt32(sID));
                }
                MessageBox.Show(this, "Anula Notificação de envio de documentos fora de prazo para acolhimento", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "Anula_TibcoNotificaEnvioDocumentoForaPrazo()", 1);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                RefreshListaACOM();
            }
        }

        private void EnabledMenuStripAcom(Boolean enabled)
        {
            this.CancelaACOMToolStripMenuItem.Enabled = enabled;
            this.confirmarCancelamentoToolStripMenuItem.Enabled = enabled;
            this.anulaCancelaToolStripMenuItem.Enabled = enabled;
            this.NotificaACOMStripMenuItem.Enabled = enabled;
            this.ConfirmaNotificaACOMStripMenuItem.Enabled = enabled;
            this.AnulaNotificaACOMStripMenuItem.Enabled = enabled;
        }
        #endregion

        #region Control Events
        #region Buttons
        private void buttonACOM_Click(object sender, EventArgs e)
        {
            RefreshListaACOM();
        }
        #endregion

        private void contextMenuStripACOM_Opening(object sender, CancelEventArgs e)
        {
            /*
             * SDCIM 7 - Mostrar opções de acordo com Origem
             */
            if (this.listViewPesquisaDocumentoACOM.SelectedItems.Count < 1)
            {
                e.Cancel = true;
                return;
            }
            EnabledMenuStripAcom(true);
            for (int i = 0; i < this.listViewPesquisaDocumentoACOM.SelectedItems.Count; i++)
            {
                PesquisaDocumentoACOM docAcom = (PesquisaDocumentoACOM)listViewPesquisaDocumentoACOM.SelectedItems[i].Tag;
                Int32 id = 0;
                Int32.TryParse(docAcom.m_sDocOrigemID, out id);
                if (!docAcom.m_sCANCELA_EFECTUADO.Equals("100"))
                {
                    //SDCIM 7 - Caso seja erro tem de ser possível anular. Estado < 0
                    if (!String.IsNullOrEmpty(docAcom.m_sCANCELA_EFECTUADO) && Convert.ToInt32(docAcom.m_sCANCELA_EFECTUADO) < 0)
                    {
                        this.anulaCancelaToolStripMenuItem.Enabled = true;
                    }
                    else
                    {
                        this.anulaCancelaToolStripMenuItem.Enabled = false;
                    }
                    this.confirmarCancelamentoToolStripMenuItem.Enabled = false;
                }
                else
                {
                    this.CancelaACOMToolStripMenuItem.Enabled = false;
                }
                if (!docAcom.m_sNOTIFICA_EFECTUADO.Equals("100"))
                {
                    //SDCIM 7 - Caso seja erro tem de ser possível anular. Estado < 0
                    if (!String.IsNullOrEmpty(docAcom.m_sNOTIFICA_EFECTUADO) && Convert.ToInt32(docAcom.m_sNOTIFICA_EFECTUADO) < 0)
                    {
                        this.AnulaNotificaACOMStripMenuItem.Enabled = true;
                    }
                    else
                    {
                        this.AnulaNotificaACOMStripMenuItem.Enabled = false;
                    }
                    this.ConfirmaNotificaACOMStripMenuItem.Enabled = false;
                }
                else
                {
                    this.NotificaACOMStripMenuItem.Enabled = false;
                }
                break;
            }
        }
        #endregion

        private void PesqFicheiroACOM_Leave(object sender, EventArgs e)
        {
            this._m_oMenuInterface.enablePesqFicheiroAcom(true);
            this.Dispose();
        }
    }
}