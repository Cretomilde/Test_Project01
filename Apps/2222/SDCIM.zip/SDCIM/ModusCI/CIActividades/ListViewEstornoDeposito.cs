﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CIActividades
{
    public class ListViewEstornoDeposito
    {
        public String m_cREM_PAIS;
        public Int16 m_iREM_BANCO;
        public Int16 m_iREM_BALCAO;
        public Int32 m_iDeposito; // REM_SEQUENCIA
        public Int32 m_Estado_ID;
        public String m_Estado;
        public DateTime m_dtREM_DATA;
        public String m_sREM_OPERADOR;
        //public String m_RemessaTipo;
        //public Int64 m_iRemessa; // [REM_NUMERO]

        private void InitVars()
        {
            m_cREM_PAIS = "";
            m_dtREM_DATA = DateTime.MinValue;
            m_sREM_OPERADOR = "";
            //m_RemessaTipo = "";
            m_Estado = "";
        }

        public ListViewEstornoDeposito(SqlDataReader dr)
        {
            InitVars();

            m_cREM_PAIS = Convert.ToString(dr["REM_PAIS"]);
            m_iREM_BANCO = Convert.ToInt16(dr["REM_BANCO"]);
            m_iREM_BALCAO = Convert.ToInt16(dr["REM_BALCAO"]);
            m_iDeposito = Convert.ToInt32(dr["REM_SEQUENCIA"]);
            this.m_Estado_ID = Convert.ToInt32(dr["STATUS_ID"]);
            m_Estado = Convert.ToString(dr["NM_SACO_STATUS"]);
            m_dtREM_DATA = Convert.ToDateTime(dr["REM_DATA"]);
            m_sREM_OPERADOR = Convert.ToString(dr["REM_OPERADOR"]);
            //m_RemessaTipo = Convert.ToString(dr["REM_TIPO_ID"]);
            //m_iRemessa = Convert.ToInt64(dr["REM_NUMERO"]);
        }

        public ListViewItem MakeListViewItem(string sDateFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_cREM_PAIS.ToString();
            olvItem.SubItems.Add(m_iREM_BANCO.ToString());
            olvItem.SubItems.Add(m_iREM_BALCAO.ToString("0000"));
            olvItem.SubItems.Add(m_iDeposito.ToString("0000000"));
            olvItem.SubItems.Add(m_Estado.ToString());
            olvItem.SubItems.Add(m_dtREM_DATA.ToString(sDateFormat));//sDateFormat
            olvItem.SubItems.Add(m_sREM_OPERADOR.ToString());
            //olvItem.SubItems.Add(m_iRemessa.ToString("000000"));
            //olvItem.SubItems.Add(m_RemessaTipo.ToString());

            return olvItem;
        }
    }
}
