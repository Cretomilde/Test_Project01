﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace CIActividades
{
    public class DetalhesDocumentoBalcao
    {
        public DateTime m_dtREMIN_DATA;
        public int m_iREMIN_BALCAO;
        public string m_sREMIN_NUMERO;
        public string m_sDOC_ID;
        public string m_sDOCORI_ID;
        public int m_iDOC_BALTOM;
        public string m_sDOC_INDEX;
        public string m_sDOC_DOCNIB;
        public int DOC_TIPO;

        private void InitVars()
        {
            m_dtREMIN_DATA = DateTime.MinValue;
            m_iREMIN_BALCAO = 0;
            m_sREMIN_NUMERO = "";
            m_sDOC_ID = "-1";
            m_sDOCORI_ID = "-1";
            m_iDOC_BALTOM = 0;
            m_sDOC_INDEX = "";
            m_sDOC_DOCNIB = "";
            DOC_TIPO = 0;
        }      

        public DetalhesDocumentoBalcao(DataRow oRow)
        {
            InitVars();

            try
            {
                m_dtREMIN_DATA = Convert.ToDateTime(oRow["REMIN_DATA"]); // ?!
                m_iREMIN_BALCAO = Convert.ToInt16(oRow["REMIN_BALCAO"]);
                m_sREMIN_NUMERO = Convert.ToString(oRow["REMIN_NUMERO"]);
                m_sDOC_ID = Convert.ToString(oRow["DOC_ID"]);
                m_sDOCORI_ID = Convert.ToString(oRow["DOCORI_ID"]); // ?!
                m_iDOC_BALTOM = Convert.ToInt16(oRow["DOCBALCAO_BALTOM"]);
                if (oRow["DOC_INDEX"] == DBNull.Value)
                {
                    m_sDOC_INDEX = String.Empty;
                }
                else
                {
                    m_sDOC_INDEX = Convert.ToString(oRow["DOC_INDEX"]);
                }
                //try { m_sDOC_INDEX = Convert.ToString(oRow["DOC_INDEX"]); } catch { }
                if (oRow["DOC_NIB"] == DBNull.Value)
                {
                    m_sDOC_DOCNIB = String.Empty;
                }
                else
                {
                    m_sDOC_DOCNIB = Convert.ToString(oRow["DOC_NIB"]);
                }
                //try { m_sDOC_DOCNIB = Convert.ToString(oRow["DOC_NIB"]); } catch { }
                DOC_TIPO = Convert.ToInt16(oRow["DOC_TIPO"]); 
            }
            catch
            {
            }
        } 
    }
}
