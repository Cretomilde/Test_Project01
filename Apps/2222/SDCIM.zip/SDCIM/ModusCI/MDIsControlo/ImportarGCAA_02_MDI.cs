﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace MDIsControlo
{
    public class ImportarGCAA_02_MDI
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;
        protected CIConfigGP.CIGlobalParameters m_oParametersGCAA;

        protected int m_iLastNSeqOperacao;
        protected int m_iCurrDepDoc;

        public MDIsControloForm m_oForm=null;

        public ImportarGCAA_02_MDI(CIConfigGP.CIGlobalParameters oParam, CIConfigGP.CIGlobalParameters oParamGCAA)
        {
            m_oParameters = oParam;
            m_oParametersGCAA = oParamGCAA;
        }

        public void InsertDocumento02(DataRow oRow)
        {
            Documento_02_MDI oDoc = new Documento_02_MDI(oRow, 2, false);
            oDoc.m_oForm = m_oForm;

            if (oDoc.m_iDEP_NSEQOPERACAO != m_iLastNSeqOperacao)
            {
                m_iLastNSeqOperacao = oDoc.m_iDEP_NSEQOPERACAO;
                m_iCurrDepDoc = 0;
            }
            oDoc.m_iDOC_NSEQ = ++m_iCurrDepDoc;

            oDoc.InsertDocumentoMDI02(m_oParameters, 2, false);
        }

        public void InsertDocumentoMDI(DataRow oRow, bool bImportarImagens)
        {
            Documento_02_MDI oDoc = new Documento_02_MDI(oRow, 1, false);
            oDoc.m_oForm = m_oForm;
            if (oDoc.m_iDEP_NSEQOPERACAO != m_iLastNSeqOperacao)
            {
                m_iLastNSeqOperacao = oDoc.m_iDEP_NSEQOPERACAO;
                m_iCurrDepDoc = 0;
            }
            oDoc.m_iDOC_NSEQ = ++m_iCurrDepDoc;

            //oDoc.InsertDocumentoMDI02(m_oParameters, 1, bImportarImagens);

            oDoc.WSInsertDocumentoMDI(m_oParameters, bImportarImagens);


        }

        protected string m_sQuery02;
        protected string m_sQueryMDI;

        protected string MakeQuery()
        {
            string sQuery = "";
            sQuery += "select ";
            sQuery += " CA_PAIS as CA_PAIS,";
            sQuery += " CA_BANCO as CA_BANCO,";
            sQuery += " CA_BALCAO as CA_BALCAO,";
            sQuery += " CA_NSEQ as CA_NUMERO,";
            sQuery += " CA_PULU as CA_IDDISPOSITIVO,";
            sQuery += " CA_ORGAO_GESTOR as CA_BALCAOGESTOR,";
            sQuery += " CADEPC_DATA as DEP_DATA,";
            sQuery += " CADEPC_MOVTIME as DEP_MOVTIME,";
            sQuery += " CAPCCD_NSESSAO as DEP_NSESSAO,";
            sQuery += " CAPCCD_NRECOLHA as DEP_NRECOLHA,";
            sQuery += " right(cast(dc.CADEPC_ID as varchar(64)),5) as DEP_NSEQOPERACAO,";
            sQuery += " dc.CADEPC_ID as DEPC_ID,";
            sQuery += " dr.CADEPR_ID as DEP_ID,";
            sQuery += " -1 as DEP_QTDOCS,";
            sQuery += " ADEP_ID as DEP_ESTADO,";
            sQuery += " CADEPC_MT_TOTAL as DEP_MONTANTE,";
            //sQuery += " -1*CADEPC_MT_TOTAL as DEP_MONTANTE,";
            sQuery += " right('0000' + cast(CADEPC_CONTA_BALCAO as varchar(4)),4) + CADEPC_CONTA_NUMERO + CADEPC_CONTA_TIPO as DEP_NUMCONTA,";
            sQuery += " '02' as DEP_APLICACAO,";
            sQuery += " CADEPR_STATUS as DEP_ESTADO_OPER,";
            sQuery += " 'N' as DOC_INDICADOR_REENVIO,";
            sQuery += " DOCFIS_ZON5 as DOC_LOZIB,";
            sQuery += " DOCFIS_ZON4 as DOC_LONCONTA,";
            sQuery += " DOCFIS_ZON3 as DOC_LONCHEQUE,";
            sQuery += " DOCFIS_IMPORT as DOC_LOMONTANTE,";
            sQuery += " DOCFIS_ZON1 as DOC_LOTIPO,";
            sQuery += " DOCFIS_ID as DOC_ID,";
            sQuery += " 1 as DOC_NSEQ,";
            sQuery += " DOCFIS_INDX as DOC_REFINDEX,";
            sQuery += " DOCFIS_STAT as DOC_ESTADO,";
            sQuery += " 'jpg' as DOC_TIPOIMAGEMFRENTE,";
            sQuery += " 'jpg' as DOC_TIPOIMAGEMVERSO,";
            sQuery += " '' as DOC_IMAGEMFRENTE,";
            sQuery += " '' as DOC_IMAGEMVERSO";
            sQuery += " from ca_deposito_recolha dr with (nolock)";
            sQuery += " inner join ca_deposito_central dc with (nolock) on dr.cadepc_id=dc.cadepc_id";
            sQuery += " inner join ca_periodo_contab_central_dep pc with (nolock) on pc.capccd_id=dc.capccd_id";
            sQuery += " inner join caixa_automatica ca with (nolock) on ca.ca_id=pc.ca_id";
            sQuery += " left outer join docfisico d with (nolock) on d.cadepr_id=dr.cadepr_id ";

            m_iLastNSeqOperacao=-1;
            m_iCurrDepDoc = 0;

            return sQuery;
        }

        public string MakeQueryMDI(string sWhereClause)
        {
            string sQuery = m_oParameters.GetProfileString("GCCA2CI", "QUERIE", "DOCUMENTOMDI", "");

            if (sQuery == "")
            {
                sQuery = MakeQuery();
            }
            sQuery += sWhereClause;

            sQuery += " ORDER BY dc.CADEPC_ID, DOCFIS_ID";

            m_sQuery02 = sQuery;

            return m_sQuery02;
        }
        public string MakeQuery02(string sWhereClause)
        {
            string sQuery = m_oParameters.GetProfileString("GCCA2CI", "QUERIE", "DOCUMENTO02", "");

            if (sQuery == "")
            {
                sQuery = MakeQuery();
            }
            sQuery += sWhereClause;

            sQuery += " ORDER BY dc.CADEPC_ID, DOCFIS_ID";

            m_sQuery02 = sQuery;

            return m_sQuery02;
        }
    }
}
