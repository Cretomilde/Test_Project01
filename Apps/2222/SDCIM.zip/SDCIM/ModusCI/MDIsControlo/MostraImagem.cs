﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;
using System.IO;

namespace MDIsControlo
{
    public partial class MostraImagem : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;

        string m_sDOCMDI_ID;

        public MostraImagem()
        {
            InitializeComponent();
        }

        public MostraImagem(CIConfigGP.CIGlobalParameters oParameters, string sDOCMDI_ID)
        {
            InitializeComponent();
            m_oParameters = oParameters;
            m_sDOCMDI_ID = sDOCMDI_ID;
        }

        protected void WriteImage(byte[] aBytes, string sFileName)
        {
            StreamWriter sw = new StreamWriter(sFileName, false);
            BinaryWriter bw = new BinaryWriter(sw.BaseStream);
            bw.Write(aBytes);
            sw.Close();
            bw.Close();
        }

        public string getImgFrente(CIConfigGP.CIGlobalParameters oParameters)
        {
            string sFileNameFrente, sWhereClauseFront;
            sWhereClauseFront = " where DOCMDI_ID= " + m_sDOCMDI_ID + " and IMG_SIDE = 0";// and IMG_TYPE= 'JPG'";
            byte[] aImgF = (byte[])oParameters.DirectSqlScalar("select top 1 IMG_IMAGE from dbo.IMAGEM" + sWhereClauseFront);

            sFileNameFrente = m_oParameters.GetTempFileName("IMGMDIFront") + ".jpg";
            WriteImage(aImgF, sFileNameFrente);

            return sFileNameFrente;

        }

        public string getImgBack(CIConfigGP.CIGlobalParameters oParameters)
        {
            string sFileNameFrente, sWhereClauseFront;
            sWhereClauseFront = " where DOCMDI_ID= " + m_sDOCMDI_ID + " and IMG_SIDE = 1 ";// and IMG_TYPE= 'JPG'";
            byte[] aImgF = (byte[])oParameters.DirectSqlScalar("select top 1 IMG_IMAGE from dbo.IMAGEM" + sWhereClauseFront);

            sFileNameFrente = m_oParameters.GetTempFileName("IMGMDIBack") + ".jpg";
            WriteImage(aImgF, sFileNameFrente);

            return sFileNameFrente;

        }

        private void MostraImagem_Load(object sender, EventArgs e)
        {
            string sFileName;
            try
            {
                //parte da frente
                sFileName = getImgFrente(m_oParameters);
                picImgFront.Image = System.Drawing.Image.FromFile(sFileName);
                picImgFront.SizeMode = PictureBoxSizeMode.StretchImage;

                //parte de tras
                sFileName = getImgBack(m_oParameters);
                pictImgBack.Image = System.Drawing.Image.FromFile(sFileName);
                pictImgBack.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "MDIMostraImagemForm", 11);
                labelErro.Visible = true;   
            }
        }

        private void MostraImagem_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                if (picImgFront.Image != null) picImgFront.Image.Dispose();
                if (pictImgBack.Image != null) pictImgBack.Image.Dispose();

                picImgFront.Image = null;
                pictImgBack.Image = null;
            }
            catch (Exception ex)
            {
                GenericLog.GenLogRegistarErro(ref ex, "MDIMostraImagemForm", 12);
                MessageBox.Show(this, ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
     }
}