﻿namespace MDIsControlo
{
    partial class MostraImagem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelErro = new System.Windows.Forms.Label();
            this.pictImgBack = new System.Windows.Forms.PictureBox();
            this.picImgFront = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictImgBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picImgFront)).BeginInit();
            this.SuspendLayout();
            // 
            // labelErro
            // 
            this.labelErro.AutoSize = true;
            this.labelErro.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelErro.ForeColor = System.Drawing.Color.Red;
            this.labelErro.Location = new System.Drawing.Point(75, 235);
            this.labelErro.Name = "labelErro";
            this.labelErro.Size = new System.Drawing.Size(454, 56);
            this.labelErro.TabIndex = 6;
            this.labelErro.Text = "ERRO NA IMAGEM";
            this.labelErro.Visible = false;
            // 
            // pictImgBack
            // 
            this.pictImgBack.Location = new System.Drawing.Point(55, 265);
            this.pictImgBack.Name = "pictImgBack";
            this.pictImgBack.Size = new System.Drawing.Size(489, 249);
            this.pictImgBack.TabIndex = 5;
            this.pictImgBack.TabStop = false;
            // 
            // picImgFront
            // 
            this.picImgFront.Location = new System.Drawing.Point(55, 10);
            this.picImgFront.Name = "picImgFront";
            this.picImgFront.Size = new System.Drawing.Size(489, 249);
            this.picImgFront.TabIndex = 4;
            this.picImgFront.TabStop = false;
            // 
            // MostraImagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 533);
            this.Controls.Add(this.labelErro);
            this.Controls.Add(this.pictImgBack);
            this.Controls.Add(this.picImgFront);
            this.Name = "MostraImagem";
            this.Text = "MostraImagem";
            this.Load += new System.EventHandler(this.MostraImagem_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MostraImagem_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pictImgBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picImgFront)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelErro;
        private System.Windows.Forms.PictureBox pictImgBack;
        private System.Windows.Forms.PictureBox picImgFront;
    }
}