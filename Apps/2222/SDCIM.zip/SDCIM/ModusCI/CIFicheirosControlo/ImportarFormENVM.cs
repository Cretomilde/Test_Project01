﻿using System;
using System.Collections.Generic;
using System.Text;
using CIFicheiro;

namespace CIFicheirosControlo
{
    class ImportarFormENVM : ImportarForm
    {
        public ImportarFormENVM(CIConfigGP.CIGlobalParameters oParameters, string sFileName)
            : base(oParameters, sFileName)
        {
            m_oFile = new CIFicheiro.FicheiroEnvm(this, oParameters);
        }

        //public override void ImportarFile(string sFileName)
        //{
        //    m_oFile.processaFile(sFileName);
        //}

    }
}
