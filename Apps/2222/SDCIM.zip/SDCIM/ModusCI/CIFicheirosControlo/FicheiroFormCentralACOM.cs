﻿using System;
using System.Data;
using System.Windows.Forms;

using NBiis;
using NBIISNET;

namespace CIFicheirosControlo
{
    public class FicheiroFormCentralACOM : FicheiroFormCentralENVM
    {

        private string m_sBalcao;

        public FicheiroFormCentralACOM(CIConfigGP.CIGlobalParameters oParameters, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
            : base (oParameters, oMenuInterface)
        {
            this.Text = "Importação de ACOM";
            m_sFichTipo = "2";
            
        }


        public override string getFich()
        {
            return "ACOM";
        }

        public override void disableMainMenu()
        {
            m_oMenuInterface.processaAcomEnable(false);
        }

        protected override void importarFicheiro()
        {
           
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "ACOM Files (" + m_oParameters.m_sSintaxFilesToImportACOM + ")|" + m_oParameters.m_sSintaxFilesToImportACOM + "|All Files (*.*)|*.*";
            openFileDialog.Title = "Escolha o Ficheiro";
           

            if (openFileDialog.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            this.m_sFicheiroNome = openFileDialog.FileName;

            string sSmg = "Inicio de carregamento do ficheiro ACOM: " + m_sFicheiroNome;
            GenericLog.GenLogRegistarAlerta(sSmg, "importarFicheiro()", 700);
            m_oParameters.EnviarAlertaSituacao(700, sSmg );
            ImportarFormACOM oImportarForm = new ImportarFormACOM(m_oParameters, m_sFicheiroNome);
            oImportarForm.ShowDialog(); 
        }

        public override void refreshListViewFich()
        {
            try
            {
                listViewFicheiro.MyClear();
                listViewLote.MyClear();
                listViewDetalhe.MyClear();
                string sQuery;
                ListViewImportFichAcom oListViewFichAcom;
                sQuery = getFichQuery();
                //DataSet ds = m_oParameters.DirectSqlDataSet(sQuery, "VW_IMPORT_FICHEIRO");
                DataSet ds = m_oParameters.DirectSqlDataSet(sQuery);
                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    oListViewFichAcom = new ListViewImportFichAcom(oRow, m_oParameters);

                    ListViewItem oItem = oListViewFichAcom.makeListViewFich(m_oParameters.DateSysFmt, m_oParameters.DateTimeSysFmt);

                    oItem.Tag = oListViewFichAcom;

                    listViewFicheiro.Items.Add(oItem);
                }
                ds.Dispose();
                labelFicheiros.Text = listViewFicheiro.Items.Count.ToString() + " Ficheiros";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public override void refreshListViewLote()
        {
            string sQuery;
            listViewLote.BeginUpdate();
            listViewLote.MyClear();
            listViewDetalhe.MyClear();

            ListViewImportFichAcom oListViewFichAcom = (ListViewImportFichAcom)listViewFicheiro.SelectedItems[0].Tag;

            sQuery = "select * from VW_IMPORT_LOTEACOM with (nolock) where fich_id = " + oListViewFichAcom.m_lFichID.ToString();

            if (this.cbOrigem.SelectedIndex > 0)
            {
                sQuery += " AND DOCACOM_ORIGEM_ID = " + this.cbOrigem.SelectedValue.ToString();
            }

            ListViewImportLoteAcom oListViewLoteAcom;

            DataSet ds = m_oParameters.DirectSqlDataSet(sQuery, "VW_IMPORT_LOTEACOM");

            foreach (DataRow oRow in ds.Tables[0].Rows)
            {
                oListViewLoteAcom = new ListViewImportLoteAcom(oRow, m_oParameters);
                ListViewItem oItem = oListViewLoteAcom.makeListViewLote(m_oParameters.DateSysFmt, m_oParameters.DateTimeSysFmt);
                oItem.Tag = oListViewLoteAcom;
                listViewLote.Items.Add(oItem);

            }
            ds.Dispose();
            labelLotes.Text = listViewLote.Items.Count.ToString() + " Lotes";
            listViewLote.EndUpdate();
        }

        public override void criaColunasLote()
        {
            listViewLote.Columns.Clear();
            listViewLote.Columns.Insert(0, "Lote ID", 60, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(1, "Fich ID", 60, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(2, "Lote Nr", 60, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(3, "Lote Status", 120, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(4, "Origem", 120, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(5, "Produto", 60, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(6, "Data Proc", 112, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(7, "Tot Reg", 60, HorizontalAlignment.Right);
            listViewLote.Columns.Insert(8, "Mont Total", 100, HorizontalAlignment.Right);
        }

        public override void refreshListViewDetalhe()
        {
            string sQuery;

            ListViewImportLoteAcom oListViewLoteAcom = (ListViewImportLoteAcom)listViewLote.SelectedItems[0].Tag;

            if (!GetBalcao(oListViewLoteAcom.m_lLoteId.ToString(), oListViewLoteAcom.m_OrigemID))
            {
                return;
            }

            try
            {
                Cursor = Cursors.WaitCursor;
                frmEspereUmMomento.ShowWaitForm();
                listViewDetalhe.BeginUpdate();
                listViewDetalhe.MyClear();

                sQuery = "select * from VW_IMPORT_DETACOM  with (nolock) where loteAcom_id = " + oListViewLoteAcom.m_lLoteId.ToString();
                sQuery += " and DOCACOM_BALCAO=" + m_sBalcao;
                if (this.cbOrigem.SelectedIndex > 0)
                {
                    sQuery += " AND DOCACOM_ORIGEM_ID = " + this.cbOrigem.SelectedValue.ToString();
                }
                ListViewImportDetAcom oListViewDetAcom;
                DataSet ds = m_oParameters.DirectSqlDataSet(sQuery, "VW_IMPORT_DETACOM");
                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    oListViewDetAcom = new ListViewImportDetAcom(oRow, m_oParameters);
                    ListViewItem oItem = oListViewDetAcom.makeListViewDet(m_oParameters.DateSysFmt, m_oParameters.DateTimeSysFmt);
                    oItem.Tag = oListViewDetAcom;
                    listViewDetalhe.Items.Add(oItem);
                }
                ds.Dispose();
                labelDetalhes.Text = listViewDetalhe.Items.Count.ToString() + " Documentos";
                listViewDetalhe.EndUpdate();
            }
            finally
            {
                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
        }

        private bool GetBalcao(string sLote, Int32 origem_id)
        {
            m_sBalcao = "";

            try
            {
                FormBalcao oForm = new FormBalcao(m_oParameters, sLote, origem_id);
                oForm.ShowDialog();

                m_sBalcao = oForm.Tag.ToString();
                if (m_sBalcao == "")
                {
                    return false;
                }
                return true;
            }
            catch 
            {
                return false;
            }
        }

        public override void criaColunasDetalhe()
        {
            listViewDetalhe.Columns.Clear();

            Int32 i = 0;
            listViewDetalhe.Columns.Insert(i++, "Doc Acom ID", 80, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Lote Id", 50, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Doc ID", 60, HorizontalAlignment.Center);
            //SDCIM 7 - Adição de coluna DOCACOM Origem
            listViewDetalhe.Columns.Insert(i++, "Origem", 60, HorizontalAlignment.Center);
            //SDCIM 7 - Adição de coluna DOCACOM Origem
            listViewDetalhe.Columns.Insert(i++, "Refarq", 100, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Refarq2", 100, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Balcao", 150, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Codana", 180, HorizontalAlignment.Left);
            listViewDetalhe.Columns.Insert(i++, "Import", 100, HorizontalAlignment.Right);
            listViewDetalhe.Columns.Insert(i++, "Linha opt", 212, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Chave H", 80, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Chave Hext", 50, HorizontalAlignment.Center);
        }

        public override string getQuery(ListViewImportFich oListViewFichAcom)
        {
            return "exec dbo.Delete_FicheiroACOM " + oListViewFichAcom.m_lFichID.ToString();
            
        }
    }
}