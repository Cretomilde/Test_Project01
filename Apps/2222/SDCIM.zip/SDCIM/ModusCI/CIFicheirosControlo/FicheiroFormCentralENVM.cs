﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using NBiis;
using NBiis.Generic;
using NBIISNET;
using System.Text;
namespace CIFicheirosControlo
{

    public partial class FicheiroFormCentralENVM : Form
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters; 
        public string m_sFichTipo;

        protected string m_sFicheiroNome;
        protected CIConfigGlobalParameters.CIMenuInterface m_oMenuInterface;

        /// <summary>
        /// E001212 - adicionado construtor por defeito para não dar erro ao visualizar form ACOM 
        /// </summary>
        public FicheiroFormCentralENVM()
        {

        }
        public FicheiroFormCentralENVM(CIConfigGP.CIGlobalParameters oParameters, CIConfigGlobalParameters.CIMenuInterface oMenuInterface)
        {
            m_oParameters = oParameters;
            InitializeComponent();
            m_oMenuInterface = oMenuInterface;
            this.Text = "Importação de ENVM";

            m_sFichTipo = "1";
            this.LoadCbOrigem();
            criaColunasLote();
            criaColunasDetalhe();

        }

        public virtual string getFich()
        {
            return "ENVM";
        }

        private void FicheiroFormCentral_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            //SUPFBKOFF 20 intervalo de dados por defeito passou a ser 1 dia.
            this.dateTimeDataIni.Value = DateTime.Now.Date;  //sdcim 7, passou de 15 para 1 por causa do número de registos 
            this.dateTimeDataEND.Value = DateTime.Now.Date;
            refreshListViewFich();
            desimportarToolStripMenuItem.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);
            buttonImportar.Enabled = (m_oParameters.UserLogged.m_iUserGroup <= 1);
            disableMainMenu();
        }

        public virtual void disableMainMenu()
        {
            m_oMenuInterface.processarEnvmEnable(false);
        }

        protected virtual void importarFicheiro()
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "ENVM Files (*" + m_oParameters.m_sSintaxFilesToImportENVM + ")|*" + m_oParameters.m_sSintaxFilesToImportENVM + "|All Files (*.*)|*.*";
            openFileDialog.Title = "Escolha o Ficheiro";

            if (openFileDialog.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            this.m_sFicheiroNome = openFileDialog.FileName;

            string sSmg = "Inicio de carregamento do ficheiro ENVM: " + m_sFicheiroNome;
            GenericLog.GenLogRegistarAlerta(sSmg, "importarFicheiro()", 700);
            m_oParameters.EnviarAlertaSituacao(700, sSmg);

            ImportarFormENVM oImportarForm = new ImportarFormENVM(m_oParameters, m_sFicheiroNome);
            oImportarForm.ShowDialog();

        }

        private void buttonImportar_Click(object sender, EventArgs e)
        {

            importarFicheiro();


            refreshListViewFich();
        }

        public virtual void refreshListViewFich()
        {
            try
            {
                listViewFicheiro.MyClear();
                listViewLote.MyClear();
                listViewDetalhe.MyClear();
                string sQuery;
                ListViewImportFichEnvm oListViewFichEnvm;
                sQuery = getFichQuery();
                //DataSet ds = m_oParameters.DirectSqlDataSet(sQuery, "VW_IMPORT_FICHEIRO");
                DataSet ds = m_oParameters.DirectSqlDataSet(sQuery);

                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    oListViewFichEnvm = new ListViewImportFichEnvm(oRow, m_oParameters);

                    ListViewItem oItem = oListViewFichEnvm.makeListViewFich(m_oParameters.DateSysFmt, m_oParameters.DateTimeSysFmt);

                    oItem.Tag = oListViewFichEnvm;

                    listViewFicheiro.Items.Add(oItem);
                }
                ds.Dispose();
                labelFicheiros.Text = listViewFicheiro.Items.Count.ToString() + " Ficheiros";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Método que retorna a query para preenchimento da lista de ficheiros
        /// </summary>
        /// <returns>string com query</returns>
        public virtual string getFichQuery()
        {
            StringBuilder sQuery = new StringBuilder();
            /*
             * porque exisitem para o meu tipo de ficheiro duas origem é necessário fazer disctint.
             * sQuery.Append(String.Format(@"SELECT [FICH_ID],[FICHTIPO_ID],[FICH_NOME],[FICH_BANCO],[FICH_NSEQ],[FICH_DATA],[FICH_REFCMP],[FICH_TOTREG],[FICH_MONTTOTAL],[FICH_FULLPATHNAME]
                         ,[FICH_ERRO],[FICH_STATUS],[FICH_ULTIMO],[FICHEIROSTAT_DESC],[FICHTIPO_ABR],[FICH_TIMER],[OrigemID],[REMORI_DESC] from VW_IMPORT_FICHEIRO where FICHTIPO_ID={0}", m_sFichTipo));
            */
            if (m_sFichTipo.Equals("1"))
            {
                sQuery.Append(String.Format(@"SELECT DISTINCT dbo.FICHEIRO.[FICH_ID],dbo.FICHEIRO.[FICHTIPO_ID],[FICH_NOME],[FICH_BANCO],
                                            [FICH_NSEQ],[FICH_DATA],[FICH_REFCMP],[FICH_TOTREG],[FICH_MONTTOTAL],[FICH_FULLPATHNAME],
                                            [FICH_ERRO],[FICH_STATUS],[FICH_ULTIMO],[FICHEIROSTAT_DESC],[FICHTIPO_ABR],[FICH_TIMER]   
                        FROM dbo.FICHEIRO WITH (nolock) INNER JOIN dbo.FICHEIRO_STATUS WITH (nolock) ON dbo.FICHEIRO.FICH_STATUS = dbo.FICHEIRO_STATUS.FICHEIROSTAT_ID
                            INNER JOIN dbo.FICHEIRO_TIPO WITH (nolock) ON dbo.FICHEIRO.FICHTIPO_ID = dbo.FICHEIRO_TIPO.FICHTIPO_ID 
                            INNER JOIN dbo.LOTE_ENVM AS envm WITH (nolock) ON envm.FICH_ID =  dbo.FICHEIRO.FICH_ID
                            INNER JOIN dbo.DOCUMENTO_ENVM AS docENVM WITH (nolock) ON envm.LOTEENV_ID = docENVM.LOTEENV_ID
                            INNER JOIN dbo.REMESSA_ORIGEM AS remOrigem WITH (nolock) ON remOrigem.REMORI_ID = docENVM.DOCENV_ORIGEM_ID WHERE dbo.FICHEIRO.FICHTIPO_ID={0}", m_sFichTipo));
            }
            else
            {
                sQuery.Append(String.Format(@"SELECT DISTINCT dbo.FICHEIRO.[FICH_ID],dbo.FICHEIRO.[FICHTIPO_ID],[FICH_NOME],[FICH_BANCO],
                                            [FICH_NSEQ],[FICH_DATA],[FICH_REFCMP],[FICH_TOTREG],[FICH_MONTTOTAL],[FICH_FULLPATHNAME],
                                            [FICH_ERRO],[FICH_STATUS],[FICH_ULTIMO],[FICHEIROSTAT_DESC],[FICHTIPO_ABR],[FICH_TIMER]
                        FROM dbo.FICHEIRO WITH (nolock) INNER JOIN dbo.FICHEIRO_STATUS WITH (nolock) ON dbo.FICHEIRO.FICH_STATUS = dbo.FICHEIRO_STATUS.FICHEIROSTAT_ID 
                            INNER JOIN dbo.FICHEIRO_TIPO WITH (nolock) ON dbo.FICHEIRO.FICHTIPO_ID = dbo.FICHEIRO_TIPO.FICHTIPO_ID 
                            INNER JOIN dbo.LOTE_ACOM AS acom WITH (nolock) ON acom.FICH_ID =  dbo.FICHEIRO.FICH_ID
                            INNER JOIN dbo.DOCUMENTO_ACOM AS docACOM WITH (nolock) ON acom.LOTEACOM_ID =  docACOM.LOTEACOM_ID
                            INNER JOIN dbo.REMESSA_ORIGEM AS remOrigem WITH (nolock) ON remOrigem.REMORI_ID = docACOM.DOCACOM_ORIGEM_ID WHERE dbo.FICHEIRO.FICHTIPO_ID={0}", m_sFichTipo));
            }
            if (this.cbOrigem.SelectedIndex > 0)
            {
                if (m_sFichTipo.Equals("1"))
                {
                    sQuery.Append(String.Format(" AND docENVM.DOCENV_ORIGEM_ID = {0}", this.cbOrigem.SelectedValue.ToString()));
                }
                else
                {
                    sQuery.Append(String.Format(" AND docACOM.DOCACOM_ORIGEM_ID = {0}", this.cbOrigem.SelectedValue.ToString()));
                }
            }
            sQuery.Append(String.Format(" and (FICH_DATA between '{0}' and '{1}'", dateTimeDataIni.Value.ToString(m_oParameters.DateSysFmt), dateTimeDataEND.Value.AddDays(+1).ToString(m_oParameters.DateSysFmt)));
            sQuery.Append(String.Format(" or FICH_TIMER between '{0}' and '{1}')", dateTimeDataIni.Value.ToString(m_oParameters.DateSysFmt), dateTimeDataEND.Value.AddDays(+1).ToString(m_oParameters.DateSysFmt)));
            sQuery.Append(" order by FICH_TIMER desc");
            return sQuery.ToString();
        }

        public virtual void refreshListViewLote()
        {

            string sQuery;
            listViewLote.BeginUpdate();
            listViewLote.MyClear();
            listViewDetalhe.MyClear();
            ListViewImportFichEnvm oListViewFichEnvm = (ListViewImportFichEnvm)listViewFicheiro.SelectedItems[0].Tag;
            sQuery = "select * from VW_IMPORT_LOTEENVM where fich_id = " + oListViewFichEnvm.m_lFichID.ToString();
            if (this.cbOrigem.SelectedIndex > 0)
            {
                sQuery += " AND DOCENV_ORIGEM_ID = " + this.cbOrigem.SelectedValue.ToString();
            }
            ListViewImportLoteEnvm oListViewLoteEnvm;
            DataSet ds = m_oParameters.DirectSqlDataSet(sQuery, "VW_IMPORT_LOTEENVM");
            foreach (DataRow oRow in ds.Tables[0].Rows)
            {
                oListViewLoteEnvm = new ListViewImportLoteEnvm(oRow, m_oParameters);
                ListViewItem oItem = oListViewLoteEnvm.makeListViewLote(m_oParameters.DateSysFmt, m_oParameters.DateTimeSysFmt);
                oItem.Tag = oListViewLoteEnvm;
                listViewLote.Items.Add(oItem);
            }
            ds.Dispose();
            labelLotes.Text = listViewLote.Items.Count.ToString() + " Lotes";
            listViewLote.EndUpdate();
        }

        private void listViewFicheiro_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                refreshListViewLote();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public virtual void criaColunasLote()
        {
            listViewLote.Columns.Clear();
            int i = 0;
            listViewLote.Columns.Insert(i++, "LoteID", 50, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "FichId", 50, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "LoteNr", 50, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "Origem", 70, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "Status", 70, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "Balcao", 150, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "ReminID", 60, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "Nr Rem", 70, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "Dt Rem", 70, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "Montante", 100, HorizontalAlignment.Right);
            listViewLote.Columns.Insert(i++, "TRem", 50, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "TCapt", 50, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "Docs", 50, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "Reg", 50, HorizontalAlignment.Right);
            listViewLote.Columns.Insert(i++, "Mont Total", 100, HorizontalAlignment.Right);
            listViewLote.Columns.Insert(i++, "CGD Error", 60, HorizontalAlignment.Left);
            listViewLote.Columns.Insert(i++, "Anomal", 100, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "Mont. Apurado", 100, HorizontalAlignment.Right);
            listViewLote.Columns.Insert(i++, "Chave H", 100, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "Chave Hext", 50, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "Val Req", 40, HorizontalAlignment.Center);
            listViewLote.Columns.Insert(i++, "Servadic", 40, HorizontalAlignment.Center);
        }

        private void listViewLote_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                //Cursor = Cursors.WaitCursor;
                //frmEspereUmMomento.ShowWaitForm();
                refreshListViewDetalhe();
            }
            catch (Exception ex)
            {
                //Cursor = Cursors.Default;
                //frmEspereUmMomento.HideWaitForm();
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //Cursor = Cursors.Default;
                //frmEspereUmMomento.HideWaitForm();
            }
        }

        public virtual void refreshListViewDetalhe()
        {
            try
            {
                Cursor = Cursors.WaitCursor;
                frmEspereUmMomento.ShowWaitForm();
                string sQuery;
                listViewDetalhe.BeginUpdate();
                listViewDetalhe.MyClear();


                ListViewImportLoteEnvm oListViewLoteEnvm = (ListViewImportLoteEnvm)listViewLote.SelectedItems[0].Tag;

                sQuery = "select * from VW_IMPORT_DETENVM where loteenv_id = " + oListViewLoteEnvm.m_lLoteId.ToString();

                if (this.cbOrigem.SelectedIndex > 0)
                {
                    sQuery += " AND DOCENV_ORIGEM_ID = " + this.cbOrigem.SelectedValue.ToString();
                }

                ListViewImportDetEnvm oListViewDetEnvm;

                DataSet ds = m_oParameters.DirectSqlDataSet(sQuery, "VW_IMPORT_DETENVM");

                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    oListViewDetEnvm = new ListViewImportDetEnvm(oRow, m_oParameters);

                    ListViewItem oItem = oListViewDetEnvm.makeListViewDet(m_oParameters.DateSysFmt, m_oParameters.DateTimeSysFmt);
                    oItem.Tag = oListViewDetEnvm;

                    listViewDetalhe.Items.Add(oItem);

                }
                ds.Dispose();
                labelDetalhes.Text = listViewDetalhe.Items.Count.ToString() + " Documentos";
                listViewDetalhe.EndUpdate();

            }
            finally
            {
                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
        }

        public virtual void criaColunasDetalhe()
        {
            listViewDetalhe.Columns.Clear();
            int i = 0;
            listViewDetalhe.Columns.Insert(i++, "Doc Envm ID", 80, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Lote Id", 50, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Doc ID", 60, HorizontalAlignment.Center);
            //SDCIM 7 - Adição de coluna DOCENVM Origem 
            listViewDetalhe.Columns.Insert(i++, "Origem", 60, HorizontalAlignment.Left);
            //SDCIM 7 - Adição de coluna DOCENVM Origem 
            listViewDetalhe.Columns.Insert(i++, "Zona 5", 100, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Zona 4", 100, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Zona 3", 100, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Zona 2", 100, HorizontalAlignment.Right);
            listViewDetalhe.Columns.Insert(i++, "Zona 1", 60, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Refarq", 112, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Anomal", 190, HorizontalAlignment.Left);
            listViewDetalhe.Columns.Insert(i++, "Duplicado", 60, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Codana", 80, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Req Doc", 60, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Servadic", 60, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Img Qual", 60, HorizontalAlignment.Center);
            listViewDetalhe.Columns.Insert(i++, "Chave H", 100, HorizontalAlignment.Left);
            listViewDetalhe.Columns.Insert(i++, "Chave Hext", 50, HorizontalAlignment.Left);

        }

        private void btRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                refreshListViewFich();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void desimportarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listViewFicheiro.SelectedItems.Count != 1)
                return;

            desimportar();
        }

        public virtual string getQuery(ListViewImportFich oListViewFichEnvm)
        {
            return "exec dbo.Delete_FicheiroENVM " + oListViewFichEnvm.m_lFichID.ToString();
        }

        private void desimportar()
        {

            ListViewImportFich oListViewFich = (ListViewImportFich)listViewFicheiro.SelectedItems[0].Tag;
            try
            {

                if (MessageBox.Show("Tem a certeza que deseja desimportar o ficheiro?", Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    m_oParameters.DirectSqlNonQuery(getQuery(oListViewFich));

                    string sSmg = "Ficheiro ID: " + oListViewFich.m_lFichID.ToString() + " " + oListViewFich.getTipoFich() + " - " + oListViewFich.m_sFullPath + " desimportado ";
                    GenericLog.GenLogRegistarAlerta(sSmg, "DesimportarFicheiro()", 700);
                    m_oParameters.EnviarAlertaSituacao(700, sSmg);

                }
                refreshListViewFich();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void contextMenuStripMudarEstadoFich_Opening(object sender, CancelEventArgs e)
        {
            if (listViewFicheiro.SelectedItems.Count == 0)
            {
                contextMenuStripMudarEstadoFich.Enabled = false;
            }
            else
            {
                contextMenuStripMudarEstadoFich.Enabled = true;
            }
        }

        private void buttonExitJanela_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void associarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewImportFich oListViewFich = (ListViewImportFich)listViewFicheiro.SelectedItems[0].Tag;

            string sCmd = "exec dbo.Update_ActualizarAutoAssociarFicheiro " + oListViewFich.m_lFichID.ToString();
            try
            {
                Cursor = Cursors.WaitCursor;
                frmEspereUmMomento.ShowWaitForm();

                m_oParameters.DirectSqlNonQuery(sCmd);
                GenericLog.GenLogRegistarAlerta(sCmd, "AssociarFicheiro()", 700);
                m_oParameters.EnviarAlertaSituacao(700, sCmd);
                refreshListViewFich();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
        }

        private void LoadCbOrigem()
        {
            try
            {
                string strQuery = "SELECT  [REMORI_ID],[REMORI_ABR] FROM [dbo].[REMESSA_ORIGEM] WHERE I_VISIVEL = 'TRUE' ORDER BY [REMORI_ABR] ASC";
                DataSet ds = m_oParameters.DirectSqlDataSet(strQuery, "REMESSA_ORIGEM");
                List<ComboBoxItem> items = new List<ComboBoxItem>();
                items.Add(new ComboBoxItem
                {
                    ISelected = true,
                    Text = "Todos",
                    Value = "0"
                });
                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    ComboBoxItem item = new ComboBoxItem
                    {
                        ISelected = false,
                        Text = oRow["REMORI_ABR"].ToString(),
                        Value = oRow["REMORI_ID"].ToString()
                    };
                    items.Add(item);
                }
                ds.Dispose();
                this.cbOrigem.DataSource = items;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
                frmEspereUmMomento.HideWaitForm();
            }
        }

        private void listViewDetalhe_DoubleClick(object sender, EventArgs e)
        {
            ListViewImportDet detalhe = (ListViewImportDet)listViewDetalhe.SelectedItems[0].Tag;
            if (detalhe.m_lDocID > 0)
            {
                MostraImagem form = new MostraImagem(this.m_oParameters, detalhe.m_lDocID, detalhe.m_iDocOrigemID);
                form.ShowDialog();
            }
            else
                MessageBox.Show(this, "Documento não associado", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
