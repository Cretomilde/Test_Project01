﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Text;

namespace CIFicheirosControlo
{
    public partial class FormBalcao : Form
    {
        protected string m_sLOTEACOM_ID;
        protected Int32 m_origem_id;
        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public FormBalcao(CIConfigGP.CIGlobalParameters oParameters, string sLOTEACOM_ID, Int32 origem_id)
        {
            InitializeComponent();
            m_sLOTEACOM_ID = sLOTEACOM_ID;
            m_oParameters = oParameters;
            this.m_origem_id = origem_id;
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Tag = "";
            Dispose();
        }

        private void RefreshListViewBalcoes()
        {
            try
            {
                string sQt;
                decimal dMt;
                string sBalcao;

                listViewResumoLote.MyClear();
                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("select * from  VW_DOCACOM_RESUMO_BALCAO where loteacom_id = " + m_sLOTEACOM_ID);
                strQuery.Append(" AND DOCACOM_ORIGEM_ID = " + this.m_origem_id.ToString());
                if (this.txBalcao.Text.Length > 0)
                {
                    strQuery.Append(" AND DOCACOM_BALCAO = " + txBalcao.Text);
                }
                strQuery.Append(" order by DOCACOM_BALCAO");
                DataSet ds = m_oParameters.DirectSqlDataSet(strQuery.ToString(), "VW_DOCACOM_RESUMO_BALCAO");

                foreach (DataRow oRow in ds.Tables[0].Rows)
                {
                    sBalcao = oRow["DOCACOM_BALCAO"].ToString().PadLeft(4, '0');
                    sQt = oRow["DOCACOM_QT"].ToString();
                    dMt = Convert.ToDecimal(oRow["DOCACOM_IMPORT"]);
                    ListViewItem oItem = new ListViewItem();
                    oItem.Tag = sBalcao;
                    oItem.Text = sBalcao;
                    oItem.SubItems.Add(sQt.PadLeft(6, ' '));
                    string montanteToInsert = dMt.ToString().Equals("0") ? dMt.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(dMt).PadLeft(16, ' ');
                    //oItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(dMt).PadLeft(16, ' '));
                    oItem.SubItems.Add(montanteToInsert);
                    listViewResumoLote.Items.Add(oItem);
                }
                ds.Dispose();
                labelBalcoes.Text = listViewResumoLote.Items.Count.ToString() + " Balcões";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormBalcao_Load(object sender, EventArgs e)
        {
            RefreshListViewBalcoes();
        }


        protected void ProcessaOK()
        {
            this.Tag = "";
            try
            {
                if (listViewResumoLote.SelectedItems.Count != 1)
                {
                    return;
                }
                this.Tag = listViewResumoLote.SelectedItems[0].Tag.ToString();
                Dispose();
            }
            catch
            {
                return;
            }
        }

        private void txBalcao_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txBalcao.Text, "[^0-9]"))
            {
                MessageBox.Show("Campo numérico");
                txBalcao.Text.Remove(txBalcao.Text.Length - 1);
                txBalcao.Text = "";
            }

            if (txBalcao.Text.Length >= 4)
            {
                txBalcao.MaxLength = 4;
            }
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            this.FormatarTxtBalcao();
            RefreshListViewBalcoes();
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            ProcessaOK();
        }

        private void listViewResumoLote_MouseDoubleClick_1(object sender, MouseEventArgs e)
        {
            ProcessaOK();
        }

        private void txBalcao_Leave(object sender, EventArgs e)
        {
            this.FormatarTxtBalcao();
        }

        private void FormatarTxtBalcao()
        {
            txBalcao.Text = txBalcao.Text.Trim().PadLeft(4, '0');
        }
    }
}