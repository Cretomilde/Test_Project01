﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CIFicheirosControlo
{
    class ImportarFormACOM : ImportarForm
    {
        public ImportarFormACOM(CIConfigGP.CIGlobalParameters oParameters, string sFileName)
            : base(oParameters, sFileName)
        {
            m_oFile = new CIFicheiro.FicheiroAcom(this, oParameters);
        }
         

        //public override void ImportarFile(string sFileName)
        //{
        //    m_oFile.processaFile(sFileName);
        //}

    }
}
