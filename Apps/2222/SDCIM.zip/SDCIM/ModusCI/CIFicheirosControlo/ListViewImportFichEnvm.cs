﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIFicheirosControlo
{
    public class ListViewImportFichEnvm : ListViewImportFich
    {

        public ListViewImportFichEnvm(DataRow oRow, CIConfigGP.CIGlobalParameters oParameters)
            :base(oRow, oParameters)
        {
        }

        public override string getTipoFich()
        {
            return "ENVM";
        }
    }
}
