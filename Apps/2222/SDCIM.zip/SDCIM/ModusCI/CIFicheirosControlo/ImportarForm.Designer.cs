﻿using CIConfigGlobalParameters;

namespace CIFicheirosControlo
{
    partial class ImportarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ImportarForm));
            this.ColumnTimer = new System.Windows.Forms.ColumnHeader();
            this.ColumnDescricao = new System.Windows.Forms.ColumnHeader();
            this.edCounter = new System.Windows.Forms.TextBox();
            this.btParar = new System.Windows.Forms.Button();
            this.listViewMsgImportar = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.SuspendLayout();
            // 
            // ColumnTimer
            // 
            this.ColumnTimer.Text = "Timer";
            this.ColumnTimer.Width = 80;
            // 
            // ColumnDescricao
            // 
            this.ColumnDescricao.Text = "Descrição";
            this.ColumnDescricao.Width = 350;
            // 
            // edCounter
            // 
            this.edCounter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.edCounter.Enabled = false;
            this.edCounter.Location = new System.Drawing.Point(148, 12);
            this.edCounter.Name = "edCounter";
            this.edCounter.Size = new System.Drawing.Size(176, 20);
            this.edCounter.TabIndex = 13;
            this.edCounter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btParar
            // 
            this.btParar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btParar.Location = new System.Drawing.Point(16, 220);
            this.btParar.Name = "btParar";
            this.btParar.Size = new System.Drawing.Size(456, 24);
            this.btParar.TabIndex = 8;
            this.btParar.Text = "&Parar / Sair";
            this.btParar.Click += new System.EventHandler(this.btParar_Click);
            // 
            // listViewMsgImportar
            // 
            this.listViewMsgImportar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewMsgImportar.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listViewMsgImportar.GridLines = true;
            this.listViewMsgImportar.Location = new System.Drawing.Point(16, 48);
            this.listViewMsgImportar.Name = "listViewMsgImportar";
            this.listViewMsgImportar.Size = new System.Drawing.Size(456, 160);
            this.listViewMsgImportar.TabIndex = 14;
            this.listViewMsgImportar.UseCompatibleStateImageBehavior = false;
            this.listViewMsgImportar.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Timer";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Mensagem";
            this.columnHeader2.Width = 389;
            // 
            // ImportarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(496, 256);
            this.Controls.Add(this.listViewMsgImportar);
            this.Controls.Add(this.edCounter);
            this.Controls.Add(this.btParar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ImportarForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ImportarForm";
            this.Activated += new System.EventHandler(this.ImportarForm_Activated);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.ColumnHeader ColumnTimer;
        internal System.Windows.Forms.ColumnHeader ColumnDescricao;
        internal System.Windows.Forms.TextBox edCounter;
        internal System.Windows.Forms.Button btParar;
        private System.Windows.Forms.ListView listViewMsgImportar;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
    }
}