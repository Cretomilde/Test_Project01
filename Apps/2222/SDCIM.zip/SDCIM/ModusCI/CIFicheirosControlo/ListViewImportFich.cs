﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIFicheirosControlo
{
    public abstract class ListViewImportFich
    {
        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public string m_sFich_nome;
        public int m_iFich_banco;
        public int m_iFich_nseq;
        public DateTime m_dtFich_data;
        public string m_sFich_refcmp;
        public int m_iFich_totreg;
        public double m_dFich_monttotal;
        public int m_iFich_ultimo;
        public DateTime m_dtFich_timer;

        public long m_lFichID;
        public int m_iFichTipo;
        public int m_iFichStatus;
        public string m_sFichStatusDesc;
        public string m_sFullPath;
        public string m_sErro;

        //public abstract ListViewItem makeListViewFich(string sDateFormat, string sDateTimeFormat);
        public abstract string getTipoFich();
        
        public ListViewImportFich()
        {
            m_lFichID = 0;
            m_iFichTipo = 0;
            m_iFichStatus = 0;
            m_sFichStatusDesc = "";
            m_sFullPath = "";
            m_sErro = "";
            
            this.m_oParameters = null;
        }
        public ListViewImportFich(DataRow oRow, CIConfigGP.CIGlobalParameters oParameters)
        {
            this.m_oParameters = oParameters;

            m_lFichID = Convert.ToInt64(oRow["FICH_ID"]);
            m_iFichTipo = Convert.ToInt16(oRow["FICHTIPO_ID"]);
            m_iFichStatus = Convert.ToInt16(oRow["FICH_STATUS"]);
            m_sFichStatusDesc = oRow["FICHEIROSTAT_DESC"].ToString();
            m_sFich_nome = oRow["FICH_NOME"].ToString();
            m_iFich_banco = Convert.ToInt16(oRow["FICH_BANCO"]);
            m_iFich_nseq = Convert.ToInt16(oRow["FICH_NSEQ"]);
            m_dtFich_data = Convert.ToDateTime(oRow["FICH_DATA"]);
            m_sFich_refcmp = oRow["FICH_REFCMP"].ToString();
            m_iFich_totreg = Convert.ToInt32(oRow["FICH_TOTREG"]);
            m_dFich_monttotal = Convert.ToDouble(oRow["FICH_MONTTOTAL"]);
            m_iFich_ultimo = Convert.ToInt16(oRow["FICH_ULTIMO"]);
            m_dtFich_timer = Convert.ToDateTime(oRow["FICH_TIMER"]);
            m_sFullPath = oRow["FICH_FULLPATHNAME"].ToString();
            m_sErro = oRow["FICH_ERRO"].ToString();

        }

        public ListViewItem makeListViewFich(string sDateFormat, string sDateTimeFormat)
        {
            ListViewItem olvItem = new ListViewItem();

            olvItem.Text = m_lFichID.ToString();
            olvItem.SubItems.Add(m_iFichTipo.ToString());
            olvItem.SubItems.Add(m_sFich_nome);
            olvItem.SubItems.Add(m_iFichStatus.ToString() + " " + m_sFichStatusDesc);
            olvItem.SubItems.Add(m_dtFich_data.ToString());//falta converter
            olvItem.SubItems.Add(m_iFich_nseq.ToString());
            olvItem.SubItems.Add(m_iFich_banco.ToString());
            olvItem.SubItems.Add(m_sFich_refcmp);
            olvItem.SubItems.Add(m_iFich_totreg.ToString());
            string montanteToInsert = m_dFich_monttotal.ToString().Equals("0") ? m_dFich_monttotal.ToString("0.00") : NBiis.Generic.GenericFunctions.ToMoney(m_dFich_monttotal).PadLeft(16, ' ');
            //olvItem.SubItems.Add(NBiis.Generic.GenericFunctions.ToMoney(m_dFich_monttotal).PadLeft(16, ' '));
            olvItem.SubItems.Add(montanteToInsert);
            olvItem.SubItems.Add(m_iFich_ultimo.ToString());
            olvItem.SubItems.Add(m_dtFich_timer.ToString());//falta converter
            olvItem.SubItems.Add(m_sFullPath);
            olvItem.SubItems.Add(m_sErro);
            return olvItem;
        }


    }
}
