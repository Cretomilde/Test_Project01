﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIServTester
{
    public partial class ProcessarRemessas : CIComumInterface
    {
        public void ErrorMessage(string sMessage)
        {
            MessageBox.Show("ProcessarRemessas Error: " + sMessage);
        }
        public void WarningMessage(string sMessage)
        {
            MessageBox.Show("ProcessarRemessas Warning: " + sMessage);
        }
        public void InfoMessage(string sMessage, string sHeader)
        {
            MessageBox.Show("ProcessarRemessas Info: " + sMessage);
        }
        public void InfoMessageCount(string sMessage)
        {
        }

        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public ProcessarRemessas(CIConfigGP.CIGlobalParameters oParameters)
        {
            m_oParameters = oParameters;

            CIServRemessas.ServRemessa oRem = new CIServRemessas.ServRemessa(this, m_oParameters);

            string sREMIN_ID = oRem.REMIN_IDParaProcessar();

            if (sREMIN_ID.Length != 0)
            {
                GenericLog.GenLogRegistarInfo("Inicio ProcessaRemessa: " + sREMIN_ID, "ProcessarRemessas", 45);
                oRem.ProcessaRemessa(sREMIN_ID);
                GenericLog.GenLogRegistarInfo("Fim ProcessaRemessa: " + sREMIN_ID, "ProcessarRemessas", 46);
            }
        }
    }
}
