﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

using NBiis;
using NBiis.Generic;
using NBIISNET;
using CIConfigGlobalParameters;

namespace CIServTester
{
    public partial class ProcessarRemessasBalcao : CIComumInterface
    {
        public void ErrorMessage(string sMessage)
        {
            MessageBox.Show("ProcessarRemessas Error: " + sMessage);
        }
        public void WarningMessage(string sMessage)
        {
            MessageBox.Show("ProcessarRemessas Warning: " + sMessage);
        }
        public void InfoMessage(string sMessage, string sHeader)
        {
            MessageBox.Show("ProcessarRemessas Info: " + sMessage);
        }
        public void InfoMessageCount(string sMessage)
        {
        }

        protected CIConfigGP.CIGlobalParameters m_oParameters;

        public ProcessarRemessasBalcao(CIConfigGP.CIGlobalParameters oParameters)
        {
            m_oParameters = oParameters;

            CIServRemessas.ServRemessa oRem = new CIServRemessas.ServRemessa(this, m_oParameters);

            Int64? sREMIN_ID = oRem.RemessaBalcaoParaProcessar();

            if (sREMIN_ID.HasValue)
            {
                GenericLog.GenLogRegistarInfo("Inicio ProcessaRemessaBalcao: " + sREMIN_ID.Value.ToString(), "ProcessaRemessaBalcao", 45);
                oRem.TratarTranchesBalcao(sREMIN_ID.Value);
                GenericLog.GenLogRegistarInfo("Fim ProcessaRemessaBalcao: " + sREMIN_ID.Value.ToString(), "ProcessaRemessaBalcao", 46);
            }
        }
    }
}
