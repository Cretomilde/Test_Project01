$files = Get-ChildItem -Path $PSScriptRoot -Recurse -Include "*.cs", "*.vb"
Write-Output "File|LinesOfCode|KeywordCount"
foreach ($file in $files) {
    if ($file.Name -eq 'metrics.ps1') { continue }
    try {
        $content = Get-Content -Path $file.FullName -Raw -ErrorAction Stop
        $loc = $content.Split([Environment]::NewLine).Count
        
        $complexity = 0
        if ($file.Extension -eq ".cs") {
            # Keywords for complexity
            $pattern = 'if|while|for|foreach|case|catch|&&|\|\||\?\?'
            $complexity += ([regex]::Matches($content, $pattern)).Count
        } elseif ($file.Extension -eq ".vb") {
            # VB is case-insensitive for keywords
            $pattern = 'If|While|For|ForEach|Case|Catch|AndAlso|OrElse|Select Case'
            $complexity += ([regex]::Matches($content, $pattern, 'IgnoreCase')).Count
        }
        
        Write-Output "$($file.Name)|$loc|$complexity"
    } catch {
        Write-Output "$($file.Name)|Error|Error"
    }
}
